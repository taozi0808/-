/**
 * Rest layer visual models.
 */
package com.daitoj.tkms.web.rest.vm;
