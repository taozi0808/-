/**
 * Rest layer error handling.
 */
package com.daitoj.tkms.web.rest.errors;
