/**
 * Application management.
 */
package com.daitoj.tkms.management;
