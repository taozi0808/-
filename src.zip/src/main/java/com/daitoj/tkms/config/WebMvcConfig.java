package com.daitoj.tkms.config;

import com.daitoj.tkms.modules.common.interceptor.PositionInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** WebMvcConfigurer */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

  /** リクエストパラメータチエックインターセプター */
  private final PositionInterceptor positionInterceptor;

  /** コンストラクタ */
  public WebMvcConfig(PositionInterceptor positionInterceptor) {
    this.positionInterceptor = positionInterceptor;
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {

    registry
        .addInterceptor(positionInterceptor)
        .addPathPatterns("/api/**") // チエックするAPI
        .excludePathPatterns("/api/v1/login/auth"); // チエックしない
  }
}
