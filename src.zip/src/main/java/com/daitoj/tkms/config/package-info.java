/**
 * Application configuration.
 */
package com.daitoj.tkms.config;
