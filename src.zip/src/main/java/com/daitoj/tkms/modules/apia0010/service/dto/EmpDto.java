package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** 従業員情報 */
@Schema(name = "EmpDto", description = "従業員情報")
public class EmpDto {
  /** 従業員コード */
  @Schema(description = "従業員コード")
  private String empCd;

  /** 従業員氏 */
  @Schema(description = "従業員氏")
  private String empShi;

  /** 従業員名 */
  @Schema(description = "従業員名")
  private String empMei;

  /** 従業員氏名 */
  @Schema(description = "従業員氏名")
  private String empShimei;

  /** メールアドレス */
  @Schema(description = "メールアドレス")
  private String mailAddress;

  /** 所属事業所コード */
  @Schema(description = "所属事業所コード")
  private String belongOfficeCd;

  /** 役職コード */
  @Schema(description = "役職コード")
  private String positionCd;

  /** 入社年月日 */
  @Schema(description = "入社年月日")
  private String employmentYmd;

  /** 退職年月日 */
  @Schema(description = "退職年月日")
  private String terminationYmd;

  public String getEmpCd() {
    return empCd;
  }

  public void setEmpCd(String empCd) {
    this.empCd = empCd;
  }

  public String getEmpShi() {
    return empShi;
  }

  public void setEmpShi(String empShi) {
    this.empShi = empShi;
  }

  public String getEmpMei() {
    return empMei;
  }

  public void setEmpMei(String empMei) {
    this.empMei = empMei;
  }

  public String getEmpShimei() {
    return empShimei;
  }

  public void setEmpShimei(String empShimei) {
    this.empShimei = empShimei;
  }

  public String getMailAddress() {
    return mailAddress;
  }

  public void setMailAddress(String mailAddress) {
    this.mailAddress = mailAddress;
  }

  public String getBelongOfficeCd() {
    return belongOfficeCd;
  }

  public void setBelongOfficeCd(String belongOfficeCd) {
    this.belongOfficeCd = belongOfficeCd;
  }

  public String getPositionCd() {
    return positionCd;
  }

  public void setPositionCd(String positionCd) {
    this.positionCd = positionCd;
  }

  public String getEmploymentYmd() {
    return employmentYmd;
  }

  public void setEmploymentYmd(String employmentYmd) {
    this.employmentYmd = employmentYmd;
  }

  public String getTerminationYmd() {
    return terminationYmd;
  }

  public void setTerminationYmd(String terminationYmd) {
    this.terminationYmd = terminationYmd;
  }
}
