package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.MEmp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** 従業員情報リポジトリ */
@Repository
public interface MEmpRepository extends JpaRepository<MEmp, String> {
  /**
   * 従業員情報を取得する
   *
   * @param loginId ユーザーID
   * @param delFlg 削除フラグ
   * @return 従業員情報
   */
  MEmp findByLoginIdAndDelFlg(String loginId, String delFlg);
}
