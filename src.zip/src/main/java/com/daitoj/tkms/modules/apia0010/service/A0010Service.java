package com.daitoj.tkms.modules.apia0010.service;

import com.daitoj.tkms.domain.MEmp;
import com.daitoj.tkms.domain.MMenuItem;
import com.daitoj.tkms.domain.MPosition;
import com.daitoj.tkms.domain.MSystemConfig;
import com.daitoj.tkms.domain.MVendorHdr;
import com.daitoj.tkms.domain.MWorker;
import com.daitoj.tkms.domain.TNotification;
import com.daitoj.tkms.domain.TPartnerNotification;
import com.daitoj.tkms.modules.apia0010.repository.A0010S01Repository;
import com.daitoj.tkms.modules.apia0010.repository.A0010S02Repository;
import com.daitoj.tkms.modules.apia0010.repository.mapper.A0010Mapper;
import com.daitoj.tkms.modules.apia0010.service.dto.A0010ReturnData;
import com.daitoj.tkms.modules.apia0010.service.dto.EmpDto;
import com.daitoj.tkms.modules.apia0010.service.dto.MenuItemDto;
import com.daitoj.tkms.modules.apia0010.service.dto.NotificationDto;
import com.daitoj.tkms.modules.apia0010.service.dto.PartnerNotificationDto;
import com.daitoj.tkms.modules.apia0010.service.dto.PositionDto;
import com.daitoj.tkms.modules.apia0010.service.dto.VendorHdrDto;
import com.daitoj.tkms.modules.apia0010.service.dto.WorkerDto;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.constants.Message;
import com.daitoj.tkms.modules.common.constants.SystemConfig;
import com.daitoj.tkms.modules.common.repository.MEmpRepository;
import com.daitoj.tkms.modules.common.repository.MMenuItemRepository;
import com.daitoj.tkms.modules.common.repository.MPositionRepository;
import com.daitoj.tkms.modules.common.repository.MSystemConfigRepository;
import com.daitoj.tkms.modules.common.repository.MVendorHdrRepository;
import com.daitoj.tkms.modules.common.repository.TNotificationRepository;
import com.daitoj.tkms.modules.common.repository.TPartnerNotificationRepository;
import com.daitoj.tkms.modules.common.service.InvalidUserException;
import com.daitoj.tkms.modules.common.service.SystemException;
import com.daitoj.tkms.modules.common.service.dto.ApiResult;
import com.daitoj.tkms.modules.common.service.dto.CustomUserDetails;
import io.micrometer.common.util.StringUtils;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

/** 案件一覧ビジネスロジック */
@Service
@Transactional
public class A0010Service {
  private static final Logger LOG = LoggerFactory.getLogger(A0010Service.class);

  /** メニュー項目情報リポジトリ(従業員) */
  private final A0010S01Repository a0010S01Repository;

  /** 作業員情報リポジトリ */
  private final A0010S02Repository a0010S02Repository;

  /** システム設定情報リポジトリ */
  private final MSystemConfigRepository msystemConfigRepository;

  /** 従業員情報リポジトリ */
  private final MEmpRepository mempRepository;

  /** 業者情報ヘッダリポジトリ */
  private final MVendorHdrRepository vendorHdrRepository;

  /** メニュー項目情報リポジトリ */
  private final MMenuItemRepository menuItemRepository;

  /** お知らせ情報リポジトリ */
  private final TNotificationRepository notificationRepository;

  /** 協力会お知らせ情報リポジトリ */
  private final TPartnerNotificationRepository partnerNotificationRepository;

  /** 役職情報リポジトリ */
  private final MPositionRepository mpositionRepository;

  /** 業者情報マッパー */
  private final A0010Mapper a0010Mapper;

  /** メッセージ */
  private final MessageSource messageSource;

  /** コンストラクタ */
  public A0010Service(
      A0010S01Repository a0010S01Repository,
      A0010S02Repository a0010S02Repository,
      MSystemConfigRepository msystemConfigRepository,
      MEmpRepository mempRepository,
      MVendorHdrRepository vendorHdrRepository,
      MMenuItemRepository menuItemRepository,
      TNotificationRepository notificationRepository,
      TPartnerNotificationRepository partnerNotificationRepository,
      MPositionRepository mpositionRepository,
      A0010Mapper a0010Mapper,
      MessageSource messageSource) {
    this.a0010S01Repository = a0010S01Repository;
    this.a0010S02Repository = a0010S02Repository;
    this.msystemConfigRepository = msystemConfigRepository;
    this.mempRepository = mempRepository;
    this.vendorHdrRepository = vendorHdrRepository;
    this.menuItemRepository = menuItemRepository;
    this.notificationRepository = notificationRepository;
    this.partnerNotificationRepository = partnerNotificationRepository;
    this.mpositionRepository = mpositionRepository;
    this.a0010Mapper = a0010Mapper;
    this.messageSource = messageSource;
  }

  /**
   * ログイン情報取得
   *
   * @param userDetails ユーザ情報
   * @return ログイン情報
   */
  public ApiResult<A0010ReturnData> getLoginInfo(CustomUserDetails userDetails) {
    try {
      // 社員情報
      MEmp empInfo = null;
      // 業者情報ヘッダ
      MVendorHdr vendorHdr = null;
      // 作業員
      MWorker worderInfo = null;
      // メニュー情報
      List<MMenuItem> menuItemList = null;
      // 役職情報
      MPosition positionInfo = null;

      // システム利用可能時間-開始時間
      MSystemConfig startTime =
          msystemConfigRepository.findById_SysCdAndId_ConfigKeyAndDelFlg(
              SystemConfig.SYS_CD_USETM,
              SystemConfig.SYS_USABLE_START_TIME,
              CommonConstants.DELETE_FLAG_VALID);

      // システム利用可能時間-終了時間
      MSystemConfig endTime =
          msystemConfigRepository.findById_SysCdAndId_ConfigKeyAndDelFlg(
              SystemConfig.SYS_CD_USETM,
              SystemConfig.SYS_USABLE_END_TIME,
              CommonConstants.DELETE_FLAG_VALID);

      // 利用時間チェック
      if (!checkWorkTime(startTime, endTime)) {
        // メッセージ
        String msg =
            messageSource.getMessage(Message.MSGID_A0004, null, LocaleContextHolder.getLocale());

        LOG.warn(msg);

        // 結果情報
        return ApiResult.error(Message.MSGID_A0004, msg);
      }

      // お知らせ情報
      List<TNotification> notificationList = null;
      // 協力会お知らせ情報
      List<TPartnerNotification> partnerNotificationList = null;

      // 戻り値
      A0010ReturnData returnData = new A0010ReturnData();
      // アカウント区分
      returnData.setAccountKubun(userDetails.getAccountKubun());

      // アカウント区分が"1（社員）の場合
      if (CommonConstants.ACCOUNT_K_EMP.equals(userDetails.getAccountKubun())) {
        // 社員情報
        empInfo =
            mempRepository.findByLoginIdAndDelFlg(
                userDetails.getUsername(), CommonConstants.DELETE_FLAG_VALID);

        if (empInfo == null) {
          // メッセージ
          String msg =
              messageSource.getMessage(Message.MSGID_A0003, null, LocaleContextHolder.getLocale());

          LOG.warn(msg);

          // 結果情報
          throw new InvalidUserException(Message.MSGID_A0003, msg);
        }

        // 社員情報Dtoに変換する
        EmpDto empDto = a0010Mapper.toEmpDto(empInfo);
        // 社員情報を設定
        returnData.setEmpInfo(empDto);

        // メニュー情報
        menuItemList =
            a0010S01Repository.findEmpMenuItems(
                userDetails.getUsername(),
                CommonConstants.HAS_PERMISSION,
                Integer.valueOf(CommonConstants.ACCOUNT_K_EMP),
                CommonConstants.DELETE_FLAG_VALID);

        // 役職情報を取得
        positionInfo =
            mpositionRepository.findByPositionCdAndDelFlg(
                empInfo.getPositionCd(), CommonConstants.DELETE_FLAG_VALID);

        if (positionInfo == null) {
          // メッセージ
          String msg =
              messageSource.getMessage(Message.MSGID_K00006, null, LocaleContextHolder.getLocale());

          LOG.warn(msg);

          // 結果情報
          throw new InvalidUserException(Message.MSGID_K00006, msg);
        }

        // 役職情報Dtoに変換する
        PositionDto positionDto = a0010Mapper.toPositionDto(positionInfo);
        // 役職情報を設定
        returnData.setPositionInfo(positionDto);

        // お知らせ情報を取得
        notificationList =
            notificationRepository.findByDelFlgOrderById(CommonConstants.DELETE_FLAG_VALID);

        // お知らせ情報がある場合
        if (!CollectionUtils.isEmpty(notificationList)) {
          // Dtoに変換する
          List<NotificationDto> notifications = a0010Mapper.toNotificationDtoList(notificationList);

          // お知らせ情報を設定
          returnData.setNotificationList(notifications);
        }

        // アカウント区分が"2"（協力業者）の場合
      } else if (CommonConstants.ACCOUNT_K_VENDOR.equals(userDetails.getAccountKubun())) {
        // 業者情報ヘッダ
        vendorHdr =
            vendorHdrRepository.findByLoginIdAndDelFlg(
                userDetails.getUsername(), CommonConstants.DELETE_FLAG_VALID);

        if (vendorHdr == null) {
          // メッセージ
          String msg =
              messageSource.getMessage(Message.MSGID_A0003, null, LocaleContextHolder.getLocale());

          LOG.warn(msg);

          // 結果情報
          throw new InvalidUserException(Message.MSGID_A0003, msg);
        }

        // 業者情報ヘッダDtoに変換する
        VendorHdrDto vhdDto = a0010Mapper.toVendorHdrDto(vendorHdr);
        // 業者情報ヘッダを設定
        returnData.setVendorHdrInfo(vhdDto);

        // アカウント区分が"3"（協力業者社員）の場合
      } else if (CommonConstants.ACCOUNT_K_VENDOR_WORKER.equals(userDetails.getAccountKubun())) {
        // 作業員
        worderInfo =
            a0010S02Repository.findWorkerInfo(
                userDetails.getUsername(), CommonConstants.DELETE_FLAG_VALID);

        if (worderInfo == null) {
          // メッセージ
          String msg =
              messageSource.getMessage(Message.MSGID_A0003, null, LocaleContextHolder.getLocale());

          LOG.warn(msg);

          // 結果情報
          throw new InvalidUserException(Message.MSGID_A0003, msg);
        }

        // 作業員情報Dtoに変換する
        WorkerDto workerDto = a0010Mapper.toWorkerDto(worderInfo);
        // 作業員情報を設定
        returnData.setWorkerInfo(workerDto);
      }

      // アカウント区分が"2"（協力業者）の場合
      // アカウント区分が"3"（協力業者社員）の場合
      if (CommonConstants.ACCOUNT_K_VENDOR.equals(userDetails.getAccountKubun())
          || CommonConstants.ACCOUNT_K_VENDOR_WORKER.equals(userDetails.getAccountKubun())) {
        // メニュー情報
        menuItemList =
            menuItemRepository.findByDelFlgAndMenu_DelFlgAndMenu_Id(
                CommonConstants.DELETE_FLAG_VALID,
                CommonConstants.DELETE_FLAG_VALID,
                Integer.valueOf(userDetails.getAccountKubun()));

        // 協力会お知らせ情報
        partnerNotificationList =
            partnerNotificationRepository.findByDelFlgOrderById(CommonConstants.DELETE_FLAG_VALID);
      }

      // メニュー情報がある場合
      if (!CollectionUtils.isEmpty(menuItemList)) {
        // Dtoに変換する
        List<MenuItemDto> menuList = a0010Mapper.toMenuItemDtoList(menuItemList);

        // ツリー構造
        List<MenuItemDto> list = buildMenuTree(menuList);

        // メニュー情報を設定
        returnData.setMenuItemList(list);
      }

      // 協力会お知らせ情報がある場合
      if (!CollectionUtils.isEmpty(partnerNotificationList)) {
        // Dtoに変換する
        List<PartnerNotificationDto> partnerNotifications =
            a0010Mapper.toPartnerNotificationDtoList(partnerNotificationList);

        // 協力会お知らせ情報を設定
        returnData.setPartnerNotificationList(partnerNotifications);
      }

      return ApiResult.success(returnData);
    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw new SystemException(ex.toString(), ex);
    }
  }

  /**
   * メニューツリーを構築
   *
   * @param flatList メニュー項目リスト
   * @return 変換されたメニュー項目リスト
   */
  private List<MenuItemDto> buildMenuTree(List<MenuItemDto> flatList) {
    // メニュー項目IDマップ
    Map<Integer, MenuItemDto> map = new HashMap<>();
    // メニュー項目のリスト
    List<MenuItemDto> rootItems = new ArrayList<>();

    // マップに変換
    for (MenuItemDto item : flatList) {
      map.put(item.getId(), item);
    }

    // 親メニュー項目に追加
    for (MenuItemDto item : flatList) {
      Integer parentId = item.getParentMenuItemId();
      if (parentId == null) {
        // ルートアイテムに追加
        rootItems.add(item);
      } else {
        // 親IDが存在する場合
        MenuItemDto parent = map.get(parentId);
        if (parent != null) {
          // 親メニュー項目に子を追加
          parent.getChildren().add(item);
        }
      }
    }

    // ソート
    sortChildren(rootItems);
    return rootItems;
  }

  /**
   * ソート処理
   *
   * @param items メニュー項目リスト
   */
  private void sortChildren(List<MenuItemDto> items) {
    for (MenuItemDto item : items) {
      // 表示順でソート
      item.getChildren().sort(Comparator.comparingInt(MenuItemDto::getDisplayOrder));
      // 再帰的に子メニュー項目のソート
      sortChildren(item.getChildren());
    }
  }

  /**
   * 利用時間チェック
   *
   * @param startTime 開始時間
   * @param endTime 終了時間
   * @return 利用可能
   */
  private boolean checkWorkTime(MSystemConfig startTime, MSystemConfig endTime) {
    // フォーマット
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm");
    // システム時間
    LocalTime now = LocalTime.now();

    if (startTime != null && StringUtils.isNotBlank(startTime.getConfigValue())) {
      LocalTime start = LocalTime.parse(startTime.getConfigValue(), formatter);
      // 時間チェック
      if (now.isBefore(start)) {
        return false;
      }
    }

    if (endTime != null && StringUtils.isNotBlank(endTime.getConfigValue())) {
      LocalTime end = LocalTime.parse(endTime.getConfigValue(), formatter);

      // 時間チェック
      if (now.isAfter(end)) {
        return false;
      }
    }

    return true;
  }
}
