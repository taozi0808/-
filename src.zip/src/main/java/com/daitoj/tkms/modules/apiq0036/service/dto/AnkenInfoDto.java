package com.daitoj.tkms.modules.apiq0036.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

/** 案件情報 */
@Schema(name = "AnkenInfoDto", description = "検索結果")
public class AnkenInfoDto {

  /** 案件コード */
  private String ankenCode;

  /** 案件枝コード */
  private String ankenEdaCode;

  /** 案件名 */
  private String ankenName;

  /** 顧客コード */
  private String kokyakuCode;

  /** 顧客名 */
  private String kokyakuName;

  /** 想定金額 */
  private BigDecimal souteiKingaku;

  /** 現場住所１ */
  private String genbaJyuusyo1;

  /** 現場住所２ */
  private String genbaJyuusyo2;

  /** 受注見込日 */
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate jycyuuMikomiYmd;

  /** 着工希望日 */
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate cyakkouKibouYmd;

  /** 営業部門コード */
  private String eigyouBumonCode;

  /** 営業部門名 */
  private String eigyouBumonName;

  /** 営業担当者コード */
  private String eigyouTantousyaCode;

  /** 営業担当者_氏 */
  private String eigyouTantousyaShi;

  /** 営業担当者_名 */
  private String eigyouTantousyaMe;

  /** 営業担当者_氏名 */
  private String eigyouTantousyaShiMei;

  /** 進捗度コード */
  private String shincyokudoCode;

  /** 進捗度 */
  private String shincyokudo;

  /** コンストラクタ */
  public AnkenInfoDto() {}

  /**
   * コンストラクタ
   *
   * @param ankenCode 案件コード
   * @param ankenEdaCode 案件枝コード
   * @param ankenName 案件名
   * @param kokyakuCode 顧客コード
   * @param kokyakuName 顧客名
   * @param souteiKingaku 想定金額
   * @param genbaJyuusyo1 現場住所１
   * @param genbaJyuusyo2 現場住所２
   * @param jycyuuMikomiYmd 受注見込日
   * @param cyakkouKibouYmd 着工希望日
   * @param eigyouBumonCode 営業部門コード
   * @param eigyouBumonName 営業部門名
   * @param eigyouTantousyaCode 営業担当者コード
   * @param jyuugyouinShi 営業担当者_氏
   * @param jyuugyouinMei 営業担当者_名
   * @param jyuugyouinShimei 営業担当者_氏名
   * @param shincyokudoCode 進捗度コード
   * @param shincyokudo 進捗度
   */
  public AnkenInfoDto(
      String ankenCode,
      String ankenEdaCode,
      String ankenName,
      String kokyakuCode,
      String kokyakuName,
      BigDecimal souteiKingaku,
      String genbaJyuusyo1,
      String genbaJyuusyo2,
      LocalDate jycyuuMikomiYmd,
      LocalDate cyakkouKibouYmd,
      String eigyouBumonCode,
      String eigyouBumonName,
      String eigyouTantousyaCode,
      String jyuugyouinShi,
      String jyuugyouinMei,
      String jyuugyouinShimei,
      String shincyokudoCode,
      String shincyokudo) {
    this.ankenCode = ankenCode;
    this.ankenEdaCode = ankenEdaCode;
    this.ankenName = ankenName;
    this.kokyakuCode = kokyakuCode;
    this.kokyakuName = kokyakuName;
    this.souteiKingaku = souteiKingaku;
    this.genbaJyuusyo1 = genbaJyuusyo1;
    this.genbaJyuusyo2 = genbaJyuusyo2;
    this.jycyuuMikomiYmd = jycyuuMikomiYmd;
    this.cyakkouKibouYmd = cyakkouKibouYmd;
    this.eigyouBumonCode = eigyouBumonCode;
    this.eigyouBumonName = eigyouBumonName;
    this.eigyouTantousyaCode = eigyouTantousyaCode;
    this.eigyouTantousyaShi = jyuugyouinShi;
    this.eigyouTantousyaMe = jyuugyouinMei;
    this.eigyouTantousyaShiMei = jyuugyouinShimei;
    this.shincyokudoCode = shincyokudoCode;
    this.shincyokudo = shincyokudo;
  }

  @Schema(
      name = "ankenCode",
      description = "案件コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("ankenCode")
  public String getAnkenCode() {
    return ankenCode;
  }

  public void setAnkenCode(String ankenCode) {
    this.ankenCode = ankenCode;
  }

  @Schema(
      name = "ankenEdaCode",
      description = "案件枝コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("ankenEdaCode")
  public String getAnkenEdaCode() {
    return ankenEdaCode;
  }

  public void setAnkenEdaCode(String ankenEdaCode) {
    this.ankenEdaCode = ankenEdaCode;
  }

  @Schema(name = "ankenName", description = "案件名", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("ankenName")
  public String getAnkenName() {
    return ankenName;
  }

  public void setAnkenName(String ankenName) {
    this.ankenName = ankenName;
  }

  @Schema(
      name = "kokyakuCode",
      description = "顧客コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("kokyakuCode")
  public String getKokyakuCode() {
    return kokyakuCode;
  }

  public void setKokyakuCode(String kokyakuCode) {
    this.kokyakuCode = kokyakuCode;
  }

  @Schema(
      name = "kokyakuName",
      description = "顧客名",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("kokyakuName")
  public String getKokyakuName() {
    return kokyakuName;
  }

  public void setKokyakuName(String kokyakuName) {
    this.kokyakuName = kokyakuName;
  }

  @Schema(
      name = "souteiKingaku",
      description = "想定金額",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("souteiKingaku")
  public BigDecimal getSouteiKingaku() {
    return souteiKingaku;
  }

  public void setSouteiKingaku(BigDecimal souteiKingaku) {
    this.souteiKingaku = souteiKingaku;
  }

  @Schema(
      name = "genbaJyuusyo1",
      description = "現場住所１",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("genbaJyuusyo1")
  public String getGenbaJyuusyo1() {
    return genbaJyuusyo1;
  }

  public void setGenbaJyuusyo1(String genbaJyuusyo1) {
    this.genbaJyuusyo1 = genbaJyuusyo1;
  }

  @Schema(
      name = "genbaJyuusyo2",
      description = "現場住所２",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("genbaJyuusyo2")
  public String getGenbaJyuusyo2() {
    return genbaJyuusyo2;
  }

  public void setGenbaJyuusyo2(String genbaJyuusyo2) {
    this.genbaJyuusyo2 = genbaJyuusyo2;
  }

  @Schema(
      name = "jycyuuMikomiYmd",
      description = "受注見込日(yyyy-MM-dd)",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonFormat(pattern = "yyyy-MM-dd")
  @JsonProperty("jycyuuMikomiYmd")
  public LocalDate getJycyuuMikomiYmd() {
    return jycyuuMikomiYmd;
  }

  public void setJycyuuMikomiYmd(LocalDate jycyuuMikomiYmd) {
    this.jycyuuMikomiYmd = jycyuuMikomiYmd;
  }

  @Schema(
      name = "cyakkouKibouYmd",
      description = "着工希望日(yyyy-MM-dd)",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonFormat(pattern = "yyyy-MM-dd")
  @JsonProperty("cyakkouKibouYmd")
  public LocalDate getCyakkouKibouYmd() {
    return cyakkouKibouYmd;
  }

  public void setCyakkouKibouYmd(LocalDate cyakkouKibouYmd) {
    this.cyakkouKibouYmd = cyakkouKibouYmd;
  }

  @Schema(
      name = "eigyouBumonCode",
      description = "営業部門コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouBumonCode")
  public String getEigyouBumonCode() {
    return eigyouBumonCode;
  }

  public void setEigyouBumonCode(String eigyouBumonCode) {
    this.eigyouBumonCode = eigyouBumonCode;
  }

  @Schema(
      name = "eigyouBumonName",
      description = "営業部門名",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouBumonName")
  public String getEigyouBumonName() {
    return eigyouBumonName;
  }

  public void setEigyouBumonName(String eigyouBumonName) {
    this.eigyouBumonName = eigyouBumonName;
  }

  @Schema(
      name = "eigyouTantousyaCode",
      description = "営業担当者コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouTantousyaCode")
  public String getEigyouTantousyaCode() {
    return eigyouTantousyaCode;
  }

  public void setEigyouTantousyaCode(String eigyouTantousyaCode) {
    this.eigyouTantousyaCode = eigyouTantousyaCode;
  }

  @Schema(
      name = "eigyouTantousyaShi",
      description = "営業担当者_氏",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouTantousyaShi")
  public String getEigyouTantousyaShi() {
    return eigyouTantousyaShi;
  }

  public void setEigyouTantousyaShi(String eigyouTantousyaShi) {
    this.eigyouTantousyaShi = eigyouTantousyaShi;
  }

  @Schema(
      name = "eigyouTantousyaMe",
      description = "営業担当者_名",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouTantousyaMe")
  public String getEigyouTantousyaMe() {
    return eigyouTantousyaMe;
  }

  public void setEigyouTantousyaMe(String eigyouTantousyaMe) {
    this.eigyouTantousyaMe = eigyouTantousyaMe;
  }

  @Schema(
      name = "eigyouTantousyaShiMei",
      description = "営業担当者_氏名",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("eigyouTantousyaShiMei")
  public String getEigyouTantousyaShiMei() {
    return eigyouTantousyaShiMei;
  }

  public void setEigyouTantousyaShiMei(String eigyouTantousyaShiMei) {
    this.eigyouTantousyaShiMei = eigyouTantousyaShiMei;
  }

  @Schema(
      name = "shincyokudoCode",
      description = "進捗度コード",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("shincyokudoCode")
  public String getShincyokudoCode() {
    return shincyokudoCode;
  }

  public void setShincyokudoCode(String shincyokudoCode) {
    this.shincyokudoCode = shincyokudoCode;
  }

  @Schema(
      name = "shincyokudo",
      description = "進捗度",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("shincyokudo")
  public String getShincyokudo() {
    return shincyokudo;
  }

  public void setShincyokudo(String shincyokudo) {
    this.shincyokudo = shincyokudo;
  }
}
