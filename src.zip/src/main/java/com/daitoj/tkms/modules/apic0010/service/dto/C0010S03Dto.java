package com.daitoj.tkms.modules.apic0010.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

/** 概算一覧印刷パラメータ */
@Schema(name = "C0010S03Dto", description = "概算一覧印刷パラメータ")
public class C0010S03Dto {

  /** 利用PCのシステム日付 */
  @NotNull
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private String sysDate;

  @Schema(
      name = "sysDate",
      description = "利用PCのシステム日付(yyyy-MM-dd HH:mm:ss)",
      requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  public String getSysDate() {
    return sysDate;
  }

  public void setSysDate(String sysDate) {
    this.sysDate = sysDate;
  }
}
