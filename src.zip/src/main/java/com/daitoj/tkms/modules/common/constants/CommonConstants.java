package com.daitoj.tkms.modules.common.constants;

/** 定数定義 */
public final class CommonConstants {

  /** CSV出力のCharset */
  public static final String CSV_CHARSET_SHIFT_JIS = "Shift_JIS";

  /** 削除フラグ */
  public static final String DELETE_FLAG_VALID = "0";

  /** 権限なし */
  public static final String NO_PERMISSION = "0";

  /** 権限あり */
  public static final String HAS_PERMISSION = "1";

  /** アカウント区分:社員 */
  public static final String ACCOUNT_K_EMP = "1";

  /** アカウント区分:協力業者 */
  public static final String ACCOUNT_K_VENDOR = "2";

  /** アカウント区分:協力業者社員 */
  public static final String ACCOUNT_K_VENDOR_WORKER = "3";

  /** HttpHeaderのログインID */
  public static final String HTTP_HEADER_LOGIN_ID = "login_id";

  /** HttpHeaderのアカウント区分 */
  public static final String HTTP_HEADER_ACCOUNT_K = "account_k";

  /** HttpHeaderの役職コード */
  public static final String HTTP_HEADER_POSITION_CD = "position_cd";

  /** HttpHeaderの承認権限 */
  public static final String HTTP_HEADER_CONFIRM_PERM = "confirm_perm";

  /** HttpHeaderの削除権限 */
  public static final String HTTP_HEADER_DELETE_PERM = "delete_perm";

  /** HttpHeaderの編集権限 */
  public static final String HTTP_HEADER_EDIT_PERM = "edit_perm";

  /** HttpHeaderの参照権限 */
  public static final String HTTP_HEADER_REFER_PERM = "refer_perm";

  /** HttpHeaderのメニューID */
  public static final String HTTP_HEADER_MENU_ID = "menu_id";
}
