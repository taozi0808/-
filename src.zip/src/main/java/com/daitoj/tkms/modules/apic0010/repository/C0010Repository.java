package com.daitoj.tkms.modules.apic0010.repository;

import com.daitoj.tkms.domain.TRoughEstHdr;
import com.daitoj.tkms.modules.apic0010.service.dto.GaisanInfoDto;
import java.time.LocalDate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** 概算一覧のリポジトリ */
@Repository
public interface C0010Repository extends JpaRepository<TRoughEstHdr, Long> {

  /**
   * 初期表示データ取得
   *
   * @param delFlg 除フラグ削除フラグ
   * @return 概算一覧
   */
  @Query(
      "SELECT new com.daitoj.tkms.modules.apic0010.service.dto.GaisanInfoDto("
          + "tp.projectCd, treh.roughEstCd, "
          + "tp.projectNm, mc.customerCd, mc.customerNm1, tp.estSubmitDueDt, "
          + "treh.roughEstTotalAmt, tp.startHopeYmd, tp.startHopeYmd, mo.orgCd, mo.orgNm, "
          + "me.empCd, me.empShimei) "
          + "FROM TRoughEstHdr treh "
          + "INNER JOIN TProject tp ON treh.project.id = tp.id "
          + "AND tp.delFlg = :delFlg "
          + "INNER JOIN MCustomer mc ON mc.customerCd = treh.customerCd "
          + "AND mc.delFlg = :delFlg "
          + "INNER JOIN MOrg mo ON mo.id = treh.roughEstOrgId "
          + "AND mo.delFlg = :delFlg "
          + "INNER JOIN MEmp me ON me.empCd = treh.roughEstPicCd "
          + "AND me.delFlg = :delFlg "
          + "WHERE treh.delFlg = :delFlg ")
  Page<GaisanInfoDto> getGaisanInfo(@Param("delFlg") String delFlg, Pageable pageable);

  /**
   * 検索処理
   *
   * @param ankenCode 案件コード
   * @param ankenName 案件名（ｶﾅ含む）
   * @param gaisanCode 概算コード
   * @param kokyakuCode 顧客コード
   * @param kokyakuName 顧客名（ｶﾅ含む）
   * @param teisyutsukigenStart 見積提出期限（開始）
   * @param teisyutsukigenEnd 見積提出期限（終了）
   * @param gaisanTantousyaCode 概算部門
   * @param gaisanTantousya 概算担当者
   * @param delFlg 除フラグ
   * @return 概算一覧
   */
  @Query(
      "SELECT new com.daitoj.tkms.modules.apic0010.service.dto.GaisanInfoDto("
          + "tp.projectCd, treh.roughEstCd, "
          + "tp.projectNm, mc.customerCd, mc.customerNm1, tp.estSubmitDueDt, "
          + "treh.roughEstTotalAmt, tp.startHopeYmd, tp.startHopeYmd, mo.orgCd, mo.orgNm, "
          + "me.empCd, me.empShimei) "
          + "FROM TRoughEstHdr treh "
          + "INNER JOIN TProject tp ON treh.project.id = tp.id "
          + "AND tp.delFlg = :delFlg "
          + "INNER JOIN MCustomer mc ON mc.customerCd = treh.customerCd "
          + "AND mc.delFlg = :delFlg "
          + "INNER JOIN MOrg mo ON mo.id = treh.roughEstOrgId "
          + "AND mo.delFlg = :delFlg "
          + "INNER JOIN MEmp me ON me.empCd = treh.roughEstPicCd "
          + "AND me.delFlg = :delFlg "
          + "WHERE treh.delFlg = :delFlg "
          + "AND (:ankenCode IS NULL OR tp.projectCd LIKE %:ankenCode%) "
          + "AND (:ankenName IS NULL OR treh.roughEstCd LIKE %:ankenName% "
          + " OR treh.hisNo LIKE %:ankenName%) "
          + "AND (:gaisanCode IS NULL OR treh.roughEstCd LIKE %:gaisanCode%) "
          + "AND (:kokyakuCode IS NULL OR mc.customerCd LIKE %:kokyakuCode%) "
          + "AND (:kokyakuName IS NULL OR mc.customerNm1 LIKE %:kokyakuName% "
          + " OR mc.customerKnNm LIKE %:kokyakuName%) "
          + "AND COALESCE(:teisyutsukigenStart, tp.estSubmitDueDt) <= tp.estSubmitDueDt "
          + "AND tp.estSubmitDueDt <= COALESCE(:teisyutsukigenEnd, tp.estSubmitDueDt) "
          + "AND (:gaisanTantousyaCode IS NULL OR mo.orgCd LIKE %:gaisanTantousyaCode%) "
          + "AND (:gaisanTantousya IS NULL OR me.empCd LIKE %:gaisanTantousya%)")
  Page<GaisanInfoDto> searchGaisanInfo(
      @Param("ankenCode") String ankenCode,
      @Param("ankenName") String ankenName,
      @Param("gaisanCode") String gaisanCode,
      @Param("kokyakuCode") String kokyakuCode,
      @Param("kokyakuName") String kokyakuName,
      @Param("teisyutsukigenStart") LocalDate teisyutsukigenStart,
      @Param("teisyutsukigenEnd") LocalDate teisyutsukigenEnd,
      @Param("gaisanTantousyaCode") String gaisanTantousyaCode,
      @Param("gaisanTantousya") String gaisanTantousya,
      @Param("delFlg") String delFlg,
      Pageable pageable);
}
