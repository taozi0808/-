package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.MMenuItem;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** メニュー項目情報リポジトリ */
@Repository
public interface MMenuItemRepository extends JpaRepository<MMenuItem, Integer> {
  /**
   * メニュー項目情報取得
   *
   * @param menuItemDelFlg 削除フラグ
   * @param menuDelFlg 削除フラグ
   * @param menuId メニューID
   * @return メニュー項目情報
   */
  List<MMenuItem> findByDelFlgAndMenu_DelFlgAndMenu_Id(
      String menuItemDelFlg, String menuDelFlg, Integer menuId);
}
