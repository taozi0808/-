package com.daitoj.tkms.modules.apib0010.service.dto;

import com.daitoj.tkms.modules.common.service.dto.BasePageRequest;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

/** 案件一覧パラメータ */
@Schema(name = "B0010S01Dto", description = "案件一覧パラメータ")
public class B0010S01Dto extends BasePageRequest {

  /** 所属部署役職コード */
  @NotNull
  @Schema(description = "役職コード", requiredMode = Schema.RequiredMode.REQUIRED)
  private String yakusyokuCode;

  /** 案件コード */
  @Schema(name = "ankenCode", description = "案件コード")
  private String ankenCode;

  /** 案件名（ｶﾅ含む） */
  @Schema(name = "ankenName", description = "案件名（ｶﾅ含む）")
  private String ankenName;

  /** 受注状態リスト */
  @Valid
  @NotNull
  @Size(min = 1)
  @Schema(
      name = "listJyucyuuJyoutai",
      description = "受注状態リスト",
      requiredMode = Schema.RequiredMode.REQUIRED)
  private List<String> listJyucyuuJyoutai;

  /** 顧客名（ｶﾅ含む） */
  @Schema(name = "kokyakuName", description = "顧客名（ｶﾅ含む）")
  private String kokyakuName;

  /** 受注見込日（開始） */
  @Schema(name = "jmYmdStart", description = "受注見込日（開始）(yyyy-MM-dd)", example = "2025-01-02")
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate jmYmdStart;

  /** 受注見込日（終了） */
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  @JsonFormat(pattern = "yyyy-MM-dd")
  @Schema(name = "jmYmdEnd", description = "受注見込日（終了）(yyyy-MM-dd)", example = "2025-01-02")
  private LocalDate jmYmdEnd;

  /** 営業部門 */
  @Schema(name = "eigyouBumon", description = "営業部門")
  private String eigyouBumon;

  /** 営業担当者 */
  @Schema(name = "eigyouTantousya", description = "営業担当者")
  private String eigyouTantousya;

  public String getYakusyokuCode() {
    return yakusyokuCode;
  }

  public void setYakusyokuCode(String yakusyokuCode) {
    this.yakusyokuCode = yakusyokuCode;
  }

  public String getAnkenCode() {
    return ankenCode;
  }

  public void setAnkenCode(String ankenCode) {
    this.ankenCode = ankenCode;
  }

  public String getAnkenName() {
    return ankenName;
  }

  public void setAnkenName(String ankenName) {
    this.ankenName = ankenName;
  }

  public List<String> getListJyucyuuJyoutai() {
    return listJyucyuuJyoutai;
  }

  public void setListJyucyuuJyoutai(List<String> listJyucyuuJyoutai) {
    this.listJyucyuuJyoutai = listJyucyuuJyoutai;
  }

  public String getKokyakuName() {
    return kokyakuName;
  }

  public void setKokyakuName(String kokyakuName) {
    this.kokyakuName = kokyakuName;
  }

  public LocalDate getJmYmdStart() {
    return jmYmdStart;
  }

  public void setJmYmdStart(LocalDate jmYmdStart) {
    this.jmYmdStart = jmYmdStart;
  }

  public LocalDate getJmYmdEnd() {
    return jmYmdEnd;
  }

  public void setJmYmdEnd(LocalDate jmYmdEnd) {
    this.jmYmdEnd = jmYmdEnd;
  }

  public String getEigyouBumon() {
    return eigyouBumon;
  }

  public void setEigyouBumon(String eigyouBumon) {
    this.eigyouBumon = eigyouBumon;
  }

  public String getEigyouTantousya() {
    return eigyouTantousya;
  }

  public void setEigyouTantousya(String eigyouTantousya) {
    this.eigyouTantousya = eigyouTantousya;
  }
}
