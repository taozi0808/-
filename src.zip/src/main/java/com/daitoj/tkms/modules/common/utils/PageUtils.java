package com.daitoj.tkms.modules.common.utils;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

/** ページ処理クラス */
public class PageUtils {
  /**
   * Pageable取得
   *
   * @param page ページインデックス
   * @param size ページ数
   * @return Pageable
   */
  public static Pageable resolvePageable(int page, int size) {
    if (page <= 0 || size <= 0) {
      return Pageable.unpaged();
    }
    return PageRequest.of(page - 1, size);
  }
}
