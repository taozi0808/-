package com.daitoj.tkms.modules.common.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** マスタデータ情報 */
@Schema(name = "MitemSettingDto", description = "マスタデータ情報")
public class MitemSettingDto {

  /** 項目コード */
  @Schema(name = "itemCd", description = "項目コード ")
  private String itemCd;

  /** 項目内容 */
  @Schema(name = "itemValue", description = "項目内容")
  private String itemValue;

  public String getItemCd() {
    return itemCd;
  }

  public void setItemCd(String itemCd) {
    this.itemCd = itemCd;
  }

  public String getItemValue() {
    return itemValue;
  }

  public void setItemValue(String itemValue) {
    this.itemValue = itemValue;
  }
}
