//package com.daitoj.tkms.modules.apiq0036.service;
//
//import com.daitoj.tkms.domain.MitemListSetting;
//import com.daitoj.tkms.domain.YakusyokuInfo;
//import com.daitoj.tkms.modules.apiq0036.repository.Q0036Repository;
//import com.daitoj.tkms.modules.apiq0036.repository.mapper.Q0036Mapper;
//import com.daitoj.tkms.modules.apiq0036.service.dto.*;
//import com.daitoj.tkms.modules.common.constants.CommonConstants;
//import com.daitoj.tkms.modules.common.constants.MasterData;
//import com.daitoj.tkms.modules.common.constants.Message;
//import com.daitoj.tkms.modules.common.repository.MitemListSettingRepository;
//import com.daitoj.tkms.modules.common.repository.YakusyokuInfoRepository;
//import com.daitoj.tkms.modules.common.repository.mapper.MitemSettingMapper;
//import com.daitoj.tkms.modules.common.service.ReportService;
//import com.daitoj.tkms.modules.common.service.dto.ApiResult;
//import com.daitoj.tkms.modules.common.service.dto.MitemSettingDto;
//import com.daitoj.tkms.modules.common.service.dto.PaginationMeta;
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import net.sf.jasperreports.engine.JRDataSource;
//import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
//import org.apache.commons.csv.CSVFormat;
//import org.apache.commons.csv.CSVPrinter;
//import org.apache.commons.csv.QuoteMode;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.MessageSource;
//import org.springframework.context.i18n.LocaleContextHolder;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.stereotype.Service;
//import org.springframework.util.CollectionUtils;
//
//import java.io.OutputStream;
//import java.io.OutputStreamWriter;
//import java.nio.charset.Charset;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.List;
//import java.util.Map;
//
///** 作業員名簿業者一覧ビジネスロジック */
//@Service
//public class Q0036Service {
//
//  private static final Logger LOG = LoggerFactory.getLogger(Q0036Service.class);
//
//  /** DB日付フォーマット */
//  private static final String DATE_FORMAT = "yyyyMMdd";
//
//  /** 帳票日付フォーマット */
//  private static final String PDF_DATE_FORMAT = "yyyy年MM年dd日HH:mm:ss";
//
//  /** CSVヘッダ */
//  private static final String[] CSV_HEADER = {
//    "案件コード",
//    "案件枝コード",
//    "案件名",
//    "顧客コード",
//    "顧客名",
//    "現場住所",
//    "想定金額",
//    "受注見込日",
//    "着工希望日",
//    "営業担当部門コード",
//    "営業担当部門",
//    "営業担当者コード",
//    "営業担当者",
//    "進捗度コード",
//    "進捗度"
//  };
//
//  /** 案件一覧のDTOマッピング */
//  private final Q0036Mapper q0036Mapper;
//
//  /** マスタデータのDTOマッピング */
//  private final MitemSettingMapper mitemSettingMapper;
//
//  /** 役職情報リポジトリ */
//  private final YakusyokuInfoRepository yakusyokuInfoRepository;
//
//  /** マスタデータリポジトリ */
//  private final MitemListSettingRepository mitemListSettingRepository;
//
//  /** 案件一覧のクエリ */
//  private final Q0036Repository q0036Repository;
//
//  /** メッセージ */
//  private final MessageSource messageSource;
//
//  /** レポートサービス */
//  private final ReportService reportService;
//
//  /** fasterxml.jacksonのObjectMapper */
//  private final ObjectMapper objectMapper;
//
//  /** CSVファイル名 */
//  public static final String APP_NAME = "案件一覧";
//
//  /** レポートファイル名 */
//  public static final String REPORT_FILE_NAME = "Q0036.jasper";
//
//  /** コンストラクタ */
//  public Q0036Service(
//      Q0036Mapper q0036Mapper,
//      MitemSettingMapper mitemSettingMapper,
//      YakusyokuInfoRepository yakusyokuInfoRepository,
//      MitemListSettingRepository mitemListSettingRepository,
//      Q0036Repository q0036Repository,
//      MessageSource messageSource,
//      ReportService reportService,
//      ObjectMapper objectMapper) {
//    this.q0036Mapper = q0036Mapper;
//    this.mitemSettingMapper = mitemSettingMapper;
//    this.yakusyokuInfoRepository = yakusyokuInfoRepository;
//    this.mitemListSettingRepository = mitemListSettingRepository;
//    this.q0036Repository = q0036Repository;
//    this.messageSource = messageSource;
//    this.reportService = reportService;
//    this.objectMapper = objectMapper;
//  }
//
//  /**
//   * 初期表示
//   *
//   * @param inDto 案件情報取得パラメータ
//   * @return 案件情報取得結果
//   */
//  public ApiResult<Q0036ReturnData> getInitInfo(Q0036S01Dto inDto, Pageable pageable) {
//    try {
//      // 検索パラメータ作成
//      List<String> codes = q0036Mapper.getSbSyozokuCodes(inDto);
//
//      // 権限リストを取得
//      List<YakusyokuInfo> authInfoList =
//          yakusyokuInfoRepository.findByYakusyokuCodeInAndDeleteFlg(
//              codes, CommonConstants.DELETE_FLAG_VALID);
//
//      // 取得件数が０件だった場合
//      if (CollectionUtils.isEmpty(authInfoList)) {
//        // メッセージ
//        String msg =
//            messageSource.getMessage(Message.MSGID_K00006, null, LocaleContextHolder.getLocale());
//
//        LOG.error(msg);
//
//        // 結果情報
//        return ApiResult.error(Message.MSGID_K00006, msg);
//      }
//
//      // 編集権限＝"1"のレコード数
//      long hensyuuCount =
//          authInfoList.stream()
//              .filter(info -> CommonConstants.HAS_PERMISSION.equals(info.getHensyuuKengen()))
//              .count();
//
//      // 参照権限＝"1"のレコード数
//      long sansyouCount =
//          authInfoList.stream()
//              .filter(info -> CommonConstants.HAS_PERMISSION.equals(info.getSansyouKengen()))
//              .count();
//
//      // 編集権限 (編集権限＝"1"のレコードが１件以上の場合は”1”、０件の場合は"0")
//      String hensyuuKengen =
//          hensyuuCount > 1 ? CommonConstants.HAS_PERMISSION : CommonConstants.NO_PERMISSION;
//      // 参照権限 (参照権限＝"1"のレコードが１件以上の場合は”1”、０件の場合は"0")
//      String sansyouKengen =
//          sansyouCount > 1 ? CommonConstants.HAS_PERMISSION : CommonConstants.NO_PERMISSION;
//
//      // 案件情報を取得
//      Page<AnkenInfoDto> ankenList =null;
////          Q0036Repository.findInitInfo(
////              inDto.getListJyucyuuJyoutai(), CommonConstants.DELETE_FLAG_VALID, pageable);
//
//      // マスタデータを取得
//      List<MitemListSetting> mitemList =
//          mitemListSettingRepository
//              .findById_ItemClassCdAndId_EffectiveStartDtLessThanEqualAndDelFlgOrderByDisplayOrder(
//                  MasterData.ITEM_CLASS_CD,
//                  LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_FORMAT)),
//                  CommonConstants.DELETE_FLAG_VALID);
//
//      // マスタデータDtoに変換する
//      List<MitemSettingDto> dtoList = mitemSettingMapper.toDto(mitemList);
//
//      // 戻り値
//      Q0036ReturnData returnData = new Q0036ReturnData();
//      // 案件情報リスト
//      returnData.setListAnkenInfo(ankenList.getContent());
//      // 編集権限
//      returnData.setHensyuuKengen(hensyuuKengen);
//      // 参照権限
//      returnData.setSansyouKengen(sansyouKengen);
//      // マスタデータ(受注状態)
//      returnData.setMitemSettingD0001(dtoList);
//
//      // ページ情報
//      PaginationMeta meta = new PaginationMeta(ankenList);
//
//      return ApiResult.success(returnData, meta);
//
//    } catch (Exception ex) {
//      LOG.error(ex.toString(), ex);
//
//      throw ex;
//    }
//  }
//
//  /**
//   * 検索処理
//   *
//   * @param inDto 案件情報取得パラメータ
//   * @return 案件情報取得結果
//   */
//  public ApiResult<Q0036ReturnData> getAnkenInfo(Q0036S01Dto inDto, Pageable pageable) {
//    try {
//      // 案件情報を取得
//      Page<AnkenInfoDto> ankenList =
//          q0036Repository.findAnkenInfo(
//              inDto.getListJyucyuuJyoutai(),
//              CommonConstants.DELETE_FLAG_VALID,
//              inDto.getAnkenCode(),
//              inDto.getAnkenName(),
//              inDto.getKokyakuName(),
//              inDto.getJmYmdStart(),
//              inDto.getJmYmdEnd(),
//              inDto.getEigyouBumon(),
//              inDto.getEigyouTantousya(),
//              pageable);
//
//      // 取得件数が０件だった場合
//      if (CollectionUtils.isEmpty(ankenList.getContent())) {
//        // メッセージ
//        String msg =
//            messageSource.getMessage(Message.MSGID_K00001, null, LocaleContextHolder.getLocale());
//
//        LOG.info(msg);
//
//        // 結果情報
//        return ApiResult.error(Message.MSGID_K00001, msg);
//      }
//
//      // 戻り値
//      Q0036ReturnData returnData = new Q0036ReturnData();
//      // 案件情報リスト
//      returnData.setListAnkenInfo(ankenList.getContent());
//
//      // ページ情報
//      PaginationMeta meta = new PaginationMeta(ankenList);
//
//      return ApiResult.success(returnData, meta);
//
//    } catch (Exception ex) {
//      LOG.error(ex.toString(), ex);
//
//      throw ex;
//    }
//  }
//
//  /**
//   * CSV出力
//   *
//   * @param inDto 案件情報取得パラメータ
//   * @param outputStream Stream
//   */
//  public void downLoadCsv(Q0036S02Dto inDto, OutputStream outputStream) throws Exception {
//    try {
//      // ヘッダ設定（カンマ区切り）
//      CSVFormat csvFormat =
//          CSVFormat.DEFAULT
//              .builder()
//              .setDelimiter(',')
//              .setQuoteMode(QuoteMode.ALL)
//              .setHeader(CSV_HEADER)
//              .get();
//
//      // 案件情報を取得
//      Page<AnkenInfoDto> ankenList =
//          q0036Repository.findAnkenInfo(
//              inDto.getListJyucyuuJyoutai(),
//              CommonConstants.DELETE_FLAG_VALID,
//              inDto.getAnkenCode(),
//              inDto.getAnkenName(),
//              inDto.getKokyakuName(),
//              inDto.getJmYmdStart(),
//              inDto.getJmYmdEnd(),
//              inDto.getEigyouBumon(),
//              inDto.getEigyouTantousya(),
//              Pageable.unpaged());
//
//      Charset charset = Charset.forName(CommonConstants.CSV_CHARSET_SHIFT_JIS);
//
//      try (CSVPrinter printer =
//          new CSVPrinter(new OutputStreamWriter(outputStream, charset), csvFormat)) {
//        // データがある場合
//        if (!CollectionUtils.isEmpty(ankenList.getContent())) {
//          for (AnkenInfoDto ankenInfo : ankenList) {
//            // 明細行設定
//            printer.printRecord(
//                ankenInfo.getAnkenCode(),
//                ankenInfo.getAnkenEdaCode(),
//                ankenInfo.getAnkenName(),
//                ankenInfo.getKokyakuCode(),
//                ankenInfo.getKokyakuName(),
//                ankenInfo.getSouteiKingaku(),
//                String.join("", ankenInfo.getGenbaJyuusyo1(), ankenInfo.getGenbaJyuusyo2()),
//                ankenInfo.getJycyuuMikomiYmd(),
//                ankenInfo.getCyakkouKibouYmd(),
//                ankenInfo.getEigyouBumonCode(),
//                ankenInfo.getEigyouBumonName(),
//                ankenInfo.getEigyouTantousyaCode(),
//                String.join(
//                        "　", ankenInfo.getEigyouTantousyaShi(), ankenInfo.getEigyouTantousyaMe())
//                    .trim(),
//                ankenInfo.getShincyokudoCode(),
//                ankenInfo.getShincyokudo());
//          }
//        }
//      }
//
//    } catch (Exception ex) {
//      LOG.error(ex.toString(), ex);
//
//      throw ex;
//    }
//  }
//
//  /**
//   * 印刷処理
//   *
//   * @param inDto 案件情報印刷パラメータ
//   * @return pdf
//   */
//  public byte[] exportReportToPdf(Q0036S02Dto inDto) throws Exception {
//    try {
//      // 案件情報を取得
//      Page<AnkenInfoDto> ankenList =
//          q0036Repository.findAnkenInfo(
//              inDto.getListJyucyuuJyoutai(),
//              CommonConstants.DELETE_FLAG_VALID,
//              inDto.getAnkenCode(),
//              inDto.getAnkenName(),
//              inDto.getKokyakuName(),
//              inDto.getJmYmdStart(),
//              inDto.getJmYmdEnd(),
//              inDto.getEigyouBumon(),
//              inDto.getEigyouTantousya(),
//              Pageable.unpaged());
//
//      // 印刷パラメータ
//      Q0036S03Dto printDto = new Q0036S03Dto();
//      // 利用PCのシステム日付
//      printDto.setSysDate(inDto.getSysDate().format(DateTimeFormatter.ofPattern(PDF_DATE_FORMAT)));
//
//      // レポートに渡すパラメータ
//      Map<String, Object> paramsMap =
//          objectMapper.convertValue(printDto, new TypeReference<Map<String, Object>>() {});
//
//      // データソースを生成する
//      JRDataSource dataSource = new JRBeanCollectionDataSource(ankenList.getContent());
//
//      // レポートを生成する
//      return reportService.exportReportToPdf(REPORT_FILE_NAME, paramsMap, dataSource);
//    } catch (Exception ex) {
//      LOG.error(ex.toString(), ex);
//
//      throw ex;
//    }
//  }
//}
