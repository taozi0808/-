package com.daitoj.tkms.modules.apia0010.repository;

import com.daitoj.tkms.domain.MMenuItem;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** メニュー項目情報リポジトリ */
@Repository
public interface A0010S01Repository extends JpaRepository<MMenuItem, Integer> {
  /**
   * メニュー項目情報を取得する
   *
   * @param loginId ユーザーID
   * @param delFlg 削除フラグ
   * @return メニュー項目情報
   */
  @Query(
      """
          SELECT mi
          FROM MEmp emp
          JOIN MEmpOrg eo ON emp = eo.empCd
          JOIN MOrgMenuItem omi ON eo.org = omi.mOrg
          JOIN MMenuItem mi ON omi.menuItem = mi
          JOIN MMenu menu ON mi.menu = menu
          WHERE emp.loginId = :loginId
          AND emp.delFlg = :delFlg
          AND eo.delFlg = :delFlg
          AND omi.delFlg = :delFlg
          AND omi.referPerm = :referPerm
          AND menu.id = :accountKbn
          ORDER BY mi.displayOrder
          """)
  List<MMenuItem> findEmpMenuItems(
      @Param("loginId") String loginId,
      @Param("referPerm") String referPerm,
      @Param("accountKbn") Integer accountKbn,
      @Param("delFlg") String delFlg);
}
