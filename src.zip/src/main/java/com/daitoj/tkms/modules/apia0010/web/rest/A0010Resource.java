package com.daitoj.tkms.modules.apia0010.web.rest;

import static com.daitoj.tkms.security.SecurityUtils.AUTHORITIES_KEY;
import static com.daitoj.tkms.security.SecurityUtils.JWT_ALGORITHM;

import com.daitoj.tkms.modules.apia0010.service.A0010Service;
import com.daitoj.tkms.modules.apia0010.service.dto.A0010ApiResult;
import com.daitoj.tkms.modules.apia0010.service.dto.A0010Dto;
import com.daitoj.tkms.modules.apia0010.service.dto.A0010ReturnData;
import com.daitoj.tkms.modules.apia0010.service.dto.PositionDto;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.service.dto.ApiResult;
import com.daitoj.tkms.modules.common.service.dto.CustomUserDetails;
import com.daitoj.tkms.modules.common.service.dto.ErrorInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** ログインコントローラ */
@RestController
@Tag(name = "tkmsapi", description = "ログインのAPI")
@RequestMapping("/api/v1/login")
public class A0010Resource {
  private static final Logger LOG = LoggerFactory.getLogger(A0010Resource.class);

  @Value("${jhipster.security.authentication.jwt.token-validity-in-seconds:0}")
  private long tokenValidityInSeconds;

  /** サービス */
  private final A0010Service a0010Service;

  /** 認証マネージャ */
  private final AuthenticationManagerBuilder authenticationManagerBuilder;

  /** エンコード */
  private final JwtEncoder jwtEncoder;

  /** コンストラクタ */
  public A0010Resource(
      A0010Service a0010Service,
      AuthenticationManagerBuilder authenticationManagerBuilder,
      JwtEncoder jwtEncoder) {
    this.a0010Service = a0010Service;
    this.authenticationManagerBuilder = authenticationManagerBuilder;
    this.jwtEncoder = jwtEncoder;
  }

  /**
   * ログイン処理
   *
   * @param inDto パラメータ
   * @return ログイン情報
   */
  @Operation(
      summary = "ログイン処理",
      description = "ログイン情報を取得する",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "成功",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = A0010ApiResult.class))),
        @ApiResponse(
            responseCode = "500",
            description = "システムエラー",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorInfo.class)))
      })
  @PostMapping("/auth")
  public ResponseEntity<?> authorize(@Valid @RequestBody A0010Dto inDto) {

    // ユーザーIDとパスワードを使って認証トークンを作成
    UsernamePasswordAuthenticationToken authenticationToken =
        new UsernamePasswordAuthenticationToken(inDto.getUserId(), inDto.getPassword());

    // 認証マネージャで認証を実行
    Authentication authentication =
        authenticationManagerBuilder.getObject().authenticate(authenticationToken);

    // 認証情報をセキュリティコンテキストに設定
    SecurityContextHolder.getContext().setAuthentication(authentication);

    // 認証後のユーザー情報を取得
    CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

    // ログイン情報取得
    ApiResult<A0010ReturnData> ret = a0010Service.getLoginInfo(userDetails);

    if (ret.getError() != null) {
      // レスポンスを返却
      return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    A0010ReturnData data = ret.getData();

    // JWTを作成
    String jwt =
        this.createToken(
            authentication, inDto.getUserId(), data.getAccountKubun(), data.getPositionInfo());

    // HTTPヘッダーにJWTを設定
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setBearerAuth(jwt);

    // ユーザー情報にJWTをセット

    data.setIdToken(jwt);

    // ユーザー情報とJWT付きのレスポンスを返却
    return new ResponseEntity<>(ret, httpHeaders, HttpStatus.OK);
  }

  /**
   * JWTトークンを作成するメソッド
   *
   * @param authentication 認証情報
   * @param accountKubun アカウント区分
   * @param positionInfo 役職情報
   * @return JWT
   */
  private String createToken(
      Authentication authentication,
      String loginId,
      String accountKubun,
      PositionDto positionInfo) {

    // 認証されたユーザーの権限をスペース区切りで結合
    String authorities =
        authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.joining(" "));

    // トークンの発行時間と有効期限を設定
    Instant now = Instant.now();
    Instant validity;
    validity = now.plus(this.tokenValidityInSeconds, ChronoUnit.SECONDS);

    // JWTのクレームを作成
    JwtClaimsSet.Builder claimsBuilder =
        JwtClaimsSet.builder()
            .issuedAt(now)
            .expiresAt(validity)
            .subject(authentication.getName())
            .claim(AUTHORITIES_KEY, authorities);

    // ログインID
    claimsBuilder.claim(CommonConstants.HTTP_HEADER_LOGIN_ID, loginId);

    // アカウント区分
    claimsBuilder.claim(CommonConstants.HTTP_HEADER_ACCOUNT_K, accountKubun);

    // 役職情報
    if (positionInfo != null) {
      // 役職コード
      claimsBuilder.claim(CommonConstants.HTTP_HEADER_POSITION_CD, positionInfo.getPositionCd());
      // 承認権限
      claimsBuilder.claim(CommonConstants.HTTP_HEADER_CONFIRM_PERM, positionInfo.getConfirmPerm());
      // 削除権限
      claimsBuilder.claim(CommonConstants.HTTP_HEADER_DELETE_PERM, positionInfo.getDeletePerm());
      // 編集権限
      claimsBuilder.claim(CommonConstants.HTTP_HEADER_EDIT_PERM, positionInfo.getEditPerm());
      // 参照権限
      claimsBuilder.claim(CommonConstants.HTTP_HEADER_REFER_PERM, positionInfo.getReferPerm());
    }

    // JWTのヘッダーを作成
    JwsHeader jwsHeader = JwsHeader.with(JWT_ALGORITHM).build();
    // JWTをエンコードしてトークンを取得
    return this.jwtEncoder
        .encode(JwtEncoderParameters.from(jwsHeader, claimsBuilder.build()))
        .getTokenValue();
  }
}
