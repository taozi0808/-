package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;

/** メニュー情報 */
@Schema(name = "MenuItemDto", description = "メニュー情報")
public class MenuItemDto {
  /** メニュー項目ID */
  @Schema(description = "メニュー項目ID")
  private Integer id;

  /** 上位メニュー項目ID */
  @Schema(description = "上位メニュー項目ID")
  private Integer parentMenuItemId;

  /** 機能ID */
  @Schema(description = "機能ID")
  private String pg;

  /** 表示名 */
  @Schema(description = "表示名")
  private String menuItemNm;

  /** 表示PATH */
  @Schema(description = "表示PATH")
  private String menuItemPath;

  /** 表示ICON */
  @Schema(description = "表示ICON")
  private String menuItemIcon;

  /** 表示順 */
  @Schema(description = "表示順")
  private Integer displayOrder;

  /** アカウント区分 */
  @Schema(description = "説明チップ")
  private String menuItemTooltip;

  /** 子メニュー */
  @Schema(description = "子メニュー")
  private List<MenuItemDto> children = new ArrayList<>();

  public List<MenuItemDto> getChildren() {
    return children;
  }

  public void setChildren(List<MenuItemDto> children) {
    this.children = children;
  }

  public String getMenuItemTooltip() {
    return menuItemTooltip;
  }

  public void setMenuItemTooltip(String menuItemTooltip) {
    this.menuItemTooltip = menuItemTooltip;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public String getMenuItemIcon() {
    return menuItemIcon;
  }

  public void setMenuItemIcon(String menuItemIcon) {
    this.menuItemIcon = menuItemIcon;
  }

  public String getMenuItemPath() {
    return menuItemPath;
  }

  public void setMenuItemPath(String menuItemPath) {
    this.menuItemPath = menuItemPath;
  }

  public String getMenuItemNm() {
    return menuItemNm;
  }

  public void setMenuItemNm(String menuItemNm) {
    this.menuItemNm = menuItemNm;
  }

  public String getPg() {
    return pg;
  }

  public void setPg(String pg) {
    this.pg = pg;
  }

  public Integer getParentMenuItemId() {
    return parentMenuItemId;
  }

  public void setParentMenuItemId(Integer parentMenuItemId) {
    this.parentMenuItemId = parentMenuItemId;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
}
