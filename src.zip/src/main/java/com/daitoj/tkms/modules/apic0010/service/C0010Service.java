package com.daitoj.tkms.modules.apic0010.service;

import com.daitoj.tkms.domain.MPosition;
import com.daitoj.tkms.modules.apic0010.repository.C0010Repository;
import com.daitoj.tkms.modules.apic0010.service.dto.C0010ReturnData;
import com.daitoj.tkms.modules.apic0010.service.dto.C0010S01Dto;
import com.daitoj.tkms.modules.apic0010.service.dto.C0010S02Dto;
import com.daitoj.tkms.modules.apic0010.service.dto.C0010S03Dto;
import com.daitoj.tkms.modules.apic0010.service.dto.GaisanInfoDto;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.constants.Message;
import com.daitoj.tkms.modules.common.repository.MItemListSettingRepository;
import com.daitoj.tkms.modules.common.repository.MPositionRepository;
import com.daitoj.tkms.modules.common.service.ReportService;
import com.daitoj.tkms.modules.common.service.dto.ApiResult;
import com.daitoj.tkms.modules.common.service.dto.PaginationMeta;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/** 概算一覧ビジネスロジック */
@Service
public class C0010Service {

  private static final Logger LOG = LoggerFactory.getLogger(C0010Service.class);

  /** DB日付フォーマット */
  private static final String DATE_FORMAT = "yyyyMMdd";

  /** 帳票日付フォーマット */
  private static final String PDF_DATE_FORMAT = "yyyy年MM年dd日HH:mm:ss";

  /** CSVヘッダ */
  private static final String[] CSV_HEADER = {
    "案件コード", "概算コード", "案件名", "顧客コード", "顧客名", "見積提出期限", "概算金額", "着工希望時期", "完工希望時期", "概算部門", "概算担当者"
  };


  /** 役職情報リポジトリ */
  private final MPositionRepository mpositionRepository;

  /** マスタデータリポジトリ */
  private final MItemListSettingRepository mitemListSettingRepository;

  /** 概算一覧のクエリ */
  private final C0010Repository c0010Repository;

  /** メッセージ */
  private final MessageSource messageSource;

  /** レポートサービス */
  private final ReportService reportService;

  /** fasterxml.jacksonのObjectMapper */
  private final ObjectMapper objectMapper;

  /** CSVファイル名 */
  public static final String APP_NAME = "概算一覧";

  /** レポートファイル名 */
  public static final String REPORT_FILE_NAME = "C0010.jasper";

  /** コンストラクタ */
  public C0010Service(
      MPositionRepository mpositionRepository,
      MItemListSettingRepository mitemListSettingRepository,
      C0010Repository c0010Repository,
      MessageSource messageSource,
      ReportService reportService,
      ObjectMapper objectMapper) {
    this.mpositionRepository = mpositionRepository;
    this.mitemListSettingRepository = mitemListSettingRepository;
    this.c0010Repository = c0010Repository;
    this.messageSource = messageSource;
    this.reportService = reportService;
    this.objectMapper = objectMapper;
  }

  /**
   * 初期表示
   *
   * @param inDto 概算情報取得パラメータ
   * @return 概算情報取得結果
   */
  public ApiResult<C0010ReturnData> getInitInfo(C0010S01Dto inDto, Pageable pageable) {
    try {
        // 権限リストを取得
        List<MPosition> authInfoList =
            mpositionRepository.findByPositionCdAndDelFlg(
                inDto.getYakusyokuCode(), CommonConstants.DELETE_FLAG_VALID);

      // 取得件数が０件だった場合
      if (CollectionUtils.isEmpty(authInfoList)) {
        // メッセージ
        String msg =
            messageSource.getMessage(Message.MSGID_K00006, null, LocaleContextHolder.getLocale());

        LOG.warn(msg);

        // 結果情報
        return ApiResult.error(Message.MSGID_K00006, msg);
      }

      // 編集権限＝"1"のレコード数
      long hensyuuCount =
          authInfoList.stream()
              .filter(info -> CommonConstants.HAS_PERMISSION.equals(info.getEditPerm()))
              .count();

      // 参照権限＝"1"のレコード数
      long sansyouCount =
          authInfoList.stream()
              .filter(info -> CommonConstants.HAS_PERMISSION.equals(info.getReferPerm()))
              .count();

      // 編集権限 (編集権限＝"1"のレコードが１件以上の場合は”1”、０件の場合は"0")
      String hensyuuKengen =
          hensyuuCount > 1 ? CommonConstants.HAS_PERMISSION : CommonConstants.NO_PERMISSION;
      // 参照権限 (参照権限＝"1"のレコードが１件以上の場合は”1”、０件の場合は"0")
      String sansyouKengen =
          sansyouCount > 1 ? CommonConstants.HAS_PERMISSION : CommonConstants.NO_PERMISSION;

      // 概算情報を取得
      Page<GaisanInfoDto> ankenList =
          c0010Repository.getGaisanInfo(CommonConstants.DELETE_FLAG_VALID, pageable);

      // 戻り値
      C0010ReturnData returnData = new C0010ReturnData();
      // 概算情報リスト
      returnData.setListGaisanInfo(ankenList.getContent());
      // 編集権限
      returnData.setHensyuuKengen(hensyuuKengen);
      // 参照権限
      returnData.setSansyouKengen(sansyouKengen);

      // ページ情報
      PaginationMeta meta = new PaginationMeta(ankenList);

      return ApiResult.success(returnData, meta);

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw ex;
    }
  }

  /**
   * 検索処理
   *
   * @param inDto 概算情報取得パラメータ
   * @return 概算情報取得結果
   */
  public ApiResult<C0010ReturnData> getAnkenInfo(C0010S01Dto inDto, Pageable pageable) {
    try {
      // 概算情報を取得
      Page<GaisanInfoDto> ankenList =
          c0010Repository.searchGaisanInfo(
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getGaisanCode(),
              inDto.getKokyakuCode(),
              inDto.getKokyakuName(),
              inDto.getTeisyutsukigenStart(),
              inDto.getTeisyutsukigenEnd(),
              inDto.getGaisanTantousyaCode(),
              inDto.getGaisanTantousya(),
              CommonConstants.DELETE_FLAG_VALID,
              pageable);

      // 取得件数が０件だった場合
      if (CollectionUtils.isEmpty(ankenList.getContent())) {
        // メッセージ
        String msg =
            messageSource.getMessage(Message.MSGID_K00001, null, LocaleContextHolder.getLocale());

        LOG.info(msg);

        // 結果情報
        return ApiResult.error(Message.MSGID_K00001, msg);
      }

      // 戻り値
      C0010ReturnData returnData = new C0010ReturnData();
      // 概算情報リスト
      returnData.setListGaisanInfo(ankenList.getContent());

      // ページ情報
      PaginationMeta meta = new PaginationMeta(ankenList);

      return ApiResult.success(returnData, meta);

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw ex;
    }
  }

  /**
   * CSV出力
   *
   * @param inDto 概算情報取得パラメータ
   * @param outputStream Stream
   */
  public void downLoadCsv(C0010S02Dto inDto, OutputStream outputStream) throws Exception {
    try {
      // ヘッダ設定（カンマ区切り）
      CSVFormat csvFormat =
          CSVFormat.DEFAULT
              .builder()
              .setDelimiter(',')
              .setQuoteMode(QuoteMode.ALL)
              .setHeader(CSV_HEADER)
              .get();

      // 概算情報を取得
      Page<GaisanInfoDto> ankenList =
          c0010Repository.searchGaisanInfo(
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getGaisanCode(),
              inDto.getKokyakuCode(),
              inDto.getKokyakuName(),
              inDto.getTeisyutsukigenStart(),
              inDto.getTeisyutsukigenEnd(),
              inDto.getGaisanTantousyaCode(),
              inDto.getGaisanTantousya(),
              CommonConstants.DELETE_FLAG_VALID,
              Pageable.unpaged());

      Charset charset = Charset.forName(CommonConstants.CSV_CHARSET_SHIFT_JIS);

      try (CSVPrinter printer =
          new CSVPrinter(new OutputStreamWriter(outputStream, charset), csvFormat)) {
        // データがある場合
        if (!CollectionUtils.isEmpty(ankenList.getContent())) {
          for (GaisanInfoDto ankenInfo : ankenList) {
            // 明細行設定
            printer.printRecord(
                ankenInfo.getAnkenCode(),
                ankenInfo.getGaisanCode(),
                ankenInfo.getAnkenName(),
                ankenInfo.getKokyakuCode(),
                ankenInfo.getKokyakuName(),
                ankenInfo.getMitsumoriTeisyutsuYmd(),
                ankenInfo.getGaisankingaku(),
                ankenInfo.getChakkouKibouYmd(),
                ankenInfo.getKankouKibouYmd(),
                ankenInfo.getGaisanBumon(),
                ankenInfo.getGaisanTantousya());
          }
        }
      }

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw ex;
    }
  }

  /**
   * 印刷処理
   *
   * @param inDto 概算情報印刷パラメータ
   * @return pdf
   */
  public byte[] exportReportToPdf(C0010S02Dto inDto) throws Exception {
    try {
      // 概算情報を取得
      Page<GaisanInfoDto> ankenList =
          c0010Repository.searchGaisanInfo(
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getGaisanCode(),
              inDto.getKokyakuCode(),
              inDto.getKokyakuName(),
              inDto.getTeisyutsukigenStart(),
              inDto.getTeisyutsukigenEnd(),
              inDto.getGaisanTantousyaCode(),
              inDto.getGaisanTantousya(),
              CommonConstants.DELETE_FLAG_VALID,
              Pageable.unpaged());

      // 印刷パラメータ
      C0010S03Dto printDto = new C0010S03Dto();
      // 利用PCのシステム日付
      printDto.setSysDate(inDto.getSysDate().format(DateTimeFormatter.ofPattern(PDF_DATE_FORMAT)));

      // レポートに渡すパラメータ
      Map<String, Object> paramsMap =
          objectMapper.convertValue(printDto, new TypeReference<Map<String, Object>>() {});

      // データソースを生成する
      JRDataSource dataSource = new JRBeanCollectionDataSource(ankenList.getContent());

      // レポートを生成する
      return reportService.exportReportToPdf(REPORT_FILE_NAME, paramsMap, dataSource);
    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw ex;
    }
  }
}
