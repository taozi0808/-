package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** お知らせ情報 */
@Schema(name = "NotificationDto", description = "お知らせ情報")
public class NotificationDto {
  /** お知らせID */
  @Schema(description = "お知らせID")
  private Long id;

  /** 通知区分 */
  @Schema(description = "通知区分")
  private String notificationK;

  /** お知らせタイトル */
  @Schema(description = "お知らせタイトル")
  private String notificationTitle;

  /** お知らせ内容 */
  @Schema(description = "お知らせ内容")
  private String notificationContent;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getNotificationK() {
    return notificationK;
  }

  public void setNotificationK(String notificationK) {
    this.notificationK = notificationK;
  }

  public String getNotificationTitle() {
    return notificationTitle;
  }

  public void setNotificationTitle(String notificationTitle) {
    this.notificationTitle = notificationTitle;
  }

  public String getNotificationContent() {
    return notificationContent;
  }

  public void setNotificationContent(String notificationContent) {
    this.notificationContent = notificationContent;
  }
}
