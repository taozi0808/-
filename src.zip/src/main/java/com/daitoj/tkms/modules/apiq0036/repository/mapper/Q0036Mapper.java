//package com.daitoj.tkms.modules.apiq0036.repository.mapper;
//
//import com.daitoj.tkms.modules.apiq0036.service.dto.SyozokuBusyoCodeItem;
//import com.daitoj.tkms.modules.apiq0036.service.dto.Q0036S01Dto;
//import org.mapstruct.Mapper;
//
//import java.util.Collections;
//import java.util.List;
//import java.util.stream.Collectors;
//
///** 作業員名簿業者一覧マッパー */
//@Mapper(componentModel = "spring")
//public interface Q0036Mapper {
//
//  /**
//   * DTOマッピング
//   *
//   * @param dto 作業員名簿業者一覧パラメータ
//   * @return 所属部署役職コード
//   */
//  @SuppressWarnings({"checkstyle:Indentation", "checkstyle:RequireEmptyLineBeforeBlockTagGroup"})
//  default List<String> getSbSyozokuCodes(Q0036S01Dto dto) {
//    if (dto == null || dto.getListSyozokuBusyoCode() == null) {
//      return Collections.emptyList();
//    }
//    return dto.getListSyozokuBusyoCode().stream()
//        .map(SyozokuBusyoCodeItem::getSbSyozokuCode)
//        .collect(Collectors.toList());
//  }
//}
