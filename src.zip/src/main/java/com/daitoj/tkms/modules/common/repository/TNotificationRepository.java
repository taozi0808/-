package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.TNotification;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** お知らせ情報リポジトリ */
@Repository
public interface TNotificationRepository extends JpaRepository<TNotification, Long> {

  /**
   * お知らせ情報を取得
   *
   * @param delFlg 削除フラグ
   * @return お知らせ情報
   */
  List<TNotification> findByDelFlgOrderById(@Param("delFlg") String delFlg);
}
