package com.daitoj.tkms.modules.common.web.rest;

import com.daitoj.tkms.modules.common.service.CloudStorageService;
import com.daitoj.tkms.modules.common.service.dto.ErrorInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** ストレージコントローラ */
@RestController
@Tag(name = "tkmsapi", description = "ストレージのAPI")
@RequestMapping("/api/v1/storage")
public class StorageResource {

  /** ストレージサービス */
  private final CloudStorageService cloudStorageService;

  /** コンストラクタ */
  public StorageResource(CloudStorageService cloudStorageService) {
    this.cloudStorageService = cloudStorageService;
  }

  /**
   * ファイルアップロード
   *
   * @param file ファイル
   * @return オブジェクト名
   */
  @Operation(
      summary = "ファイルアップロード",
      description = "ファイルをアップロードする",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "成功",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ResponseEntity.class))),
        @ApiResponse(
            responseCode = "500",
            description = "システムエラー",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorInfo.class)))
      })
  @PostMapping("/upload")
  public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file) {

    // オブジェクト名
    String objectName = cloudStorageService.upload(file);

    // 結果
    Map<String, String> ret = new HashMap<>();
    ret.put("objectName", objectName);

    return ResponseEntity.ok().body(ret);
  }

  /**
   * ファイルをダウンロードする
   *
   * @param objectName オブジェクト名
   * @return ファイルStream
   */
  @Operation(
      summary = "ファイルダウンロード",
      description = "ファイルをダウンロードする",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "成功",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ResponseEntity.class))),
        @ApiResponse(
            responseCode = "500",
            description = "システムエラー",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorInfo.class)))
      })
  @GetMapping("/download")
  public ResponseEntity<InputStreamResource> download(
      @RequestParam("objectName") String objectName) {

    // パス
    Path filePath = Paths.get(objectName);
    // // ファイル名
    String fileName = filePath.getFileName().toString();
    String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);

    // ファイルStream
    InputStream inputStream = cloudStorageService.download(objectName);
    InputStreamResource resource = new InputStreamResource(inputStream);

    return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE)
        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + encodedFileName)
        .body(resource);
  }

  /**
   * ファイルUrlを取得する
   *
   * @param objectName オブジェクト名
   * @return ファイルUrl
   */
  @Operation(
      summary = "ファイルUrl取得",
      description = "ファイルUrlを取得する",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "成功",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ResponseEntity.class))),
        @ApiResponse(
            responseCode = "500",
            description = "システムエラー",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorInfo.class)))
      })
  @GetMapping("/get")
  public ResponseEntity<?> getUrl(@RequestParam("objectName") String objectName) {

    // ファイルUrl
    String url = cloudStorageService.createUrl(objectName);

    // 結果
    Map<String, String> ret = new HashMap<>();
    ret.put("url", url);

    return ResponseEntity.ok().body(ret);
  }
}
