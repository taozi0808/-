package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** 業者情報ヘッダ情報 */
@Schema(name = "VendorHdrDto", description = "業者情報ヘッダ情報")
public class VendorHdrDto {

  /** 業者情報ヘッダID */
  @Schema(description = "業者情報ヘッダID")
  private Long id;

  /** 業者コード */
  @Schema(description = "業者コード")
  private String vendorCd;

  /** 業者支店コード */
  @Schema(description = "業者支店コード")
  private String vendorBranchCd;

  /** 業者名 */
  @Schema(description = "業者名")
  private String vendorNm;

  /** 業者支店名 */
  @Schema(description = "業者支店名")
  private String vendorBranchNm;

  /** ログインID */
  @Schema(description = "ログインID")
  private String loginId;

  /** メールアドレス */
  @Schema(description = "メールアドレス")
  private String mailAddress;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getVendorCd() {
    return vendorCd;
  }

  public void setVendorCd(String vendorCd) {
    this.vendorCd = vendorCd;
  }

  public String getVendorBranchCd() {
    return vendorBranchCd;
  }

  public void setVendorBranchCd(String vendorBranchCd) {
    this.vendorBranchCd = vendorBranchCd;
  }

  public String getVendorNm() {
    return vendorNm;
  }

  public void setVendorNm(String vendorNm) {
    this.vendorNm = vendorNm;
  }

  public String getVendorBranchNm() {
    return vendorBranchNm;
  }

  public void setVendorBranchNm(String vendorBranchNm) {
    this.vendorBranchNm = vendorBranchNm;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }

  public String getMailAddress() {
    return mailAddress;
  }

  public void setMailAddress(String mailAddress) {
    this.mailAddress = mailAddress;
  }
}
