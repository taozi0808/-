package com.daitoj.tkms.modules.common.constants;

/** マスタデータ定義 */
public class MasterData {
  /** 項目分類コード(受注状態) */
  public static final String ITEM_CLASS_CD_D0001 = "D0001";

  /** 項目分類コード(進捗度) */
  public static final String ITEM_CLASS_CD_D0003 = "D0003";
}
