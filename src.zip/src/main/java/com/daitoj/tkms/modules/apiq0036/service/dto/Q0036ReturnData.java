package com.daitoj.tkms.modules.apiq0036.service.dto;

import com.daitoj.tkms.modules.common.service.dto.MitemSettingDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.ArrayList;
import java.util.List;

/** 作業員名簿業者一覧検索結果 */
@Schema(name = "Q0036ReturnData", description = "作業員名簿業者一覧検索結果")
public class Q0036ReturnData {

  /** 作業員名簿業者リスト */
  private List<AnkenInfoDto> listAnkenInfo = new ArrayList<>();

  /** 編集権限 */
  private String hensyuuKengen;

  /** 参照権限 */
  private String sansyouKengen;

  /** マスタデータ(受注状態) */
  private List<MitemSettingDto> mitemSettingD0001;

  @Schema(
      name = "listAnkenInfo",
      description = "作業員名簿業者リスト",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("listAnkenInfo")
  public List<AnkenInfoDto> getListAnkenInfo() {
    return listAnkenInfo;
  }

  public void setListAnkenInfo(List<AnkenInfoDto> listAnkenInfo) {
    this.listAnkenInfo = listAnkenInfo;
  }

  @Schema(
      name = "hensyuuKengen",
      description = "編集権限",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("hensyuuKengen")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public String getHensyuuKengen() {
    return hensyuuKengen;
  }

  public void setHensyuuKengen(String hensyuuKengen) {
    this.hensyuuKengen = hensyuuKengen;
  }

  @Schema(
      name = "sansyouKengen",
      description = "参照権限",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sansyouKengen")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public String getSansyouKengen() {
    return sansyouKengen;
  }

  public void setSansyouKengen(String sansyouKengen) {
    this.sansyouKengen = sansyouKengen;
  }

  @Schema(name = "mitemSettingD0001", description = "スタデータ(受注状態)")
  @JsonProperty("mitemSettingD0001")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public List<MitemSettingDto> getMitemSettingD0001() {
    return mitemSettingD0001;
  }

  public void setMitemSettingD0001(List<MitemSettingDto> mitemSettingD0001) {
    this.mitemSettingD0001 = mitemSettingD0001;
  }
}
