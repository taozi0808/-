package com.daitoj.tkms.modules.apic0010.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;

/** 概算一覧検索結果 */
@Schema(name = "C0010ReturnData", description = "概算一覧検索結果")
public class C0010ReturnData {

  /** 概算情報リスト */
  private List<GaisanInfoDto> listGaisanInfo = new ArrayList<>();

  /** 編集権限 */
  private String hensyuuKengen;

  /** 参照権限 */
  private String sansyouKengen;

  @Schema(
      name = "listGaisanInfo",
      description = "概算情報リスト",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("listGaisanInfo")
  public List<GaisanInfoDto> getListGaisanInfo() {
    return listGaisanInfo;
  }

  public void setListGaisanInfo(List<GaisanInfoDto> listGaisanInfo) {
    this.listGaisanInfo = listGaisanInfo;
  }

  @Schema(
      name = "hensyuuKengen",
      description = "編集権限",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("hensyuuKengen")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public String getHensyuuKengen() {
    return hensyuuKengen;
  }

  public void setHensyuuKengen(String hensyuuKengen) {
    this.hensyuuKengen = hensyuuKengen;
  }

  @Schema(
      name = "sansyouKengen",
      description = "参照権限",
      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sansyouKengen")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public String getSansyouKengen() {
    return sansyouKengen;
  }

  public void setSansyouKengen(String sansyouKengen) {
    this.sansyouKengen = sansyouKengen;
  }
}
