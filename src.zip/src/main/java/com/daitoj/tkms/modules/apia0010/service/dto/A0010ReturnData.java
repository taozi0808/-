package com.daitoj.tkms.modules.apia0010.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;

/** ログイン結果 */
@Schema(name = "A0010ReturnData", description = "ログイン結果")
public class A0010ReturnData {
  /** アカウント区分 */
  @Schema(description = "アカウント区分")
  private String accountKubun;

  /** メニュー情報 */
  @Schema(description = "メニュー情報")
  private List<MenuItemDto> menuItemList;

  /** 従業員情報 */
  @Schema(description = "従業員情報")
  private EmpDto empInfo;

  /** 業者情報ヘッダ */
  @Schema(description = "業者情報ヘッダ")
  private VendorHdrDto vendorHdrInfo;

  /** 作業員情報ヘッダ */
  @Schema(description = "作業員情報ヘッダ")
  private WorkerDto workerInfo;

  /** 役職情報 */
  @Schema(description = "役職情報")
  private PositionDto positionInfo;

  /** お知らせ情報 */
  @Schema(description = "お知らせ情報")
  private List<NotificationDto> notificationList;

  /** 協力会お知らせ情報 */
  @Schema(description = "協力会お知らせ情報")
  private List<PartnerNotificationDto> partnerNotificationList;

  /** Token */
  @Schema(description = "Token")
  private String idToken;

  public String getAccountKubun() {
    return accountKubun;
  }

  public void setAccountKubun(String accountKubun) {
    this.accountKubun = accountKubun;
  }

  @JsonProperty("id_token")
  public String getIdToken() {
    return idToken;
  }

  public void setIdToken(String idToken) {
    this.idToken = idToken;
  }

  public List<MenuItemDto> getMenuItemList() {
    return menuItemList;
  }

  public void setMenuItemList(List<MenuItemDto> menuItemList) {
    this.menuItemList = menuItemList;
  }

  public EmpDto getEmpInfo() {
    return empInfo;
  }

  public void setEmpInfo(EmpDto empInfo) {
    this.empInfo = empInfo;
  }

  public VendorHdrDto getVendorHdrInfo() {
    return vendorHdrInfo;
  }

  public void setVendorHdrInfo(VendorHdrDto vendorHdrInfo) {
    this.vendorHdrInfo = vendorHdrInfo;
  }

  public WorkerDto getWorkerInfo() {
    return workerInfo;
  }

  public void setWorkerInfo(WorkerDto workerInfo) {
    this.workerInfo = workerInfo;
  }

  public List<NotificationDto> getNotificationList() {
    return notificationList;
  }

  public void setNotificationList(List<NotificationDto> notificationList) {
    this.notificationList = notificationList;
  }

  public List<PartnerNotificationDto> getPartnerNotificationList() {
    return partnerNotificationList;
  }

  public void setPartnerNotificationList(List<PartnerNotificationDto> partnerNotificationList) {
    this.partnerNotificationList = partnerNotificationList;
  }

  public PositionDto getPositionInfo() {
    return positionInfo;
  }

  public void setPositionInfo(PositionDto positionInfo) {
    this.positionInfo = positionInfo;
  }
}
