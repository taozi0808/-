//package com.daitoj.tkms.modules.apiq0036.service.dto;
//
//import com.daitoj.tkms.modules.common.service.dto.BasePageRequest;
//import com.fasterxml.jackson.annotation.JsonFormat;
//import io.swagger.v3.oas.annotations.media.Schema;
//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotNull;
//import jakarta.validation.constraints.Size;
//import org.springframework.format.annotation.DateTimeFormat;
//
///** 案件一覧パラメータ */
//@Schema(name = "Q0036S01Dto", description = "作業員名簿業者一覧パラメータ")
//public class Q0036S01Dto extends BasePageRequest {
//
//  /** 所属部署コードリスト */
//  @NotNull
//  @Valid
//  @Size(min = 1)
//  private List<@Valid SyozokuBusyoCodeItem> listSyozokuBusyoCode = new ArrayList<>();
//
//  /** 業者コード */
//  private String gyousyaCode;
//
//  /** 業者名 */
//  private String gyousyaName;
//
//  /** 産廃許可期限 */
//  private String sanhaiKyokaKigen;
//
//  /** 業種 */
//  private String gyousyu;
//
//  /** 解体登録 */
//  private String kaitaiTouroku;
//
//  /** 警備認定 */
//  private String keibiNintei;
//
//  /** 産廃許可 */
//  private String sanhaiKyoka;
//
//  /** 現場コード */
//  private String genbaCode;
//
//  /** 現場名 */
//  private String genbaName;
//
//  /** 注文書No */
//  private String tyuumonsyoNumber;
//
//  /** 大工種 */
//  private String daikusyu;
//
//  /** 該当着手日（開始） */
//  @DateTimeFormat(pattern = "yyyy-MM-dd")
//  private LocalDate gaitouTyakusyuYmdStart;
//
//  /** 該当着手日（終了） */
//  @DateTimeFormat(pattern = "yyyy-MM-dd")
//  private LocalDate gaitouTyakusyYmdEnd;
//
//  /** 該当引渡日（開始） */
//  @DateTimeFormat(pattern = "yyyy-MM-dd")
//  private LocalDate gaitouHikiwatashiYmdStart;
//
//  /** 該当引渡日（終了） */
//  @DateTimeFormat(pattern = "yyyy-MM-dd")
//  private LocalDate gaitouHikiwatashiYmdEnd;
//
//  @Schema(
//      name = "listSyozokuBusyoCode",
//      description = "所属部署コードリスト",
//      requiredMode = Schema.RequiredMode.REQUIRED)
//  public List<@Valid SyozokuBusyoCodeItem> getListSyozokuBusyoCode() {
//    return listSyozokuBusyoCode;
//  }
//
//  public void setListSyozokuBusyoCode(List<@Valid SyozokuBusyoCodeItem> listSyozokuBusyoCode) {
//    this.listSyozokuBusyoCode = listSyozokuBusyoCode;
//  }
//
//  @Schema(
//      name = "gyousyaCode",
//      description = "業者コード",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getGyousyaCode() {
//    return gyousyaCode;
//  }
//
//  public void setGyousyaCode(String angyousyaCodekenCode) {
//    this.gyousyaCode = gyousyaCode;
//  }
//
//  @Schema(
//      name = "gyousyaName",
//      description = "業者名",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getGyousyaName() {
//    return gyousyaName;
//  }
//
//  public void setGyousyaName(String gyousyaName) {
//    this.gyousyaName = gyousyaName;
//  }
//
//  @Schema(
//      name = "sanhaiKyokaKigen",
//      description = "産廃許可期限",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getSanhaiKyokaKigen() {
//    return sanhaiKyokaKigen;
//  }
//
//  public void setSanhaiKyokaKigen(String sanhaiKyokaKigen) {
//    this.sanhaiKyokaKigen = sanhaiKyokaKigen;
//  }
//
//  @Schema(name = "gyousyu", description = "業種", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getGyousyu() {
//    return gyousyu;
//  }
//
//  public void setGyousyu(String gyousyu) {
//    this.gyousyu = gyousyu;
//  }
//
//  @Schema(
//      name = "kaitaiTouroku",
//      description = "解体登録",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getKaitaiTouroku() {
//    return kaitaiTouroku;
//  }
//
//  public void setKaitaiTouroku(String kaitaiTouroku) {
//    this.kaitaiTouroku = kaitaiTouroku;
//  }
//
//  @Schema(
//      name = "keibiNintei",
//      description = "警備認定",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getKeibiNintei() {
//    return keibiNintei;
//  }
//
//  public void setKeibiNintei(String keibiNintei) {
//    this.keibiNintei = keibiNintei;
//  }
//
//  @Schema(
//      name = "sanhaiKyoka",
//      description = "産廃許可",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getSanhaiKyoka() {
//    return sanhaiKyoka;
//  }
//
//  public void setSanhaiKyoka(String sanhaiKyoka) {
//    this.sanhaiKyoka = sanhaiKyoka;
//  }
//
//  @Schema(
//      name = "genbaCode",
//      description = "現場コード",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getGenbaCode() {
//    return genbaCode;
//  }
//
//  public void setGenbaCode(String genbaCode) {
//    this.genbaCode = genbaCode;
//  }
//
//  @Schema(name = "genbaName", description = "現場名", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getGenbaName() {
//    return genbaName;
//  }
//
//  public void setGenbaName(String genbaName) {
//    this.genbaName = genbaName;
//  }
//
//  @Schema(
//      name = "tyuumonsyoNumber",
//      description = "注文書No",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getTyuumonsyoNumber() {
//    return tyuumonsyoNumber;
//  }
//
//  public void setTyuumonsyoNumber(String tyuumonsyoNumber) {
//    this.tyuumonsyoNumber = tyuumonsyoNumber;
//  }
//
//  @Schema(name = "daikusyu", description = "大工種", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  public String getDaikusyu() {
//    return daikusyu;
//  }
//
//  public void setDaikusyu(String daikusyu) {
//    this.daikusyu = daikusyu;
//  }
//
//  @Schema(
//      name = "gaitouTyakusyuYmdStart",
//      description = "該当着手日（開始）(yyyy-MM-dd)",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  @JsonFormat(pattern = "yyyy-MM-dd")
//  public LocalDate getGaitouTyakusyuYmdStart() {
//    return gaitouTyakusyuYmdStart;
//  }
//
//  public void setGaitouTyakusyuYmdStart(LocalDate gaitouTyakusyuYmdStart) {
//    this.gaitouTyakusyuYmdStart = gaitouTyakusyuYmdStart;
//  }
//
//  @Schema(
//      name = "gaitouTyakusyYmdEnd",
//      description = "該当着手日（終了）(yyyy-MM-dd)",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  @JsonFormat(pattern = "yyyy-MM-dd")
//  public LocalDate getGaitouTyakusyYmdEnd() {
//    return gaitouTyakusyYmdEnd;
//  }
//
//  public void setGaitouTyakusyYmdEnd(LocalDate gaitouTyakusyYmdEnd) {
//    this.gaitouTyakusyYmdEnd = gaitouTyakusyYmdEnd;
//  }
//
//  @Schema(
//      name = "gaitouHikiwatashiYmdStart",
//      description = "該当引渡日（開始）(yyyy-MM-dd)",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  @JsonFormat(pattern = "yyyy-MM-dd")
//  public LocalDate getGaitouHikiwatashiYmdStart() {
//    return gaitouHikiwatashiYmdStart;
//  }
//
//  public void setGaitouHikiwatashiYmdStart(LocalDate gaitouHikiwatashiYmdStart) {
//    this.gaitouHikiwatashiYmdStart = gaitouHikiwatashiYmdStart;
//  }
//
//  @Schema(
//      name = "gaitouHikiwatashiYmdEnd",
//      description = "該当引渡日（終了）(yyyy-MM-dd)",
//      requiredMode = Schema.RequiredMode.NOT_REQUIRED)
//  @JsonFormat(pattern = "yyyy-MM-dd")
//  public LocalDate getGaitouHikiwatashiYmdEnd() {
//    return gaitouHikiwatashiYmdEnd;
//  }
//
//  public void setGaitouHikiwatashiYmdEnd(LocalDate gaitouHikiwatashiYmdEnd) {
//    this.gaitouHikiwatashiYmdEnd = gaitouHikiwatashiYmdEnd;
//  }
//}
