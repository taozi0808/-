package com.daitoj.tkms.modules.apib0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;

/** 案件一覧印刷パラメータ */
@Schema(name = "B0010S03Dto", description = "案件一覧印刷パラメータ")
public class B0010S03Dto extends B0010S01Dto {

  /** 利用PCのシステム日付 */
  @Schema(
      name = "sysDate",
      description = "利用PCのシステム日付(yyyy年MM年dd日HH:mm:ss)",
      requiredMode = Schema.RequiredMode.REQUIRED)
  @NotNull
  private String sysDate;

  public String getSysDate() {
    return sysDate;
  }

  public void setSysDate(String sysDate) {
    this.sysDate = sysDate;
  }
}
