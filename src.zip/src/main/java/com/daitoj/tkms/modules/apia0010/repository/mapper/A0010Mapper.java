package com.daitoj.tkms.modules.apia0010.repository.mapper;

import com.daitoj.tkms.domain.MEmp;
import com.daitoj.tkms.domain.MMenuItem;
import com.daitoj.tkms.domain.MPosition;
import com.daitoj.tkms.domain.MVendorHdr;
import com.daitoj.tkms.domain.MWorker;
import com.daitoj.tkms.domain.TNotification;
import com.daitoj.tkms.domain.TPartnerNotification;
import com.daitoj.tkms.modules.apia0010.service.dto.EmpDto;
import com.daitoj.tkms.modules.apia0010.service.dto.MenuItemDto;
import com.daitoj.tkms.modules.apia0010.service.dto.NotificationDto;
import com.daitoj.tkms.modules.apia0010.service.dto.PartnerNotificationDto;
import com.daitoj.tkms.modules.apia0010.service.dto.PositionDto;
import com.daitoj.tkms.modules.apia0010.service.dto.VendorHdrDto;
import com.daitoj.tkms.modules.apia0010.service.dto.WorkerDto;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

/** ログインマッパー */
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface A0010Mapper {

  /**
   * メニュー情報からメニューDtoに変換する.
   *
   * @param menuItem メニュー
   * @return メニューDto
   */
  @Mapping(source = "pg.pgId", target = "pg")
  MenuItemDto toMenuItemDto(MMenuItem menuItem);

  /**
   * メニュー情報リストからメニューDtoリストに変換する.
   *
   * @param menuItems メニュー情報リスト
   * @return メニューDtoリスト
   */
  List<MenuItemDto> toMenuItemDtoList(List<MMenuItem> menuItems);

  /**
   * 従業員情報から従業員Dtoに変換する.
   *
   * @param emp 従業員
   * @return 従業員Dto
   */
  EmpDto toEmpDto(MEmp emp);

  /**
   * 業者情報ヘッダ情報から業者情報ヘッダDtoに変換する.
   *
   * @param vhd 業者情報ヘッダ
   * @return 業者情報ヘッダDto
   */
  VendorHdrDto toVendorHdrDto(MVendorHdr vhd);

  /**
   * 作業員情報から作業員Dtoに変換する.
   *
   * @param worker 作業員情報
   * @return 作業員Dto
   */
  WorkerDto toWorkerDto(MWorker worker);

  /**
   * お知らせ情報からお知らせ情報Dtoに変換する.
   *
   * @param notification お知らせ情報
   * @return お知らせ情報 Dto
   */
  NotificationDto toNotificationDto(TNotification notification);

  /**
   * お知らせ情報リストからお知らせ情報Dtoリストに変換する.
   *
   * @param notifications お知らせ情報リスト
   * @return お知らせ情報リスト
   */
  List<NotificationDto> toNotificationDtoList(List<TNotification> notifications);

  /**
   * 協力会お知らせ情報から協力会お知らせ情報Dtoに変換する.
   *
   * @param partNotification 協力会お知らせ情報
   * @return 協力会お知らせ情報 Dto
   */
  PartnerNotificationDto toPartnerNotificationDto(TPartnerNotification partNotification);

  /**
   * 協力会お知らせ情報リストから協力会お知らせ情報Dtoリストに変換する.
   *
   * @param partnerNotifications 協力会お知らせ情報リスト
   * @return 協力会お知らせ情報リスト
   */
  List<PartnerNotificationDto> toPartnerNotificationDtoList(
      List<TPartnerNotification> partnerNotifications);

  /**
   * 役職情報から役職Dtoに変換する.
   *
   * @param pos 役職情報
   * @return 役職情報Dto
   */
  PositionDto toPositionDto(MPosition pos);
}
