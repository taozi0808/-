//package com.daitoj.tkms.modules.apiq0036.repository;
//
//import com.daitoj.tkms.domain.AnkeninfoHeader;
//import com.daitoj.tkms.domain.AnkeninfoHeaderId;
//import com.daitoj.tkms.modules.apiq0036.service.dto.AnkenInfoDto;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import java.time.LocalDate;
//import java.util.List;
//
///** 作業員名簿業者一覧のリポジトリ */
//@Repository
//public interface Q0036Repository extends JpaRepository<AnkeninfoHeader, AnkeninfoHeaderId> {
//
//  /**
//   * 初期表示データ取得
//   *
//   * @param statusList 受注状態リスト
//   * @param deleteFlg 除フラグ削除フラグ
//   * @return 作業員名簿業者一覧
//   */
//  @Query(
//      "SELECT new com.daitoj.tkms.modules.apiq0036.service.dto.AnkenInfoDto("
//          + "ah.id.ankenCode, ah.id.ankenEdaCode, ah.ankenName, ah.kokyakuCode, "
//          + "kh.kokyakuName, ah.souteiKingaku, ah.genbaJyuusyo1, ah.genbaJyuusyo2, "
//          + "ah.jycyuuMikomiYmd, ah.cyakkouKibouYmd, ah.eigyouBumonCode, si.busyoName, "
//          + "ah.eigyouTantousyaCode, ji.jyuugyouinShi, ji.jyuugyouinMei, ji.jyuugyouinShimei, "
//          + "ah.shincyokudoCode, shi.shincyokudo) "
//          + "FROM AnkeninfoHeader ah "
//          + "INNER JOIN KokyakuInfoHeader kh ON ah.kokyakuCode = kh.kokyakuCode "
//          + "AND kh.deleteFlg = :deleteFlg "
//          + "INNER JOIN SoshikiInfo si ON ah.eigyouBumonCode = si.id.busyoCode "
//          + "AND ah.eigyouBumonTksYmd = si.id.tekiyouStratYmd "
//          + "AND si.deleteFlg = :deleteFlg "
//          + "INNER JOIN JyuugyouinInfo ji ON ah.eigyouTantousyaCode = ji.jyuugyouinCode "
//          + "INNER JOIN ShincyokudoInfo shi ON ah.shincyokudoCode = shi.shincyokudoCode "
//          + "AND shi.deleteFlg = :deleteFlg "
//          + "WHERE ah.jyucyuujYoutaiCode IN :statusList "
//          + "AND ah.deleteFlg = :deleteFlg")
//  Page<AnkenInfoDto> findInitInfo(
//      @Param("statusList") List<String> statusList,
//      @Param("deleteFlg") String deleteFlg,
//      Pageable pageable);
//
//  /**
//   * 検索処理
//   *
//   * @param statusList 受注状態リスト
//   * @param deleteFlg 除フラグ
//   * @param ankenCode 案件コード
//   * @param ankenName 案件名（ｶﾅ含む）
//   * @param kokyakuName 顧客名（ｶﾅ含む）
//   * @param startDate 受注見込時期（開始）
//   * @param endDate 受注見込時期（終了）
//   * @param bumonName 営業部門
//   * @param tantouName 営業担当者
//   * @return 案件一覧
//   */
//  @Query(
//      "SELECT new com.daitoj.tkms.modules.apia0010.service.dto.AnkenInfoDto("
//          + "ah.id.ankenCode, ah.id.ankenEdaCode, ah.ankenName, ah.kokyakuCode, "
//          + "kh.kokyakuName, ah.souteiKingaku, ah.genbaJyuusyo1, ah.genbaJyuusyo2, "
//          + "ah.jycyuuMikomiYmd, ah.cyakkouKibouYmd, ah.eigyouBumonCode, si.busyoName, "
//          + "ah.eigyouTantousyaCode, ji.jyuugyouinShi, ji.jyuugyouinMei, ji.jyuugyouinShimei, "
//          + "ah.shincyokudoCode, shi.shincyokudo) "
//          + "FROM AnkeninfoHeader ah "
//          + "INNER JOIN KokyakuInfoHeader kh ON ah.kokyakuCode = kh.kokyakuCode "
//          + "AND kh.deleteFlg = :deleteFlg "
//          + "INNER JOIN SoshikiInfo si ON ah.eigyouBumonCode = si.id.busyoCode "
//          + "AND ah.eigyouBumonTksYmd = si.id.tekiyouStratYmd "
//          + "AND si.deleteFlg = :deleteFlg "
//          + "INNER JOIN JyuugyouinInfo ji ON ah.eigyouTantousyaCode = ji.jyuugyouinCode "
//          + "INNER JOIN ShincyokudoInfo shi ON ah.shincyokudoCode = shi.shincyokudoCode "
//          + "AND shi.deleteFlg = :deleteFlg "
//          + "WHERE ah.deleteFlg = :deleteFlg "
//          + "AND (:ankenCode IS NULL OR ah.id.ankenCode LIKE %:ankenCode%) "
//          + "AND (:ankenName IS NULL OR ah.ankenName LIKE %:ankenName% "
//          + " OR ah.ankenKanaName LIKE %:ankenName%) "
//          + "AND ah.jyucyuujYoutaiCode IN :statusList "
//          + "AND (:kokyakuName IS NULL OR kh.kokyakuName LIKE %:kokyakuName% "
//          + " OR kh.kokyakuKanaName LIKE %:kokyakuName%) "
//          + "AND COALESCE(:startDate, ah.jycyuuMikomiYmd) <= ah.jycyuuMikomiYmd "
//          + "AND ah.jycyuuMikomiYmd <= COALESCE(:endDate, ah.jycyuuMikomiYmd) "
//          + "AND (:bumonName IS NULL OR si.busyoName LIKE %:bumonName%) "
//          + "AND (:tantouName IS NULL OR ji.jyuugyouinShimei LIKE %:tantouName%)")
//  Page<AnkenInfoDto> findAnkenInfo(
//      @Param("statusList") List<String> statusList,
//      @Param("deleteFlg") String deleteFlg,
//      @Param("ankenCode") String ankenCode,
//      @Param("ankenName") String ankenName,
//      @Param("kokyakuName") String kokyakuName,
//      @Param("startDate") LocalDate startDate,
//      @Param("endDate") LocalDate endDate,
//      @Param("bumonName") String bumonName,
//      @Param("tantouName") String tantouName,
//      Pageable pageable);
//}
