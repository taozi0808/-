package com.daitoj.tkms.modules.apib0010.service;

import com.daitoj.tkms.domain.MItemListSetting;
import com.daitoj.tkms.modules.apib0010.repository.B0010Repository;
import com.daitoj.tkms.modules.apib0010.service.dto.AnkenInfoDto;
import com.daitoj.tkms.modules.apib0010.service.dto.B0010ReturnData;
import com.daitoj.tkms.modules.apib0010.service.dto.B0010S01Dto;
import com.daitoj.tkms.modules.apib0010.service.dto.B0010S02Dto;
import com.daitoj.tkms.modules.apib0010.service.dto.B0010S03Dto;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.constants.MasterData;
import com.daitoj.tkms.modules.common.constants.Message;
import com.daitoj.tkms.modules.common.repository.MItemListSettingRepository;
import com.daitoj.tkms.modules.common.repository.mapper.MItemSettingMapper;
import com.daitoj.tkms.modules.common.service.ReportService;
import com.daitoj.tkms.modules.common.service.SystemException;
import com.daitoj.tkms.modules.common.service.dto.ApiResult;
import com.daitoj.tkms.modules.common.service.dto.MitemSettingDto;
import com.daitoj.tkms.modules.common.service.dto.PaginationMeta;
import com.daitoj.tkms.modules.common.utils.DateUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/** 案件一覧ビジネスロジック */
@Service
public class B0010Service {

  private static final Logger LOG = LoggerFactory.getLogger(B0010Service.class);

  /** 帳票日付フォーマット */
  private static final String PDF_DATE_FORMAT = "yyyy年MM年dd日HH:mm:ss";

  /** CSV日付フォーマット */
  private static final String CSV_DATE_FORMAT = "yyyy年MM年dd日";

  /** CSVヘッダ */
  private static final String[] CSV_HEADER = {
    "案件コード",
    "案件枝コード",
    "案件名",
    "顧客コード",
    "顧客名",
    "現場住所",
    "想定金額",
    "受注見込日",
    "着工希望日",
    "営業担当部門コード",
    "営業担当部門",
    "営業担当者コード",
    "営業担当者",
    "進捗度コード",
    "進捗度"
  };

  /** マスタデータのDTOマッパー */
  private final MItemSettingMapper mitemSettingMapper;

  /** マスタデータリポジトリ */
  private final MItemListSettingRepository mitemListSettingRepository;

  /** 案件一覧リポジトリ */
  private final B0010Repository b0010Repository;

  /** メッセージ */
  private final MessageSource messageSource;

  /** レポートサービス */
  private final ReportService reportService;

  /** fasterxml.jacksonのObjectMapper */
  private final ObjectMapper objectMapper;

  /** CSVファイル名 */
  public static final String APP_NAME = "案件一覧";

  /** レポートファイル名 */
  public static final String REPORT_FILE_NAME = "A0010.jasper";

  /** コンストラクタ */
  public B0010Service(
      MItemSettingMapper mitemSettingMapper,
      MItemListSettingRepository mitemListSettingRepository,
      B0010Repository b0010Repository,
      MessageSource messageSource,
      ReportService reportService,
      ObjectMapper objectMapper) {
    this.mitemSettingMapper = mitemSettingMapper;
    this.mitemListSettingRepository = mitemListSettingRepository;
    this.b0010Repository = b0010Repository;
    this.messageSource = messageSource;
    this.reportService = reportService;
    this.objectMapper = objectMapper;
  }

  /**
   * 初期表示
   *
   * @param inDto 案件情報取得パラメータ
   * @return 案件情報取得結果
   */
  public ApiResult<B0010ReturnData> getInitInfo(B0010S01Dto inDto, Pageable pageable) {
    try {
      // 案件情報を取得
      Page<AnkenInfoDto> ankenList =
          b0010Repository.findInitInfo(
              inDto.getListJyucyuuJyoutai(),
              CommonConstants.DELETE_FLAG_VALID,
              MasterData.ITEM_CLASS_CD_D0003,
              pageable);

      // マスタデータを取得
      List<MItemListSetting> mitemList =
          mitemListSettingRepository
              .findById_ItemClassCdAndId_EffectiveStartDtLessThanEqualAndDelFlgOrderByDisplayOrder(
                  MasterData.ITEM_CLASS_CD_D0001,
                  LocalDate.now().format(DateTimeFormatter.ofPattern(DateUtils.DATE_FORMAT)),
                  CommonConstants.DELETE_FLAG_VALID);

      // マスタデータDtoに変換する
      List<MitemSettingDto> dtoList = mitemSettingMapper.toDto(mitemList);

      // 戻り値
      B0010ReturnData returnData = new B0010ReturnData();
      // 案件情報リスト
      returnData.setListAnkenInfo(ankenList.getContent());
      // マスタデータ(受注状態)
      returnData.setMitemSettingD0001(dtoList);

      // ページ情報
      PaginationMeta meta = new PaginationMeta(ankenList);

      return ApiResult.success(returnData, meta);

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw new SystemException(ex.toString(), ex);
    }
  }

  /**
   * 検索処理
   *
   * @param inDto 案件情報取得パラメータ
   * @return 案件情報取得結果
   */
  public ApiResult<B0010ReturnData> getAnkenInfo(B0010S01Dto inDto, Pageable pageable) {
    try {
      // 案件情報を取得
      Page<AnkenInfoDto> ankenList =
          b0010Repository.findAnkenInfo(
              inDto.getListJyucyuuJyoutai(),
              CommonConstants.DELETE_FLAG_VALID,
              MasterData.ITEM_CLASS_CD_D0003,
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getKokyakuName(),
              inDto.getJmYmdStart(),
              inDto.getJmYmdEnd(),
              inDto.getEigyouBumon(),
              inDto.getEigyouTantousya(),
              pageable);

      // 取得件数が０件だった場合
      if (CollectionUtils.isEmpty(ankenList.getContent())) {
        // メッセージ
        String msg =
            messageSource.getMessage(Message.MSGID_K00001, null, LocaleContextHolder.getLocale());

        LOG.info(msg);

        // 結果情報
        return ApiResult.error(Message.MSGID_K00001, msg);
      }

      // 戻り値
      B0010ReturnData returnData = new B0010ReturnData();
      // 案件情報リスト
      returnData.setListAnkenInfo(ankenList.getContent());

      // ページ情報
      PaginationMeta meta = new PaginationMeta(ankenList);

      return ApiResult.success(returnData, meta);

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw new SystemException(ex.toString(), ex);
    }
  }

  /**
   * CSV出力
   *
   * @param inDto 案件情報取得パラメータ
   * @param response response
   */
  public void downLoadCsv(B0010S02Dto inDto, HttpServletResponse response) {
    try {
      // ヘッダ設定（カンマ区切り）
      CSVFormat csvFormat =
          CSVFormat.DEFAULT
              .builder()
              .setDelimiter(',')
              .setQuoteMode(QuoteMode.ALL)
              .setHeader(CSV_HEADER)
              .get();

      // 案件情報を取得
      Page<AnkenInfoDto> ankenList =
          b0010Repository.findAnkenInfo(
              inDto.getListJyucyuuJyoutai(),
              CommonConstants.DELETE_FLAG_VALID,
              MasterData.ITEM_CLASS_CD_D0003,
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getKokyakuName(),
              inDto.getJmYmdStart(),
              inDto.getJmYmdEnd(),
              inDto.getEigyouBumon(),
              inDto.getEigyouTantousya(),
              Pageable.unpaged());

      Charset charset = Charset.forName(CommonConstants.CSV_CHARSET_SHIFT_JIS);

      try (CSVPrinter printer =
          new CSVPrinter(new OutputStreamWriter(response.getOutputStream(), charset), csvFormat)) {
        // データがある場合
        if (!CollectionUtils.isEmpty(ankenList.getContent())) {
          for (AnkenInfoDto ankenInfo : ankenList) {
            // 明細行設定
            printer.printRecord(
                ankenInfo.getAnkenCode(),
                ankenInfo.getAnkenEdaCode(),
                ankenInfo.getAnkenName(),
                ankenInfo.getKokyakuCode(),
                ankenInfo.getKokyakuName(),
                ankenInfo.getSouteiKingaku(),
                String.join("", ankenInfo.getGenbaJyuusyo1(), ankenInfo.getGenbaJyuusyo2()),
                DateUtils.formatDateFromYYYYMMDD(ankenInfo.getJycyuuMikomiYmd(), CSV_DATE_FORMAT),
                DateUtils.formatDateFromYYYYMMDD(ankenInfo.getCyakkouKibouYmd(), CSV_DATE_FORMAT),
                ankenInfo.getEigyouBumonCode(),
                ankenInfo.getEigyouBumonName(),
                ankenInfo.getEigyouTantousyaCode(),
                String.join(
                        "　", ankenInfo.getEigyouTantousyaShi(), ankenInfo.getEigyouTantousyaMe())
                    .trim(),
                ankenInfo.getShincyokudoCode(),
                ankenInfo.getShincyokudo());
          }
        }
      }

    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw new SystemException(ex.toString(), ex);
    }
  }

  /**
   * 印刷処理
   *
   * @param inDto 案件情報印刷パラメータ
   * @return pdf
   */
  public byte[] exportReportToPdf(B0010S02Dto inDto) {
    try {
      // 案件情報を取得
      Page<AnkenInfoDto> ankenList =
          b0010Repository.findAnkenInfo(
              inDto.getListJyucyuuJyoutai(),
              CommonConstants.DELETE_FLAG_VALID,
              MasterData.ITEM_CLASS_CD_D0003,
              inDto.getAnkenCode(),
              inDto.getAnkenName(),
              inDto.getKokyakuName(),
              inDto.getJmYmdStart(),
              inDto.getJmYmdEnd(),
              inDto.getEigyouBumon(),
              inDto.getEigyouTantousya(),
              Pageable.unpaged());

      // 印刷パラメータ
      B0010S03Dto printDto = new B0010S03Dto();
      // 利用PCのシステム日付
      printDto.setSysDate(inDto.getSysDate().format(DateTimeFormatter.ofPattern(PDF_DATE_FORMAT)));

      // レポートに渡すパラメータ
      Map<String, Object> paramsMap =
          objectMapper.convertValue(printDto, new TypeReference<Map<String, Object>>() {});

      // データソースを生成する
      JRDataSource dataSource = new JRBeanCollectionDataSource(ankenList.getContent());

      // レポートを生成する
      return reportService.exportReportToPdf(REPORT_FILE_NAME, paramsMap, dataSource);
    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      throw new SystemException(ex.toString(), ex);
    }
  }
}
