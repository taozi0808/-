package com.daitoj.tkms.modules.apia0010.repository;

import com.daitoj.tkms.domain.MWorker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** 作業員情報リポジトリ */
@Repository
public interface A0010S02Repository extends JpaRepository<MWorker, Long> {
  /**
   * 作業員情報を取得
   *
   * @param loginId ログインID
   * @param delFlg 削除フラグ
   * @return 作業員情報
   */
  @Query(
      """
          SELECT wk
          FROM MWorker wk
          JOIN wk.vendorHid2 vhd
          WHERE wk.loginId = :loginId
          AND wk.delFlg = :delFlg
          AND vhd.delFlg = :delFlg

          """)
  MWorker findWorkerInfo(@Param("loginId") String loginId, @Param("delFlg") String delFlg);
}
