package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** 役職情報 */
@Schema(name = "PositionDto", description = "役職情報")
public class PositionDto {
  /** 役職コード */
  @Schema(description = "役職コード")
  private String positionCd;

  /** 役職名 */
  @Schema(description = "役職名")
  private String positionNm;

  /** 初期役職区分;0 */
  @Schema(description = "初期役職区分")
  private String initPositionK;

  /** 承認権限;0 */
  @Schema(description = "承認権限")
  private String confirmPerm;

  /** 削除権限 */
  @Schema(description = "削除権限")
  private String deletePerm;

  /** 編集権限 */
  @Schema(description = "編集権限")
  private String editPerm;

  /** 参照権限 */
  @Schema(description = "参照権限")
  private String referPerm;

  public String getPositionCd() {
    return positionCd;
  }

  public void setPositionCd(String positionCd) {
    this.positionCd = positionCd;
  }

  public String getPositionNm() {
    return positionNm;
  }

  public void setPositionNm(String positionNm) {
    this.positionNm = positionNm;
  }

  public String getInitPositionK() {
    return initPositionK;
  }

  public void setInitPositionK(String initPositionK) {
    this.initPositionK = initPositionK;
  }

  public String getConfirmPerm() {
    return confirmPerm;
  }

  public void setConfirmPerm(String confirmPerm) {
    this.confirmPerm = confirmPerm;
  }

  public String getDeletePerm() {
    return deletePerm;
  }

  public void setDeletePerm(String deletePerm) {
    this.deletePerm = deletePerm;
  }

  public String getEditPerm() {
    return editPerm;
  }

  public void setEditPerm(String editPerm) {
    this.editPerm = editPerm;
  }

  public String getReferPerm() {
    return referPerm;
  }

  public void setReferPerm(String referPerm) {
    this.referPerm = referPerm;
  }
}
