package com.daitoj.tkms.modules.common.constants;

/** メッセージ定義 */
public class Message {

  /** IDもしくはパスワードが違います。 */
  public static final String MSGID_A0003 = "A0003";

  /** 利用可能時間外の為、ログインできません。 */
  public static final String MSGID_A0004 = "A0004";

  /** 該当件数が０件でした。検索条件を変更してください。 */
  public static final String MSGID_K00001 = "K00001";

  /** 対象機能の権限がありません。システム管理者にお問い合わせください。 */
  public static final String MSGID_K00006 = "K00006";
}
