package com.daitoj.tkms.modules.common.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/** 日付処理クラス */
public class DateUtils {

  /** DB日付フォーマット */
  public static final String DATE_FORMAT = "yyyyMMdd";

  /**
   * 日付フォーマット
   *
   * @param dateString 日付
   * @param pattern フォーマット
   * @return フォーマットした日付
   */
  public static String formatDateFromYYYYMMDD(String dateString, String pattern) {

    LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.BASIC_ISO_DATE);

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);

    return date.format(formatter);
  }
}
