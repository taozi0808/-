package com.daitoj.tkms.modules.apic0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;

/** 概算情報 */
@Schema(name = "GaisanInfoDto", description = "検索結果")
public class GaisanInfoDto {

  /** 案件コード */
  @Schema(name = "ankenCode", description = "案件コード")
  private String ankenCode;

  /** 案件名 */
  @Schema(name = "ankenName", description = "案件名")
  private String ankenName;

  /** 概算コード */
  @Schema(name = "gaisanCode", description = "概算コード")
  private String gaisanCode;

  /** 顧客コード */
  @Schema(name = "kokyakuCode", description = "顧客コード")
  private String kokyakuCode;

  /** 顧客名 */
  @Schema(name = "kokyakuName", description = "顧客名")
  private String kokyakuName;

  /** 見積提出期限 */
  @Schema(name = "mitsumoriTeisyutsuYmd", description = "見積提出期限")
  private String mitsumoriTeisyutsuYmd;

  /** 概算金額 */
  @Schema(name = "gaisankingaku", description = "概算金額")
  private BigDecimal gaisankingaku;

  /** 着工希望日 */
  @Schema(name = "chakkouKibouYmd", description = "着工希望日")
  private String chakkouKibouYmd;

  /** 完工希望日 */
  @Schema(name = "kankouKibouYmd", description = "完工希望日")
  private String kankouKibouYmd;

  /** 概算部門コード */
  @Schema(name = "gaisanBumonCode", description = "概算部門コード")
  private String gaisanBumonCode;

  /** 概算部門 */
  @Schema(name = "gaisanBumon", description = "概算部門")
  private String gaisanBumon;

  /** 概算担当者コード */
  @Schema(name = "gaisanTantousyaCode", description = "概算担当者コード")
  private String gaisanTantousyaCode;

  /** 概算担当者 */
  @Schema(name = "gaisanTantousya", description = "概算担当者")
  private String gaisanTantousya;

  /** コンストラクタ */
  public GaisanInfoDto() {}

  /**
   * コンストラクタ
   *
   * @param ankenCode 案件コード
   * @param gaisanCode 概算コード
   * @param ankenName 案件名
   * @param kokyakuCode 顧客コード
   * @param kokyakuName 顧客名
   * @param mitsumoriTeisyutsuYmd 見積提出期限
   * @param gaisankingaku 概算金額
   * @param chakkouKibouYmd 着工希望日
   * @param kankouKibouYmd 完工希望日
   * @param gaisanBumonCode 概算部門コード
   * @param gaisanBumon 概算部門
   * @param gaisanTantousyaCode 概算担当者コード
   * @param gaisanTantousya 概算担当者
   */
  public GaisanInfoDto(
      String ankenCode,
      String gaisanCode,
      String ankenName,
      String kokyakuCode,
      String kokyakuName,
      String mitsumoriTeisyutsuYmd,
      BigDecimal gaisankingaku,
      String chakkouKibouYmd,
      String kankouKibouYmd,
      String gaisanBumonCode,
      String gaisanBumon,
      String gaisanTantousyaCode,
      String gaisanTantousya) {
    this.ankenCode = ankenCode;
    this.ankenName = ankenName;
    this.gaisanCode = gaisanCode;
    this.kokyakuCode = kokyakuCode;
    this.kokyakuName = kokyakuName;
    this.mitsumoriTeisyutsuYmd = mitsumoriTeisyutsuYmd;
    this.gaisankingaku = gaisankingaku;
    this.chakkouKibouYmd = chakkouKibouYmd;
    this.kankouKibouYmd = kankouKibouYmd;
    this.gaisanBumonCode = gaisanBumonCode;
    this.gaisanBumon = gaisanBumon;
    this.gaisanTantousyaCode = gaisanTantousyaCode;
    this.gaisanTantousya = gaisanTantousya;
  }

  public String getAnkenCode() {
    return ankenCode;
  }

  public void setAnkenCode(String ankenCode) {
    this.ankenCode = ankenCode;
  }

  public String getAnkenName() {
    return ankenName;
  }

  public void setAnkenName(String ankenName) {
    this.ankenName = ankenName;
  }

  public String getGaisanCode() {
    return gaisanCode;
  }

  public void setGaisanCode(String gaisanCode) {
    this.gaisanCode = gaisanCode;
  }

  public String getKokyakuCode() {
    return kokyakuCode;
  }

  public void setKokyakuCode(String kokyakuCode) {
    this.kokyakuCode = kokyakuCode;
  }

  public String getKokyakuName() {
    return kokyakuName;
  }

  public void setKokyakuName(String kokyakuName) {
    this.kokyakuName = kokyakuName;
  }

  public String getMitsumoriTeisyutsuYmd() {
    return mitsumoriTeisyutsuYmd;
  }

  public void setMitsumoriTeisyutsuYmd(String mitsumoriTeisyutsuYmd) {
    this.mitsumoriTeisyutsuYmd = mitsumoriTeisyutsuYmd;
  }

  public BigDecimal getGaisankingaku() {
    return gaisankingaku;
  }

  public void setGaisankingaku(BigDecimal gaisankingaku) {
    this.gaisankingaku = gaisankingaku;
  }

  public String getChakkouKibouYmd() {
    return chakkouKibouYmd;
  }

  public void setChakkouKibouYmd(String chakkouKibouYmd) {
    this.chakkouKibouYmd = chakkouKibouYmd;
  }

  public String getKankouKibouYmd() {
    return kankouKibouYmd;
  }

  public void setKankouKibouYmd(String kankouKibouYmd) {
    this.kankouKibouYmd = kankouKibouYmd;
  }

  public String getGaisanBumonCode() {
    return gaisanBumonCode;
  }

  public void setGaisanBumonCode(String gaisanBumonCode) {
    this.gaisanBumonCode = gaisanBumonCode;
  }

  public String getGaisanBumon() {
    return gaisanBumon;
  }

  public void setGaisanBumon(String gaisanBumon) {
    this.gaisanBumon = gaisanBumon;
  }

  public String getGaisanTantousyaCode() {
    return gaisanTantousyaCode;
  }

  public void setGaisanTantousyaCode(String gaisanTantousyaCode) {
    this.gaisanTantousyaCode = gaisanTantousyaCode;
  }

  public String getGaisanTantousya() {
    return gaisanTantousya;
  }

  public void setGaisanTantousya(String gaisanTantousya) {
    this.gaisanTantousya = gaisanTantousya;
  }
}
