package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.MVendorHdr;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** 業者情報ヘッダリポジトリ */
@Repository
public interface MVendorHdrRepository extends JpaRepository<MVendorHdr, Long> {
  /**
   * 業者情報ヘッダを取得する
   *
   * @param loginId ユーザーID
   * @param delFlg 削除フラグ
   * @return 業者情報ヘッダ
   */
  MVendorHdr findByLoginIdAndDelFlg(String loginId, String delFlg);
}
