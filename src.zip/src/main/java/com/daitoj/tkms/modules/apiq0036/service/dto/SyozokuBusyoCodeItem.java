//package com.daitoj.tkms.modules.apiq0036.service.dto;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//import io.swagger.v3.oas.annotations.media.Schema;
//import jakarta.validation.constraints.NotNull;
//
///** 所属部署コード */
//@Schema(name = "SyozokuBusyoCodeItem", description = "所属部署コード")
//public class SyozokuBusyoCodeItem {
//  /** 所属部署コード */
//  @NotNull private String syozokuBusyoCode;
//
//  /** 所属部署役職コード */
//  @NotNull private String sbSyozokuCode;
//
//  @Schema(
//      name = "syozokuBusyoCode",
//      description = "所属部署コード",
//      requiredMode = Schema.RequiredMode.REQUIRED)
//  @JsonProperty("syozokuBusyoCode")
//  public String getSyozokuBusyoCode() {
//    return syozokuBusyoCode;
//  }
//
//  public void setSyozokuBusyoCode(String syozokuBusyoCode) {
//    this.syozokuBusyoCode = syozokuBusyoCode;
//  }
//
//  @Schema(
//      name = "sbSyozokuCode",
//      description = "所属部署役職コード",
//      requiredMode = Schema.RequiredMode.REQUIRED)
//  @JsonProperty("sbSyozokuCode")
//  public String getSbSyozokuCode() {
//    return sbSyozokuCode;
//  }
//
//  public void setSbSyozokuCode(String sbSyozokuCode) {
//    this.sbSyozokuCode = sbSyozokuCode;
//  }
//}
