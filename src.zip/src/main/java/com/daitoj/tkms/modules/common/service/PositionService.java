package com.daitoj.tkms.modules.common.service;

import com.daitoj.tkms.domain.MPosition;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.repository.MPositionRepository;
import io.micrometer.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/** 役職サービス */
@Service
public class PositionService {
  private static final Logger LOG = LoggerFactory.getLogger(PositionService.class);

  /** 役職情報リポジトリ */
  private final MPositionRepository mpositionRepository;

  /** コンストラクタ */
  public PositionService(MPositionRepository mpositionRepository) {
    this.mpositionRepository = mpositionRepository;
  }

  /**
   * 役職権限チェック
   *
   * @param positionCd 役職コード
   * @param confirmPerm 承認権限
   * @param deletePerm 削除権限
   * @param editPerm 編集権限
   * @param referPerm 参照権限
   * @return 権限が変更された:false
   */
  public boolean isPermissionValid(
      String positionCd, String confirmPerm, String deletePerm, String editPerm, String referPerm) {

    // 役職情報を取得
    MPosition positionInfo =
        mpositionRepository.findByPositionCdAndDelFlg(
            positionCd, CommonConstants.DELETE_FLAG_VALID);

    // 権限なし場合
    if (positionInfo == null) {
      return false;
    }

    // 承認権限なし場合
    if (isPermissionInvalid(confirmPerm, positionInfo.getConfirmPerm())) {
      return false;
    }

    // 削除権限なし場合
    if (isPermissionInvalid(deletePerm, positionInfo.getDeletePerm())) {
      return false;
    }

    // 編集権限なし場合
    if (isPermissionInvalid(editPerm, positionInfo.getEditPerm())) {
      return false;
    }

    // 参照権限なし場合
    if (isPermissionInvalid(referPerm, positionInfo.getReferPerm())) {
      return false;
    }

    return true;
  }

  /**
   * 権限チエック
   *
   * @param befPerm 画面権限
   * @param curPerm DB権限
   * @return 権限が変更された:false
   */
  private boolean isPermissionInvalid(String befPerm, String curPerm) {
    // チエック要の場合
    if (StringUtils.isNotBlank(befPerm)) {
      // 権限が変更された
      if (CommonConstants.HAS_PERMISSION.equals(befPerm)
          && !CommonConstants.HAS_PERMISSION.equals(curPerm)) {
        return true;
      }
    }

    return false;
  }
}
