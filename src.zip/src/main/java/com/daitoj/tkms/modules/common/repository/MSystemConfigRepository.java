package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.MSystemConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** システム設定リポジトリ */
@Repository
public interface MSystemConfigRepository extends JpaRepository<MSystemConfig, String> {

  /**
   * システム設定キーより、システム設定を取得
   *
   * @param sysCd システムコード
   * @param configKey システム設定キー
   * @param delFlg 削除フラグ
   * @return システム設定
   */
  MSystemConfig findById_SysCdAndId_ConfigKeyAndDelFlg(String sysCd, String configKey, String delFlg);
}
