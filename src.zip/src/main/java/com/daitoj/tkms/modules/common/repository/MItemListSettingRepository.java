package com.daitoj.tkms.modules.common.repository;

import com.daitoj.tkms.domain.MItemListSetting;
import com.daitoj.tkms.domain.MItemListSettingId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** マスタデータリポジトリ */
@Repository
public interface MItemListSettingRepository
    extends JpaRepository<MItemListSetting, MItemListSettingId> {

  /**
   * 項目分類コードより、マスタデータを取得する
   *
   * @param itemClassCd 項目分類コード
   * @param effectiveStartDt システム日付
   * @param delFlg 削除フラグ
   * @return マスタデータ
   */
  List<MItemListSetting>
      findById_ItemClassCdAndId_EffectiveStartDtLessThanEqualAndDelFlgOrderByDisplayOrder(
          String itemClassCd, String effectiveStartDt, String delFlg);
}
