package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** 協力会お知らせ情報 */
@Schema(name = "PartnerNotificationDto", description = "協力会お知らせ情報")
public class PartnerNotificationDto {
  /** お知らせID */
  @Schema(description = "お知らせID")
  private Long id;

  /** 協力会お知らせ内容 */
  @Schema(description = "協力会お知らせ内容")
  private String partnerNotificationContent;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getPartnerNotificationContent() {
    return partnerNotificationContent;
  }

  public void setPartnerNotificationContent(String partnerNotificationContent) {
    this.partnerNotificationContent = partnerNotificationContent;
  }
}
