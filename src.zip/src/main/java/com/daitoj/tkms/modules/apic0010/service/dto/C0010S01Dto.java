package com.daitoj.tkms.modules.apic0010.service.dto;

import com.daitoj.tkms.modules.common.service.dto.BasePageRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

/** 概算一覧パラメータ */
@Schema(name = "C0010S01Dto", description = "概算一覧パラメータ")
public class C0010S01Dto extends BasePageRequest {

  /** 案件コード */
  @Schema(name = "ankenCode", description = "案件コード")
  private String ankenCode;

  /** 案件名（ｶﾅ含む） */
  @Schema(name = "ankenName", description = "案件名（ｶﾅ含む）")
  private String ankenName;

  /** 概算コード */
  @Schema(name = "gaisanCode", description = "概算コード")
  private String gaisanCode;

  /** 顧客コード */
  @Schema(name = "kokyakuCode", description = "顧客コード")
  private String kokyakuCode;

  /** 顧客名（ｶﾅ含む） */
  @Schema(name = "kokyakuName", description = "顧客名（ｶﾅ含む）")
  private String kokyakuName;

  /** 見積提出期限（開始） */
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate teisyutsukigenStart;

  /** 見積提出期限（終了） */
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate teisyutsukigenEnd;

  /** 概算部門 */
  @Schema(name = "gaisanTantousyaCode", description = "概算部門")
  private String gaisanTantousyaCode;

  /** 概算担当者 */
  @Schema(name = "gaisanTantousya", description = "概算担当者")
  private String gaisanTantousya;

  /** 概算作成済みの案件を表示する */
  @Schema(name = "gaisanSakusei", description = "概算作成済みの案件を表示する")
  private String gaisanSakusei;

  /** 所属部署役職コード */
  @NotNull
  @Schema(description = "役職コード", requiredMode = Schema.RequiredMode.REQUIRED)
  private String yakusyokuCode;

  public @NotNull String getYakusyokuCode() {
    return yakusyokuCode;
  }

  public void setYakusyokuCode(@NotNull String yakusyokuCode) {
    this.yakusyokuCode = yakusyokuCode;
  }

  public String getAnkenCode() {
    return ankenCode;
  }

  public void setAnkenCode(String ankenCode) {
    this.ankenCode = ankenCode;
  }

  public String getAnkenName() {
    return ankenName;
  }

  public void setAnkenName(String ankenName) {
    this.ankenName = ankenName;
  }

  public String getGaisanCode() {
    return gaisanCode;
  }

  public void setGaisanCode(String gaisanCode) {
    this.gaisanCode = gaisanCode;
  }

  public String getKokyakuCode() {
    return kokyakuCode;
  }

  public void setKokyakuCode(String kokyakuCode) {
    this.kokyakuCode = kokyakuCode;
  }

  public String getKokyakuName() {
    return kokyakuName;
  }

  public void setKokyakuName(String kokyakuName) {
    this.kokyakuName = kokyakuName;
  }

  public LocalDate getTeisyutsukigenStart() {
    return teisyutsukigenStart;
  }

  public void setTeisyutsukigenStart(LocalDate teisyutsukigenStart) {
    this.teisyutsukigenStart = teisyutsukigenStart;
  }

  public LocalDate getTeisyutsukigenEnd() {
    return teisyutsukigenEnd;
  }

  public void setTeisyutsukigenEnd(LocalDate teisyutsukigenEnd) {
    this.teisyutsukigenEnd = teisyutsukigenEnd;
  }

  public String getGaisanTantousyaCode() {
    return gaisanTantousyaCode;
  }

  public void setGaisanTantousyaCode(String gaisanTantousyaCode) {
    this.gaisanTantousyaCode = gaisanTantousyaCode;
  }

  public String getGaisanTantousya() {
    return gaisanTantousya;
  }

  public void setGaisanTantousya(String gaisanTantousya) {
    this.gaisanTantousya = gaisanTantousya;
  }

  public String getGaisanSakusei() {
    return gaisanSakusei;
  }

  public void setGaisanSakusei(String gaisanSakusei) {
    this.gaisanSakusei = gaisanSakusei;
  }
}
