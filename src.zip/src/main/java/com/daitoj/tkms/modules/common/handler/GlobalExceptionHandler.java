package com.daitoj.tkms.modules.common.handler;

import com.daitoj.tkms.modules.common.constants.Message;
import com.daitoj.tkms.modules.common.service.InvalidUserException;
import com.daitoj.tkms.modules.common.service.SystemException;
import com.daitoj.tkms.modules.common.service.dto.ApiResult;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** コントローラ例外処理 */
@RestControllerAdvice
public class GlobalExceptionHandler {

  /** メッセージ */
  private final MessageSource messageSource;

  /** コンストラクタ */
  public GlobalExceptionHandler(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * システム例外処理
   *
   * @param ex SystemException
   * @param request HttpServletRequest
   * @return システムエラー情報
   */
  @ExceptionHandler(SystemException.class)
  public ResponseEntity<?> handleSystemException(SystemException ex, HttpServletRequest request) {

    // 例外処理
    ApiResult<?> response =
        ApiResult.error(
            String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
            HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
            request.getRequestURI());

    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
  }

  /**
   * ユーザ例外処理
   *
   * @param ex InvalidUserException
   * @return ログインエラー情報
   */
  @ExceptionHandler(InvalidUserException.class)
  public ResponseEntity<?> handleInvalidUserException(InvalidUserException ex) {

    // 例外処理
    ApiResult<?> response = ApiResult.error(ex.getErrorCode(), ex.getMessage());

    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
  }

  /**
   * パスワード例外処理
   *
   * @param ex BadCredentialsException
   * @return ログインエラー情報
   */
  @ExceptionHandler(BadCredentialsException.class)
  public ResponseEntity<?> handleBadCredentialsException(BadCredentialsException ex) {

    // 例外処理
    ApiResult<?> response =
        ApiResult.error(
            Message.MSGID_A0003,
            messageSource.getMessage(Message.MSGID_A0003, null, LocaleContextHolder.getLocale()));

    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
  }
}
