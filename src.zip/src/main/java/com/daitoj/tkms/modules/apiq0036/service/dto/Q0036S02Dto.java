//package com.daitoj.tkms.modules.apiq0036.service.dto;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//import io.swagger.v3.oas.annotations.media.Schema;
//import jakarta.validation.constraints.NotNull;
//import org.springframework.format.annotation.DateTimeFormat;
//
//import java.time.LocalDateTime;
//
///** 案件一覧CSV出力パラメータ */
//@Schema(name = "A0010S02Dto", description = "案件一覧CSV出力パラメータ")
//public class Q0036S02Dto extends Q0036S01Dto {
//
//  /** 利用PCのシステム日付 */
//  @NotNull
//  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
//  private LocalDateTime sysDate;
//
//  @Schema(
//      name = "sysDate",
//      description = "利用PCのシステム日付(yyyy-MM-dd HH:mm:ss)",
//      requiredMode = Schema.RequiredMode.REQUIRED)
//  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
//  public LocalDateTime getSysDate() {
//    return sysDate;
//  }
//
//  public void setSysDate(LocalDateTime sysDate) {
//    this.sysDate = sysDate;
//  }
//}
