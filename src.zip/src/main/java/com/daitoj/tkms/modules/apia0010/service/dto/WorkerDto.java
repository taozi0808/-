package com.daitoj.tkms.modules.apia0010.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/** 作業員情報 */
@Schema(name = "WorkerDto", description = "作業員情報")
public class WorkerDto {
  /** 作業員情報ID */
  @Schema(description = "作業員情報ID")
  private Long id;

  /** 業者情報ヘッダID */
  @Schema(description = "業者情報ヘッダID")
  private Long vendorHid;

  /** 作業員コード */
  @Schema(description = "作業員コード")
  private String workerCd;

  /** 作業員_氏 */
  @Schema(description = "作業員_氏")
  private String workerShi;

  /** 作業員_名 */
  @Schema(description = "作業員_名")
  private String workerMei;

  /** 作業員_氏名 */
  @Schema(description = "作業員_氏名")
  private String workerShimei;

  /** ログインID */
  @Schema(description = "ログインID")
  private String loginId;

  /** メールアドレス */
  @Schema(description = "メールアドレス")
  private String mailAddress;

  /** 業者情報ヘッダID_2 */
  @Schema(description = "業者情報ヘッダID_2")
  private VendorHdrDto vendorHid2;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getVendorHid() {
    return vendorHid;
  }

  public void setVendorHid(Long vendorHid) {
    this.vendorHid = vendorHid;
  }

  public String getWorkerCd() {
    return workerCd;
  }

  public void setWorkerCd(String workerCd) {
    this.workerCd = workerCd;
  }

  public String getWorkerShi() {
    return workerShi;
  }

  public void setWorkerShi(String workerShi) {
    this.workerShi = workerShi;
  }

  public String getWorkerMei() {
    return workerMei;
  }

  public void setWorkerMei(String workerMei) {
    this.workerMei = workerMei;
  }

  public String getWorkerShimei() {
    return workerShimei;
  }

  public void setWorkerShimei(String workerShimei) {
    this.workerShimei = workerShimei;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }

  public String getMailAddress() {
    return mailAddress;
  }

  public void setMailAddress(String mailAddress) {
    this.mailAddress = mailAddress;
  }

  public VendorHdrDto getVendorHid2() {
    return vendorHid2;
  }

  public void setVendorHid2(VendorHdrDto vendorHid2) {
    this.vendorHid2 = vendorHid2;
  }
}
