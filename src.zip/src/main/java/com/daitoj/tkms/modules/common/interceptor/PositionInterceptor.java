package com.daitoj.tkms.modules.common.interceptor;

import com.daitoj.tkms.domain.MMenuItem;
import com.daitoj.tkms.modules.common.constants.CommonConstants;
import com.daitoj.tkms.modules.common.service.MenuItemService;
import com.daitoj.tkms.modules.common.service.PositionService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.HandlerInterceptor;

/** リクエストパラメータチエックインターセプター */
@Component
public class PositionInterceptor implements HandlerInterceptor {
  private static final Logger LOG = LoggerFactory.getLogger(PositionInterceptor.class);

  /** JWTデコード */
  private final JwtDecoder jwtDecoder;

  /** 役職サービス */
  private final PositionService positionService;

  /** メニュー項目情報サービス */
  private final MenuItemService menuItemService;

  /** コンストラクタ */
  @Autowired
  public PositionInterceptor(
      JwtDecoder jwtDecoder, PositionService positionService, MenuItemService menuItemService) {
    this.jwtDecoder = jwtDecoder;
    this.positionService = positionService;
    this.menuItemService = menuItemService;
  }

  /**
   * HTTPリクエストが処理される前に、認証トークンと権限チェックを実施
   *
   * @param request リクエスト
   * @param response レスポンス
   * @param handler ハンドラ
   */
  @Override
  public boolean preHandle(
      HttpServletRequest request, HttpServletResponse response, Object handler) {

    try {
      // Authorization ヘッダーからトークンを取得
      String authHeader = request.getHeader("Authorization");

      // Authorization ヘッダーがないか、Bearer トークンでない場合
      if (authHeader == null || !authHeader.startsWith("Bearer ")) {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        return false;
      }

      // トークンの先頭部分（"Bearer "）を除去
      String token = authHeader.substring(7);
      // JWT トークンをデコード
      Jwt jwt = jwtDecoder.decode(token);
      Map<String, Object> claims = jwt.getClaims();
      // Claims が空または null の場合
      if (claims == null) {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        return false;
      }

      // ログインID
      String loginId = (String) claims.get(CommonConstants.HTTP_HEADER_LOGIN_ID);
      // アカウント区分
      String accountK = (String) claims.get(CommonConstants.HTTP_HEADER_ACCOUNT_K);
      // メニューID
      String menuId = request.getHeader(CommonConstants.HTTP_HEADER_MENU_ID);

      // 必要な情報が欠けている場合
      if (StringUtils.isBlank(loginId)
          || StringUtils.isBlank(accountK)
          || StringUtils.isBlank(menuId)) {
        response.setStatus(HttpStatus.FORBIDDEN.value());
        return false;
      }

      // ログインIDとアカウント区分でメニュー項目情報を取得
      List<MMenuItem> menuItems = menuItemService.getMenuItem(loginId, accountK);

      // メニュー項目情報が存在しない場合
      if (CollectionUtils.isEmpty(menuItems)) {
        response.setStatus(HttpStatus.FORBIDDEN.value());
        return false;
      }

      // メニューIDチェック
      List<MMenuItem> items =
          menuItems.stream().filter(menu -> Integer.parseInt(menuId) == menu.getId()).toList();

      // 一致するメニューがない場合
      if (items.isEmpty()) {
        response.setStatus(HttpStatus.FORBIDDEN.value());
        return false;
      }

      // 役職コード
      String positionCode = (String) claims.get(CommonConstants.HTTP_HEADER_POSITION_CD);
      // 承認権限
      String confirmPerm = (String) claims.get(CommonConstants.HTTP_HEADER_CONFIRM_PERM);
      // 削除権限
      String deletePerm = (String) claims.get(CommonConstants.HTTP_HEADER_DELETE_PERM);
      // 編集権限
      String editPerm = (String) claims.get(CommonConstants.HTTP_HEADER_EDIT_PERM);
      // 参照権限
      String referPerm = (String) claims.get(CommonConstants.HTTP_HEADER_REFER_PERM);

      // 役職コードが存在しない場合
      if (StringUtils.isBlank(positionCode)) {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        return false;
      }

      // 役職の権限が有効かどうかをチェック
      boolean permValid =
          positionService.isPermissionValid(
              positionCode, confirmPerm, deletePerm, editPerm, referPerm);

      // 権限が無効な場合（権限が変更された場合
      if (!permValid) {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        return false;
      }

      return true;
    } catch (Exception ex) {
      LOG.error(ex.toString(), ex);

      // 内部サーバーエラー
      response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
      return false;
    }
  }
}
