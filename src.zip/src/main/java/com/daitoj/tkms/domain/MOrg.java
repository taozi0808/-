package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 組織情報 */
@Entity
@Table(name = "m_org")
public class MOrg implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  @Column(name = "org_id", nullable = false)
  private Long id;

  @NotNull
  @Column(name = "org_rev_id", nullable = false)
  private Long orgRevId;

  @Size(max = 6)
  @NotNull
  @Column(name = "org_cd", nullable = false, length = 6)
  private String orgCd;

  @NotNull
  @Column(name = "org_nm", nullable = false, length = Integer.MAX_VALUE)
  private String orgNm;

  @NotNull
  @Column(name = "parent_org_id", nullable = false)
  private Long parentOrgId;

  @NotNull
  @Column(name = "lvl", nullable = false)
  private Integer lvl;

  @NotNull
  @Column(name = "display_order", nullable = false)
  private Integer displayOrder;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Integer getLvl() {
    return lvl;
  }

  public void setLvl(Integer lvl) {
    this.lvl = lvl;
  }

  public Long getParentOrgId() {
    return parentOrgId;
  }

  public void setParentOrgId(Long parentOrgId) {
    this.parentOrgId = parentOrgId;
  }

  public String getOrgNm() {
    return orgNm;
  }

  public void setOrgNm(String orgNm) {
    this.orgNm = orgNm;
  }

  public String getOrgCd() {
    return orgCd;
  }

  public void setOrgCd(String orgCd) {
    this.orgCd = orgCd;
  }

  public Long getOrgRevId() {
    return orgRevId;
  }

  public void setOrgRevId(Long orgRevId) {
    this.orgRevId = orgRevId;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
