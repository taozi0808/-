package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 組織・メニュー項目・対照表 */
@Entity
@Table(name = "m_org_menu_item")
public class MOrgMenuItem implements Serializable {

  private static final long serialVersionUID = 1L;

  @EmbeddedId private MOrgMenuItemId id;

  @MapsId
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "m_org_id", nullable = false)
  private MOrg mOrg;

  @MapsId
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "menu_item_id", nullable = false)
  private MMenuItem menuItem;

  @NotNull
  @Column(name = "refer_perm", nullable = false, length = Integer.MAX_VALUE)
  private String referPerm;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getReferPerm() {
    return referPerm;
  }

  public void setReferPerm(String referPerm) {
    this.referPerm = referPerm;
  }

  public MMenuItem getMenuItem() {
    return menuItem;
  }

  public void setMenuItem(MMenuItem menuItem) {
    this.menuItem = menuItem;
  }

  public MOrg getMOrg() {
    return mOrg;
  }

  public void setMOrg(MOrg mOrg) {
    this.mOrg = mOrg;
  }

  public MOrgMenuItemId getId() {
    return id;
  }

  public void setId(MOrgMenuItemId id) {
    this.id = id;
  }
}
