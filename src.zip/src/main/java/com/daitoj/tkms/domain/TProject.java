package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 案件情報 */
@Entity
@Table(name = "t_project")
public class TProject implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  @Column(name = "project_id", nullable = false)
  private Long id;

  @Size(max = 9)
  @NotNull
  @Column(name = "project_cd", nullable = false, length = 9)
  private String projectCd;

  @Size(max = 2)
  @NotNull
  @Column(name = "his_no", nullable = false, length = 2)
  private String hisNo;

  @NotNull
  @Column(name = "project_nm", nullable = false, length = Integer.MAX_VALUE)
  private String projectNm;

  @NotNull
  @Column(name = "project_kn_nm", nullable = false, length = Integer.MAX_VALUE)
  private String projectKnNm;

  @NotNull
  @Column(name = "order_st_cd", nullable = false, length = Integer.MAX_VALUE)
  private String orderStCd;

  @Size(max = 6)
  @NotNull
  @Column(name = "customer_cd", nullable = false, length = 6)
  private String customerCd;

  @NotNull
  @Column(name = "expect_amt", nullable = false, precision = 11)
  private BigDecimal expectAmt;

  @Size(max = 7)
  @NotNull
  @Column(name = "post_no", nullable = false, length = 7)
  private String postNo;

  @NotNull
  @Column(name = "constr_site_addr1", nullable = false, length = Integer.MAX_VALUE)
  private String constrSiteAddr1;

  @NotNull
  @Column(name = "constr_site_addr2", nullable = false, length = Integer.MAX_VALUE)
  private String constrSiteAddr2;

  @Size(max = 8)
  @NotNull
  @Column(name = "order_expected_ymd", nullable = false, length = 8)
  private String orderExpectedYmd;

  @Size(max = 8)
  @NotNull
  @Column(name = "start_hope_ymd", nullable = false, length = 8)
  private String startHopeYmd;

  @Size(max = 8)
  @NotNull
  @Column(name = "sales_dept_start_dt", nullable = false, length = 8)
  private String salesDeptStartDt;

  @NotNull
  @Column(name = "sales_org_id", nullable = false)
  private Long salesOrgId;

  @Size(max = 2)
  @NotNull
  @Column(name = "sales_mgr_cd", nullable = false, length = 2)
  private String salesMgrCd;

  @Size(max = 6)
  @NotNull
  @Column(name = "sales_pic_cd", nullable = false, length = 6)
  private String salesPicCd;

  @Size(max = 2)
  @NotNull
  @Column(name = "progress_cd", nullable = false, length = 2)
  private String progressCd;

  @NotNull
  @Column(name = "project_k", nullable = false, length = Integer.MAX_VALUE)
  private String projectK;

  @NotNull
  @Column(name = "gov_peo_k", nullable = false, length = Integer.MAX_VALUE)
  private String govPeoK;

  @NotNull
  @Column(name = "constr_schedule_k", nullable = false, length = Integer.MAX_VALUE)
  private String constrScheduleK;

  @Size(max = 8)
  @NotNull
  @Column(name = "est_submit_due_dt", nullable = false, length = 8)
  private String estSubmitDueDt;

  @NotNull
  @Column(name = "site_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal siteArea;

  @NotNull
  @Column(name = "building_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal buildingArea;

  @NotNull
  @Column(name = "gross_floor_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal grossFloorArea;

  @NotNull
  @Column(name = "buildup_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal buildupArea;

  @NotNull
  @Column(name = "occupied_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal occupiedArea;

  @NotNull
  @Column(name = "constr_area", nullable = false, precision = 9, scale = 2)
  private BigDecimal constrArea;

  @NotNull
  @Column(name = "households", nullable = false, precision = 7)
  private BigDecimal households;

  @NotNull
  @Column(name = "floor_cnt", nullable = false, precision = 3)
  private BigDecimal floorCnt;

  @NotNull
  @Column(name = "basement_cnt", nullable = false, precision = 3)
  private BigDecimal basementCnt;

  @NotNull
  @Column(name = "closing_day", nullable = false, length = Integer.MAX_VALUE)
  private String closingDay;

  @NotNull
  @Column(name = "payment_k", nullable = false, length = Integer.MAX_VALUE)
  private String paymentK;

  @NotNull
  @Column(name = "payment_d", nullable = false, length = Integer.MAX_VALUE)
  private String paymentD;

  @NotNull
  @Column(name = "rejection_reason", nullable = false, length = Integer.MAX_VALUE)
  private String rejectionReason;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public String getPaymentD() {
    return paymentD;
  }

  public void setPaymentD(String paymentD) {
    this.paymentD = paymentD;
  }

  public String getPaymentK() {
    return paymentK;
  }

  public void setPaymentK(String paymentK) {
    this.paymentK = paymentK;
  }

  public String getClosingDay() {
    return closingDay;
  }

  public void setClosingDay(String closingDay) {
    this.closingDay = closingDay;
  }

  public BigDecimal getBasementCnt() {
    return basementCnt;
  }

  public void setBasementCnt(BigDecimal basementCnt) {
    this.basementCnt = basementCnt;
  }

  public BigDecimal getFloorCnt() {
    return floorCnt;
  }

  public void setFloorCnt(BigDecimal floorCnt) {
    this.floorCnt = floorCnt;
  }

  public BigDecimal getHouseholds() {
    return households;
  }

  public void setHouseholds(BigDecimal households) {
    this.households = households;
  }

  public BigDecimal getConstrArea() {
    return constrArea;
  }

  public void setConstrArea(BigDecimal constrArea) {
    this.constrArea = constrArea;
  }

  public BigDecimal getOccupiedArea() {
    return occupiedArea;
  }

  public void setOccupiedArea(BigDecimal occupiedArea) {
    this.occupiedArea = occupiedArea;
  }

  public BigDecimal getBuildupArea() {
    return buildupArea;
  }

  public void setBuildupArea(BigDecimal buildupArea) {
    this.buildupArea = buildupArea;
  }

  public BigDecimal getGrossFloorArea() {
    return grossFloorArea;
  }

  public void setGrossFloorArea(BigDecimal grossFloorArea) {
    this.grossFloorArea = grossFloorArea;
  }

  public BigDecimal getBuildingArea() {
    return buildingArea;
  }

  public void setBuildingArea(BigDecimal buildingArea) {
    this.buildingArea = buildingArea;
  }

  public BigDecimal getSiteArea() {
    return siteArea;
  }

  public void setSiteArea(BigDecimal siteArea) {
    this.siteArea = siteArea;
  }

  public String getEstSubmitDueDt() {
    return estSubmitDueDt;
  }

  public void setEstSubmitDueDt(String estSubmitDueDt) {
    this.estSubmitDueDt = estSubmitDueDt;
  }

  public String getConstrScheduleK() {
    return constrScheduleK;
  }

  public void setConstrScheduleK(String constrScheduleK) {
    this.constrScheduleK = constrScheduleK;
  }

  public String getGovPeoK() {
    return govPeoK;
  }

  public void setGovPeoK(String govPeoK) {
    this.govPeoK = govPeoK;
  }

  public String getProjectK() {
    return projectK;
  }

  public void setProjectK(String projectK) {
    this.projectK = projectK;
  }

  public String getProgressCd() {
    return progressCd;
  }

  public void setProgressCd(String progressCd) {
    this.progressCd = progressCd;
  }

  public String getSalesPicCd() {
    return salesPicCd;
  }

  public void setSalesPicCd(String salesPicCd) {
    this.salesPicCd = salesPicCd;
  }

  public String getSalesMgrCd() {
    return salesMgrCd;
  }

  public void setSalesMgrCd(String salesMgrCd) {
    this.salesMgrCd = salesMgrCd;
  }

  public Long getSalesOrgId() {
    return salesOrgId;
  }

  public void setSalesOrgId(Long salesOrgId) {
    this.salesOrgId = salesOrgId;
  }

  public String getSalesDeptStartDt() {
    return salesDeptStartDt;
  }

  public void setSalesDeptStartDt(String salesDeptStartDt) {
    this.salesDeptStartDt = salesDeptStartDt;
  }

  public String getStartHopeYmd() {
    return startHopeYmd;
  }

  public void setStartHopeYmd(String startHopeYmd) {
    this.startHopeYmd = startHopeYmd;
  }

  public String getOrderExpectedYmd() {
    return orderExpectedYmd;
  }

  public void setOrderExpectedYmd(String orderExpectedYmd) {
    this.orderExpectedYmd = orderExpectedYmd;
  }

  public String getConstrSiteAddr2() {
    return constrSiteAddr2;
  }

  public void setConstrSiteAddr2(String constrSiteAddr2) {
    this.constrSiteAddr2 = constrSiteAddr2;
  }

  public String getConstrSiteAddr1() {
    return constrSiteAddr1;
  }

  public void setConstrSiteAddr1(String constrSiteAddr1) {
    this.constrSiteAddr1 = constrSiteAddr1;
  }

  public String getPostNo() {
    return postNo;
  }

  public void setPostNo(String postNo) {
    this.postNo = postNo;
  }

  public BigDecimal getExpectAmt() {
    return expectAmt;
  }

  public void setExpectAmt(BigDecimal expectAmt) {
    this.expectAmt = expectAmt;
  }

  public String getCustomerCd() {
    return customerCd;
  }

  public void setCustomerCd(String customerCd) {
    this.customerCd = customerCd;
  }

  public String getOrderStCd() {
    return orderStCd;
  }

  public void setOrderStCd(String orderStCd) {
    this.orderStCd = orderStCd;
  }

  public String getProjectKnNm() {
    return projectKnNm;
  }

  public void setProjectKnNm(String projectKnNm) {
    this.projectKnNm = projectKnNm;
  }

  public String getProjectNm() {
    return projectNm;
  }

  public void setProjectNm(String projectNm) {
    this.projectNm = projectNm;
  }

  public String getHisNo() {
    return hisNo;
  }

  public void setHisNo(String hisNo) {
    this.hisNo = hisNo;
  }

  public String getProjectCd() {
    return projectCd;
  }

  public void setProjectCd(String projectCd) {
    this.projectCd = projectCd;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
