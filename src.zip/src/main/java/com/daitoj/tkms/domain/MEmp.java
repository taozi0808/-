package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 従業員情報 */
@Entity
@Table(name = "m_emp")
public class MEmp implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Size(max = 6)
  @Column(name = "emp_cd", nullable = false, length = 6)
  private String empCd;

  @NotNull
  @Column(name = "emp_shi", nullable = false, length = Integer.MAX_VALUE)
  private String empShi;

  @NotNull
  @Column(name = "emp_mei", nullable = false, length = Integer.MAX_VALUE)
  private String empMei;

  @NotNull
  @Column(name = "emp_shimei", nullable = false, length = Integer.MAX_VALUE)
  private String empShimei;

  @Size(max = 255)
  @NotNull
  @Column(name = "login_id", nullable = false)
  private String loginId;

  @Size(max = 255)
  @NotNull
  @Column(name = "mail_address", nullable = false)
  private String mailAddress;

  @Size(max = 2)
  @NotNull
  @Column(name = "belong_office_cd", nullable = false, length = 2)
  private String belongOfficeCd;

  @Size(max = 2)
  @NotNull
  @Column(name = "position_cd", nullable = false, length = 2)
  private String positionCd;

  @Size(max = 8)
  @NotNull
  @Column(name = "employment_ymd", nullable = false, length = 8)
  private String employmentYmd;

  @Size(max = 8)
  @ColumnDefault("NULL")
  @Column(name = "termination_ymd", length = 8)
  private String terminationYmd;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getTerminationYmd() {
    return terminationYmd;
  }

  public void setTerminationYmd(String terminationYmd) {
    this.terminationYmd = terminationYmd;
  }

  public String getEmploymentYmd() {
    return employmentYmd;
  }

  public void setEmploymentYmd(String employmentYmd) {
    this.employmentYmd = employmentYmd;
  }

  public String getPositionCd() {
    return positionCd;
  }

  public void setPositionCd(String positionCd) {
    this.positionCd = positionCd;
  }

  public String getBelongOfficeCd() {
    return belongOfficeCd;
  }

  public void setBelongOfficeCd(String belongOfficeCd) {
    this.belongOfficeCd = belongOfficeCd;
  }

  public String getMailAddress() {
    return mailAddress;
  }

  public void setMailAddress(String mailAddress) {
    this.mailAddress = mailAddress;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }

  public String getEmpShimei() {
    return empShimei;
  }

  public void setEmpShimei(String empShimei) {
    this.empShimei = empShimei;
  }

  public String getEmpMei() {
    return empMei;
  }

  public void setEmpMei(String empMei) {
    this.empMei = empMei;
  }

  public String getEmpShi() {
    return empShi;
  }

  public void setEmpShi(String empShi) {
    this.empShi = empShi;
  }

  public String getEmpCd() {
    return empCd;
  }

  public void setEmpCd(String empCd) {
    this.empCd = empCd;
  }
}
