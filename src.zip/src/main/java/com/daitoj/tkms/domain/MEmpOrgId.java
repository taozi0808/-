package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Objects;
import org.hibernate.Hibernate;

@Embeddable
public class MEmpOrgId implements java.io.Serializable {
  private static final long serialVersionUID = 1273956355691520848L;

  @Size(max = 6)
  @NotNull
  @Column(name = "emp_cd", nullable = false, length = 6)
  private String empCd;

  @NotNull
  @Column(name = "org_id", nullable = false)
  private Long orgId;

  public String getEmpCd() {
    return empCd;
  }

  public void setEmpCd(String empCd) {
    this.empCd = empCd;
  }

  public Long getOrgId() {
    return orgId;
  }

  public void setOrgId(Long orgId) {
    this.orgId = orgId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    MEmpOrgId entity = (MEmpOrgId) o;
    return Objects.equals(this.empCd, entity.empCd) && Objects.equals(this.orgId, entity.orgId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(empCd, orgId);
  }
}
