package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** 項目リスト設定のキー */
@Embeddable
public class MItemListSettingId implements java.io.Serializable {
  private static final long serialVersionUID = 1L;

  @Size(max = 5)
  @NotNull
  @Column(name = "item_class_cd", nullable = false, length = 5)
  private String itemClassCd;

  @Size(max = 8)
  @NotNull
  @Column(name = "effective_start_dt", nullable = false, length = 8)
  private String effectiveStartDt;

  @Size(max = 10)
  @NotNull
  @Column(name = "item_cd", nullable = false, length = 10)
  private String itemCd;

  public String getItemClassCd() {
    return itemClassCd;
  }

  public void setItemClassCd(String itemClassCd) {
    this.itemClassCd = itemClassCd;
  }

  public String getEffectiveStartDt() {
    return effectiveStartDt;
  }

  public void setEffectiveStartDt(String effectiveStartDt) {
    this.effectiveStartDt = effectiveStartDt;
  }

  public String getItemCd() {
    return itemCd;
  }

  public void setItemCd(String itemCd) {
    this.itemCd = itemCd;
  }

}
