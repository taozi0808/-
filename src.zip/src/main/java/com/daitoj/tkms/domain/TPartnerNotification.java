package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 協力会お知らせ情報 */
@Entity
@Table(name = "t_partner_notification")
public class TPartnerNotification implements Serializable {

  @Id
  @Column(name = "partner_notification_id", nullable = false)
  private Long id;

  @NotNull
  @Column(name = "partner_notification_content", nullable = false, length = Integer.MAX_VALUE)
  private String partnerNotificationContent;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getPartnerNotificationContent() {
    return partnerNotificationContent;
  }

  public void setPartnerNotificationContent(String partnerNotificationContent) {
    this.partnerNotificationContent = partnerNotificationContent;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
