package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 概算情報 */
@Entity
@Table(name = "t_rough_est_hdr")
public class TRoughEstHdr implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  @Column(name = "rough_est_hid", nullable = false)
  private Long id;

  @Size(max = 12)
  @NotNull
  @Column(name = "rough_est_cd", nullable = false, length = 12)
  private String roughEstCd;

  @Size(max = 2)
  @NotNull
  @Column(name = "his_no", nullable = false, length = 2)
  private String hisNo;

  @Size(max = 8)
  @NotNull
  @Column(name = "rough_est_ymd", nullable = false, length = 8)
  private String roughEstYmd;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "project_id", nullable = false)
  private TProject project;

  @Size(max = 9)
  @NotNull
  @Column(name = "project_cd", nullable = false, length = 9)
  private String projectCd;

  @Size(max = 6)
  @NotNull
  @Column(name = "customer_cd", nullable = false, length = 6)
  private String customerCd;

  @Size(max = 13)
  @NotNull
  @Column(name = "est_no", nullable = false, length = 13)
  private String estNo;

  @NotNull
  @Column(name = "rough_est_total_amt", nullable = false, precision = 11)
  private BigDecimal roughEstTotalAmt;

  @NotNull
  @Column(name = "rough_est_org_id", nullable = false)
  private Long roughEstOrgId;

  @Size(max = 6)
  @NotNull
  @Column(name = "rough_est_pic_cd", nullable = false, length = 6)
  private String roughEstPicCd;

  @NotNull
  @Column(name = "area", nullable = false, length = Integer.MAX_VALUE)
  private String area;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getArea() {
    return area;
  }

  public void setArea(String area) {
    this.area = area;
  }

  public String getRoughEstPicCd() {
    return roughEstPicCd;
  }

  public void setRoughEstPicCd(String roughEstPicCd) {
    this.roughEstPicCd = roughEstPicCd;
  }

  public Long getRoughEstOrgId() {
    return roughEstOrgId;
  }

  public void setRoughEstOrgId(Long roughEstOrgId) {
    this.roughEstOrgId = roughEstOrgId;
  }

  public BigDecimal getRoughEstTotalAmt() {
    return roughEstTotalAmt;
  }

  public void setRoughEstTotalAmt(BigDecimal roughEstTotalAmt) {
    this.roughEstTotalAmt = roughEstTotalAmt;
  }

  public String getEstNo() {
    return estNo;
  }

  public void setEstNo(String estNo) {
    this.estNo = estNo;
  }

  public String getCustomerCd() {
    return customerCd;
  }

  public void setCustomerCd(String customerCd) {
    this.customerCd = customerCd;
  }

  public String getProjectCd() {
    return projectCd;
  }

  public void setProjectCd(String projectCd) {
    this.projectCd = projectCd;
  }

  public TProject getProject() {
    return project;
  }

  public void setProject(TProject project) {
    this.project = project;
  }

  public String getRoughEstYmd() {
    return roughEstYmd;
  }

  public void setRoughEstYmd(String roughEstYmd) {
    this.roughEstYmd = roughEstYmd;
  }

  public String getHisNo() {
    return hisNo;
  }

  public void setHisNo(String hisNo) {
    this.hisNo = hisNo;
  }

  public String getRoughEstCd() {
    return roughEstCd;
  }

  public void setRoughEstCd(String roughEstCd) {
    this.roughEstCd = roughEstCd;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
