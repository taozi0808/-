package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** ログイン情報 */
@Entity
@Table(name = "m_login")
public class MLogin implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Size(max = 255)
  @Column(name = "login_id", nullable = false)
  private String loginId;

  @NotNull
  @Column(name = "password", nullable = false, length = Integer.MAX_VALUE)
  private String password;

  @NotNull
  @Column(name = "account_k", nullable = false, length = Integer.MAX_VALUE)
  private String accountK;

  @Size(max = 8)
  @NotNull
  @ColumnDefault("19000101")
  @Column(name = "start_ymd", nullable = false, length = 8)
  private String startYmd;

  @Size(max = 8)
  @Column(name = "end_ymd", length = 8)
  private String endYmd;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getEndYmd() {
    return endYmd;
  }

  public void setEndYmd(String endYmd) {
    this.endYmd = endYmd;
  }

  public String getStartYmd() {
    return startYmd;
  }

  public void setStartYmd(String startYmd) {
    this.startYmd = startYmd;
  }

  public String getAccountK() {
    return accountK;
  }

  public void setAccountK(String accountK) {
    this.accountK = accountK;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }
}
