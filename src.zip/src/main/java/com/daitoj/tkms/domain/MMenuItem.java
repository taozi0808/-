package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** メニュー項目情報 */
@Entity
@Table(name = "m_menu_item")
public class MMenuItem implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "menu_item_id", nullable = false)
  private Integer id;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "menu_id", nullable = false)
  private MMenu menu;

  @Column(name = "parent_menu_item_id")
  private Integer parentMenuItemId;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pg_id")
  private MProgram pg;

  @Size(max = 255)
  @NotNull
  @Column(name = "menu_item_nm", nullable = false)
  private String menuItemNm;

  @Size(max = 255)
  @Column(name = "menu_item_path")
  private String menuItemPath;

  @Size(max = 255)
  @Column(name = "menu_item_icon")
  private String menuItemIcon;

  @NotNull
  @Column(name = "display_order", nullable = false)
  private Integer displayOrder;

  @Column(name = "menu_item_tooltip", length = Integer.MAX_VALUE)
  private String menuItemTooltip;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getMenuItemTooltip() {
    return menuItemTooltip;
  }

  public void setMenuItemTooltip(String menuItemTooltip) {
    this.menuItemTooltip = menuItemTooltip;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public String getMenuItemIcon() {
    return menuItemIcon;
  }

  public void setMenuItemIcon(String menuItemIcon) {
    this.menuItemIcon = menuItemIcon;
  }

  public String getMenuItemPath() {
    return menuItemPath;
  }

  public void setMenuItemPath(String menuItemPath) {
    this.menuItemPath = menuItemPath;
  }

  public String getMenuItemNm() {
    return menuItemNm;
  }

  public void setMenuItemNm(String menuItemNm) {
    this.menuItemNm = menuItemNm;
  }

  public MProgram getPg() {
    return pg;
  }

  public void setPg(MProgram pg) {
    this.pg = pg;
  }

  public Integer getParentMenuItemId() {
    return parentMenuItemId;
  }

  public void setParentMenuItemId(Integer parentMenuItemId) {
    this.parentMenuItemId = parentMenuItemId;
  }

  public MMenu getMenu() {
    return menu;
  }

  public void setMenu(MMenu menu) {
    this.menu = menu;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
}
