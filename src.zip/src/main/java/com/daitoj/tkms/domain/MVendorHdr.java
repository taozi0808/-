package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 業者情報ヘッダ */
@Entity
@Table(name = "m_vendor_hdr")
public class MVendorHdr implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "vendor_hid", nullable = false)
  private Long id;

  @Size(max = 6)
  @NotNull
  @Column(name = "vendor_cd", nullable = false, length = 6)
  private String vendorCd;

  @Size(max = 3)
  @NotNull
  @Column(name = "vendor_branch_cd", nullable = false, length = 3)
  private String vendorBranchCd;

  @NotNull
  @Column(name = "vendor_nm", nullable = false, length = Integer.MAX_VALUE)
  private String vendorNm;

  @NotNull
  @Column(name = "vendor_branch_nm", nullable = false, length = Integer.MAX_VALUE)
  private String vendorBranchNm;

  @Size(max = 255)
  @NotNull
  @Column(name = "login_id", nullable = false)
  private String loginId;

  @NotNull
  @Column(name = "mail_address", nullable = false, length = Integer.MAX_VALUE)
  private String mailAddress;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getMailAddress() {
    return mailAddress;
  }

  public void setMailAddress(String mailAddress) {
    this.mailAddress = mailAddress;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }

  public String getVendorBranchNm() {
    return vendorBranchNm;
  }

  public void setVendorBranchNm(String vendorBranchNm) {
    this.vendorBranchNm = vendorBranchNm;
  }

  public String getVendorNm() {
    return vendorNm;
  }

  public void setVendorNm(String vendorNm) {
    this.vendorNm = vendorNm;
  }

  public String getVendorBranchCd() {
    return vendorBranchCd;
  }

  public void setVendorBranchCd(String vendorBranchCd) {
    this.vendorBranchCd = vendorBranchCd;
  }

  public String getVendorCd() {
    return vendorCd;
  }

  public void setVendorCd(String vendorCd) {
    this.vendorCd = vendorCd;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
