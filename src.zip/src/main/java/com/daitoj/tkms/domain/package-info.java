/**
 * Domain objects.
 */
package com.daitoj.tkms.domain;
