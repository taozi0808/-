package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "m_menu")
public class MMenu {
  @Id
  @Column(name = "menu_id", nullable = false)
  private Integer id;

  @Size(max = 255)
  @NotNull
  @Column(name = "menu_nm", nullable = false)
  private String menuNm;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getMenuNm() {
    return menuNm;
  }

  public void setMenuNm(String menuNm) {
    this.menuNm = menuNm;
  }
}
