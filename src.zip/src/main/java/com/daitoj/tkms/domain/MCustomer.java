package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 顧客情報 */
@Entity
@Table(name = "m_customer")
public class MCustomer implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Size(max = 6)
  @Column(name = "customer_cd", nullable = false, length = 6)
  private String customerCd;

  @NotNull
  @Column(name = "customer_nm1", nullable = false, length = Integer.MAX_VALUE)
  private String customerNm1;

  @NotNull
  @Column(name = "customer_nm2", nullable = false, length = Integer.MAX_VALUE)
  private String customerNm2;

  @NotNull
  @Column(name = "customer_ryakusyou", nullable = false, length = Integer.MAX_VALUE)
  private String customerRyakusyou;

  @NotNull
  @Column(name = "customer_kn_nm", nullable = false, length = Integer.MAX_VALUE)
  private String customerKnNm;

  @NotNull
  @Column(name = "customer_pic_nm", nullable = false, length = Integer.MAX_VALUE)
  private String customerPicNm;

  @NotNull
  @Column(name = "customer_pic_kn_nm", nullable = false, length = Integer.MAX_VALUE)
  private String customerPicKnNm;

  @NotNull
  @Column(name = "trading_k", nullable = false, length = Integer.MAX_VALUE)
  private String tradingK;

  @Size(max = 7)
  @NotNull
  @Column(name = "post_no", nullable = false, length = 7)
  private String postNo;

  @NotNull
  @Column(name = "customer_addr", nullable = false, length = Integer.MAX_VALUE)
  private String customerAddr;

  @NotNull
  @Column(name = "customer_tel_no", nullable = false, length = Integer.MAX_VALUE)
  private String customerTelNo;

  @NotNull
  @Column(name = "customer_pic_tel_no", nullable = false, length = Integer.MAX_VALUE)
  private String customerPicTelNo;

  @NotNull
  @Column(name = "customer_fax_no", nullable = false, length = Integer.MAX_VALUE)
  private String customerFaxNo;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getCustomerFaxNo() {
    return customerFaxNo;
  }

  public void setCustomerFaxNo(String customerFaxNo) {
    this.customerFaxNo = customerFaxNo;
  }

  public String getCustomerPicTelNo() {
    return customerPicTelNo;
  }

  public void setCustomerPicTelNo(String customerPicTelNo) {
    this.customerPicTelNo = customerPicTelNo;
  }

  public String getCustomerTelNo() {
    return customerTelNo;
  }

  public void setCustomerTelNo(String customerTelNo) {
    this.customerTelNo = customerTelNo;
  }

  public String getCustomerAddr() {
    return customerAddr;
  }

  public void setCustomerAddr(String customerAddr) {
    this.customerAddr = customerAddr;
  }

  public String getPostNo() {
    return postNo;
  }

  public void setPostNo(String postNo) {
    this.postNo = postNo;
  }

  public String getTradingK() {
    return tradingK;
  }

  public void setTradingK(String tradingK) {
    this.tradingK = tradingK;
  }

  public String getCustomerPicKnNm() {
    return customerPicKnNm;
  }

  public void setCustomerPicKnNm(String customerPicKnNm) {
    this.customerPicKnNm = customerPicKnNm;
  }

  public String getCustomerPicNm() {
    return customerPicNm;
  }

  public void setCustomerPicNm(String customerPicNm) {
    this.customerPicNm = customerPicNm;
  }

  public String getCustomerKnNm() {
    return customerKnNm;
  }

  public void setCustomerKnNm(String customerKnNm) {
    this.customerKnNm = customerKnNm;
  }

  public String getCustomerRyakusyou() {
    return customerRyakusyou;
  }

  public void setCustomerRyakusyou(String customerRyakusyou) {
    this.customerRyakusyou = customerRyakusyou;
  }

  public String getCustomerNm2() {
    return customerNm2;
  }

  public void setCustomerNm2(String customerNm2) {
    this.customerNm2 = customerNm2;
  }

  public String getCustomerNm1() {
    return customerNm1;
  }

  public void setCustomerNm1(String customerNm1) {
    this.customerNm1 = customerNm1;
  }

  public String getCustomerCd() {
    return customerCd;
  }

  public void setCustomerCd(String customerCd) {
    this.customerCd = customerCd;
  }
}
