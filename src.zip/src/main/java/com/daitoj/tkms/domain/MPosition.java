package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.ColumnDefault;

/** 役職情報 */
@Entity
@Table(name = "m_position")
public class MPosition implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Size(max = 2)
  @Column(name = "position_cd", nullable = false, length = 2)
  private String positionCd;

  @NotNull
  @Column(name = "position_nm", nullable = false, length = Integer.MAX_VALUE)
  private String positionNm;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "init_position_k", nullable = false, length = Integer.MAX_VALUE)
  private String initPositionK;

  @NotNull
  @Column(name = "confirm_perm", nullable = false, length = Integer.MAX_VALUE)
  private String confirmPerm;

  @NotNull
  @Column(name = "delete_perm", nullable = false, length = Integer.MAX_VALUE)
  private String deletePerm;

  @NotNull
  @Column(name = "edit_perm", nullable = false, length = Integer.MAX_VALUE)
  private String editPerm;

  @NotNull
  @Column(name = "refer_perm", nullable = false, length = Integer.MAX_VALUE)
  private String referPerm;

  @NotNull
  @ColumnDefault("'0'")
  @Column(name = "del_flg", nullable = false, length = Integer.MAX_VALUE)
  private String delFlg;

  @NotNull
  @Column(name = "reg_ts", nullable = false)
  private Instant regTs;

  @Size(max = 255)
  @NotNull
  @Column(name = "reg_user_id", nullable = false)
  private String regUserId;

  @Size(max = 50)
  @Column(name = "reg_pg_id", length = 50)
  private String regPgId;

  @Column(name = "upd_ts")
  private Instant updTs;

  @Size(max = 255)
  @Column(name = "upd_user_id")
  private String updUserId;

  @Size(max = 50)
  @Column(name = "upd_pg_id", length = 50)
  private String updPgId;

  public String getUpdPgId() {
    return updPgId;
  }

  public void setUpdPgId(String updPgId) {
    this.updPgId = updPgId;
  }

  public String getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(String updUserId) {
    this.updUserId = updUserId;
  }

  public Instant getUpdTs() {
    return updTs;
  }

  public void setUpdTs(Instant updTs) {
    this.updTs = updTs;
  }

  public String getRegPgId() {
    return regPgId;
  }

  public void setRegPgId(String regPgId) {
    this.regPgId = regPgId;
  }

  public String getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(String regUserId) {
    this.regUserId = regUserId;
  }

  public Instant getRegTs() {
    return regTs;
  }

  public void setRegTs(Instant regTs) {
    this.regTs = regTs;
  }

  public String getDelFlg() {
    return delFlg;
  }

  public void setDelFlg(String delFlg) {
    this.delFlg = delFlg;
  }

  public String getReferPerm() {
    return referPerm;
  }

  public void setReferPerm(String referPerm) {
    this.referPerm = referPerm;
  }

  public String getEditPerm() {
    return editPerm;
  }

  public void setEditPerm(String editPerm) {
    this.editPerm = editPerm;
  }

  public String getDeletePerm() {
    return deletePerm;
  }

  public void setDeletePerm(String deletePerm) {
    this.deletePerm = deletePerm;
  }

  public String getConfirmPerm() {
    return confirmPerm;
  }

  public void setConfirmPerm(String confirmPerm) {
    this.confirmPerm = confirmPerm;
  }

  public String getInitPositionK() {
    return initPositionK;
  }

  public void setInitPositionK(String initPositionK) {
    this.initPositionK = initPositionK;
  }

  public String getPositionNm() {
    return positionNm;
  }

  public void setPositionNm(String positionNm) {
    this.positionNm = positionNm;
  }

  public String getPositionCd() {
    return positionCd;
  }

  public void setPositionCd(String positionCd) {
    this.positionCd = positionCd;
  }
}
