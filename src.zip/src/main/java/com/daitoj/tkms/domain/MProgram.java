package com.daitoj.tkms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

/** 機能情報 */
@Entity
@Table(name = "m_program")
public class MProgram {
  @Id
  @Size(max = 225)
  @Column(name = "pg_id", nullable = false, length = 225)
  private String pgId;

  public String getPgId() {
    return pgId;
  }

  public void setPgId(String pgId) {
    this.pgId = pgId;
  }
}
