/**
 * Data transfer objects for rest mapping.
 */
package com.daitoj.tkms.service.dto;
