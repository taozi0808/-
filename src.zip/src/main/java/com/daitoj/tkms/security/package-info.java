/**
 * Application security utilities.
 */
package com.daitoj.tkms.security;
