/**
 * Logging aspect.
 */
package com.daitoj.tkms.aop.logging;
