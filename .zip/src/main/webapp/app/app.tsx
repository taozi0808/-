import ErrorBoundary from 'app/shared/error/error-boundary';
import AppRoutes from 'app/routes';
import SideNav from './shared/layout/SideNav';
import HeaderNav from './shared/layout/HeaderNav';
import { CssBaseline, Container } from '@mui/material';
import { BrowserRouter } from 'react-router-dom';
import React from 'react';
import './app.scss';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import {
  CellSpanModule,
  CellStyleModule,
  ClientSideRowModelModule,
  ColumnAutoSizeModule,
  GridStateModule,
  ModuleRegistry,
  NumberEditorModule,
  RowApiModule,
  RowSelectionModule,
  RowStyleModule,
  SelectEditorModule,
  TextEditorModule,
  themeQuartz,
} from 'ag-grid-community';
import useAccountStore from './shared/zustandStore/account';
import { ContextMenuModule, RowGroupingModule } from 'ag-grid-enterprise';

ModuleRegistry.registerModules([
  RowSelectionModule,
  GridStateModule,
  ClientSideRowModelModule,
  ContextMenuModule,
  RowGroupingModule,
  CellSpanModule,
  RowApiModule,
  CellStyleModule,
  ColumnAutoSizeModule,
  TextEditorModule,
  RowStyleModule,
  NumberEditorModule,
  SelectEditorModule,
]);
export const AGGridTheme = themeQuartz.withParams({
  borderColor: '#000',
  headerRowBorder: '1px solid #000',
  rowBorder: '1px solid #000',
  headerColumnBorder: '1px solid #000',
  columnBorder: '1px solid #000',
  headerBackgroundColor: '#e7e7e7',
});

const baseHref = document.querySelector('base').getAttribute('href').replace(/\/$/, '');

const theme = createTheme({
  palette: {
    primary: {
      main: '#285ac8',
    },
  },
});

const App = () => {
  const { userName } = useAccountStore();

  return (
    <BrowserRouter basename={baseHref}>
      <CssBaseline />
      <ThemeProvider theme={theme}>
        <Container maxWidth={false} style={{ background: '#FFF', height: '100vh', padding: 0, display: 'flex' }}>
          {userName && <SideNav />}
          <Container maxWidth={false} style={{ padding: 0, flexGrow: 1, minWidth: 0 }}>
            <HeaderNav />
            <Container
              maxWidth={false}
              style={{
                background: '#fff',
                height: 'calc(100vh - 112px)',
                padding: 0,
                marginTop: '16px',
              }}
            >
              <ErrorBoundary>
                <AppRoutes />
              </ErrorBoundary>
            </Container>
          </Container>
        </Container>
      </ThemeProvider>
    </BrowserRouter>
  );
};

export default App;
