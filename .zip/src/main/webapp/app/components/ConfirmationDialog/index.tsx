import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

interface ConfirmationDialogProps {
  buttonText: string; // 触发按钮的文案
  title?: string; // 对话框标题
  content?: string; // 对话框内容
  primaryButtonText?: string; // 主按钮文案
  secondaryButtonText?: string; // 次按钮文案
  onPrimaryButtonClick?: () => void; // 主按钮点击回调
  onSecondaryButtonClick?: () => void; // 次按钮点击回调
  showSecondaryButton?: boolean; // 是否显示次按钮
}

const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  buttonText,
  title = '确认操作',
  content = '您确定要执行此操作吗？',
  primaryButtonText = '确认',
  secondaryButtonText = '取消',
  onPrimaryButtonClick,
  onSecondaryButtonClick,
  showSecondaryButton = true,
}) => {
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleConfirm = () => {
    if (onPrimaryButtonClick) {
      onPrimaryButtonClick();
    }
    handleClose();
  };

  const handleCancel = () => {
    if (onSecondaryButtonClick) {
      onSecondaryButtonClick();
    }
    handleClose();
  };

  return (
    <>
      <Button variant="contained" color="primary" onClick={handleOpen}>
        {buttonText}
      </Button>
      <Dialog open={open} onClose={handleClose} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">{content}</DialogContentText>
        </DialogContent>
        <DialogActions>
          {showSecondaryButton && (
            <Button onClick={handleCancel} color="primary">
              {secondaryButtonText}
            </Button>
          )}
          <Button onClick={handleConfirm} color="primary" autoFocus>
            {primaryButtonText}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ConfirmationDialog;
