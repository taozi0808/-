import React, { useCallback, useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { AGGridTheme } from 'app/app';
import { Box, Button, FormControl, IconButton, MenuItem, Select } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import './index.scss';
import { ClientSideRowModelModule, ColumnApiModule, ColumnAutoSizeModule, ModuleRegistry, ValidationModule } from 'ag-grid-community';
import FilterHeaderWrapper from './FilterHeaderWrapper';
ModuleRegistry.registerModules([ColumnAutoSizeModule, ColumnApiModule, ClientSideRowModelModule, ValidationModule /* Development Only */]);

export interface TableColumn {
  id: string;
  name: string;
  field: string;
  width: number;
  cssClass?: string;
  formatter?: (params: any) => string;
  enableFilterList?: boolean; // 是否启用过滤列表功能
  filterOptions?: string[]; // 如提供则用此数据，否则自动生成当前列所有唯一值
}

export interface AgGridTableProps {
  /** 外部传入的列配置 */
  columns: TableColumn[];
  /** 外部传入的数据 */
  data: any[];
  /**
   * 右键菜单配置：
   * 可以是一个数组（静态菜单项），或者一个函数，根据 ag‑Grid 提供的参数动态返回菜单项。
   * 参考 ag‑Grid API getContextMenuItems 参数格式
   */
  // eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
  contextMenuItems?: ((params: any) => (string | any)[]) | (string | any)[];
  /** 初始每页显示条数，默认为10 */
  initialPageSize?: number;
  /**
   * 扩展的 ag‑Grid 属性，
   * 可以传入任何 AgGridReact 支持的属性，例如 rowSelection 等
   */
  agGridProps?: Record<string, any>;
  disabledPagination?: boolean;
}

const BasicAgGridTable: React.FC<AgGridTableProps> = ({
  columns,
  data,
  contextMenuItems,
  initialPageSize = 10,
  agGridProps,
  disabledPagination = false,
}) => {
  // 分页相关状态（后面会根据过滤后的数据进行分页）
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(initialPageSize);

  // 全局过滤状态： key 为字段名，value 为该字段选中的过滤选项（数组为空表示不过滤）
  const [activeFilters, setActiveFilters] = useState<{ [field: string]: string[] }>({});

  // 根据 activeFilters 对原始 data 进行过滤（所有列均为 “包含在选中项内” 的规则）
  const filteredData = useMemo(() => {
    return data.filter(row => {
      return Object.keys(activeFilters).every(field => {
        const filterValues = activeFilters[field];
        if (!filterValues || filterValues.length === 0) return true;
        const cellValue = row[field];
        return filterValues.includes(cellValue?.toString());
      });
    });
  }, [data, activeFilters]);

  // 分页：根据过滤后的数据计算当前页数据
  const totalDataCount = filteredData.length;
  const totalPages = Math.ceil(totalDataCount / pageSize);
  const currentPageData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage, pageSize]);

  // 对于启用过滤列表的列，若没有提供 filterOptions，则自动生成当前列所有唯一值
  const uniqueOptionsByField = useMemo(() => {
    const map: { [key: string]: string[] } = {};
    columns.forEach(col => {
      if (col.enableFilterList) {
        const options = new Set<string>();
        data.forEach(row => {
          if (row[col.field] != null) {
            options.add(row[col.field].toString());
          }
        });
        map[col.field] = Array.from(options);
      }
    });
    return map;
  }, [columns, data]);

  // 更新指定列的过滤条件，注意：当条件变化时重置页码
  const handleGlobalFilterChange = (field: string, selected: string[]) => {
    setActiveFilters(prev => ({
      ...prev,
      [field]: selected,
    }));
    setCurrentPage(1);
  };

  const getContextMenuItems = (params: any) => {
    if (!contextMenuItems) {
      return [];
    }
    return typeof contextMenuItems === 'function' ? contextMenuItems(params) : contextMenuItems;
  };

  // 将外部列配置转换为 ag‑Grid 的 columnDefs
  // 如果配置中提供了 formatter 则通过 valueFormatter 转换
  // 对于启用 filterList 的列，设置 headerComponent 为自定义组件
  const columnDefs = useMemo(() => {
    return columns.map(col => {
      const colDef: any = {
        headerName: col.name,
        field: col.field,
        width: col.width,
      };
      if (col.cssClass) {
        colDef.cellClass = col.cssClass;
      }
      if (col.formatter) {
        colDef.valueFormatter = (params: any) => {
          params.paginationParams = {
            currentPage,
            pageSize,
          };
          return col.formatter(params);
        };
      }
      if (col.enableFilterList) {
        colDef.headerComponent = FilterHeaderWrapper;
        colDef.headerComponentParams = {
          filterOptions: col.filterOptions || uniqueOptionsByField[col.field] || [],
          // 当选中项变化时，调用父组件回调
          onGlobalFilterChanged: (selected: string[]) => handleGlobalFilterChange(col.field, selected),
        };
      }
      return colDef;
    });
  }, [columns, uniqueOptionsByField, handleGlobalFilterChange, currentPage, pageSize]);

  const onGridSizeChanged = useCallback(
    params => {
      // get the current grids width
      const gridWidth = document.querySelector('.ag-body-viewport').clientWidth;
      // keep track of which columns to hide/show
      const columnsToShow = [];
      const columnsToHide = [];
      // iterate over all columns (visible or not) and work out
      // now many columns can fit (based on their minWidth)
      let totalColsWidth = 0;
      const allColumns = params.api.getColumns();
      if (allColumns && allColumns.length > 0) {
        for (let i = 0; i < allColumns.length; i++) {
          const column = allColumns[i];
          totalColsWidth += column.getMinWidth();
          if (totalColsWidth > gridWidth) {
            columnsToHide.push(column.getColId());
          } else {
            columnsToShow.push(column.getColId());
          }
        }
      }
      // show/hide columns based on current grid width
      params.api.setColumnsVisible(columnsToShow, true);
      params.api.setColumnsVisible(columnsToHide, false);
      // wait until columns stopped moving and fill out
      // any available space to ensure there are no gaps
      window.setTimeout(() => {
        params.api.sizeColumnsToFit();
      }, 10);
    },
    [window],
  );

  const onFirstDataRendered = useCallback(params => {
    params.api.sizeColumnsToFit();
  }, []);

  // 生成翻页按钮逻辑：只显示当前页左右各 1 个页码，其他页码用省略号表示（始终显示首页与末页）
  const getPageButtons = () => {
    const buttons: (number | 'ellipsis')[] = [];
    const siblingCount = 1;
    const totalNumbers = siblingCount * 2 + 1;
    let startPage = Math.max(2, currentPage - siblingCount);
    let endPage = Math.min(totalPages - 1, currentPage + siblingCount);

    if (currentPage - siblingCount <= 1) {
      endPage = Math.min(totalPages - 1, totalNumbers);
    }
    if (currentPage + siblingCount >= totalPages) {
      startPage = Math.max(2, totalPages - totalNumbers + 1);
    }
    buttons.push(1);
    if (startPage > 2) {
      buttons.push('ellipsis');
    }
    for (let i = startPage; i <= endPage; i++) {
      buttons.push(i);
    }
    if (endPage < totalPages - 1) {
      buttons.push('ellipsis');
    }
    if (totalPages > 1) {
      buttons.push(totalPages);
    }
    return buttons;
  };

  const onPageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const onPageSizeChange = (e: any) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  return (
    <div style={{ width: '100%' }}>
      <div
        className="ag-theme-alpine"
        style={{
          width: '100%',
          height: 440, // 动态设置高度
          overflowY: 'auto', // 确保显示垂直滚动条
        }}
      >
        <AgGridReact
          gridOptions={{
            getContextMenuItems,
          }}
          columnDefs={columnDefs}
          rowData={disabledPagination ? data : currentPageData}
          domLayout="normal"
          theme={AGGridTheme}
          headerHeight={40}
          rowHeight={40}
          {...agGridProps}
        />
      </div>

      {!disabledPagination && currentPageData.length > 0 && (
        <Box display="flex" justifyContent="end" alignItems="center" mt={2}>
          <Box>
            <IconButton onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1}>
              <ArrowBackIosIcon fontSize="small" />
            </IconButton>
            {getPageButtons().map((item, index) =>
              item === 'ellipsis' ? (
                <Button key={index} disabled sx={{ pointerEvents: 'none', mx: 0.5 }} size="small">
                  ...
                </Button>
              ) : (
                <Button
                  key={index}
                  size="small"
                  onClick={() => onPageChange(item)}
                  variant={item === currentPage ? 'contained' : 'outlined'}
                  sx={{ mx: 0.5, padding: '4px 12px', minWidth: 10 }}
                >
                  {item}
                </Button>
              ),
            )}
            <IconButton onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages}>
              <ArrowForwardIosIcon fontSize="small" />
            </IconButton>
          </Box>
          <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <Select value={pageSize} onChange={onPageSizeChange}>
              <MenuItem value={10}>10件 / ページ</MenuItem>
              <MenuItem value={20}>20件 / ページ</MenuItem>
              <MenuItem value={50}>50件 / ページ</MenuItem>
              <MenuItem value={100}>100件 / ページ</MenuItem>
            </Select>
          </FormControl>
        </Box>
      )}
    </div>
  );
};

export default BasicAgGridTable;
