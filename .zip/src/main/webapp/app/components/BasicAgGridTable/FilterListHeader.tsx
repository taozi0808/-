import React, { useState, useMemo } from 'react';
import { IconButton, Popover, TextField, Checkbox, List, ListItemIcon, ListItemText, ListItemButton } from '@mui/material';
import FilterListIcon from '@mui/icons-material/FilterList';

export interface FilterListHeaderProps {
  title: string;
  filterOptions: string[];
  onFilterChanged: (selected: string[]) => void;
}

const FilterListHeader: React.FC<FilterListHeaderProps> = ({ title, filterOptions, onFilterChanged }) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedValues, setSelectedValues] = useState<string[]>([]);
  const [searchText, setSearchText] = useState('');

  const handleIconClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleToggle = (value: string) => {
    let newSelected: string[];
    if (selectedValues.includes(value)) {
      newSelected = selectedValues.filter(v => v !== value);
    } else {
      newSelected = [...selectedValues, value];
    }
    setSelectedValues(newSelected);
    onFilterChanged(newSelected);
  };

  const filteredOptions = useMemo(() => {
    return filterOptions.filter(option => option.toLowerCase().includes(searchText.toLowerCase()));
  }, [filterOptions, searchText]);

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {/* 显示列标题 */}
      <span>{title}</span>
      {/* 过滤图标 */}
      <IconButton onClick={handleIconClick} size="small">
        <FilterListIcon color={selectedValues.length > 0 ? 'primary' : 'inherit'} />
      </IconButton>
      {/* 下拉弹窗 */}
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
      >
        <div style={{ padding: 16, width: 220 }}>
          <TextField
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="搜索"
            fullWidth
            size="small"
            margin="dense"
          />
          <List dense>
            {filteredOptions.map(option => (
              <ListItemButton key={option} onClick={() => handleToggle(option)} sx={{ py: 0, minHeight: 24 }}>
                <ListItemIcon>
                  <Checkbox edge="start" checked={selectedValues.includes(option)} tabIndex={-1} disableRipple />
                </ListItemIcon>
                <ListItemText primary={option} />
              </ListItemButton>
            ))}
          </List>
        </div>
      </Popover>
    </div>
  );
};

export default FilterListHeader;
