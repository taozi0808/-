import React, { useCallback } from 'react';

interface LabelCellRenderProps {
  params: any;
  keys?: string[];
  styles?: (React.CSSProperties | ((params: any) => React.CSSProperties))[];
}

export const CustomLabelCellRender = (params: any) => {
  const rowData = params.data;
  const { keys, styles } = params;

  const resolveStyle = useCallback(
    (index: number): React.CSSProperties => {
      if (!styles || index >= styles.length) return {};

      const styleItem = styles[index];
      return typeof styleItem === 'function' ? styleItem(rowData) : styleItem;
    },
    [styles, rowData],
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {keys.map((key, index) => {
        const combinedStyle = {
          width: '100%',
          borderBottom: '1px solid black',
          ...resolveStyle(index),
        };

        return (
          <div key={key} style={combinedStyle}>
            {rowData[key]}
          </div>
        );
      })}
    </div>
  );
};
