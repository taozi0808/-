import React from 'react';
import Tooltip from '@mui/material/Tooltip';
import './index.scss';

const LastUpdateInfo = props => {
  return (
    <div className="last-update" style={props.style}>
      <div style={{ width: 100 }}>{props.title ?? '【最終更新者】'}</div>
      <div>
        社員番号：
        <Tooltip title={props.userId} arrow>
          {props.userId}
        </Tooltip>
      </div>
      <div>
        氏名：{' '}
        <Tooltip title={props.userId} arrow>
          {props.userName}
        </Tooltip>
      </div>
    </div>
  );
};

export default LastUpdateInfo;
