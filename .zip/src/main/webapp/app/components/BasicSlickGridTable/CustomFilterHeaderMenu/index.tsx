import React, { useState, useEffect, useMemo } from 'react';
import debounce from 'lodash.debounce';
import './index.scss';
import { isEqual, sortBy } from 'lodash';

export interface CustomFilterHeaderMenuProps {
  /** 外部传入的列表数据 */
  listData: string[];
  /** 如果已有过滤条件，可以传入初始选中项，便于下次打开时回显 */
  initialSelectedItems?: string[];
  /** 点击 OK 按钮后传出选中的项，外部可用来触发 slickgrid-react 的过滤 */
  onApplyFilter: (selectedValues: string[]) => void;
  onClose: () => void;
}

const CustomFilterHeaderMenu: React.FC<CustomFilterHeaderMenuProps> = ({ listData, initialSelectedItems = [], onApplyFilter, onClose }) => {
  const [isSelectAll, setIsSelectAll] = useState(isEqual(sortBy(listData), sortBy(initialSelectedItems)));
  // 搜索框文本
  const [searchTerm, setSearchTerm] = useState('');
  // 搜索过滤后的列表数据
  const [filteredList, setFilteredList] = useState<string[]>(listData);
  // 用 Set 保存选中的项，便于判断和更新（支持多选）
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set(initialSelectedItems));

  // 使用防抖函数优化输入检索（300ms 防抖）
  const debouncedFilter = useMemo(
    () =>
      debounce((term: string) => {
        const lowerTerm = term.toLowerCase();
        const filtered = listData.filter(item => item.toString().toLowerCase().includes(lowerTerm));
        setFilteredList(filtered);
      }, 300),
    [listData],
  );

  useEffect(() => {
    debouncedFilter(searchTerm);
    return () => {
      debouncedFilter.cancel();
    };
  }, [searchTerm, debouncedFilter]);

  const toggleItem = (itemValue: string) => {
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemValue)) {
        newSet.delete(itemValue);
      } else {
        newSet.add(itemValue);
      }
      setIsSelectAll(newSet.size === filteredList.length);
      return newSet;
    });
  };

  const selectAll = () => {
    if (isSelectAll) {
      setSelectedItems(new Set());
      setIsSelectAll(false);
    } else {
      setSelectedItems(new Set(filteredList));
      setIsSelectAll(true);
    }
  };

  const handleOk = () => {
    const selectedArray = Array.from(selectedItems);
    onApplyFilter(selectedArray);
    onClose();
  };

  const handleCancel = () => {
    onClose();
  };

  return (
    <div className="custom-header-menu">
      <input type="text" placeholder="搜索..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="search" />

      <div className="menu-list">
        <div className="menu-list-item">
          <input type="checkbox" checked={isSelectAll} onChange={selectAll} id="すべて選択" name="すべて選択" className="checkbox-item" />
          <label htmlFor="すべて選択">すべて選択</label>
        </div>
        {filteredList.map(item => (
          <div className="menu-list-item" key={item}>
            <input
              type="checkbox"
              checked={selectedItems.has(item)}
              onChange={() => toggleItem(item)}
              id={item}
              name={item}
              className="checkbox-item"
            />
            <label htmlFor={item}>{item}</label>
          </div>
        ))}
      </div>

      <div className="menu-actions">
        <button onClick={handleOk}>OK</button>
        <button onClick={handleCancel}>キャンセル</button>
      </div>
    </div>
  );
};

export default CustomFilterHeaderMenu;
