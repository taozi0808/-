import React, { useRef, useEffect } from 'react';
import { Column, MenuCommandItem, OnSelectedRowsChangedEventArgs, SlickgridReact, OperatorType } from 'slickgrid-react';
import './index.scss';
import { CustomPagerComponent } from './CustomPager';
import { localeJapanese } from './constans';
import { createRoot } from 'react-dom/client';
import CustomFilterHeaderMenu from './CustomFilterHeaderMenu';

export interface BasicSlickGridTable {
  /** 外部传入的列配置 */
  columns: Column[];
  /** 外部传入的数据 */
  data: any[];
  /** 初始每页显示条数，默认为10 */
  initialPageSize?: number;
  disabledPagination?: boolean;
  onSelectionChanged?: (id: string) => void;
  enableContextMenu?: boolean;
  contextMenuItems?: Array<MenuCommandItem>;
}

const BasicSlickGridTable: React.FC<BasicSlickGridTable> = ({
  columns,
  data,
  initialPageSize = 10,
  disabledPagination = false,
  onSelectionChanged,
  enableContextMenu = false,
  contextMenuItems = [],
}) => {
  const reactGridRef = useRef<any>(null);
  const selectedRowIdRef = useRef('');
  const customFilterMenuRootRef = useRef(null);
  const customFilterSelectMapRef = useRef({});

  const onSelected = (e: CustomEvent<{ eventData: any; args: OnSelectedRowsChangedEventArgs }>) => {
    if (Array.isArray(e.detail.args.rows) && e.detail.args.rows.length) {
      const grid = e.detail.args.grid;
      const item = grid.getDataItem(e.detail.args.rows[0]);
      if (item) {
        let newId = '';
        if (item.id !== selectedRowIdRef.current) {
          newId = item.id;
        } else {
          reactGridRef.current?.slickGrid?.setSelectedRows([]);
        }
        selectedRowIdRef.current = newId;
        onSelectionChanged(newId);
      }
    }
  };

  /**
   * 在表头菜单显示后，在表头菜单最后追加自定义的过滤器
   */
  const onAfterMenuShow = (e, args) => {
    if (args.column.filterable) {
      const container = document.createElement('div');
      customFilterMenuRootRef.current = createRoot(container);

      // 聚合当前列的全部数据，用于填充过滤菜单中的下拉菜单数据
      const selectOptions: string[] = reactGridRef.current.dataView.filteredItems.map(item =>
        args.column.formatter ? args.column.formatter(null, null, item[args.column.field]) : item[args.column.field],
      );

      // 插入自定义下拉菜单
      const menuElm = reactGridRef.current.extensionService._headerMenuPlugin.menuElement;
      menuElm.appendChild(container);
      customFilterMenuRootRef.current.render(
        <CustomFilterHeaderMenu
          listData={[...new Set(selectOptions)]}
          initialSelectedItems={
            customFilterSelectMapRef.current[args.column.field] ? customFilterSelectMapRef.current[args.column.field] : []
          }
          onApplyFilter={(selectedValues: string[]) => {
            customFilterSelectMapRef.current[args.column.field] = selectedValues;

            if (selectedValues.length) {
              // 实现支持多列筛选功能，每次先拿到全量的过滤条件，添加或修改后再次全量更新；
              const currentFilters = reactGridRef.current.filterService.getCurrentLocalFilters();
              const filter = currentFilters.find(item => item.columnId === args.column.id);
              if (filter) {
                filter.searchTerms = selectedValues;
              } else {
                currentFilters.push({
                  columnId: args.column.id,
                  searchTerms: selectedValues,
                  operator: OperatorType.in,
                });
              }
              reactGridRef.current.filterService.updateFilters(currentFilters);
            } else {
              reactGridRef.current.filterService.clearFilterByColumnId({}, args.column.id);
            }
          }}
          onClose={() => {
            reactGridRef.current.extensionService._headerMenuPlugin.hideMenu?.();
            customFilterMenuRootRef.current?.unmount();
          }}
        />,
      );
    }
  };

  return (
    <div onContextMenu={e => e.preventDefault()} id="basic-slick-grid-table" style={{ width: '100%', height: '100%' }}>
      <SlickgridReact
        gridId="grid1"
        columnDefinitions={columns}
        dataset={data}
        onSelectedRowsChanged={onSelected}
        onReactGridCreated={reactGrid => {
          console.log(reactGrid); // 打印 reactGrid 对象
          (window as any).aller = reactGrid.detail;
          reactGridRef.current = reactGrid.detail;
        }}
        gridOptions={{
          enableGridMenu: false,
          enableColumnReorder: false,
          enableRowSelection: true,
          multiSelect: false,
          enableCheckboxSelector: false,
          enableCellNavigation: true,
          rowSelectionOptions: {
            selectActiveRow: true,
          },
          checkboxSelector: {
            hideSelectAllCheckbox: true,
          },

          emptyDataWarning: { message: '該当件数が０件でした。検索条件を変更してください。' },
          customPaginationComponent: !disabledPagination ? CustomPagerComponent : null,
          enablePagination: !disabledPagination,
          pagination: {
            pageSize: initialPageSize,
          },
          enableHeaderMenu: true,
          headerMenu: {
            hideColumnHideCommand: true,
            hideColumnResizeByContentCommand: true,
            onBeforeMenuShow: (e, args) => {
              const commandItems = [];
              if (args.column.sortable) {
                commandItems.push({
                  iconCssClass: 'mdi mdi-sort-variant-off',
                  titleKey: 'REMOVE_SORT',
                  command: 'clear-sort',
                  positionOrder: 1,
                  title: 'ソートを解除',
                });
              }

              if (args.column.filterable) {
                commandItems.push({
                  iconCssClass: 'mdi mdi-filter-remove-outline',
                  titleKey: 'REMOVE_FILTER',
                  command: 'clear-filter',
                  positionOrder: 2,
                  title: 'フィルタを解除',
                });
              }

              if (commandItems.length && args.column.filterable) {
                commandItems.push({
                  divider: true,
                  command: '',
                  positionOrder: 3,
                });
              }

              (args.menu as any).commandItems = commandItems;
            },
            onCommand: (e, args) => {
              if (args.command === 'clear-filter') {
                customFilterSelectMapRef.current[args.column.field] = [];
              }
              if (args.command === 'clear-sort') {
                reactGridRef.current.sortService.clearSorting();
              }
              customFilterMenuRootRef.current?.unmount();
            },
            onAfterMenuShow,
          },
          autoResize: {
            container: '#basic-slick-grid-table',
            minHeight: 350,
            rightPadding: 0,
            bottomPadding: 10,
            // resizeDetection: 'container',
          },
          rowHeight: 40,
          enableContextMenu,
          contextMenu: {
            hideCopyCellValueCommand: true,
            hideCloseButton: true,
            hideOptionSection: true,
            commandItems: contextMenuItems,
          },
          enableFiltering: true,
          showHeaderRow: false,
          locales: localeJapanese,
          multiColumnSort: true,
          // tristateMultiColumnSort: true, // 开启后通过单击表头即可触发多列排序
          params: {
            hideFilterHeaderRow: true,
          },
        }}
      />
    </div>
  );
};

export default BasicSlickGridTable;
