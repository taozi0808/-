import React from 'react';
import { IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const DiaglogHead = ({ closeOnClick }) => {
  return (
    <div style={{ height: 50, backgroundColor: '#D3E3FD' }}>
      <IconButton
        aria-label="close"
        onClick={closeOnClick}
        sx={theme => ({
          position: 'absolute',
          right: 8,
          top: 8,
          color: theme.palette.grey[500],
        })}
      >
        <CloseIcon />
      </IconButton>
    </div>
  );
};

export default DiaglogHead;
