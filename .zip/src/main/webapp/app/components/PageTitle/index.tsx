import React from 'react';
import './index.scss';

const PageTitle = props => {
  return (
    <div className="page-title">
      <h1 className="title">{props.title}</h1>
      <div className="actions">{props.actions}</div>
    </div>
  );
};

export default PageTitle;
