import { useLocation, useNavigate } from 'react-router-dom';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, ListItemButton, Collapse, Box } from '@mui/material';
import {
  Menu as MenuIcon,
  ChevronLeft,
  ChevronRight,
  Apps,
  Description,
  Calculate,
  Settings,
  List as ListIcon,
  Add,
  Hub,
  PersonOutline,
  AccountBox,
  ExpandLess,
  ExpandMore,
  Topic,
} from '@mui/icons-material';
import React, { useState } from 'react';
import './index.scss';
import useAccountStore from 'app/shared/zustandStore/account';
import menuIcon1 from 'app/shared/layout/SideNav/menuIcon/menuIcon1.png';
import menuIcon2 from 'app/shared/layout/SideNav/menuIcon/menuIcon2.png';
import menuIcon3 from 'app/shared/layout/SideNav/menuIcon/menuIcon3.png';
import menuIcon4 from 'app/shared/layout/SideNav/menuIcon/menuIcon4.png';
import menuIcon5 from 'app/shared/layout/SideNav/menuIcon/menuIcon5.png';
import menuIcon6 from 'app/shared/layout/SideNav/menuIcon/menuIcon6.png';
import menuIcon7 from 'app/shared/layout/SideNav/menuIcon/menuIcon7.png';
import menuIcon8 from 'app/shared/layout/SideNav/menuIcon/menuIcon8.png';
import menuIcon9 from 'app/shared/layout/SideNav/menuIcon/menuIcon9.png';
import menuIcon10 from 'app/shared/layout/SideNav/menuIcon/menuIcon10.png';
import menuIcon11 from 'app/shared/layout/SideNav/menuIcon/menuIcon11.png';

interface MenuItem {
  key: string;
  label: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  className?: string;
  children?: MenuItem[];
  onClick?: () => void;
}

const SideNav = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [openKey, setOpenKey] = useState('');
  const { userName } = useAccountStore();

  if (userName === 'admin') {
    const items: MenuItem[] = [
      {
        key: '0',
        label: '大東建設',
        disabled: true,
        className: 'side-nav-logo',
      },
      {
        key: '/webA0040',
        label: 'ダッシュボード画面へ',
        icon: <Box component="img" src={menuIcon1} sx={{ width: 22, height: 20 }} />,
        onClick: () => {
          navigate('/webA0040');
          setOpenKey('');
        },
        className: location.pathname === '/webA0040' ? 'text-color2' : '',
      },
      {
        key: '1',
        label: '契約管理業務',
        icon: <Box component="img" src={menuIcon2} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webB0010',
            label: '案件管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webC0010',
            label: '概算管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webD0010',
            label: '精積算管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webF0010',
            label: '物件管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '2',
        label: '予算管理業務',
        icon: <Box component="img" src={menuIcon3} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webG0010',
            label: '実行予算管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '3',
        label: '見積/発注管理業務',
        icon: <Apps sx={{ color: '#285ac8' }} />,
        children: [],
      },
      {
        key: '4',
        label: '査定/支払/請求管理業務',
        icon: <Box component="img" src={menuIcon4} sx={{ width: 22, height: 20 }} />,
        children: [
          {
            key: '/webH0010',
            label: '査定管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webI0010',
            label: '出来高シミュレーション管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webJ0010',
            label: '支払管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webL0010',
            label: '請求管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '5',
        label: '工事経費管理業務',
        icon: <Box component="img" src={menuIcon5} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webM0010',
            label: '現場経費管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '6',
        label: '工事予実管理業務',
        icon: <Box component="img" src={menuIcon6} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webN0010',
            label: '工事予実管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '7',
        label: '業者管理業務',
        icon: <Box component="img" src={menuIcon7} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webO0010',
            label: '業者管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webP0010',
            label: '下請管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webQ0010',
            label: '作業員管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webQ0035',
            label: '作業員名簿管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '8',
        label: '承認管理業務',
        icon: <Box component="img" src={menuIcon9} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/WebS0010',
            label: '承認一覧（概算管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0020',
            label: '承認一覧（精積算管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0030',
            label: '承認一覧（物件管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0040',
            label: '承認一覧（実行予算管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0050',
            label: '承認一覧（査定管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0060',
            label: '承認一覧（現場経費管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0070',
            label: '承認一覧（工事予実管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0080',
            label: '承認一覧（協力業者管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0090',
            label: '承認一覧（作業員情報管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0100',
            label: '承認一覧（下請契約台帳）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0110',
            label: '承認一覧（再下請負通知書）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0120',
            label: '承認一覧（顧客管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0130',
            label: '承認一覧（会社管理）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0140',
            label: '承認一覧（自社情報）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
          {
            key: '/WebS0150',
            label: '承認一覧（作業員登録）',
            icon: <Add sx={{ color: '#285ac8' }} />,
          },
        ],
      },
      {
        key: '9',
        label: '申請管理業務',
        icon: <Apps sx={{ color: '#285ac8' }} />,
        children: [],
      },
      {
        key: '10',
        label: 'マスタ管理業務',
        icon: <Box component="img" src={menuIcon8} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webR0010',
            label: '権限管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webR0020',
            label: '組織管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webR0040',
            label: '社員管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webR0055',
            label: '顧客管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webR0080',
            label: '単価管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          // {
          //   key: '/webR0060',
          //   label: '顧客情報登録',
          //   icon: <Add sx={{ color: '#285ac8' }} />,
          // },
          // {
          //   key: '/budgetOverview2',
          //   label: '概算一覧2',
          //   icon: <Add sx={{ color: '#285ac8' }} />,
          // },
        ],
      },
    ];
    return (
      <Drawer
        variant="permanent"
        open={!collapsed}
        className="side-nav"
        PaperProps={{
          sx: {
            width: collapsed ? 35 : 260,
            backgroundColor: '#fff',
            transition: 'width 0.2s',
          },
        }}
      >
        <IconButton onClick={() => setCollapsed(!collapsed)} className="side-nav-collapse">
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </IconButton>
        <List component="nav" sx={{ width: '100%', maxWidth: 360, bgcolor: '#f5f9ff' }}>
          {items.map(item => (
            <>
              <ListItemButton
                key={item.key}
                className={item.className}
                onClick={item.onClick || (() => setOpenKey(openKey === item.key ? '' : item.key))}
              >
                {item.icon && <ListItemIcon>{item.icon}</ListItemIcon>}
                {!collapsed && (
                  <>
                    <ListItemText primary={item.label} className={openKey === item.key ? 'text-color' : ''} />
                    {item.children ? openKey === item.key ? <ExpandLess /> : <ExpandMore /> : ''}
                  </>
                )}
              </ListItemButton>
              {item.children && !collapsed && (
                <Collapse in={openKey === item.key} unmountOnExit>
                  <List component="div" disablePadding>
                    {item.children.map(child => (
                      <ListItemButton
                        sx={{ pl: 4 }}
                        key={child.key}
                        onClick={() => navigate(child.key)}
                        selected={location.pathname === child.key}
                      >
                        {child.icon && <ListItemIcon>{child.icon}</ListItemIcon>}
                        <ListItemText primary={child.label} />
                      </ListItemButton>
                    ))}
                  </List>
                </Collapse>
              )}
            </>
          ))}
        </List>
      </Drawer>
    );
  } else if (userName === 'user') {
    const items: MenuItem[] = [
      {
        key: '0',
        label: '大東建設',
        disabled: true,
        className: 'side-nav-logo',
      },
      {
        key: '/webA0040',
        label: 'ダッシュボード画面へ',
        icon: <Box component="img" src={menuIcon1} sx={{ width: 22, height: 20 }} />,
        onClick: () => {
          navigate('/webA0040');
          setOpenKey('');
        },
        className: location.pathname === '/webA0040' ? 'text-color2' : '',
      },
      {
        key: '1',
        label: '現場情報管理業務',
        icon: <Box component="img" src={menuIcon2} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webT0010',
            label: '現場情報',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '2',
        label: '作業員情報管理業務',
        icon: <Box component="img" src={menuIcon4} sx={{ width: 22, height: 20 }} />,
        children: [
          {
            key: '/webV0010',
            label: '作業員管理',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
      {
        key: '3',
        label: '発注管理業務',
        icon: <Apps sx={{ color: '#285ac8' }} />,
        children: [],
      },
      {
        key: '4',
        label: '会社情報管理業務',
        icon: <Box component="img" src={menuIcon3} sx={{ width: 20, height: 20 }} />,
        children: [
          {
            key: '/webU0010',
            label: '自社情報登録',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
          {
            key: '/webU0020',
            label: '下請登録',
            icon: <Box component="img" src={menuIcon10} sx={{ width: 15, height: 15 }} />,
          },
        ],
      },
    ];
    return (
      <Drawer
        variant="permanent"
        open={!collapsed}
        className="side-nav"
        PaperProps={{
          sx: {
            width: collapsed ? 35 : 260,
            backgroundColor: '#fff',
            transition: 'width 0.2s',
          },
        }}
      >
        <IconButton onClick={() => setCollapsed(!collapsed)} className="side-nav-collapse">
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </IconButton>
        <List component="nav" sx={{ width: '100%', maxWidth: 360, bgcolor: '#f5f9ff' }}>
          {items.map(item => (
            <>
              <ListItemButton
                key={item.key}
                className={item.className}
                onClick={item.onClick || (() => setOpenKey(openKey === item.key ? '' : item.key))}
              >
                {item.icon && <ListItemIcon>{item.icon}</ListItemIcon>}
                {!collapsed && (
                  <>
                    <ListItemText primary={item.label} className={openKey === item.key ? 'text-color' : ''} />
                    {item.children ? openKey === item.key ? <ExpandLess /> : <ExpandMore /> : ''}
                  </>
                )}
              </ListItemButton>
              {item.children && !collapsed && (
                <Collapse in={openKey === item.key} unmountOnExit>
                  <List component="div" disablePadding>
                    {item.children.map(child => (
                      <ListItemButton
                        sx={{ pl: 4 }}
                        key={child.key}
                        onClick={() => navigate(child.key)}
                        selected={location.pathname === child.key}
                      >
                        {child.icon && <ListItemIcon>{child.icon}</ListItemIcon>}
                        <ListItemText primary={child.label} />
                      </ListItemButton>
                    ))}
                  </List>
                </Collapse>
              )}
            </>
          ))}
        </List>
      </Drawer>
    );
  }
};

export default SideNav;
