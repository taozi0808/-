/**
 * 提供若干快捷工具函数，用来将列表数据暂存在localStorage中，并对列表数据进行增删改查操作；
 */
export const similarDepartments = [
  '販売部', // 销售部
  'マーケティング部', // 市场营销部
  '営業企画部', // 销售策划部
  '営業推進部', // 销售推进部
  '営業サポート部', // 销售支持部
];

export const contractStatus = [
  '0', // 未成約
  '1', // 成約
  '9', // 不成約
];

/**
 * 业者一览_提供若干快捷工具函数，用来将列表数据暂存在localStorage中，并对列表数据进行增删改查操作；
 */
export const kenkoushindan1 = ['〇', '✕'];

// 定义列表的 key，确保访问的是同一个 localStorage 项目
export const STORAGE_KEY = 'CONSTRUCTION_MANAGEMENT_DB_KEY7';
export const STORAGE_KEY_CUSTOMER = 'CONSTRUCTION_MANAGEMENT_DB_CUSTOMER';
export const STORAGE_KEY_DEKIDAKA = 'CONSTRUCTION_MANAGEMENT_DB_CUSTOMER_DEKIDAKA';
export const STORAGE_KEY_GAISAN = 'CONSTRUCTION_MANAGEMENT_DB_GAISAN';
export const STORAGE_KEY_JIKKOYOSAN = 'CONSTRUCTION_MANAGEMENT_DB_JIKKOYOSAN';
export const STORAGE_KEY_SEIKYUSYO = 'CONSTRUCTION_MANAGEMENT_DB_SEIKYUSYO';
export const WebD0010 = 'WebD0010';
export const STORAGE_KEY_SHONIN_GAISAN = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_GAISAN';
export const STORAGE_KEY_SHONIN_BUKKEN = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_BUKKEN';
export const STORAGE_KEY_SHONIN_BAKEIHI = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_BAKEIHI';
export const STORAGE_KEY_SHONIN_SEKISAN = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_SEKISAN';
export const STORAGE_KEY_SHONIN_JIKKOYOSAN = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_JIKKOYOSAN';
export const STORAGE_KEY_SHONIN_SATEI = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_SATEI';
export const STORAGE_KEY_SHONIN_KOJIYOJITSU = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_KOJIYOJITSU';
export const STORAGE_KEY_SHONIN_GYOSHA = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_GYOSHA';
export const STORAGE_KEY_SHONIN_SAGYOUIN = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_SAGYOUIN';
export const STORAGE_KEY_SHONIN_SHITAUKE_KEIYAKU = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_SHITAUKE_KEIYAKU';
export const STORAGE_KEY_SHONIN_SAISHITAUKEOI = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_SAISHITAUKEOI';
export const STORAGE_KEY_SHONIN_KOKYAKU = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_KOKYAKU';
export const STORAGE_KEY_SHONIN_KAISHA = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_KAISHA';
export const STORAGE_KEY_SHONIN_JISHA = 'CONSTRUCTION_MANAGEMENT_DB_SHONIN_JISHA';
export const STORAGE_KEY_BUKKEN = 'CONSTRUCTION_MANAGEMENT_DB_BUKKEN';
export const STORAGE_KEY_SHAIN = 'CONSTRUCTION_MANAGEMENT_DB_SHAIN';

export const DBManager = (() => {
  // 工具函数 - 从 localStorage 获取列表
  const getListFromStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  };

  // 顾客 - 工具函数 - 从 localStorage 获取列表
  const getCustomerListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_CUSTOMER);
    return data ? JSON.parse(data) : [];
  };

  // 出来高 - 工具函数 - 从 localStorage 获取列表
  const getDekidakaListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_DEKIDAKA);
    return data ? JSON.parse(data) : [];
  };

  // 概算 - 工具函数 - 从 localStorage 获取列表
  const getGaisanListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_GAISAN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（概算管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninGaisanStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_GAISAN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（物件管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninBukkenStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_BUKKEN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（現場経費管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninBakeihiStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_BAKEIHI);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（精積算一覧） - 工具函数 - 从 localStorage 获取列表
  const getShoninSekisanStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_SEKISAN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（実行予算一覧） - 工具函数 - 从 localStorage 获取列表
  const getShoninJikkoYosanListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_JIKKOYOSAN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（査定管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninSateiListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_SATEI);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（工事予実管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninKojiYojitsuStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_KOJIYOJITSU);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（協力業者管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninGyoshaStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_GYOSHA);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（作業員情報管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninSagyouInStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_SAGYOUIN);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（下請契約台帳） - 工具函数 - 从 localStorage 获取列表
  const getShoninShitaukeKeiyakuStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_SHITAUKE_KEIYAKU);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（再下請負通知書） - 工具函数 - 从 localStorage 获取列表
  const getShoninSaiShitaukeoiStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_SAISHITAUKEOI);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（顧客管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninKokyakuStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_KOKYAKU);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（会社管理） - 工具函数 - 从 localStorage 获取列表
  const getShoninKaishaStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_KAISHA);
    return data ? JSON.parse(data) : [];
  };

  // 承認一覧（自社情報） - 工具函数 - 从 localStorage 获取列表
  const getShoninJishaStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_JISHA);
    return data ? JSON.parse(data) : [];
  };

  // 物件一覧 - 工具函数 - 从 localStorage 获取列表
  const getBukkenStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHONIN_BUKKEN);
    return data ? JSON.parse(data) : [];
  };

  // 社員一覧 - 工具函数 - 从 localStorage 获取列表
  const getShainListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SHAIN);
    return data ? JSON.parse(data) : [];
  };

  // 実行予算 - 工具函数 - 从 localStorage 获取列表
  const getJikkoYosanListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_JIKKOYOSAN);
    return data ? JSON.parse(data) : [];
  };

  // 請求書
  const getSeikyushoListStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY_SEIKYUSYO);
    return data ? JSON.parse(data) : [];
  };

  // 工具函数 - 将列表保存到 localStorage
  const saveListToStorage = list => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  };

  // 精積算一覧
  const getWebD0010 = () => {
    const data = localStorage.getItem(WebD0010);
    return data ? JSON.parse(data) : [];
  };

  return {
    /**
     * 新增一条数据（从头部添加，并默认按创建时间倒序）
     * @param {Object} newItem - 要新增的对象（包含 id 和 name 等字段）
     */
    addItem(newItem) {
      const list = getListFromStorage();
      list.unshift(newItem); // 将新数据加到头部
      saveListToStorage(list);
    },

    /**
     * 获取完整列表
     * @returns {Array} - 返回完整数据列表
     */
    getList() {
      return getListFromStorage();
    },

    /**
     * 获取完整列表 - AS6042
     * @param storageKey 定义列表的Key
     * @returns {Array} - 返回完整数据列表
     */
    getMockList(storageKey: string) {
      const data = localStorage.getItem(storageKey);
      return data ? JSON.parse(data) : [];
    },

    /**
     * 出来高
     * @returns {Array} - 返回完整数据列表
     */
    getDekidakaList() {
      return getDekidakaListStorage();
    },

    /**
     * 概算
     * @returns {Array} - 返回完整数据列表
     */
    getGaisanList() {
      return getGaisanListStorage();
    },

    /**
     * 承認一覧（概算管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninGaisanDataList() {
      return getShoninGaisanStorage();
    },

    /**
     * 承認一覧（物件管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninBukkenDataList() {
      return getShoninBukkenStorage();
    },

    /**
     * 承認一覧（現場経費管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninBakeihiDataList() {
      return getShoninBakeihiStorage();
    },

    /**
     * 承認一覧（精積算一覧）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninSekisanDataList() {
      return getShoninSekisanStorage();
    },

    /**
     * 承認一覧（実行予算管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninJikkoYosanList() {
      return getShoninJikkoYosanListStorage();
    },

    /**
     * 承認一覧（査定管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninSateiList() {
      return getShoninSateiListStorage();
    },

    /**
     * 承認一覧（工事予実管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninKojiYojitsuList() {
      return getShoninKojiYojitsuStorage();
    },

    /**
     *  承認一覧（協力業者管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninGyoshaList() {
      return getShoninGyoshaStorage();
    },

    /**
     *  承認一覧（協力業者管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninSagyouInList() {
      return getShoninSagyouInStorage();
    },

    /**
     *  承認一覧（下請契約台帳）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninShitaukeKeiyaku() {
      return getShoninShitaukeKeiyakuStorage();
    },

    /**
     *  承認一覧（再下請負通知書）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninSaiShitaukeoi() {
      return getShoninSaiShitaukeoiStorage();
    },

    /**
     *  承認一覧（顧客管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninKokyaku() {
      return getShoninKokyakuStorage();
    },

    /**
     *  承認一覧（会社管理）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninKaisha() {
      return getShoninKaishaStorage();
    },

    /**
     *  承認一覧（自社情報）
     * @returns {Array} - 返回完整数据列表
     */
    getShoninJisha() {
      return getShoninJishaStorage();
    },

    /**
     *  物件一覧
     * @returns {Array} - 返回完整数据列表
     */
    getBukkenList() {
      return getBukkenStorage();
    },

    /**
     *  社員一覧
     * @returns {Array} - 返回完整数据列表
     */
    getShainList() {
      return getShainListStorage();
    },

    /**
     * 実行予算
     * @returns {Array} - 返回完整数据列表
     */
    getJikkoYosanList() {
      return getJikkoYosanListStorage();
    },

    /**
     * 請求書
     * @returns {Array} - 返回完整数据列表
     */
    getSeikyushoList() {
      return getSeikyushoListStorage();
    },

    /**
     * 精積算一覧
     * @returns {Array} - 返回完整数据列表
     */
    getgetWebD0010List() {
      return getWebD0010();
    },

    /**
     * 顾客获取完整列表
     * @returns {Array} - 返回完整数据列表
     */
    getCustomerList() {
      return getCustomerListStorage();
    },

    /**
     * 根据 id 删除某一条数据
     * @param {string|number} id - 要删除数据的 id
     */
    deleteItemById(id) {
      const list = getListFromStorage();
      const updatedList = list.filter(item => item.id !== id);
      saveListToStorage(updatedList);
    },

    /**
     * 根据 id 获取某一条数据
     * @param {string|number} id - 要查找数据的 id
     * @returns {Object|null} - 返回查找到的数据对象，未找到则返回 null
     */
    getItemById(id) {
      const list = getListFromStorage();
      return list.find(item => item.id === id) || null;
    },

    /**
     * 根据 id 获取Cutomer某一条数据
     * @param {string|number} id - 要查找数据的 id
     * @returns {Object|null} - 返回查找到的数据对象，未找到则返回 null
     */
    getItemByCustomerId(id) {
      const list = getCustomerListStorage();
      return list.find(item => item.id === id) || null;
    },

    /**
     * 根据 id 更新已有数据
     * @param {string|number} id - 要更新数据的 id
     * @param {Object} updatedData - 要更新的数据内容
     */
    updateItemById(id, updatedData) {
      const list = getListFromStorage();
      const index = list.findIndex(item => item.id === id);
      if (index !== -1) {
        list[index] = {
          ...list[index],
          ...updatedData,
          updatedAt: new Date().toISOString(),
        }; // 更新数据并加上更新时间
        saveListToStorage(list);
      }
    },
  };
})();

// 生成指定长度的UUID
export const generateUUID = (length = 12) => {
  return Array.from(crypto.getRandomValues(new Uint8Array(length)))
    .map(byte => byte.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, length);
};

/** *************************
 *生成案件code【アルファベット1桁+年月6桁+連番2桁】
 */

function generateAnkenCodeString(): string {
  // 闭包维护顺番计数器（私有状态）
  let serialCounter = 0;

  serialCounter++;

  // 1. 生成随机字母（大小写混合）
  const randomLetter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 52)];

  // 2. 生成随机年月（YYYYMM 格式，年份范围 1900-2099，月份 1-12）
  const year = 1900 + Math.floor(Math.random() * 100);
  const month = Math.floor(Math.random() * 12) + 1;
  const yearMonth = `${year.toString().padStart(2, '0')}${month.toString().padStart(2, '0')}`;

  // 3. 生成顺番（自动递增，补零到2位）
  const serial = serialCounter.toString().padStart(2, '0');

  return `${randomLetter}${yearMonth}${serial}`;
}

/** *************************
 *生成案件名方法
 */

function generateJapaneseBuildingProjectName(): string {
  // 闭包维护项目计数器（私有状态）
  let projectCounter = 0;

  // 预定义数据池
  const regions = ['東京', '大阪', '名古屋', '福岡', '札幌', '京都', '横滨', '神户', '广岛', '仙台'];
  const projectTypes = [
    'マンション建設',
    'オフィスビル',
    '商業施設',
    'リゾートホテル',
    '学校校舎',
    '病院',
    '駅前再開発',
    '新築住宅',
    '工場建設',
    '歴史建築修復',
  ];
  const modifiers = ['プロジェクト', '計画', 'タワー', 'コンプレックス', 'シティ', 'ヴィラ', 'パーク'];
  const suffixes = ['Phase1', 'AreaA', 'BlockB', 'New', 'Alpha'];

  projectCounter++;

  // 1. 随机选择地域（带行政区划）
  const region = regions[Math.floor(Math.random() * regions.length)];
  const district = ['・港区', '・新宿区', '・中野区', '・大阪市北区'][Math.floor(Math.random() * 4)];

  // 2. 随机组合项目类型和修饰词
  const projectName = projectTypes[Math.floor(Math.random() * projectTypes.length)];
  const modifier = modifiers[Math.floor(Math.random() * modifiers.length)];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

  // 3. 生成唯一编号（补零到3位）
  const serialNumber = projectCounter.toString().padStart(3, '0');

  // 4. 组合完整名称（符合日本命名习惯）
  let fullName = `${region}${district} ${projectName} ${modifier}`;

  // 5. 添加可选后缀（30%概率）
  if (Math.random() < 0.3) {
    fullName += ` ${suffix}`;
  }

  // 6. 格式标准化（全角括号和空格）
  fullName = fullName
    .replace(/ /g, '　') // 全角空格
    .replace(/([a-z])/g, match => String.fromCharCode(match.charCodeAt(0) + 65)) // 强制大写
    .trim();

  // 4. 组合并格式化
  return fullName; // 使用全角空格连接
}
/** *************************
 *生成日本电话号码
 */
function generateJapanesePhoneNumber(): string {
  // 日本电话号码格式规范
  const phoneNumber = [
    '090-0901-2120', // 移动电话（Docomo/au/SoftBank）
    '080-0635-1234', // 移动电话（Willcom）
    '070-2134-0987', // 移动电话（LINE Pay）
    '03-0906-3467', // 东京都区号
    '06-5678-2314', // 大阪都区号
    '077-7894-6354', // 北海道区号
    '045-5201-3698', // 福冈都区号
  ];

  // 随机选择号码格式
  return phoneNumber[Math.floor(Math.random() * phoneNumber.length)];
}
/** *************************
 *生成住所方法
 */
function generateJapaneseAddress(): string {
  // 移除闭包状态，每次调用独立生成
  const prefectures = [
    '東京都',
    '大阪府',
    '北海道',
    '青森県',
    '岩手県',
    '宮城県',
    '秋田県',
    '山形県',
    '福島県',
    '茨城県',
    '栃木県',
    '群馬県',
    '埼玉県',
    '千葉県',
    '神奈川県',
    '新潟県',
    '富山県',
    '石川県',
    '福井県',
    '山梨県',
    '長野県',
    '岐阜県',
    '静岡県',
    '愛知県',
    '三重県',
    '滋賀県',
    '京都府',
    '大阪府',
    '兵庫県',
    '奈良県',
    '和歌山県',
    '鳥取県',
    '島根県',
    '岡山県',
    '広島県',
    '山口県',
    '徳島県',
    '香川県',
    '愛媛県',
    '高知県',
    '福岡県',
    '佐賀県',
    '長崎県',
    '熊本県',
    '大分県',
    '宮崎県',
    '鹿児島県',
    '沖縄県',
  ];

  const prefectureDistricts = {
    東京都: ['千代田区', '新宿区', '涩谷区', '中野区', '港区', '麻布区'],
    大阪府: ['大阪市', '堺市', '北区', '西区', '中央区', '南区'],
    北海道: ['札幌市', '小樽市', '函館市', '旭川市', '釣路市'],
  };

  // 1. 随机选择要素
  const prefecture = prefectures[Math.floor(Math.random() * prefectures.length)];
  const district = prefectureDistricts[prefecture]?.[Math.floor(Math.random() * prefectureDistricts[prefecture].length)] || prefecture;

  // 2. 生成地址核心部分
  const chome = Math.floor(Math.random() * 9) + 1; // 1-9丁目
  const bangai = `${Math.floor(Math.random() * 30) + 1}-${Math.floor(Math.random() * 10) + 1}`;

  // 3. 生成可选信息（30%概率）
  const buildingInfo =
    Math.random() < 0.3 ? ` ${['丁目', '町', '字', '番地'][Math.floor(Math.random() * 4)]}${Math.floor(Math.random() * 100) + 1}` : '';

  // 4. 组合并格式化
  return [district, `${chome}丁目${bangai}`, buildingInfo].join('　'); // 使用全角空格连接
}
/** *************************
 *生成姓名方法
 */
function generateCustomerName(): string {
  let nameCounter = 0;

  // 预定义数据池（可扩展）
  const surnames = [
    '佐藤',
    '鈴木',
    '本田',
    '岡本',
    '森田',
    '中村',
    '小林',
    '西村',
    '長野',
    '田中',
    '伊藤',
    '山本',
    '近藤',
    '鳥居',
    '後藤',
    '高橋',
    '清水',
    '藤田',
    '坂本',
    '加藤',
    '吉田',
    '松本',
    '井戸',
    '木村',
    '山口',
    '久保',
    '増田',
  ];

  const givenNames = {
    male: ['翔', '健', '浩', '俊', '良', '正', '哲', '和', '裕', '恭'],
    female: ['美咲', '千夏', '咲希', '愛菜', '玲奈', '佳代', '真由美', '葵', '遥', '萌'],
  };

  const middleNames = ['英', '樹', '花', '香', '美', '子', '文', '雅', '志', '朋'];

  nameCounter++;

  // 1. 随机选择性别（默认50%概率）
  const isMale = Math.random() < 0.5;

  // 2. 生成核心姓名
  const surname = surnames[Math.floor(Math.random() * surnames.length)];
  const givenName = givenNames[isMale ? 'male' : 'female'][Math.floor(Math.random() * givenNames[isMale ? 'male' : 'female'].length)];

  return [surname, givenName].join('　'); // 使用全角空格连接
}
/** *************************
 *片假名转换映射表（按常见姓氏/名字分类）
 */
const KatakanaMap: { [key: string]: string } = {
  // 姓氏
  佐藤: 'サトウ',
  鈴木: 'スズキ',
  本田: 'ホンダ',
  岡本: 'オカモト',
  森田: 'モリタ',
  中村: 'ナカムラ',
  小林: 'コバヤシ',
  西村: 'ニシムラ',
  長野: 'ナガノ',
  田中: 'タナカ',
  伊藤: 'イトウ',
  山本: 'ヤマモト',
  近藤: 'コンドウ',
  鳥居: 'トリイ',
  後藤: 'ゴトウ',
  高橋: 'タカハシ',
  清水: 'シミズ',
  藤田: 'フジタ',
  坂本: 'サカモト',
  加藤: 'カトウ',
  吉田: 'ヨシダ',
  松本: 'マツモト',
  井戸: 'イド',
  木村: 'キムラ',
  山口: 'ヤマグチ',
  久保: 'クボ',
  増田: 'マスダ',

  // 男性名字
  翔: 'ショウ',
  健: 'ケン',
  浩: 'コウ',
  俊: 'トシ',
  良: 'リョウ',
  正: 'セイ',
  哲: 'テツ',
  和: 'カズ',
  裕: 'ユウ',
  恭: 'キョウ',

  // 女性名字
  美咲: 'ミサキ',
  千夏: 'チナツ',
  咲希: 'サキ',
  愛菜: 'マナ',
  玲奈: 'レナ',
  佳代: 'カヨ',
  真由美: 'マユミ',
  葵: 'アオイ',
  遥: 'ハルカ',
  萌: 'モエ',

  // 中间名
  英: 'ヒデ',
  樹: 'ジュ',
  花: 'カ',
  香: 'カオリ',
  美: 'ミ',
  子: 'コ',
  文: 'ブン',
  雅: 'ミヤビ',
  志: 'シ',
  朋: 'トモ',
};

// 增强版转换函数（支持复合词和特殊读音）
function convertToKatakana(fullName: string): string {
  // 分割姓氏和名字（假设用全角空格分隔）
  const [surname, givenName] = fullName.split('　');

  // 处理姓氏
  const katakanaSurname = KatakanaMap[surname] || surname; // 未定义时保留原汉字

  // 处理名字（支持复合词）
  const processNamePart = (name: string): string => {
    // 尝试完整匹配
    if (KatakanaMap[name]) return KatakanaMap[name];

    // 拆分复合词（最多尝试两次拆分）
    const extendedHan = '[\\u4E00-\\u9FFF\\u3400-\\u4DBF\\u20000-\\u2EBEF]';
    const parts = name.split(new RegExp(`(?<=[${extendedHan}])(?=[${extendedHan}])`, 'gu'));
    if (parts.length > 1) {
      const combined = parts.map(part => KatakanaMap[part] || part).join('');
      if (combined !== name) return combined;
    }

    // 最后手段：逐字转换
    return Array.from(name)
      .map(char => KatakanaMap[char] || char)
      .join('');
  };

  return `${katakanaSurname}${processNamePart(givenName)}`;
}

/** ***********
 * 随机生成进步度状态
 */
function generateJapaneseProgress(): string {
  const progressStages = ['商談中', '概算見積提出', '正式見積提出', '見積合意', '契約書提出', '成約', '不成約'];

  return progressStages[Math.floor(Math.random() * progressStages.length)];
}
/**
 * 建築関連業種
 * @returns 建設分野の詳細業種
 */
function generateConstructionGyoushuData(): string {
  const constructionCategories = [
    '土木工事業',
    '建築工事業',
    '建築工事業',
    '建築工事業',
    '大工工事業',
    '左官工事業',
    '屋根工事業',
    '電気工事業',
    '管工事業',
    '内装仕上工事業',
    '解体工事業',
    '建築資材卸売業',
  ];

  return constructionCategories[Math.floor(Math.random() * constructionCategories.length)];
}

/**
 * 生成随机有无状态
 * @returns "有" 或 "無"
 */
function generatePresence(): string {
  return Math.random() < 0.5 ? '有' : '無';
}

/**
 * 業者名‐業者支店名
 * @returns 業者名‐業者支店名
 */
function generateVendorInfo(): string {
  const vendorNames: string[] = [
    '大東株式会社',
    '大東建設',
    '大東電機',
    '大東運輸',
    '大東商事',
    '大東食品',
    '大東通信',
    '大東銀行',
    '大東不動産',
    '大東化工',
    '大東機械',
    '大東流通',
    '大東保険',
    '大東教育',
    '大東観光',
    '大東メディカル',
    '大東エンジニアリング',
    '大東エナジー',
    '大東テクノロジー',
    '大東ライフ',
  ];

  const branchNames: string[] = [
    '東京支店',
    '大阪支店',
    '名古屋支店',
    '福岡支店',
    '札幌支店',
    '横浜支店',
    '仙台支店',
    '広島支店',
    '京都支店',
    '神戸支店',
    '新宿支店',
    '渋谷支店',
    '池袋支店',
    '千葉支店',
    '埼玉支店',
    '静岡支店',
    '金沢支店',
    '熊本支店',
    '長崎支店',
    '那覇支店',
  ];

  // 随机选择一个業者名和一个支店名
  const vendorName: string = vendorNames[Math.floor(Math.random() * vendorNames.length)];
  const branchName: string = branchNames[Math.floor(Math.random() * branchNames.length)];

  // 使用全角空格连接業者名和支店名
  const fullName: string = vendorName + '　' + branchName;

  return fullName;
}

export const generateRandomData = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 用于测试多列排序用的data
  for (let i = 0; i < 8; i++) {
    const no = i + 1;
    const testSortData = {
      no,
      id: getRandomString(16),
      ankenCode: '111111', // 固定案件代码
      // 按索引分组设置案件名称
      ankenName: i < 4 ? '2222' : '3333',
      // 按模4分组设置客户名称（4组×2条）
      kokyakuName: (() => {
        const groups = ['4444', '5555', '6666', '7777'];
        return groups[i % 4];
      })(),
      genbaJyuusyo1: generateJapaneseAddress(), // 随机生成住所
      souteiKingaku: Math.floor(Math.random() * 10000) + 10000, // 随机生成金额
      jyucyuuMikomiYMD: getRandomDate('2023-01-01', '2025-01-01').toLocaleDateString(), // 随机生成订单时间
      cyakkouKibouYMD: getRandomDate('2023-01-01', '2025-01-01').toLocaleDateString(), // 随机生成开始时间
      eigyouBumonName: similarDepartments[Math.floor(Math.random() * similarDepartments.length)],
      eigyouTantousyaShiMei: generateCustomerName() + ' （担当）', // 随机生成担当
      shincyokudo: generateJapaneseProgress(), // 随机生成状态
      updateUserId: no + Math.floor(Math.random() * 100) + 1,
      updateTime: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      listJyucyuuJyoutai: contractStatus[Math.floor(Math.random() * contractStatus.length)], // 随机生成成约状态
    };

    randomData.push(testSortData);
  }

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const no = i + 1;
    const data = {
      no,
      id: getRandomString(16), // 随机生成一个ID
      ankenCode: generateAnkenCodeString(), // 随机生成案件code
      ankenName: generateJapaneseBuildingProjectName(), // 随机生成案件名字
      kokyakuName: generateCustomerName(), // 随机生成名字
      genbaJyuusyo1: generateJapaneseAddress(), // 随机生成住所
      souteiKingaku: Math.floor(Math.random() * 10000) + 10000, // 随机生成金额
      jyucyuuMikomiYMD: getRandomDate('2023-01-01', '2025-01-01').toLocaleDateString(), // 随机生成订单时间
      cyakkouKibouYMD: getRandomDate('2023-01-01', '2025-01-01').toLocaleDateString(), // 随机生成开始时间
      eigyouBumonName: similarDepartments[Math.floor(Math.random() * similarDepartments.length)],
      eigyouTantousyaShiMei: generateCustomerName() + ' （担当）', // 随机生成担当
      shincyokudo: generateJapaneseProgress(), // 随机生成状态
      updateUserId: no + Math.floor(Math.random() * 100) + 1,
      updateTime: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      listJyucyuuJyoutai: contractStatus[Math.floor(Math.random() * contractStatus.length)], // 随机生成成约状态
    };

    randomData.push(data);
  }

  return randomData;
};

export const generatCustomerData = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const no = i + 1;
    const data = {
      no: no,
      id: getRandomString(16), // 随机生成一个ID
      customerCode: generateAnkenCodeString(), // 随机生成顧客コード
      customerName: generateCustomerName(), // 随机生成顧客名字
      kuben: i % 2 === 0 ? '無' : '有', // 随机取引先区分
      gyousyu: i % 2 === 0 ? '業種' : '業態', // 業種・業態
      Jyuusyo: generateJapaneseAddress(), // 住所
      telno: generateJapanesePhoneNumber(), // 電話番号
      daihyoumei: generateCustomerName(), // 随机生成代表者名
      updateUserId: Math.floor(Math.random() * 100) + 1,
      updateTime: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      listJyucyuuJyoutai: contractStatus[Math.floor(Math.random() * contractStatus.length)], // 随机生成成约状态

      managerName: generateCustomerName(),
      managerKana: convertToKatakana(generateCustomerName()),
      customerShortName: generateCustomerName(),
      customerKana: convertToKatakana(generateCustomerName()),
      transactionType: '10',
      postalCodePart1: '0411',
      postalCodePart2: '0980',
      customerAddress: generateJapaneseAddress(),
      phone: generateJapanesePhoneNumber(),
      mobile: generateJapanesePhoneNumber(),
      fax: generateJapanesePhoneNumber(),
      bankName: '三井住友銀行',
      branchName: '新宿支店',
      depositType: '勘定',
      accountNumber: getRandomString(16),
      accountHolder: generateCustomerName(),

      capital: '20000',
      numberOfEmployees: '16',
      industry: '奈良公園春日大社',
      representativeName: generateCustomerName(),
      companyUrl: 'https://baidu.com',
      remarks: 'this is remark',
    };

    randomData.push(data);
  }

  return randomData;
};

// 用于生成随机日期
function randomDate(start, end) {
  const startDate = new Date(start);
  const endDate = new Date(end);
  return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
}

function randomDateTime(start, end) {
  const startDate = new Date(start);
  const endDate = new Date(end);

  const randowTimestamp = Math.floor(Math.random() * (endDate.getTime() - startDate.getTime() + 1)) + startDate.getTime();

  return new Date(randowTimestamp);
}

// 业者_一览和下请一览
export const generatGyoushaData = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      id: getRandomString(16), // 随机生成一个ID
      gyoushaCode: getRandomString(6) + '-' + getRandomString(3), // 業者コード‐業者支店コード
      gyoushaName: generateVendorInfo(), // 業者名‐業者支店名
      address: generateJapaneseAddress(), // 住所
      representName: generateCustomerName(), // 随机生成代表者名
      tenwabango: generateJapanesePhoneNumber(), // 電話番号
      gyoushu: generateConstructionGyoushuData() + '、' + generateConstructionGyoushuData() + '、' + generateConstructionGyoushuData(), // 業種
      kaitaiTouroku: generatePresence(),
      keibiNintei: generatePresence(),
      sanpaiKyoka: generatePresence(),
      kyokaKigen: randomDate('2023-01-01', '2025-01-01').toISOString(),
    };

    randomData.push(data);
  }

  return randomData;
};

// 作业员名单
export const sagyouInMeiboData = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 現場名
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  const koyouKeitai = ['社員', '協力'];

  const japaneseJobs = ['大工', '左官', '鉄筋工', '鳶', '配管工', '電気工', '板金工', 'タイル工', '型枠工', '内装工'];

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      id: getRandomString(16), // 随机生成一个ID
      // 名簿
      rowIndex: i + 1,
      chuBunshoNo: 'J' + getRandomString(13), // 注文No
      chuBunshoKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 注文金額
      daikuShu: japaneseJobs[Math.floor(Math.random() * japaneseJobs.length)], // 大工種
      gyoushaCode: getRandomString(6) + '-' + getRandomString(3), // 業者コード
      ichiJiGyoushaMei: generateJapaneseName() + '　' + koyouKeitai[Math.floor(Math.random() * koyouKeitai.length)], // 一次業者名
      gaitouChakushuNichi: randomDate('2023-01-01', '2025-01-01').toISOString(), // 該当着手日
      gaitouBikiWataruNichi: randomDate('2023-01-01', '2025-01-01').toISOString(), // 該当引渡日
      // 现场
      genbaCode: getRandomString(6) + '-' + getRandomString(3) + '-' + getRandomString(3), // 現場コード
      genbaName: genbaName[Math.floor(Math.random() * genbaName.length)], // 現場名
      senninGijutsuMono: generateJapaneseName(), // 専任技術者
      genbaChakushuNichi: randomDate('2023-01-01', '2025-01-01').toISOString(), // 現場着手日
      genbaBikiWataruNichi: randomDate('2023-01-01', '2025-01-01').toISOString(), // 現場引渡日
      shoruiTeishutsuJoukyou: Math.random() < 0.5 ? 0 : 1, // 書類提出状況
    };

    randomData.push(data);
  }

  return randomData;
};
export const JuguoinDataList = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomNum(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中'];
    const firstNames = ['太郎', '花子', '健一', '優子'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  // 職種
  const shokushus = [
    { label: '総務', value: '001' },
    { label: '営業', value: '002' },
    { label: '技術', value: '003' },
    { label: '生産', value: '004' },
  ];
  // 所属部
  const shozokuBus = [
    { label: 'IT部', value: '001' },
    { label: 'マーケティング部', value: '002' },
    { label: 'デザイン部', value: '003' },
    { label: '営業部', value: '004' },
    { label: 'サポート部', value: '005' },
    { label: '人事部', value: '006' },
    { label: '財務部', value: '007' },
    { label: '物流部', value: '008' },
    { label: 'プロジェクト部', value: '009' },
    { label: '品質管理部', value: '010' },
  ];
  // 所属課
  const shozokuKas = [
    { label: '開発課', value: '001' },
    { label: '戦略課', value: '002' },
    { label: 'グラフィック課', value: '003' },
    { label: '営業課', value: '004' },
    { label: 'カスタマーサービス課', value: '005' },
    { label: '採用課', value: '006' },
    { label: '経理課', value: '007' },
    { label: '配送課', value: '008' },
    { label: '管理課', value: '009' },
    { label: 'テスト課', value: '010' },
  ];
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 所属役職
  const shozokuYakushoskus = [
    { label: '一般社員', value: '001' },
    { label: '主任', value: '002' },
    { label: '係長', value: '003' },
    { label: '課長', value: '004' },
    { label: '次長', value: '005' },
    { label: '部長', value: '006' },
    { label: '本部長', value: '007' },
    { label: '常務取締役', value: '008' },
    { label: '専務取締役', value: '009' },
    { label: '代表取締役社長', value: '010' },
  ];
  const zokugaraArr = ['夫', '妻', '子', '父', '母', '祖父', '祖母'];
  const shikakuArr = ['統計士', 'データ解析士', 'PHP技術者', 'Rails技術者', 'Python3 エンジニア認定'];
  const levelCollection = ['A', 'B', 'C', 'D', 'E'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const dataArr = [];
    for (let j = 0; j < Math.floor(Math.random() * 5) + 1; j++) {
      const data1 = {
        id: j + 1,
        shikakuName: shikakuArr[Math.floor(Math.random() * shikakuArr.length)],
        level: levelCollection[Math.floor(Math.random() * levelCollection.length)],
        yukokigen: `${Math.floor(Math.random() * 5) + 1}年`,
      };
      dataArr.push(data1);
    }
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 社員コード
      shainCode: getRandomNum(7),
      // 氏名
      shiMei: generateJapaneseName(),
      // 職種
      shokushu: shokushus[Math.floor(Math.random() * shokushus.length)],
      // 所属部署 部
      shozokuBu: shozokuBus[Math.floor(Math.random() * shozokuBus.length)],
      // 所属部署 課
      shozokuKa: shozokuKas[Math.floor(Math.random() * shozokuKas.length)],
      // 所属部署 役職
      shozokuYakushoku: shozokuYakushoskus[Math.floor(Math.random() * shozokuYakushoskus.length)], // 随机生成所属役職
      // 生年月日
      birth: getRandomDate('1991-01-01', '1998-01-01').toISOString(),
      // 入社年月日
      nyusah: getRandomDate('2010-01-01', '2015-01-01').toISOString(),
      // 退職年月日
      taishoku: i % 10 === 0 ? getRandomDate('2015-01-01', '2025-01-01').toISOString() : '',
      // 会社携帯番号
      kaishaKeitaiNo: `${getRandomNum(3)}-${getRandomNum(4)}-${getRandomNum(4)}`,
      // メールアドレス
      emailAddress: `${getRandomString(9)}@gmail.com`,
      // 適用開始日付
      tekiyoKaishiDate: `${getRandomDate('2025-01-01', '2025-01-31').toISOString().split('-')[0]}-${getRandomDate('2025-01-01', '2025-01-31').toISOString().split('-')[1]}-${getRandomDate('2025-01-01', '2025-01-31').toISOString().split('-')[2].substring(0, 2)}`,
      // ログインID
      loginID: getRandomString(8),
      // パスワード
      password: getRandomString(8),
      // 郵便番号
      yuBinNo: `${getRandomNum(4)}-${getRandomNum(4)}`,
      // 住所1
      address1: generateJapaneseAddress(),
      // 住所2
      address2: generateJapaneseAddress(),
      // 個人携帯番号
      kojinkeitaiNo: `${getRandomNum(3)}-${getRandomNum(4)}-${getRandomNum(4)}`,
      // 自宅電話番号
      jitakudenwaNo: `${getRandomNum(3)}-${getRandomNum(4)}-${getRandomNum(4)}`,
      // 住所
      address: generateJapaneseAddress(),
      // 緊急連絡先氏名
      kinkyuShiMei: generateJapaneseName(),
      // 電話番号
      denwaNo: `${getRandomNum(3)}-${getRandomNum(4)}-${getRandomNum(4)}`,
      // 続柄
      zokugara: zokugaraArr[Math.floor(Math.random() * zokugaraArr.length)],
      // 取得資格
      shutokuShikakuList: dataArr,
    };

    randomData.push(data);
  }

  return randomData;
};

// 业者一览数据
export const sagyouInData = num => {
  const randomData = [];
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  // 雇用形態
  const koyouKeitai = ['社員', '協力'];

  // CCUS和健康診断
  const kenkoushindan = ['〇', '✕'];

  const kenkouhoken = ['健康保険組合', '非健康保険'];

  // 厚生年金he雇用保険
  const kouseinenkin = ['加入', '未加入'];

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      id: getRandomString(16), // 随机生成一个ID
      rowIndex: i + 1,
      sagyouInCode: getRandomString(14),
      shimei: generateJapaneseName(),
      koyouKeitai: koyouKeitai[Math.floor(Math.random() * koyouKeitai.length)],
      CCUS: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      kenkoushindan: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      kenkouhoken: kenkouhoken[Math.floor(Math.random() * kenkouhoken.length)],
      kouseinenkin: kouseinenkin[Math.floor(Math.random() * kenkouhoken.length)],
      koyouhoken: kouseinenkin[Math.floor(Math.random() * kouseinenkin.length)],
    };

    randomData.push(data);
  }

  return randomData;
};

export const bukkenDataList = num => {
  const randomData = [];
  // 用于生成随机字符串的辅助函数
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 該当エリア
  const gaitouAreaArr = [
    '北海道事務所',
    '宮城事務所',
    '福島事務所',
    '東京事務所',
    '神奈川事務所',
    '愛知事務所',
    '静岡事務所',
    '大阪事務所',
    '京都事務所',
    '広島事務所',
    '岡山事務所',
    '香川事務所',
    '愛媛事務所',
    '福岡事務所',
    '沖縄事務所',
  ];
  // 物件名
  const bukkenNameArr = [
    '梅田ターミナル直結次世代タワー',
    'みなとみらいAI監視型物流ハブ',
    '栄駅前省エネスマートビル',
    '九州デジタルメディア複合棟 ',
    '大通公園地下耐震商業街',
    '清水寺景観統合文化施設',
    'ポートアイランド医療特区A棟',
    '宇品港自動搬送物流センター',
    '東北大学AI研究棟',
    '海浜公園隣接ECOオフィス',
    '新都心防災対応データセンター  ',
    '富士山景観バリアフリー分譲宅',
    '航空宇宙産業支援ラボ',
    '熊本城復興関連交流施設',
    '国際リゾート島海上ホテル',
    '兼六園文化保存研究棟',
    'アルプス自然共生型トレーニングセンター',
    '朱鷺メッセ連携会議棟',
    '山陽新幹線防災監視棟 ',
    '東大寺歴史遺産修復工房',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  // 工事部門
  const kojiBumonArr = [
    '臨海副都心AI橋梁新設工事区画',
    '港島次世代配管系統工区',
    '富士山砂防堰堤建設計画',
    '卸町地区地盤改良工区',
    '宇品航路疏浚作業棟',
    '京浜埠頭耐震強化岸壁',
  ];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 物件コード
      bukkenCode: getRandom(7),
      // 該当エリア
      gaitouArea: gaitouAreaArr[Math.floor(Math.random() * gaitouAreaArr.length)],
      // 物件名
      bukkenName: bukkenNameArr[Math.floor(Math.random() * bukkenNameArr.length)],
      // 顧客コード
      kokyakuCode: getRandom(6),
      // 顧客名
      kokyakuName: generateJapaneseName(),
      // 受注年月日
      juchuYmd: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 請負金額
      ukeoiKingaku: Math.floor(Math.random() * 5000) + 1,
      // 着工日
      chakkouDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 完工日
      kankoDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 工事部門
      kojiBumon: kojiBumonArr[Math.floor(Math.random() * kojiBumonArr.length)],
      // 工事管理職
      kojiKanrishoku: generateJapaneseName(),
      // 専任技術者
      senninGijutsuSha: generateJapaneseName(),
      // 施工担当者
      sekoTantoSha: generateJapaneseName(),
    };

    randomData.push(data);
  }

  return randomData;
};
export const genbaKeihiDataList = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const resultArr = ['未承認', '承認', '否認', '差戻'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      no: i + 1,
      id: getRandomString(16),
      genbaCode: getRandom(7) + '-' + getRandom(3) + '-' + getRandom(2),
      genbaName: genbaNameArr[Math.floor(Math.random() * genbaNameArr.length)],
      genbaChakushuDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      genbahikiwatashiDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      shinseiSha: generateJapaneseName(),
      keihiShinseiDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      shoninSha: generateJapaneseName(),
      keihishoninShaDate: i !== 0 ? getRandomDate('2023-01-01', '2025-01-01').toISOString() : '',
      keihiKingakkuTotal: getRandom(6),
      // 申請日
      shinseiBi: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
export const DekidakaSimulationDataList = num => {
  const randomData = [];
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];

  function formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}年${month}月${day}日`;
  }

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const no = i + 1;
    const genbaCodeNum1 = getRandomString(3);
    const genbaCodeNum2 = getRandomString(3);
    const genbaCodeNum3 = getRandomString(2);

    const data = {
      no: no,
      id: no,
      genbaCode: `2025${genbaCodeNum1}-${genbaCodeNum2}-${genbaCodeNum3}`, // 現場コード
      genbaName: genbaName[Math.floor(Math.random() * genbaName.length)], // 現場名
      genbaChakkouDate: formatDate(randomDate('2023-01-01', '2025-01-01')), // 現場着工日
      genbaKankouDate: formatDate(randomDate('2023-01-01', '2025-01-01')), // 現場完工日
      isZure: i % 2 === 0 ? true : false,
    };

    randomData.push(data);
  }

  return randomData;
};

// 概算一覧
export const gaisanDataList = num => {
  const gaisanData = [];
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];
  const kekkaList = ['承認待ち', '差戻'];

  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];

  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  for (let i = 0; i < num; i++) {
    const data = {
      id: i + 1,
      ankenCode: `N202408-${i.toString().padStart(4, '0')}`,
      ankenName: `墨田区${i + 1}丁目計画`,
      gaisanCode: `202408${i.toString().padStart(3, '0')}`,
      genbaJusho: genbaName[Math.floor(Math.random() * genbaName.length)],
      kokyakuCode: getRandomString(6),
      kokyakuName: '○○建設',
      mitsumoriTeishutsuKigen: randomDate('2023-01-01', '2025-01-01'),
      gaisanKingaku: Math.floor(Math.random() * 99999999),
      chakkoKiboJiki: randomDateTime('2023-01-01', '2025-01-01'),
      kankoKiboJiki: randomDateTime('2023-01-01', '2025-01-01'),
      gaisanBumon: bumonName[Math.floor(Math.random() * bumonName.length)],
      gaisanTantousya: generateJapaneseName(),
      sinseisya: generateJapaneseName(),
      sinseiDate: randomDate('2023-01-01', '2025-01-01'),
      kekka: kekkaList[Math.floor(Math.random() * kekkaList.length)],
    };

    gaisanData.push(data);
  }

  return gaisanData;
};

// 查定一览
export const sateiDataList = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];
  // 工事部門
  const KojiBumon = [
    '东京工事部門',
    '大阪工事部門',
    '名古屋工事部門',
    '建設工事部門',
    '環境工事部門',
    '電気工事部門',
    '新工事部門',
    '旧工事部門',
    '企画工事部門',
    '実施工事部門',
  ];

  // 工事工程
  const KojiKotei = [
    '基礎工事',
    '地盤改良工事',
    '杭打ち工事',
    '基礎コンクリート工事',
    '擁壁工事',
    '東京駅舎基礎工事',
    '東京タワー外装工事',
    '東京道路舗装工事',
    '建設現場基礎工事',
    '建設現場外壁工事',
    '建設現場屋根工事',
  ];

  function formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}年${month}月${day}日`;
  }

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no: i + 1,
      id: getRandomString(16),
      genbaCode: getRandom(7) + '-' + getRandom(3) + '-' + getRandom(2), // 現場コード
      genbaName: genbaNameArr[Math.floor(Math.random() * genbaNameArr.length)], // 現場名
      kojiBumon: KojiBumon[Math.floor(Math.random() * KojiBumon.length)], // 工事部門
      genbaShocho: generateJapaneseName(), // 現場所長
      senninGijutsuSha: generateJapaneseName(), // 専任技術者
      kojiKotei: KojiKotei[Math.floor(Math.random() * KojiKotei.length)], // 工事工程
      sateiShoninBi: formatDate(randomDate('2023-01-01', '2025-01-01')), // 査定承認日
      jikkoYosanKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 実行予算金額
      hachuKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 発注金額
      zengetsuMadeSateiZumiKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 前月迄査定済金額
      togetsuSateiKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 当月査定金額
      sateiZumiGokeiKingaku: Math.floor(Math.random() * 10000000) + 10000000, // 査定済合計金額
      miSateiZa: Math.floor(Math.random() * 10000000) + 10000000, // 未査定残
    };

    randomData.push(data);
  }

  return randomData;
};

// 実行予算一覧
export const jikkoYosanDataList = num => {
  const dataList = [];
  const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
  const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];

  const generateJapaneseName = () => {
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  for (let i = 0; i < num; i++) {
    const data = {
      id: i + 1,
      genbaCode: `2024001-000-${i.toString().padStart(3, '0')}`,
      jikkoYosanCode: `1234567-000-${i.toString().padStart(3, '0')}`,
      genbaName: `${lastNames[Math.floor(Math.random() * lastNames.length)]}建設工事`,
      yosanSinseiDate: randomDateTime('2023-01-01', '2025-01-01'),
      yosanShoninDate: randomDateTime('2023-01-01', '2025-01-01'),
      yosanSakuseiBumon: bumonName[Math.floor(Math.random() * bumonName.length)],
      yosanSakuseiSha: generateJapaneseName(),
      jikkoYosanKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      hatchuuKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      mihatchuuKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      sateizumiKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      misateiZan: Math.floor(Math.random() * 10000000) + 10000000,
    };

    dataList.push(data);
  }

  return dataList;
};

// 権限管理
export const securityDataList1 = num => {
  const dataList = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 部門名
  const bumonArr = [
    '財務部',
    '人事部',
    '情報技術部',
    'マーケティング部',
    '営業部',
    'カスタマーサービス部',
    '法務部',
    '総務部',
    '購買部',
    '研究開発部',
    '生産部',
    '品質管理部',
    'ロジスティクス部',
    '戦略開発部',
    '研修部',
  ];
  // 契約管理リスト
  const keiyakuManagerList = ['', '建築工事契約', '電気設備契約', '水道工事契約', '外構工事契約'];

  // 予算管理リスト
  const yosanManagerList = ['', '基本設計予算', '実施設計予算', '施工予算', '予備費'];

  // 発注管理リスト
  const hatchuManagerList = ['', '資材発注', '人材発注', '重機リース', '専門業者委託'];

  // 査定/支払/請求管理リスト
  const sateiShiharaiSeihyuManagerList = ['', '出来高査定', '進捗支払', '最終請求', '修正請求'];

  // 工事経費管理リスト
  const kojiKeihiManagerList = ['', '人件費', '資材費', '設備賃借料', '安全管理費'];

  // 工事予実管理リスト
  const kojiYojitsuManagerList = ['', '基礎工事', '躯体工事', '設備工事', '仕上工事'];

  // 業者管理リスト
  const gyoshaManagerList = ['', '建設', '電気', '管工', '資材'];

  // 承認管理リスト
  const shoninManagerList = ['', '現場承認', '支店長承認', '本社決済', '顧客確認'];

  // マスタ・連携管理リスト
  const masterManagerList = ['', '資材マスタ', '工程マスタ', 'ERP連携', 'CAD連携'];

  for (let i = 0; i < num; i++) {
    const data = {
      // id
      id: i + 1,
      // 部門コード
      bumonCode: getRandom(7),
      // 部門名
      bumonName: bumonArr[Math.floor(Math.random() * bumonArr.length)],
      // 契約管理
      keiyakuManager: keiyakuManagerList[Math.floor(Math.random() * keiyakuManagerList.length)],
      // 予算管理
      yosanManager: yosanManagerList[Math.floor(Math.random() * yosanManagerList.length)],
      // 発注管理
      hatchuManager: hatchuManagerList[Math.floor(Math.random() * hatchuManagerList.length)],
      // 査定/支払/請求管理
      sateiShiharaiSeihyuManager: sateiShiharaiSeihyuManagerList[Math.floor(Math.random() * sateiShiharaiSeihyuManagerList.length)],
      // 工事経費管理
      kojiKeihiManager: kojiKeihiManagerList[Math.floor(Math.random() * kojiKeihiManagerList.length)],
      // 工事予実管理
      kojiYojitsuManager: kojiYojitsuManagerList[Math.floor(Math.random() * kojiYojitsuManagerList.length)],
      // 業者管理
      gyoshaManager: gyoshaManagerList[Math.floor(Math.random() * gyoshaManagerList.length)],
      // 承認管理
      shoninManager: shoninManagerList[Math.floor(Math.random() * shoninManagerList.length)],
      // マスタ・連携管理
      masterManager: masterManagerList[Math.floor(Math.random() * masterManagerList.length)],
    };
    dataList.push(data);
  }
  return dataList;
};
export const securityDataList2 = num => {
  const dataList = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 役職名
  const yakushokuNameArr = ['代表取締役社長', '専務取締役', '常務取締役', '本部長', '部長', '次長', '課長', '係長', '主任', '一般社員'];
  const kenkoushindan = ['〇', '✕'];
  for (let j = 0; j < num; j++) {
    const data = {
      // id
      id: j + 1,
      // 役職コード
      yakushokuCode: getRandom(7),
      // 役職名
      yakushokuName: yakushokuNameArr[Math.floor(Math.random() * yakushokuNameArr.length)],
      // 承認
      shonin: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // 削除
      delete: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // 保存
      save: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // 編集
      edit: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // 参照
      preview: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // データ区分
      dataKbn: j === 1 || j === 3 ? 1 : 0,
    };

    dataList.push(data);
  }

  return dataList;
};

// 請求書管理
export const seikyushoDataList = num => {
  const dataList = [];
  const jpNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
  const shiharaiJyokenList = ['引き渡し時', '着工時', '上棟着手'];

  for (let i = 0; i < num; i++) {
    const seikyushoData = {
      id: i + 1,
      ankenCode: `N202503-${Math.floor(Math.random() * 99)}`,
      ankenName: `${jpNames[Math.floor(Math.random() * jpNames.length)]}ビル建設工事`,
      ankenKanaName: 'ｼﾗﾅｲ ｱﾝｹﾝﾒｲ',
      bukkenCode: `0000${i.toString().padStart(3, '0')}`,
      bukkenKanaName: 'ｼﾗﾅｲ ﾌﾞｯｹﾝﾒｲ ',
      bukkenName: `${jpNames[Math.floor(Math.random() * jpNames.length)]}ビル建設工事`,
      kokyakuCode: `1000${i.toString().padStart(3, '0')}`,
      kokyakuKanaName: 'ｼﾗﾅｲ ｺｷｬｸﾒｲ',
      kokyakuName: `${jpNames[Math.floor(Math.random() * jpNames.length)]}株式会社`,
      bukkenChakushuDate: randomDateTime('2023-01-01', '2025-01-01'),
      bukkenHikiwatashiDate: randomDateTime('2023-01-01', '2025-01-01'),
      ukeoiKingakuZeinuki: Math.floor(Math.random() * 10000000) + 10000000,
      shohizeiKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      seikyushoNo: `000000${i.toString().padStart(3, '0')}-${Math.floor(Math.random() * 99)}`,
      shiharaiJyoken: `${shiharaiJyokenList[Math.floor(Math.floor(Math.random() * shiharaiJyokenList.length))]}`,
      seikyuDate: randomDateTime('2023-01-01', '2025-01-01'),
      nyuukinYoteiDate: randomDateTime('2019-01-01', '2025-01-01'),
      ukeoiKingakuZeikomi: Math.floor(Math.random() * 10000000) + 10000000,
      seikyuzumiKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      konkaiSeikyuKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      miseikyuZan: Math.floor(Math.random() * 10000000) + 10000000,
    };

    dataList.push(seikyushoData);
  }

  return dataList;
};

// 概算一覧
export const WebD0010List = num => {
  const gaisanData = [];
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];

  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];

  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  for (let i = 0; i < num; i++) {
    const data = {
      id: getRandomString(10), // 随机生成一个ID
      no: i + 1,
      seisekisanCode: `202408-${i.toString().padStart(4, '0')}`,
      ankenCode: `N202408-${i.toString().padStart(4, '0')}`,
      ankenName: `墨田区${i + 1}丁目計画`,
      gaisanCode: `202408${i.toString().padStart(3, '0')}`,
      genbaJusho: genbaName[Math.floor(Math.random() * genbaName.length)],
      kokyakuCode: getRandomString(5),
      kokyakuName: '○○建設',
      chakkouDate: randomDate('2023-01-01', '2025-01-01'),
      juchuYmd: randomDate('2024-01-01', '2025-01-01'),
      seisekisanKingaku: Math.floor(Math.random() * 99999999),
      gaisanKingaku: Math.floor(Math.random() * 99999999),
      busyoName: bumonName[Math.floor(Math.random() * bumonName.length)],
      name: generateJapaneseName(),
    };

    gaisanData.push(data);
  }

  return gaisanData;
};
export const shoninBukkenDataList = num => {
  const randomData = [];
  // 用于生成随机字符串的辅助函数
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 該当エリア
  const gaitouAreaArr = [
    '北海道事務所',
    '宮城事務所',
    '福島事務所',
    '東京事務所',
    '神奈川事務所',
    '愛知事務所',
    '静岡事務所',
    '大阪事務所',
    '京都事務所',
    '広島事務所',
    '岡山事務所',
    '香川事務所',
    '愛媛事務所',
    '福岡事務所',
    '沖縄事務所',
  ];
  // 物件名
  const bukkenNameArr = [
    '梅田ターミナル直結次世代タワー',
    'みなとみらいAI監視型物流ハブ',
    '栄駅前省エネスマートビル',
    '九州デジタルメディア複合棟 ',
    '大通公園地下耐震商業街',
    '清水寺景観統合文化施設',
    'ポートアイランド医療特区A棟',
    '宇品港自動搬送物流センター',
    '東北大学AI研究棟',
    '海浜公園隣接ECOオフィス',
    '新都心防災対応データセンター  ',
    '富士山景観バリアフリー分譲宅',
    '航空宇宙産業支援ラボ',
    '熊本城復興関連交流施設',
    '国際リゾート島海上ホテル',
    '兼六園文化保存研究棟',
    'アルプス自然共生型トレーニングセンター',
    '朱鷺メッセ連携会議棟',
    '山陽新幹線防災監視棟 ',
    '東大寺歴史遺産修復工房',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  // 工事部門
  const kojiBumonArr = [
    '臨海副都心AI橋梁新設工事区画',
    '港島次世代配管系統工区',
    '富士山砂防堰堤建設計画',
    '卸町地区地盤改良工区',
    '宇品航路疏浚作業棟',
    '京浜埠頭耐震強化岸壁',
  ];
  const resultArr = ['未承認', '承認', '否認', '差戻'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 物件コード
      bukkenCode: getRandom(7),
      // 物件名
      bukkenName: bukkenNameArr[Math.floor(Math.random() * bukkenNameArr.length)],
      // 顧客名
      kokyakuName: generateJapaneseName(),
      // 着工日
      chakkouDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 完工日
      kankoDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
// 承認一覧（概算管理）
export const shoninGaisanDataList = num => {
  const gaisanData = [];
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];

  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];
  const resultArr = ['未承認', '承認', '否認', '差戻'];
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  for (let i = 0; i < num; i++) {
    const data = {
      id: i + 1,
      ankenCode: `N202408-${i.toString().padStart(4, '0')}`,
      ankenName: `墨田区${i + 1}丁目計画`,
      gaisanCode: `202408${i.toString().padStart(3, '0')}`,
      kokyakuCode: getRandomString(5),
      kokyakuName: '○○建設',
      mitsumoriTeishutsuKigen: randomDate('2023-01-01', '2025-01-01'),
      gaisanKingaku: Math.floor(Math.random() * 99999999),
      chakkoKiboJiki: randomDateTime('2023-01-01', '2025-01-01'),
      kankoKiboJiki: randomDateTime('2023-01-01', '2025-01-01'),
      gaisanBumon: bumonName[Math.floor(Math.random() * bumonName.length)],
      gaisanTantousya: generateJapaneseName(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    gaisanData.push(data);
  }

  return gaisanData;
};
// 精積算一覧
export const sekisanDataList = num => {
  const gaisanData = [];
  const genbaName = [
    '小笠原諸島',
    '日光東照宮陽明門',
    '奈良公園春日大社',
    '沖縄県国頭郡東村',
    '北海道苫小牧市錦岡',
    '東京都江東区森下',
    '青森県西津軽郡深浦町',
    '長崎県対馬市厳原町',
    '屋久島',
  ];

  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];

  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  const resultArr = ['未承認', '承認', '否認', '差戻'];

  for (let i = 0; i < num; i++) {
    const data = {
      // id
      id: getRandomString(10),
      // No.
      no: i + 1,
      seisekisanCode: `202408-${i.toString().padStart(4, '0')}`,
      // 案件名称
      ankenName: `墨田区${i + 1}丁目計画`,
      // 顧客コード
      kokyakuCode: getRandomString(6),
      // 顧客名
      kokyakuName: generateJapaneseName(),
      // 概算金額
      seisekisanKingaku: Math.floor(Math.random() * 99999999),
      // 精積算金額
      gaisanKingaku: Math.floor(Math.random() * 99999999),
      // 承認日
      chakkouDate: randomDate('2023-01-01', '2025-01-01'),
      // 作成日/ 修正日
      juchuYmd: randomDate('2024-01-01', '2025-01-01'),
      // 担当部門
      tantoBumon: bumonName[Math.floor(Math.random() * bumonName.length)],
      // 担当者
      tantoSha: generateJapaneseName(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    gaisanData.push(data);
  }

  return gaisanData;
};
// 承認一覧（実行予算管理）
export const shoninJikkoYosanDataList = num => {
  const dataList = [];
  const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
  const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];
  const resultArr = ['未承認', '承認', '否認', '差戻'];
  const generateJapaneseName = () => {
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  for (let i = 0; i < num; i++) {
    const data = {
      // id
      id: i + 1,
      // 物件コード
      bukkenCode: getRandom(7),
      // 物件名称
      bukkenName: `${lastNames[Math.floor(Math.random() * lastNames.length)]}建設工事`,
      // 請負金額
      ukeoiKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      // 実行予算金額
      jikkoYosanKingaku: Math.floor(Math.random() * 10000000) + 10000000,
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    dataList.push(data);
  }

  return dataList;
};

// 査定一覧
export const shoninSateiDataList = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];
  // 工事部門
  const KojiBumon = [
    '東京工事部門',
    '大阪工事部門',
    '名古屋工事部門',
    '建設工事部門',
    '環境工事部門',
    '電気工事部門',
    '新工事部門',
    '旧工事部門',
    '企画工事部門',
    '実施工事部門',
  ];
  const resultArr = ['未承認', '承認', '否認', '差戻'];

  // 工事工程
  const KojiKotei = [
    '基礎工事',
    '地盤改良工事',
    '杭打ち工事',
    '基礎コンクリート工事',
    '擁壁工事',
    '東京駅舎基礎工事',
    '東京タワー外装工事',
    '東京道路舗装工事',
    '建設現場基礎工事',
    '建設現場外壁工事',
    '建設現場屋根工事',
  ];

  function formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}年${month}月${day}日`;
  }

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no: i + 1,
      id: getRandomString(16),
      // 現場コード
      genbaCode: getRandom(7) + '-' + getRandom(3) + '-' + getRandom(2),
      // 現場名
      genbaName: genbaNameArr[Math.floor(Math.random() * genbaNameArr.length)],
      // 現場所長
      genbaShocho: generateJapaneseName(),
      // 専任技術者
      tantoBumon: KojiBumon[Math.floor(Math.random() * KojiBumon.length)],
      // 工事工程
      kojiKotei: KojiKotei[Math.floor(Math.random() * KojiKotei.length)],
      // 査定承認日
      sateiShoninBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
export const shoninKojiYojitsuList = num => {
  const randomData = [];
  // 用于生成随机字符串的辅助函数
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 該当エリア
  const gaitouAreaArr = [
    '北海道事務所',
    '宮城事務所',
    '福島事務所',
    '東京事務所',
    '神奈川事務所',
    '愛知事務所',
    '静岡事務所',
    '大阪事務所',
    '京都事務所',
    '広島事務所',
    '岡山事務所',
    '香川事務所',
    '愛媛事務所',
    '福岡事務所',
    '沖縄事務所',
  ];
  // 物件名
  const bukkenNameArr = [
    '梅田ターミナル直結次世代タワー',
    'みなとみらいAI監視型物流ハブ',
    '栄駅前省エネスマートビル',
    '九州デジタルメディア複合棟 ',
    '大通公園地下耐震商業街',
    '清水寺景観統合文化施設',
    'ポートアイランド医療特区A棟',
    '宇品港自動搬送物流センター',
    '東北大学AI研究棟',
    '海浜公園隣接ECOオフィス',
    '新都心防災対応データセンター  ',
    '富士山景観バリアフリー分譲宅',
    '航空宇宙産業支援ラボ',
    '熊本城復興関連交流施設',
    '国際リゾート島海上ホテル',
    '兼六園文化保存研究棟',
    'アルプス自然共生型トレーニングセンター',
    '朱鷺メッセ連携会議棟',
    '山陽新幹線防災監視棟 ',
    '東大寺歴史遺産修復工房',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const resultArr = ['未承認', '承認', '否認', '差戻'];

  // 工事部門
  const kojiBumonArr = [
    '臨海副都心AI橋梁新設工事区画',
    '港島次世代配管系統工区',
    '富士山砂防堰堤建設計画',
    '卸町地区地盤改良工区',
    '宇品航路疏浚作業棟',
    '京浜埠頭耐震強化岸壁',
  ];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 物件コード
      bukkenCode: getRandom(7),
      // 物件名
      bukkenName: bukkenNameArr[Math.floor(Math.random() * bukkenNameArr.length)],
      // 着工日
      chakkouDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 完成引渡日
      kaiseiHikiwatashiDate: getRandomDate('2023-01-01', '2025-01-01').toISOString(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
// 业者_一览和下请一览
export const shoninGyoshaList = num => {
  const randomData = [];

  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const resultArr = ['未承認', '承認', '否認', '差戻'];

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // 随机生成一个ID
      id: getRandomString(16),
      // 業者コード
      gyoushaCode: getRandomString(6),
      // 業者名‐業者支店名
      gyoushaName: generateVendorInfo(),
      // 解体登録
      kaitaiTouroku: generatePresence(),
      // 警備認定
      keibiNintei: generatePresence(),
      // 産廃許可
      sanpaiKyoka: generatePresence(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
// 业者一览数据
export const shoninSagyouInData = num => {
  const randomData = [];
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };

  // 雇用形態
  const koyouKeitai = ['社員', '協力'];

  // CCUS和健康診断
  const kenkoushindan = ['〇', '✕'];

  const kenkouhoken = ['健康保険組合', '非健康保険'];
  const resultArr = ['未承認', '承認', '否認', '差戻'];

  // 厚生年金he雇用保険
  const kouseinenkin = ['加入', '未加入'];

  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      id: getRandomString(16), // 随机生成一个ID
      // 作業員コード
      sagyouInCode: getRandomString(14),
      // 氏名
      shimei: generateJapaneseName(),
      // 雇用区分
      koyouKbn: koyouKeitai[Math.floor(Math.random() * koyouKeitai.length)],
      // 健康診断
      kenkoushindan: kenkoushindan[Math.floor(Math.random() * kenkoushindan.length)],
      // 健康保険
      kenkouhoken: kenkouhoken[Math.floor(Math.random() * kenkouhoken.length)],
      // 厚生年金
      kouseinenkin: kouseinenkin[Math.floor(Math.random() * kenkouhoken.length)],
      // 雇用保険
      koyouhoken: kouseinenkin[Math.floor(Math.random() * kouseinenkin.length)],
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};
export const shoninShitaukeKeiyaku = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const adressArr = ['東京都', '大阪府', '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県', '茨城県'];

  const resultArr = ['未承認', '承認', '否認', '差戻'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 現場コード
      genbaCode: getRandom(7) + '-' + getRandom(3) + '-' + getRandom(2),
      // 現場名称
      genbaName: genbaNameArr[Math.floor(Math.random() * genbaNameArr.length)],
      // 現場住所
      genbaAddress: adressArr[Math.floor(Math.random() * adressArr.length)],
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};

export const shoninSaiShitaukeoi = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];

  const vendorNames: string[] = [
    '大東株式会社',
    '大東建設',
    '大東電機',
    '大東運輸',
    '大東商事',
    '大東食品',
    '大東通信',
    '大東銀行',
    '大東不動産',
    '大東化工',
    '大東機械',
    '大東流通',
    '大東保険',
    '大東教育',
    '大東観光',
    '大東メディカル',
    '大東エンジニアリング',
    '大東エナジー',
    '大東テクノロジー',
    '大東ライフ',
  ];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const adressArr = ['東京都', '大阪府', '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県', '茨城県'];

  const resultArr = ['未承認', '承認', '否認', '差戻'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 元請業者
      motoukeGyousha: vendorNames[Math.floor(Math.random() * vendorNames.length)],
      // 下請業者
      shitaukeGyousha: vendorNames[Math.floor(Math.random() * vendorNames.length)],
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i === 1 ? 'あり' : '',
    };

    randomData.push(data);
  }

  return randomData;
};

export const shoninKokyaku = num => {
  const randomData = [];
  function getRandom(length) {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机字符串的辅助函数
  function getRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  // 用于生成随机日期
  function getRandomDate(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  }
  // 現場名
  const genbaNameArr = [
    '東京湾跨海トンネル掘削現場',
    '大阪第3ターミナル鉄骨組立区域',
    '名古屋自動化工場PLC制御調整区',
    '北海道風力発電所第2基設置エリア',
    '福岡地下鉄七隈線防水工事区間',
    '横浜スマートシティIoTシステムテスト区',
    '広島太陽光パネル増設工事現場',
    '仙台医療センター耐震補強作業域',
    '北九州LNG貯蔵タンク溶接検査区',
    'つくば研究学園都市光ケーブル布設現場',
  ];

  const vendorNames: string[] = [
    '大東株式会社',
    '大東建設',
    '大東電機',
    '大東運輸',
    '大東商事',
    '大東食品',
    '大東通信',
    '大東銀行',
    '大東不動産',
    '大東化工',
    '大東機械',
    '大東流通',
    '大東保険',
    '大東教育',
    '大東観光',
    '大東メディカル',
    '大東エンジニアリング',
    '大東エナジー',
    '大東テクノロジー',
    '大東ライフ',
  ];
  const masterKbnArr = ['従業員情報登録', '従業員情報修正', '組織編集', '取引先新規登録', '取引先既存編集'];
  // 生成随机的日本姓名函数
  const generateJapaneseName = () => {
    const lastNames = ['佐藤', '鈴木', '高橋', '田中', '湯村', '保手', '浜'];
    const firstNames = ['太郎', '花子', '健一', '優子', '橋本', '楽天', '嶽'];
    return `${lastNames[Math.floor(Math.random() * lastNames.length)]} ${firstNames[Math.floor(Math.random() * firstNames.length)]}`;
  };
  const adressArr = ['東京都', '大阪府', '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県', '茨城県'];

  const resultArr = ['未承認', '承認', '否認', '差戻'];
  const torihikisakiKbnArr = ['得意先', '納品先', '請求先', '仕入先', '支払先'];
  const gyomuGyoshuArr = ['情報通信業・通信業', 'サービス業・医療', '運輸業・水運業', '運輸業・航空運輸業', '運輸業・倉庫業'];
  // 用于生成一个随机的对象
  for (let i = 0; i < num; i++) {
    const data = {
      // no
      no: i + 1,
      // id
      id: getRandomString(16),
      // 顧客コード
      kokyakuCode: getRandom(6),
      // 顧客名
      kokyakuName: generateJapaneseName(),
      // 取引先区分
      torihikisakiKbn: torihikisakiKbnArr[Math.floor(Math.random() * 5)],
      // 業務・業種
      gyomuGyoshu: gyomuGyoshuArr[Math.floor(Math.random() * 5)],
      // 代表者名
      daihyoshaName: generateJapaneseName(),
      // 申請者
      shinseiSha: generateJapaneseName(),
      // 申請日
      shinseiBi: randomDate('2023-01-01', '2025-01-01').toISOString(),
      // result
      result: resultArr[Math.floor(Math.random() * 4)],
      // コメント
      comment: i % 2 === 0 ? true : false,
      // マスタ区分
      masterKbn: masterKbnArr[Math.floor(Math.random() * 5)],
      // 業者コード
      gyoushaCode: getRandom(9),
      // マスタ区分
      kaishaName: vendorNames[Math.floor(Math.random() * vendorNames.length)],
    };

    randomData.push(data);
  }

  return randomData;
};
