import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, Button, Select, MenuItem, Box } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebF0010SearchDialog.scss';
import DialogHead from 'app/components/DialogHead';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';

const WebF0010SearchDialog = ({ onSearch }) => {
  // TODO
  // const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  // フォーム」
  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 物件コード
      bukkenCode: '',
      // 物件名
      bukkenName: '',
      // 顧客コード
      kokyakuCode: '',
      // 顧客名
      kokyakuName: '',
      // 受注年月
      jtYmdFrom: '',
      jtYmdTo: '',
      // 該当エリア
      gaitouEria: '',
      // 着手日
      tyakusyubi: '',
      // 完工日
      kankoubi: '',
      // 工事部門
      koujiBumon: '',
      // 工事管理職
      koujiKanrisyoku: '',
      // 専任技術者
      senninGijyutusya: '',
      // 施工担当者
      sekouTantousya: '',
    },
  });

  // フォームを送信
  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };
  const bukkenCodeOptions = [
    { id: 0, name: '', code: '1088813' }, // 未選択用
    { id: 1, name: '1088814', code: '1088814' },
    { id: 2, name: '1088815', code: '1088815' },
    { id: 3, name: '1088816', code: '1088816' },
  ];

  const bukkenNameOptions = [
    { id: 0, name: '', code: 'PROJN-000' },
    { id: 1, name: '丸の内オフィス棟新築工事', code: 'PROJN-TKY101' },
    { id: 2, name: '名古屋駅前複合商業施設', code: 'PROJN-NGO202' },
    { id: 3, name: '札幌大通公園地下駐車場', code: 'PROJN-SAP303' },
  ];

  const kokyakuCodeOptions = [
    { id: 0, name: '', code: '' },
    { id: 1, name: '8065625', code: '8065625' },
    { id: 2, name: '8065626', code: '8065626' },
    { id: 3, name: '8065627', code: '8065627' },
  ];

  const kokyakuNameOptions = [
    { id: 0, name: '', code: 'CLIN-000' },
    { id: 1, name: '保手 優子', code: 'CLIN-MITSUI-F' },
    { id: 2, name: '佐藤 橋本', code: 'CLIN-SUMITOMO' },
    { id: 3, name: '湯村 花子', code: 'CLIN-TOKYU' },
  ];

  const areaOptions = [
    { id: 0, name: '', code: 'AREA-000' },
    { id: 1, name: '首都圏（東京・神奈川）', code: 'AREA-KANTO' },
    { id: 2, name: '近畿圏（大阪・京都）', code: 'AREA-KINKI' },
    { id: 3, name: '中部圏（名古屋・岐阜）', code: 'AREA-CHUBU' },
  ];

  const koujiBumonOptions = [
    { id: 0, name: '', code: 'DEPT-000' },
    { id: 1, name: '土木基盤工事部', code: 'DEPT-CIVIL' },
    { id: 2, name: '建築躯体工事部', code: 'DEPT-ARCH' },
    { id: 3, name: '設備環境工事部', code: 'DEPT-FACILITY' },
  ];

  const koujiKanrisyokuOptions = [
    { id: 0, name: '', code: 'MNG-000' },
    { id: 1, name: '現場監督（1級建築士）', code: 'MNG-ARCH-1' },
    { id: 2, name: '主任技術者（土木施工管理技士）', code: 'MNG-CIVIL-2' },
    { id: 3, name: '設備統括責任者（管工事施工管理技士）', code: 'MNG-PLUMB-3' },
  ];

  const senninGijyutusyaOptions = [
    { id: 0, name: '', code: 'ENG-000' },
    { id: 1, name: '構造解析専門技術者', code: 'ENG-STRUCT' },
    { id: 2, name: '電気設備設計主任者', code: 'ENG-ELEC' },
    { id: 3, name: '地質調査技士', code: 'ENG-GEO' },
  ];

  const sekouTantousyaOptions = [
    { id: 0, name: '', code: 'STAFF-000' },
    { id: 1, name: '山田 太郎（土木）', code: 'STAFF-YAMADA' },
    { id: 2, name: '佐藤 一郎（電気）', code: 'STAFF-SATO' },
    { id: 3, name: '田中 浩二（機械）', code: 'STAFF-TANAKA' },
  ];

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)} className="webF0010-search-container">
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" size="small" style={{ minWidth: 96 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" size="small" style={{ minWidth: 96 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box sx={{ paddingBottom: '30px' }} display="flex">
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between" width="54%">
                <Box flex={1}>
                  <Controller
                    name="bukkenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>物件コード</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {bukkenCodeOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="bukkenName"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>物件名(ｶﾅ含む)</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {bukkenNameOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="kokyakuCode"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>顧客コード</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {kokyakuCodeOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="kokyakuName"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>顧客名</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {kokyakuNameOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Box flex={1}>
                    <LocalizationProvider
                      dateAdapter={AdapterDayjs}
                      adapterLocale="ja"
                      localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                    >
                      <Controller
                        name="jtYmdFrom"
                        control={control}
                        render={({ field }) => (
                          <div className="bukken-search-item">
                            <label style={{ textAlign: 'center' }}>受注年月</label>
                            <DatePicker
                              {...field}
                              slotProps={{
                                popper: {
                                  className: 'webF0010-search-container',
                                },
                                textField: {
                                  placeholder: '',
                                },
                              }}
                              sx={{
                                width: '170px',
                                textAlignLast: 'end',
                              }}
                              format="YYYY年MM月DD日"
                              value={field.value ? dayjs(field.value) : null}
                            />
                          </div>
                        )}
                      />
                    </LocalizationProvider>
                  </Box>
                  <Box flex={1}>
                    <LocalizationProvider
                      dateAdapter={AdapterDayjs}
                      adapterLocale="ja"
                      localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                    >
                      <Controller
                        name="jtYmdTo"
                        control={control}
                        render={({ field }) => (
                          <div className="bukken-search-item">
                            <label style={{ minWidth: 20 }}>～</label>
                            <DatePicker
                              {...field}
                              slotProps={{
                                popper: {
                                  className: 'webF0010-search-container',
                                },
                                textField: {
                                  placeholder: '',
                                },
                              }}
                              sx={{
                                width: '170px',
                                textAlignLast: 'end',
                              }}
                              format="YYYY年MM月DD日"
                              value={field.value ? dayjs(field.value) : null}
                            />
                          </div>
                        )}
                      />
                    </LocalizationProvider>
                  </Box>
                </Box>
                <Box flex={1}>
                  <Controller
                    name="gaitouEria"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>該当エリア</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {areaOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between" width="44%">
                <Box flex={1}>
                  <LocalizationProvider
                    dateAdapter={AdapterDayjs}
                    adapterLocale="ja"
                    localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                  >
                    <Controller
                      name="tyakusyubi"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ textAlign: 'center' }}>着手日</label>
                          <DatePicker
                            {...field}
                            slotProps={{
                              popper: {
                                className: 'webF0010-search-container',
                              },
                              textField: {
                                placeholder: '',
                              },
                            }}
                            sx={{
                              width: '100%',
                              textAlignLast: 'end',
                            }}
                            format="YYYY年MM月DD日"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        </div>
                      )}
                    />
                  </LocalizationProvider>
                </Box>
                <Box flex={1}>
                  <LocalizationProvider
                    dateAdapter={AdapterDayjs}
                    adapterLocale="ja"
                    localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                  >
                    <Controller
                      name="kankoubi"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ textAlign: 'center' }}>完工日</label>
                          <DatePicker
                            {...field}
                            slotProps={{
                              popper: {
                                className: 'webF0010-search-container',
                              },
                              textField: {
                                placeholder: '',
                              },
                            }}
                            sx={{
                              width: '100%',
                              textAlignLast: 'end',
                            }}
                            format="YYYY年MM月DD日"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        </div>
                      )}
                    />
                  </LocalizationProvider>
                </Box>
                <Box flex={1}>
                  <Controller
                    name="koujiBumon"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>工事部門</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {koujiBumonOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="koujiKanrisyoku"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>工事管理職</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {koujiKanrisyokuOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="senninGijyutusya"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>専任技術者</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {senninGijyutusyaOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="sekouTantousya"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>施工担当者</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webF0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {sekouTantousyaOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebF0010SearchDialog;
