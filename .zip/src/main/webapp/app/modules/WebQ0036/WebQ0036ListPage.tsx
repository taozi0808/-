import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebQ0036ListPage.scss';
import dayjs from 'dayjs';
import { DBManager, sagyouInMeiboData } from 'app/shared/util/construction-list';
import WebQ0036SearchDialog from './SearchDialog/WebQ0036SearchDialog';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { Column, FieldType, Filters } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';

const WebQ0036ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const columnRef = useRef<Array<Column>>([
    {
      id: 'No',
      name: 'No',
      field: 'no',
      minWidth: 48,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'chuBunshoNo',
      name: '注文書No',
      field: 'chuBunshoNo',
      minWidth: 160,
      sortable: true,
      filterable: true,
    },
    {
      id: 'chuBunshoKingaku',
      name: '注文書金額',
      field: 'chuBunshoKingaku',
      minWidth: 140,
      sortable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      filterable: true,
      filter: { model: Filters.compoundInputNumber },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    { id: 'daikuShu', name: '大工種', field: 'daikuShu', width: 183, sortable: true, filterable: true },
    {
      id: 'gyoushaCode',
      name: '業者コード',
      field: 'gyoushaCode',
      minWidth: 130,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-right',
    },
    {
      id: 'ichiJiGyoushaMei',
      name: '一次業者名',
      field: 'ichiJiGyoushaMei',
      width: 140,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-right',
    },
    {
      id: 'gaitouChakushuNichi',
      name: '該当着手日',
      field: 'gaitouChakushuNichi',
      sortable: true,
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
    {
      id: 'gaitouBikiWataruNichi',
      name: '該当引渡日',
      field: 'gaitouBikiWataruNichi',
      sortable: true,
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
  ]);

  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = '0'
    //     sansyouKengen = '0'
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === '1',
    //   sansyouKengen: sansyouKengen === '1',
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sagyouInMeiboList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY998');
    if (sagyouInMeiboList.length === 0) {
      sagyouInMeiboList = sagyouInMeiboData(500);
      // 番号作成
      sagyouInMeiboList = sagyouInMeiboList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY998', JSON.stringify(sagyouInMeiboList));
    }
    setRowData(sagyouInMeiboList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('業者一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webQ0036-list" id="webQ0036-list-container">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webQ0037/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webQ0037/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebQ0036SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>
        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webQ0037/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webQ0037/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebQ0036ListPage;
