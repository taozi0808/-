import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button, TextField, Box, Typography, Container, List, ListItem, ListItemText, Paper } from '@mui/material';
import './WebA0020PasswordResetPage.scss';

const ResetPassword = () => {
  const navigate = useNavigate();

  const handleSubmit = event => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const id = formData.get('id') as string;

    if (!id) {
      setError('IDを入力されていません。'); // エラーメッセージ
    } else {
      setError(null); // エラーメッセージのクリア
      navigate('/webA0010');
    }
  };

  const [steps, setSteps] = useState([]);
  const [notes, setNotes] = useState([]);
  const [error, setError] = useState<string | null>(null); // エラーのステータス

  // Mockデータの取得
  useEffect(() => {
    const fetchData = async () => {
      // 非同期処理のシミュレーション
      const data = await new Promise<{ steps: string[]; notes: string[] }>(resolve => {
        setTimeout(() => {
          resolve({
            steps: [
              '正しいご自身の社員コードを、IDに入力してください。',
              '「再通知メール送信」ボタンをクリックしてください。',
              '画面が切り替わりましたら、バスワード再通知メールの送信がされています。Outlookをご確認ください。',
            ],
            notes: [
              '当掛けは、パソコンのブラウザ（Google Chrome）での操作を前提としております。',
              'スマートフォンや他ブラウザでは正常に処理されない可能性があります。',
            ],
          });
        }, 1000); // 1 秒遅延をシミュレートする
      });

      setSteps(data.steps);
      setNotes(data.notes);
    };

    fetchData();
  }, []);

  return (
    <Container maxWidth="md" className="webA0020-container">
      {/* タイトル */}
      <Box textAlign="left" mt={4} sx={{ marginLeft: '40px' }}>
        <Typography variant="h4" sx={{ fontSize: '16px' }}>
          パスワード再通知メール送信画面
        </Typography>
      </Box>

      {/* 情報入力 */}
      <Box
        mt={4}
        mb={4}
        sx={{
          width: '80%',
          borderBottom: '1px solid #000',
          paddingBottom: '6px',
          paddingTop: '6px',
          marginLeft: '40px', // タイトルと揃える
          marginTop: '12px',
          marginBottom: '2px',
        }}
      >
        <Typography variant="body1" sx={{ fontSize: '14px' }}>
          情報入力
        </Typography>
      </Box>

      <Box sx={{ marginLeft: '40px' }}>
        <Typography variant="h6" className="title" sx={{ fontSize: '12px' }}>
          パスワード再通知メールを会社メールへ送信します。
        </Typography>

        <Paper elevation={3} sx={{ padding: 3, width: '80%', marginLeft: '40px', marginTop: '2px', boxShadow: 'none' }}>
          <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2, marginTop: '0px' }}>
            {/* エラーメッセージ */}
            {error && (
              <Typography variant="body2" color="error" sx={{ mb: 1 }}>
                {error}
              </Typography>
            )}
            <TextField fullWidth label="ID" name="id" margin="normal" variant="outlined" sx={{ marginTop: '4px' }} className="loginLable" />
            <Box mt={2} textAlign="left" sx={{ marginTop: '4px' }}>
              <Button type="submit" variant="contained" color="primary">
                通知メール送信
              </Button>
            </Box>
          </Box>
        </Paper>
      </Box>

      {/* 底部ボックスの内容 */}
      <Box sx={{ position: 'relative', minHeight: 'auto', width: '100%' }}>
        <Box mt={4} className="footer-box" sx={{ marginLeft: '40px' }}>
          <Typography variant="body2" fontWeight="bold" sx={{ fontSize: '0.575rem' }}>
            【手順】
          </Typography>
          <List>
            {steps.map((step, index) => (
              <ListItem key={index}>
                <ListItemText primary={`${index + 1}. ${step}`} sx={{ fontSize: '0.575rem' }} className="footer-list-item" />
              </ListItem>
            ))}
          </List>

          <Typography variant="body2" fontWeight="bold" sx={{ fontSize: '0.575rem' }}>
            【注意】
          </Typography>
          <List>
            {notes.map((note, index) => (
              <ListItem key={index}>
                <ListItemText primary={note} className="footer-list-item" />
              </ListItem>
            ))}
          </List>
        </Box>

        {/* Link */}
        <Box className="right-bottom-element">
          <Link to="https://www.daito-j.com/privacy" target="_blank">
            ブライバシーボリシー
          </Link>
        </Box>
      </Box>
    </Container>
  );
};

export default ResetPassword;
