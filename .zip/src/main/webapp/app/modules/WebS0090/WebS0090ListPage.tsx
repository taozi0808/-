import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0090ListPage.scss';
import { DBManager, STORAGE_KEY_SHONIN_SAGYOUIN, shoninSagyouInData } from 'app/shared/util/construction-list';
import { Column, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import dayjs from 'dayjs';
import WebS0090SearchDialog from './SearchDialog/WebS0090SearchDialog';

const WebS0090ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 50,
      sortable: true,
      filterable: true,
      cssClass: 'center',
    },
    {
      id: 'sagyouInCode',
      name: '作業員コード',
      field: 'sagyouInCode',
      minWidth: 165,
      sortable: true,
      filterable: true,
    },
    {
      id: 'shimei',
      name: '氏名',
      field: 'shimei',
      minWidth: 80,
      sortable: true,
      filterable: true,
    },
    {
      id: 'koyouKbn',
      name: '雇用区分',
      field: 'koyouKbn',
      width: 114,
      sortable: true,
      filterable: true,
    },
    {
      id: 'kenkoushindan',
      name: '健康診断',
      field: 'kenkoushindan',
      width: 90,
      sortable: true,
      filterable: true,
    },
    {
      id: 'kenkouhoken',
      name: '健康保険',
      field: 'kenkouhoken',
      minWidth: 100,
      sortable: true,
      filterable: true,
    },
    {
      id: 'kouseinenkin',
      name: '厚生年金',
      field: 'kouseinenkin',
      width: 85,
      sortable: true,
      filterable: true,
    },
    {
      id: 'koyouhoken',
      name: '雇用保険',
      field: 'koyouhoken',
      width: 85,
      sortable: true,
      filterable: true,
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 80,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 140,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 50,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 50,
      sortable: true,
      filterable: true,
      cssClass: 'center',
      formatter: LinkFormatter,
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sagyouInList = DBManager.getShoninSagyouInList();
    if (sagyouInList.length === 0) {
      sagyouInList = shoninSagyouInData(500);
      // 番号作成
      sagyouInList = sagyouInList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SHONIN_SAGYOUIN, JSON.stringify(sagyouInList));
    }
    setRowData(sagyouInList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('承認一覧（作業員情報管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0090-list" id="WebS0090-list-container">
        <div className="top-operation">
          <div>
            <WebS0090SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO:正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webQ0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0090ListPage;
