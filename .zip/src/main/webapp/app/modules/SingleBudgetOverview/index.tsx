// import React, { useState, useMemo } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';

// const SummaryTable = () => {
//   const rawData = [
//     { item: '商品A', price: 100, quantity: 2 },
//     { item: '商品B', price: 200, quantity: 3 },
//     { item: '商品C', price: 150, quantity: 1 },
//   ];

//   // 计算合计并添加到数据
//   const rowData = useMemo(() => {
//     const totalPrice = rawData.reduce((sum, row) => sum + row.price * row.quantity, 0);
//     const totalQuantity = rawData.reduce((sum, row) => sum + row.quantity, 0);

//     return [
//       ...rawData,
//       {
//         item: '合计',
//         price: '',
//         quantity: totalQuantity,
//         total: totalPrice,
//         isSummaryRow: true,
//       },
//     ];
//   }, [rawData]);

//   const [columnDefs] = useState([
//     { headerName: '商品', field: 'item' },
//     { headerName: '单价', field: 'price' },
//     { headerName: '数量', field: 'quantity' },
//     {
//       headerName: '金额',
//       valueGetter: params => (params.data.isSummaryRow ? params.data.total : params.data.price * params.data.quantity),
//     },
//   ]);

//   // 行样式
//   const getRowStyle = params => {
//     if (params.data.isSummaryRow) {
//       return { background: '#f5f5f5', fontWeight: 'bold' };
//     }
//     return null;
//   };

//   return (
//     <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
//       <AgGridReact
//         rowData={rowData}
//         columnDefs={columnDefs}
//         getRowStyle={getRowStyle}
//         defaultColDef={{
//           flex: 1,
//           resizable: true,
//         }}
//       />
//     </div>
//   );
// };

// export default SummaryTable;
