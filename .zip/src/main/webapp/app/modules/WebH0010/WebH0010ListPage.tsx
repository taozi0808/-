import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@mui/material';
import './WebH0010ListPage.scss';
import '../../app.scss';
import WebH0010SearchDialog from './SearchDialog/WebH0010SearchDialog';
import { DBManager, sateiDataList } from 'app/shared/util/construction-list';
import { useNavigate } from 'react-router-dom';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { Column, FieldType } from 'slickgrid-react';

const WebH0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const [selectedId, setSelectedId] = useState('');
  const navigate = useNavigate();
  const [permissionInfo] = useState({
    // TODO: 次のインタフェースがドッキングされると、両方の権限のデフォルト値がfalseに変更されます。
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const columnRef = useRef<Array<Column>>([
    {
      id: 'No',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      minWidth: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      width: 280,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kojiBumon',
      name: '工事部門',
      field: 'kojiBumon',
      width: 115,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaShocho',
      name: '現場所長',
      field: 'genbaShocho',
      width: 110,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'senninGijutsuSha',
      name: '専任技術者',
      field: 'senninGijutsuSha',
      width: 110,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kojiKotei',
      name: '工事工程',
      field: 'kojiKotei',
      width: 165,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'sateiShoninBi',
      name: '査定承認日',
      field: 'sateiShoninBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'jikkoYosanKingaku',
      name: '実行予算金額',
      field: 'jikkoYosanKingaku',
      minWidth: 130,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'hachuKingaku',
      name: '発注金額',
      field: 'hachuKingaku',
      minWidth: 130,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'zengetsuMadeSateiZumiKingaku',
      name: '前月迄査定済金額',
      field: 'zengetsuMadeSateiZumiKingaku',
      minWidth: 155,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'togetsuSateiKingaku',
      name: '当月査定金額',
      field: 'togetsuSateiKingaku',
      minWidth: 130,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'sateiZumiGokeiKingaku',
      name: '査定済合計金額',
      field: 'sateiZumiGokeiKingaku',
      minWidth: 155,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'miSateiZa',
      name: '未査定残',
      field: 'miSateiZa',
      minWidth: 130,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const handleSearch = values => {
    // TODO: 次の3つのフィールドを置き換えます
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // TODO: インタフェース・ドキュメントがある場合は、次のコードを放します。
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sateiList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_SATEI996');
    if (sateiList.length === 0) {
      sateiList = sateiDataList(500);
      // 番号作成
      sateiList = sateiList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_SATEI996', JSON.stringify(sateiList));
    }
    setRowData(sateiList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('査定一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webH0010-list-container" id="webH0010-list-container-container">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webH0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webH0030/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebH0010SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO: 正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webB0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebH0010ListPage;
