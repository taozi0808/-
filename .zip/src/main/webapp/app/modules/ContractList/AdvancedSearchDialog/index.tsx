import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Checkbox, FormControlLabel, Box, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useForm, Controller } from 'react-hook-form';
import './index.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const AdvancedSearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const { control, handleSubmit } = useForm({
    // TODO: 接口对接时按需修改字段名称，尤其是listJyucyuuJyoutai，因为目前还不知道受主状态的枚举值
    defaultValues: {
      ankenCode: '',
      ankenName: '',
      listJyucyuuJyoutai: {
        '1': true,
        '2': false,
        '3': false,
      },
      kokyakuName: '',
      jmYmdStart: '',
      jmYmdEnd: '',
      eigyouBumon: '',
      eigyouTantousya: '',
    },
  });

  const onSubmit = data => {
    // TODO: 有了接口文档后，按需调整入参数据结构；
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    if (data.listJyucyuuJyoutai.length === 0) {
      notify('受注状態を選択してください', 'warning');
      return;
    }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    // TODO: 接口对接时按需修改字段名称，尤其是listJyucyuuJyoutai，因为目前还不知道受主状态的枚举值
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={theme => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '40px 8px 12px 0' }}>
              <Button type="submit" variant="contained">
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="ad-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>案件コード</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 8 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Box flex={1} mr={1}>
                    <Controller
                      name="jmYmdStart"
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>受注見込日</label>
                          <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="jmYmdEnd"
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label style={{ minWidth: 20 }}>～</label>
                          <TextField {...field} size="small" type="date" fullWidth InputLabelProps={{ shrink: true }} />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenName"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>案件名(か含む)</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 255 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="eigyouBumon"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>営業部門</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 20 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2} display="flex" gap={1}>
                  <label style={{ lineHeight: '36px', width: 100 }}>受注状態</label>
                  {/* 第一个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.1"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="未成約" />}
                  />

                  {/* 第二个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.2"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="成約" />}
                  />

                  {/* 第三个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.3"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="不成約" />}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="eigyouTantousya"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>営業担当者</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 32 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>

              <Box display="flex" justifyContent="flex-start">
                <Controller
                  name="kokyakuName"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%', marginBottom: 40 }}>
                      <label>顧客名(か含む)</label>
                      <TextField {...field} fullWidth inputProps={{ maxLength: 255 }} size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AdvancedSearchDialog;
