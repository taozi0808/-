import React, { useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Box, Select, MenuItem } from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebI0010SearchDialog.scss';

const WebI0010SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  // ポップアップ開ける処理
  const handleClickOpen = () => setOpen(true);
  // ポップアップ閉じる処理
  const handleClose = () => {
    setOpen(false);
    // ポップアップが閉じる後、データをクリアする
    setTimeout(() => {
      reset();
    }, 0);
  };

  // 仮データ START
  const genjyoCodeList = [
    { value: '1', label: '1234567-000-001', remark: 'なし' },
    { value: '2', label: '1234567-000-002', remark: 'なし' },
    { value: '3', label: '1234567-000-003', remark: 'なし' },
    { value: '4', label: '1234567-000-004', remark: 'なし' },
    { value: '5', label: '1234567-000-005', remark: 'なし' },
    { value: '6', label: '1234567-000-006', remark: 'なし' },
    { value: '7', label: '1234567-000-007', remark: 'なし' },
    { value: '8', label: '1234567-000-008', remark: 'なし' },
    { value: '9', label: '1234567-000-009', remark: 'なし' },
  ];

  const genjyoNameList = [
    { value: '1', label: '現場001' },
    { value: '2', label: '現場002' },
    { value: '3', label: '現場003' },
    { value: '4', label: '現場004' },
  ];
  // 仮データ END

  const { control, handleSubmit, reset } = useForm({
    defaultValues: {
      // 現場コード
      genjyoCode: '',
      // 現場名
      genjyoName: '',
      // 現場着工日
      genbaChakkouDateFrom: '',
      genbaChakkouDateTo: '',
      // 現場完工日
      genbaKankouDateFrom: '',
      genbaKankouDateTo: '',
    },
  });

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <React.Fragment>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleClickOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />

        <DialogContent className="webI0010-search-container">
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* ボタンエリア */}
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>

            {/* 検索条件エリア */}
            <Box className="dialog-content" display="flex" flexDirection="column" gap={2} style={{ margin: '0px 100px 100px 100px' }}>
              {/* 現場コード */}
              <Box>
                <Controller
                  name="genjyoCode"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>現場コード</label>
                      <Select
                        size="small"
                        inputRef={field.ref}
                        fullWidth
                        {...field}
                        style={{ width: 150 }}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                        }}
                      >
                        <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                        {genjyoCodeList.map(item => (
                          <MenuItem key={item.value} value={item.value}>
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              {/* 現場名 */}
              <Box>
                <Controller
                  name="genjyoName"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>現場名</label>
                      <Select
                        size="small"
                        inputRef={field.ref}
                        fullWidth
                        {...field}
                        style={{ width: '52%' }}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                        }}
                      >
                        <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                        {genjyoNameList.map(item => (
                          <MenuItem key={item.value} value={item.value}>
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              {/* 現場着工日 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={15}>
                  <div className="ad-search-item">
                    <label>現場着工日</label>
                    <Controller
                      name="genbaChakkouDateFrom"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" {...field} />}
                    />
                    <div
                      style={{
                        lineHeight: '36px',
                        padding: '0 10px',
                      }}
                    >
                      ～
                    </div>
                    <Controller
                      name="genbaChakkouDateTo"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" {...field} />}
                    />
                  </div>
                </Box>
              </Box>
              {/* 現場完工日 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={15}>
                  <div className="ad-search-item">
                    <label>現場完工日</label>
                    <Controller
                      name="genbaKankouDateFrom"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" {...field} />}
                    />
                    <div
                      style={{
                        lineHeight: '36px',
                        padding: '0 10px',
                      }}
                    >
                      ～
                    </div>
                    <Controller
                      name="genbaKankouDateTo"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" {...field} />}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
};

export default WebI0010SearchDialog;
