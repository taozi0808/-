import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import React, { useState, FC, useEffect, useRef, useMemo, useCallback, StrictMode } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebU0020CreateForm.scss';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { Box } from '@mui/material';
import { CustomButtonRender } from 'app/components/CustomRender/customButtonRender';
import {
  ColDef,
  ColGroupDef,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  ICellRendererParams,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);

interface IRow {
  id: string;
  conditionName1: string;
  conditionName2: string;
  conditionName3: string;
  conditionName4: string;
  conditionName11: string;
  conditionName12: string;
  country: number;
  group: number;
  level: 1 | 2 | 3;
  isColoe: 0 | 1;
}

/**
 * Web-P-0030
 * 下請登録
 */
const WebU0020CreateForm: FC = () => {
  const navigate = useNavigate();
  const gridRef = useRef();
  const [data, setData] = useState<IRow[]>([
    {
      id: '1',
      conditionName1: '0001',
      conditionName11: '',
      conditionName12: '',
      conditionName2: '0001-xxx',
      conditionName3: '0001-address',
      conditionName4: '0001-tel',
      country: 1,
      group: 1,
      level: 1,
      isColoe: 1,
    },
    {
      id: '2',
      conditionName1: '0001',
      conditionName11: '0002',
      conditionName12: '',
      conditionName2: '0002-xxx',
      conditionName3: '0002-address',
      conditionName4: '0002-tel',
      country: 2,
      group: 2,
      level: 2,
      isColoe: 1,
    },
    {
      id: '3',
      conditionName1: '0001',
      conditionName11: '0002',
      conditionName12: '0003',
      conditionName2: '0003-xxx',
      conditionName3: '0003-address',
      conditionName4: '0003-tel',
      country: 2,
      group: 3,
      level: 3,
      isColoe: 1,
    },
    {
      id: '4',
      conditionName1: '0001',
      conditionName11: '0002',
      conditionName12: '0004',
      conditionName2: '0004-xxx',
      conditionName3: '0004-address',
      conditionName4: '0004-tel',
      country: 2,
      group: 4,
      level: 3,
      isColoe: 0,
    },
    {
      id: '5',
      conditionName1: '0001',
      conditionName11: '00012',
      conditionName12: '',
      conditionName2: '0002-xxx',
      conditionName3: '0002-address',
      conditionName4: '0002-tel',
      country: 3,
      group: 5,
      level: 2,
      isColoe: 1,
    },
    {
      id: '6',
      conditionName1: '0001',
      conditionName11: '0002',
      conditionName12: '0003',
      conditionName2: '0003-xxx',
      conditionName3: '0003-address',
      conditionName4: '0003-tel',
      country: 3,
      group: 6,
      level: 3,
      isColoe: 1,
    },
    {
      id: '7',
      conditionName1: '0001',
      conditionName11: '0002',
      conditionName12: '0004',
      conditionName2: '0004-xxx',
      conditionName3: '0004-address',
      conditionName4: '0004-tel',
      country: 3,
      group: 7,
      level: 3,
      isColoe: 0,
    },
  ]);
  const [rowData, setRowData] = useState(data);

  const daikushuParams = ['鉄筋工', '配管工', '電気工', '(other)'];
  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      editable: true,
    };
  }, []);

  const UserIdNameRender = params => {
    const { level, conditionName1, conditionName11, conditionName12, isColoe } = params.data;
    if (level === 1) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center">
            <div style={{ height: '30px' }}>{conditionName1}</div>
          </Box>
        </div>
      );
    } else if (level === 2) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <PlayArrowIcon />
          </Box>
          <Box flex={6}>
            <div style={{ height: '30px' }}>{conditionName11}</div>
          </Box>
        </div>
      );
    } else {
      if (isColoe === 1) {
        return (
          <div style={{ display: 'flex', width: '100%' }}>
            <Box flex={3} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
              <PlayArrowIcon />
            </Box>
            <Box flex={5}>
              <div style={{ height: '30px' }}>{conditionName12}</div>
            </Box>
          </div>
        );
      } else {
        return (
          <div style={{ display: 'flex', width: '100%' }}>
            <Box flex={3} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
              <PlayArrowIcon />
            </Box>
            <Box flex={5} className="center-cell-coloer">
              <div style={{ height: '30px' }}>{conditionName12}</div>
            </Box>
          </div>
        );
      }
    }
  };

  const sortData = (dataList: any) => {
    if (dataList.level === 1) {
      const newRow = {
        ...dataList,
        level: 2,
        isColoe: 1,
        country: data.length,
        group: dataList.group,
      };
      data.push(newRow);
    } else {
      const newRow = {
        ...dataList,
        level: 3,
        isColoe: 0,
        country: dataList.country + '',
        group: data.length + '',
      };
      data.push(newRow);
    }
    const dataList1 = [...data].sort((a, b) => {
      if (a.country < b.country) return -1;
      if (a.country > b.country) return 1;
      if (a.group < b.group) return -1;
      if (a.group > b.group) return 1;
      return parseInt(a.id, 10) - parseInt(b.id, 10);
    });
    for (let i = 0; i < dataList1.length; i++) {
      dataList1[i].id = i + 1 + '';
      dataList1[i].group = i + 1;
    }
    return dataList1;
  };

  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      minWidth: 50,
      maxWidth: 80,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '業者コード',
      field: '',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      minWidth: 180,
      maxWidth: 300,
      cellRenderer: UserIdNameRender,
      valueGetter: params =>
        params.data.level === 1
          ? params.data.conditionName1
          : params.data.level === 2
            ? params.data.conditionName11
            : params.data.conditionName12,
      valueSetter: params => {
        if (params.data.level === 1) {
          params.data.conditionName1 = params.newValue;
        } else if (params.data.level === 2) {
          params.data.conditionName11 = params.newValue;
        } else {
          params.data.conditionName12 = params.newValue;
        }
        return true;
      },
    },
    {
      headerName: '業者名',
      field: 'conditionName2',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      // cellClass: 'center-cell',
      cellClass: params => {
        return params.data.isColoe === 1 ? 'center-cell' : 'center-cell center-cell-coloer';
      },
      // spanRows: true,
      minWidth: 250,
      maxWidth: 500,
    },
    {
      headerName: 'メールアドレス',
      field: 'conditionName3',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      // cellClass: 'center-cell',
      // spanRows: true,
      minWidth: 300,
      maxWidth: 500,
      cellClass: params => {
        return params.data.isColoe === 1 ? 'center-cell' : 'center-cell center-cell-coloer';
      },
    },
    {
      headerName: '業者招待',
      field: 'conditionName4',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      minWidth: 140,
      maxWidth: 200,
      cellRenderer: (params: ICellRendererParams) => {
        if (params.data.level === 3) {
          return null;
        }
        return <CustomButtonRender params={params} />;
      },
      cellRendererParams: {
        buttonName: (itme: any) => {
          return itme.level === 1 ? `二次業者招待` : itme.level === 2 ? `三次業者招待` : '';
        },
        buttonStyle: {
          width: '100%',
          backgroundColor: `#B1E8FF`,
          color: `#181D1F`,
        },
        onButtonClick: (itme: any) => {
          setData(sortData(itme));
        },
      },
    },
  ]);

  // 画面名
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('下請登録');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webu0020-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <div
          className="ag-theme-alpine column-group-table"
          style={{
            padding: 16,
            width: 'auto',
            height: '76%',
            overflowY: 'auto',
          }}
        >
          <AgGridReact
            rowData={data}
            theme={AGGridTheme}
            columnDefs={columnRef.current}
            headerHeight={30}
            rowHeight={30}
            defaultColDef={defaultColDef}
          />
        </div>
      </div>
    </div>
  );
};
export default WebU0020CreateForm;
