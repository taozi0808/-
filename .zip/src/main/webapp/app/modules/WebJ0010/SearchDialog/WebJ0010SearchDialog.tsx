import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Checkbox, FormControlLabel, Box } from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import './WebJ0010SearchDialog.scss';
import '../../../app.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebJ0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedValue, setSelectedValue] = useState('');

  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 現場コード
      genbaCode: '',
      // 現場名（ｶﾅ含む）
      genbaName: '',
      // 査定年月
      sateiNengetsu: '',
      // 支払日
      shiharaiNichi1: '',
      shiharaiNichi2: '',
      // 協力業者コード
      gyoushaCode: '',
      // 協力業者名（ｶﾅ含む）
      gyoushaName: '',
      // 支払データ作成済みも表示する
      dataSakuseiFlg: true,
    },
  });
  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '400px',
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="webJ0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <div className="webJ0010-search-item">
                    <label>現場コード</label>
                    <Controller
                      name="genbaCode"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '100%' }} size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="webJ0010-search-item">
                    <label>現場名（ｶﾅ含む）</label>
                    <Controller
                      name="genbaName"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ minWidth: '126%' }} size="small" />}
                    />
                  </div>
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <div className="webJ0010-search-item">
                    <label>協力業者コード</label>
                    <Controller
                      name="gyoushaCode"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '100%' }} size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="webJ0010-search-item">
                    <label>協力業者名（ｶﾅ含む）</label>
                    <Controller
                      name="gyoushaName"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ minWidth: '126%' }} size="small" />}
                    />
                  </div>
                </Box>
              </Box>
              <LocalizationProvider
                dateAdapter={AdapterDayjs}
                adapterLocale="ja"
                localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
              >
                <Box display="flex" justifyContent="space-between" className="cell-date-picker">
                  <Box flex={1} display="flex" justifyContent="space-between">
                    <div className="webJ0010-search-item">
                      <label>支払日</label>
                      <Controller
                        name="shiharaiNichi1"
                        control={control}
                        render={({ field, fieldState }) => (
                          <DatePicker
                            {...field}
                            disableFuture={!!fieldState.error}
                            sx={{ width: '100%', textAlignLast: 'end' }}
                            format="YYYY年MM月DD日"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        )}
                      />
                    </div>
                    <div className="webJ0010-search-item">
                      <label style={{ minWidth: 25, padding: '0 5px 0 5px' }}>～</label>
                      <Controller
                        name="shiharaiNichi2"
                        control={control}
                        render={({ field, fieldState }) => (
                          <DatePicker
                            {...field}
                            disableFuture={!!fieldState.error}
                            sx={{ width: '100%', textAlignLast: 'end' }}
                            format="YYYY年MM月DD日"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        )}
                      />
                    </div>
                  </Box>
                </Box>
              </LocalizationProvider>
              <LocalizationProvider
                dateAdapter={AdapterDayjs}
                adapterLocale="ja"
                localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
              >
                <Box display="flex" justifyContent="space-between" className="cell-date-picker" sx={{ width: '130%' }}>
                  <Box flex={1} mr={2}>
                    <div className="webJ0010-search-item" style={{ width: '76.5%' }}>
                      <label>査定年月</label>
                      <Controller
                        name="sateiNengetsu"
                        control={control}
                        render={({ field, fieldState }) => (
                          <DatePicker
                            {...field}
                            disableFuture={!!fieldState.error}
                            sx={{ width: '100%', textAlignLast: 'end' }}
                            format="YYYY年MM月"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        )}
                      />
                    </div>
                  </Box>
                  <Box flex={1} display="flex" justifyContent="space-between">
                    <Controller
                      name="dataSakuseiFlg"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="支払データ作成済みも表示する" />
                      )}
                    />
                  </Box>
                </Box>
              </LocalizationProvider>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebJ0010SearchDialog;
