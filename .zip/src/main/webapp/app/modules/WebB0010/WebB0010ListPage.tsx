import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebB0010ListPage.scss';
import dayjs from 'dayjs';
import { STORAGE_KEY, DBManager, generateRandomData } from 'app/shared/util/construction-list';
import WebB0010SearchDialog from './SearchDialog/WebB0010SearchDialog';
import { Column, FieldType } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const WebB0010 = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const columnRef = useRef<Array<Column>>([
    {
      id: 'ankenCode',
      name: '案件コード',
      field: 'ankenCode',
      width: 180,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    { id: 'ankenName', name: '案件名', field: 'ankenName', width: 180, sortable: true, filterable: true, type: FieldType.string },
    { id: 'kokyakuName', name: '顧客名', field: 'kokyakuName', width: 130, sortable: true, filterable: true, type: FieldType.string },
    {
      id: 'genbaJyuusyo1',
      name: '現場住所',
      field: 'genbaJyuusyo1',
      width: 180,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'souteiKingaku',
      name: '想定金額',
      field: 'souteiKingaku',
      cssClass: 'align-right',
      width: 140,
      sortable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      filterable: true,
      type: FieldType.number,
    },
    {
      id: 'jyucyuuMikomiYMD',
      name: '受注見込日',
      field: 'jyucyuuMikomiYMD',
      width: 220,
      sortable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'cyakkouKibouYMD',
      name: '着工希望日',
      field: 'cyakkouKibouYMD',
      width: 220,
      sortable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'eigyouBumonName',
      name: '営業部門',
      field: 'eigyouBumonName',
      width: 110,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'eigyouTantousyaShiMei',
      name: '営業担当者',
      field: 'eigyouTantousyaShiMei',
      width: 130,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'shincyokudo',
      name: '進捗度',
      field: 'shincyokudo',
      width: 120,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // TODO: インターフェースとして利用する時、2つの権限のデフォルト値はどちらもfalseに変更する必要がある
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  // 検索ボタン押下時処理ロジック
  const handleSearch = values => {
    // TODO: この3つのフィールドを置き換える必要がある
    // const params = {
    //   listSyozokuBusyoCode: 'test',
    //   syozokuBusyoCode: 'test',
    //   sbSyozokuCode: 'test',
    //   ...values,
    // };

    // TODO: インターフェースが決まりましたら、以下のコードをコメントアウトする。
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // モックデータ設定（一時的）
    let contractList = DBManager.getList();
    if (contractList.length === 0) {
      contractList = generateRandomData(200);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    }

    // 検索処理ロジック（一時的）
    contractList = contractList.filter(item => {
      // 案件コード检索
      if (values.ankenCode && !item.ankenCode.includes(values.ankenCode)) {
        return false;
      }

      // 案件名检索
      if (values.ankenName && !item.ankenName.includes(values.ankenName)) {
        return false;
      }

      // 顧客名检索
      if (values.kokyakuName && !item.kokyakuName.includes(values.kokyakuName)) {
        return false;
      }

      // 営業部門检索
      if (values.eigyouBumon && !item.eigyouBumonName.includes(values.eigyouBumon)) {
        return false;
      }

      // 営業担当者检索
      if (values.eigyouTantousya && !item.eigyouTantousyaShiMei.includes(values.eigyouTantousya)) {
        return false;
      }

      // 受注状態检索
      if (values.listJyucyuuJyoutai && !values.listJyucyuuJyoutai.includes(item.listJyucyuuJyoutai)) {
        return false;
      }

      // 受注予定日区间检索
      if (values.jmYmdStart && values.jmYmdEnd) {
        const jyucyuuDate = new Date(item.jyucyuuMikomiYMD);
        const startDate = new Date(values.jmYmdStart);
        const endDate = new Date(values.jmYmdEnd);

        if (jyucyuuDate < startDate || jyucyuuDate > endDate) {
          return false;
        }
      }

      return true;
    });

    setRowData(contractList);
  };

  // 選択された一覧明細行のIDを設定する
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  // 画面の機能名を設定する
  useEffect(() => {
    setPageTitle('案件一覧');
    return () => setPageTitle('');
  }, []);

  // 各ボタン押下時、処理ロジックを設定する
  return (
    <div className="webB0010-container">
      <div className="top-operation">
        <div>
          <Button
            variant="contained"
            size="small"
            style={{ marginRight: '8px', minWidth: 96 }}
            onClick={() => {
              navigate('/webB0030/add');
            }}
          >
            新規登録
          </Button>
          {permissionInfo.hensyuuKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webB0030/edit/${selectedId}`);
              }}
            >
              編集
            </Button>
          )}
          {permissionInfo.sansyouKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webB0030/preview/${selectedId}`);
              }}
            >
              参照
            </Button>
          )}
        </div>
        <div>
          <WebB0010SearchDialog onSearch={handleSearch} />
          {rowData.length > 0 && (
            <>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                印刷
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                CSV出力
              </Button>
            </>
          )}
        </div>
      </div>

      {/* フォームの共通部品を引用する */}
      <BasicSlickGridTable
        columns={columnRef.current}
        data={rowData}
        onSelectionChanged={onSelectedRowsChanged}
        enableContextMenu
        // 一覧明細行に右クリック時、処理メニューを表示する
        contextMenuItems={[
          // TODO: インターフェースから返される権限に基づいて右クリックメニューの可用性を制御する必要がある
          {
            title: '編集',
            command: 'edit',
            action: (_, callbackArgs) => {
              navigate(`/webB0030/edit/${callbackArgs.dataContext.id}`);
            },
          },
          {
            title: '参照',
            command: 'preview',
            action: (_, callbackArgs) => {
              navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
            },
          },
        ]}
      />
    </div>
  );
};

export default WebB0010;
