import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Checkbox, FormControlLabel, Box, IconButton } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import DialogHead from 'app/components/DialogHead';
import './WebB0010SearchDialog.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebB0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const { control, handleSubmit } = useForm({
    // TODO: インターフェースが決まりましたら、フィールド名を必要に応じて変更してください。
    // 受取側状態の列挙値がまだ不明です。
    defaultValues: {
      ankenCode: '',
      ankenName: '',
      listJyucyuuJyoutai: {
        '0': true,
        '1': false,
        '9': false,
      },
      kokyakuName: '',
      jmYmdStart: '',
      jmYmdEnd: '',
      eigyouBumon: '',
      eigyouTantousya: '',
    },
  });

  const onSubmit = data => {
    // TODO: インターフェースが決まりましたら、必要に応じて入力パラメータのデータ構造を調整します。
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    if (data.listJyucyuuJyoutai.length === 0) {
      notify('受注状態を選択してください', 'warning');
      return;
    }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    // TODO: インターフェースが決まりましたら、フィールド名を必要に応じて変更してください。
    // 受取側状態の列挙値がまだ不明です。
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>

      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />

        <DialogContent className="webB0010-dialog-background-color">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: '104px' }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>

            <Box display="flex" flexDirection="column" gap={2} className="webB0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-anken">
                        <label>案件コード</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 8 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between" style={{ marginRight: '2.8%' }}>
                  <div className="ad-search-item-anken">
                    <label>受注見込日</label>
                  </div>
                  <Box flex={1} mr={1}>
                    <Controller
                      name="jmYmdStart"
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item-anken" style={{ marginRight: '-21px' }}>
                          <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="jmYmdEnd"
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item-anken" style={{ maxWidth: '86.3%' }}>
                          <label style={{ minWidth: 20, padding: '0 10px 0 0' }}>～</label>
                          <TextField {...field} size="small" type="date" fullWidth InputLabelProps={{ shrink: true }} />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenName"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-anken">
                        <label>案件名(かナ含む)</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 255 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} style={{ marginRight: '7%' }}>
                  <Controller
                    name="eigyouBumon"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-anken">
                        <label>営業部門</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 20 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2} display="flex" gap={1}>
                  <label style={{ lineHeight: '36px', width: 100, textAlign: 'center' }}>受注状態</label>
                  {/* 一番目のチェックボックス */}
                  <Controller
                    name="listJyucyuuJyoutai.0"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="未成約" />}
                  />

                  {/* 二番目のチェックボックス */}
                  <Controller
                    name="listJyucyuuJyoutai.1"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="成約" />}
                  />

                  {/* 三番目のチェックボックス */}
                  <Controller
                    name="listJyucyuuJyoutai.9"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="不成約" />}
                  />
                </Box>
                <Box flex={1} style={{ marginRight: '7%' }}>
                  <Controller
                    name="eigyouTantousya"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-anken">
                        <label>営業担当者</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 32 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>

              <Box display="flex" justifyContent="flex-start">
                <Controller
                  name="kokyakuName"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item-anken" style={{ width: '100%', marginBottom: 40, maxWidth: '45.6%' }}>
                      <label>顧客名(かナ含む)</label>
                      <TextField {...field} fullWidth inputProps={{ maxLength: 255 }} size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebB0010SearchDialog;
