/** 定义表单各字段的数据类型 */
export interface CustomerManagementFormValues {
  customerCode: string;
  customerName: string;
  customerShortName: string;
  customerKana: string;
  managerName: string;
  managerKana: string;
  transactionType: string;
  postalCodePart1: string;
  postalCodePart2: string;
  customerAddress: string;
  phone: {
    part1: string;
    part2: string;
    part3: string;
  };
  mobile: {
    part1: string;
    part2: string;
    part3: string;
  };
  fax: {
    part1: string;
    part2: string;
    part3: string;
  };
  bankName: string;
  branchName: string;
  depositType: string;
  accountNumber: string;
  accountHolder: string;

  capital: string;
  numberOfEmployees: string;
  industry: string;
  representativeName: string;
  companyUrl: string;
  remarks: string;
}
