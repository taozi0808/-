import React, { FC, useMemo } from 'react';
import BasicAgGridTable from 'app/components/BasicAgGridTable';

interface Column {
  bukkenCode: string; // 物件コード
  bukkenName: string; // 物件名
  chumonShoNumber: string; // 注文書番号
  juchuKingaku: number | string; // 受注金額
  nyukinKingaku: number | string; // 入金金額
  hatchuHikiwatashiTanka: string; // 発注引き渡し単価
  status: string; // 状態
  keiyakuBi: string; // 契約日
  saishuBi: string; // 最終日
}

interface Props {
  rowData: Column[];
}

const Table: FC<Props> = ({ rowData }) => {
  const columnDefs = useMemo(() => {
    return [
      { name: '物件コード', field: 'bukkenCode', width: 120 },
      { name: '物件名', field: 'bukkenName', width: 200 },
      { name: '注文書番号', field: 'chumonShoNumber', width: 120 },
      { name: '受注金額', field: 'juchuKingaku', width: 120 },
      { name: '入金金額', field: 'nyukinKingaku', width: 120 },
      { name: '発注引き渡し単価', field: 'hatchuHikiwatashiTanka', width: 120 },
      { name: '状態', field: 'status', width: 120 },
      { name: '契約日', field: 'keiyakuBi', width: 120 },
      { name: '最終日', field: 'saishuBi', width: 120 },
    ];
  }, []);

  const gridStyle = useMemo(() => {
    return {
      width: '90%',
      height: '400px',
    };
  }, []);

  return (
    <div style={gridStyle} className="ag-theme-alpine">
      <BasicAgGridTable data={rowData} columns={columnDefs as any} disabledPagination />
    </div>
  );
};

export default Table;
