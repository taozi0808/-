import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebR0055ListPage.scss';
import { STORAGE_KEY_CUSTOMER, DBManager, generatCustomerData } from 'app/shared/util/construction-list';
import WebR0055SearchDialog from './SearchDialog/WebR0055SearchDialog';
import { Column, FieldType, Filters } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';

const CustomerList = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const gridRef = useRef(null);
  const columnRef = useRef<Array<Column>>([
    {
      id: 'id',
      name: 'No',
      field: 'no',
      width: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    { id: 'customerCode', name: '顧客コード', field: 'customerCode', width: 130, sortable: true, filterable: true, type: FieldType.string },
    { id: 'customerName', name: '顧客名', field: 'customerName', width: 220, sortable: true, filterable: true, type: FieldType.string },
    { id: 'kuben', name: '取引先区分', field: 'kuben', width: 130, sortable: true, filterable: true, type: FieldType.string },
    {
      id: 'gyousyu',
      name: '業種・業態',
      field: 'gyousyu',
      width: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    { id: 'Jyuusyo', name: '住所', field: 'Jyuusyo', width: 320, sortable: true, filterable: true, type: FieldType.string },
    { id: 'telno', name: '電話番号', field: 'telno', width: 150, sortable: true, filterable: true, type: FieldType.string },
    { id: 'daihyoumei', name: '代表者名', field: 'daihyoumei', width: 160, sortable: true, filterable: true, type: FieldType.string },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // TODO: API実装後，権限をFalse設定
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // TODO: API実装後下記換え
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // TODO: API実装後使用
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // mockデータ
    let customerList = DBManager.getCustomerList();
    if (customerList.length === 0) {
      customerList = generatCustomerData(500);
      localStorage.setItem(STORAGE_KEY_CUSTOMER, JSON.stringify(customerList));
    }
    setRowData(customerList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('顧客情報一覧');
    return () => setPageTitle('');
  }, [setPageTitle]);

  return (
    <div>
      <div className="webR0055-container" id="webR0055-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate('/webR0060/add');
              }}
            >
              新規登録
            </Button>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0060/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0060/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebR0055SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* テーブルの表示 */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO: APIインターフェースから返却される権限に基づいて、右クリックメニューの使用可否を制御する必要があります。
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webR0060/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webR0060/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default CustomerList;
