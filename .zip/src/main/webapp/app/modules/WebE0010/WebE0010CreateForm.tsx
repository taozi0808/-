import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebE0010CreateForm.scss';
import dayjs from 'dayjs';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { jaJP } from '@mui/x-date-pickers/locales';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useForm, Controller } from 'react-hook-form';
import { DialogContent, TextField, Button, Box } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { WebD0010, DBManager, STORAGE_KEY_GAISAN } from 'app/shared/util/construction-list';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import {
  ColDef,
  ColGroupDef,
  ICellRendererParams,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  GridReadyEvent,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule,
]);

const WebE0010 = () => {
  const navigate = useNavigate();
  const [dataSource, setDataSource] = useState([]);
  const { setPageTitle } = usePageTitleStore();
  const { id, type, stare } = useParams();
  const titleName = stare === 'webD' ? '正式見積書作成' : '概算見積書作成';
  const field1titleName = stare === 'webD' ? '精積算コード' : '概算コード';

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {
      field1: '',
      field2: '',
      ankenCode: '',
      name6: '',
      field20: '',
      name2: '',
      name3: '',
      name122: '',
      name1: '',
      field4: '',
      field5: '',
      field6: '',
      field7: '',
      field8: '',
      field9: '',
      field10: '',
      field11: '',
      field12: '',
      field13: '',
      field14: '',
    },
    mode: 'onBlur',
  });
  // サンプルデータ
  const [data, setData] = useState([]);
  const [rowData, setRowData] = useState(data);
  const gridRef = useRef<AgGridReact>();

  const columnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '見積条件',
      field: 'conditionName',
      minWidth: 170,
      maxWidth: 280,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '内容',
      field: 'percentage',
      minWidth: 450,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const daikushuParams = [
    {
      label: '',
      value: '',
    },
    {
      label: '土木工事',
      value: 0,
    },
    {
      label: '建築工事',
      value: 1,
    },
    {
      label: '電気工',
      value: 2,
    },
  ];
  const taniParams = [
    {
      label: '',
      value: '',
    },
    {
      label: '式',
      value: 0,
    },
    {
      label: '箱',
      value: 1,
    },
  ];
  const table1ColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'key',
      minWidth: 60,
      maxWidth: 60,
      spanRows: true,
      cellClass: 'center-cell',
    },
    {
      headerName: '区分/大工種',
      field: 'columns12',
      minWidth: 170,
      maxWidth: 250,
      cellClass: 'center-cell',
      children: [
        {
          headerName: '第工種',
          field: 'columns22',
          minWidth: 170,
          maxWidth: 250,
          cellClass: 'center-cell',
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: daikushuParams.map(opt => opt.value),
          },
          valueFormatter: params => {
            const option = daikushuParams.find(opt => opt.value === params.value);
            if (option) {
              return option.label;
            }
          },
          valueParser: params => {
            return params.newValue;
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.columns12 : params.data.columns22;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.columns12 = params.newValue;
            } else {
              params.data.columns22 = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '規格',
      field: 'columns13',
      minWidth: 170,
      maxWidth: 250,
      spanRows: true,
      cellClass: 'center-cell',
    },
    {
      headerName: '数量',
      field: 'columns14',
      minWidth: 100,
      maxWidth: 200,
      children: [
        {
          headerName: '単位',
          field: 'columns24',
          minWidth: 100,
          maxWidth: 200,
          cellClass: params => {
            return params.node.rowIndex % 2 === 0 ? 'end-cell' : 'center-cell';
          },
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: taniParams.map(opt => opt.value),
          },
          valueFormatter: params => {
            const option = taniParams.find(opt => opt.value === params.value);
            if (option) {
              return option.label;
            } else {
              return params.value;
            }
          },
          valueParser: params => {
            return params.newValue;
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.columns14 : params.data.columns24;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.columns14 = params.newValue;
            } else {
              params.data.columns24 = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '単価',
      field: 'columns15',
      minWidth: 170,
      maxWidth: 250,
      cellClass: 'end-cell',
      children: [
        {
          headerName: '合計金額/概算金額',
          field: 'columns15',
          cellClass: 'end-cell',
          minWidth: 170,
          maxWidth: 250,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0
              ? params.data.columns15
              : new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.data.columns15);
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.columns15 = params.newValue;
            } else {
              params.data.columns15 = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '備考',
      field: 'columns17',
      spanRows: true,
      minWidth: 270,
      cellClass: 'center-cell',
    },
  ]);

  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      editable: true,
    };
  }, []);
  const sagyouInList = DBManager.getMockList(stare === 'webD' ? WebD0010 : STORAGE_KEY_GAISAN);
  const editData = sagyouInList.find(item => item.id.toString() === id) || null;
  const sagyouInList1 = DBManager.getMockList('WebD0030');
  useEffect(() => {
    if (id) {
      setValue('field1', editData.ankenCode);
      setValue('field2', '00');
      setValue('ankenCode', editData.ankenCode);
      setValue('name6', 'N202408');
      setValue('name2', '墨田区太平2丁目計画');
      setValue('name3', 'すみだくたいへいちょうめけいかく');
      setValue('name122', '10001');
      setValue('name1', '大東建設株式会社');
      setValue('field4', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1351254000));
      setValue('field5', '7.00');
      setValue('field6', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(94590000));
      setValue('field7', '5.26');
      setValue('field8', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(71156000));
      setValue('field9', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(254));
      setValue('field10', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1517000000));
      setValue('field11', '10');
      setValue('field12', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(151700000));
      setValue('field13', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1668700000));
      setValue('field14', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(16615000));
      setValue('field20', '2024-10-10');
    }
    const tempDataSource = [];
    for (let i = 0; i < 10; i++) {
      tempDataSource.push({
        id: i + 1,
        key: i + 1,
        columns12: 1,
        columns22: 2,
        columns13: i,
        columns14: 9,
        columns24: 1,
        columns15: 2,
        columns25: 1,
        columns26: 2,
        columns17: '備考' + (i + 1),
      });
    }
    const newCurData = [];
    for (let i = 0; i < tempDataSource.length; i++) {
      newCurData.push(tempDataSource[i]);
      newCurData.push(tempDataSource[i]);
    }
    setDataSource(newCurData);
    const tempData = [];
    for (let i = 0; i < 6; i++) {
      tempData.push({
        id: i + 1,
        conditionName: 'columns12' + (i + 1),
        percentage: 'columns22' + (i + 1),
      });
    }
    setData(tempData);

    setPageTitle('見積書作成');
    return () => setPageTitle('');
  }, []);

  // 新しい行を追加
  const addRow = () => {
    const newKey = `${data.length + 1}`;
    setData([...data, { id: newKey, conditionName: '', percentage: '' }]);
    setTimeout(() => {
      if (gridRef.current?.api) {
        const lastRowIndex = gridRef.current.api.getDisplayedRowCount() - 1;
        gridRef.current.api.ensureIndexVisible(lastRowIndex, 'bottom');
      }
    }, 100);
  };

  // 保存
  const onFinish = record => {
    // notify('正常に保存されました');
    if (stare === 'webD') {
      navigate(`/webD0030/${type}/${id}`);
    } else {
      navigate(`/webC0030/${type}/${id}`);
    }
  };
  // クリア
  const onClear = record => {
    if (id) {
      setValue('field1', editData.ankenCode);
      setValue('field2', '00');
      setValue('ankenCode', editData.ankenCode);
      setValue('name6', 'N202408');
      setValue('name2', '墨田区太平2丁目計画');
      setValue('name3', 'すみだくたいへいちょうめけいかく');
      setValue('name122', '10001');
      setValue('name1', '大東建設株式会社');
      setValue('field4', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1351254000));
      setValue('field5', '7.00');
      setValue('field6', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(94590000));
      setValue('field7', '5.26');
      setValue('field8', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(71156000));
      setValue('field9', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(254));
      setValue('field10', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1517000000));
      setValue('field11', '10');
      setValue('field12', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(151700000));
      setValue('field13', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1668700000));
      setValue('field14', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(16615000));
      setValue('field20', '2024-10-10');
    }
    const tempDataSource = [];
    for (let i = 0; i < 10; i++) {
      tempDataSource.push({
        id: i + 1,
        key: i + 1,
        columns12: 1,
        columns22: 2,
        columns13: i,
        columns14: 9,
        columns24: 1,
        columns15: 2,
        columns25: 1,
        columns26: 2,
        columns17: '備考' + (i + 1),
      });
    }
    const newCurData = [];
    for (let i = 0; i < tempDataSource.length; i++) {
      newCurData.push(tempDataSource[i]);
      newCurData.push(tempDataSource[i]);
    }
    setDataSource(newCurData);
    const tempData = [];
    for (let i = 0; i < 6; i++) {
      tempData.push({
        id: i + 1,
        conditionName: 'columns12' + (i + 1),
        percentage: 'columns22' + (i + 1),
      });
    }
    setData(tempData);
  };

  // 削除
  const onDelete = record => {
    // notify('該当データを削除します。よろしいでしょうか？', 'warning');
    if (stare === 'webD') {
      navigate(`/webD0030/${type}/${id}`);
    } else {
      navigate(`/webC0030/${type}/${id}`);
    }
    // notify('正常に削除されました');
  };

  // キャンセル
  const onCancel = record => {
    if (stare === 'webD') {
      navigate(`/webD0030/${type}/${id}`);
    } else {
      navigate(`/webC0030/${type}/${id}`);
    }
    // notify('未保存の編集内容を破棄して呼び出し元の画面に遷移します。よろしいでしょうか？', 'warning');
    // navigate('/contractList');
  };

  const formatCurrency = (value: string, name: string) => {
    const numericValue = value.replace(/[^\d.-]/g, '');
    if (name === 'field4') {
      return setValue('field4', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field6') {
      return setValue('field6', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field8') {
      return setValue('field8', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field9') {
      return setValue('field9', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field10') {
      return setValue('field10', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field12') {
      return setValue('field12', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field13') {
      return setValue('field13', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else if (name === 'field14') {
      return setValue('field14', new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(Number(numericValue)));
    } else {
      return null;
    }
  };

  return (
    <div>
      <DialogContent className="webE0010-container">
        <Box flex={3} mr={2} display="flex">
          <Box flex={4} mr={2}>
            <div style={{ fontSize: '26px', border: '2px solid black', textAlign: 'center', width: '100%', backgroundColor: '#EF7373' }}>
              {titleName}
            </div>
          </Box>
          <Box flex={4} mr={2}>
            <div className="top">
              <div className="top-item">
                <LastUpdateInfo userId={''} />
                <LastUpdateInfo userId={''} title="【承認者】" />
              </div>
              <div className="top-item">
                <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
                <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
              </div>
            </div>
          </Box>
        </Box>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onFinish}>
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              申請
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onClear}>
              クリア
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onDelete}>
              削除
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCancel}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              印刷
            </Button>
          </div>
        </div>
        <form>
          <Box display="flex" flexDirection="column" gap={2} className="ad-search-estimate">
            {/*  積算/精積算コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box className="ad-search-item" flex={2} mr={2}>
                {/* <Box> */}
                <Box flex={4}>
                  <Controller
                    name="field1"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>{field1titleName}</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field2"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label>-</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="ankenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item" style={{ width: '60%' }}>
                        <label>案件コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  見積書コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="name6"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>見積書コード</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <LocalizationProvider
                    dateAdapter={AdapterDayjs}
                    adapterLocale="ja"
                    localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                  >
                    <Controller
                      name="field20"
                      control={control}
                      rules={{ required: '見積日付が入力されていません。' }}
                      render={({ field, fieldState }) => (
                        <div className="ad-search-item cell-date-picker" style={{ width: '60%', height: 40 }}>
                          <label>見積日付</label>
                          <DatePicker
                            label=""
                            {...field}
                            disableFuture={!!fieldState.error}
                            sx={{
                              width: '100%',
                              textAlignLast: 'end',
                              height: '40px',
                            }}
                            format="YYYY年MM月DD日"
                            value={field.value ? dayjs(field.value) : null}
                          />
                        </div>
                      )}
                    />
                  </LocalizationProvider>
                </Box>
              </Box>
            </Box>
            {/*  見積書名*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="name2"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>見積名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="name3"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>見積カナ名</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  顧客コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="name122"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>顧客コード</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="name1"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>顧客名</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  純工事費計*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="field4"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>純工事費計</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        onChange={e => formatCurrency(e.target.value, 'field4')}
                        sx={{
                          width: '100%',
                          textAlignLast: 'end',
                        }}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between"></Box>
            </Box>
            {/*  工事経費*/}
            <Box display="flex" justifyContent="space-between">
              <Box className="ad-search-item" flex={2} mr={2}>
                <Box flex={3}>
                  <Controller
                    name="field5"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>工事経費</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={3}>
                  <Controller
                    name="field6"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label>%</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          onChange={e => formatCurrency(e.target.value, 'field4')}
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={3}></Box>
            </Box>
            {/*  販売管理費*/}
            <Box display="flex" justifyContent="space-between">
              <Box className="ad-search-item" flex={2} mr={2}>
                <Box flex={3}>
                  <Controller
                    name="field7"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>販売管理費</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={3}>
                  <Controller
                    name="field8"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label>%</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          onChange={e => formatCurrency(e.target.value, 'field4')}
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="field9"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item" style={{ width: '50%' }}>
                        <label>調整金額</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          onChange={e => formatCurrency(e.target.value, 'field4')}
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  見積金額（税抜）*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="field10"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>見積金額（税抜）</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        onChange={e => formatCurrency(e.target.value, 'field4')}
                        sx={{
                          width: '100%',
                          textAlignLast: 'end',
                        }}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3} display="flex" justifyContent="space-between">
                <Box flex={3}>
                  <Controller
                    name="field11"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>消費税率</label>
                        <TextField
                          {...field}
                          fullWidth
                          size="small"
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                        <span style={{ width: '20px', paddingTop: '12px', paddingLeft: '20px' }}>%</span>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={5}>
                  <Controller
                    name="field12"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>消費税額</label>
                        <TextField
                          {...field}
                          fullWidth
                          onChange={e => formatCurrency(e.target.value, 'field4')}
                          size="small"
                          sx={{
                            width: '100%',
                            textAlignLast: 'end',
                          }}
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  見積金額（税込）*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="field13"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>見積金額（税込）</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        onChange={e => formatCurrency(e.target.value, 'field4')}
                        sx={{
                          width: '100%',
                          textAlignLast: 'end',
                        }}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
            {/*  粗利益金額*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} mr={2}>
                <Controller
                  name="field14"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>粗利益金額</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        onChange={e => formatCurrency(e.target.value, 'field4')}
                        sx={{
                          width: '100%',
                          textAlignLast: 'end',
                        }}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
            <div className="ad-search-item">
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <label>見積条件</label>
                <label
                  onClick={() => {
                    addRow();
                  }}
                >
                  <AddCircleOutlineIcon></AddCircleOutlineIcon>
                </label>
              </div>
              <div className="ag-theme-alpine" style={{ width: '70%' }}>
                <AgGridReact
                  ref={gridRef}
                  rowData={data}
                  theme={AGGridTheme}
                  columnDefs={columnDefs.current}
                  headerHeight={30}
                  rowHeight={30}
                  defaultColDef={defaultColDef}
                  domLayout="autoHeight"
                />
              </div>
            </div>
            {/* 先行作業内諾書表格 */}
            <div className="ag-theme-alpine" style={{ width: '100%', height: '421px' }}>
              <AgGridReact
                rowData={dataSource}
                theme={AGGridTheme}
                columnDefs={table1ColumnDefs.current}
                defaultColDef={defaultColDef}
                headerHeight={30}
                rowHeight={30}
                enableCellSpan
                animateRows={false}
              />
            </div>
          </Box>
        </form>
      </DialogContent>
    </div>
  );
};

export default WebE0010;
