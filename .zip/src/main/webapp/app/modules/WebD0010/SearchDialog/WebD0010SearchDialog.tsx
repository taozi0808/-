import React, { useState } from 'react';
import { Dialog, DialogActions, DialogContent, FormControlLabel, Checkbox, Button, Select, MenuItem, Box, TextField } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebD0010SearchDialog.scss';

const WebD0010SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const { control, handleSubmit, setValue } = useForm({
    defaultValues: {
      field1: '',
      field2: '',
      field3: '',
      field4: '',
      field5: '',
      field6: '',
      fieldCheck: false,
    },
  });

  const onSubmit = data => {
    onSearch(data);
    handleClose();
  };

  const handleChange = (e: any, field: any) => {
    setValue(field.name, e.target.value);
  };

  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} maxWidth="lg" style={{ margin: '20px' }}>
        <DialogHead closeOnClick={handleClose} />
        <DialogContent className="webD0010-background-color">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: '104px' }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="webD0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="field1"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>案件コード/案件名</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field2"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>顧客コード/顧客名</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="field3"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>概算コード</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field4"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>精積算部門</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" justifyContent="flex-start">
                <Box flex={1} mr={2}>
                  <Controller
                    name="field5"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>精積算コード</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field6"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <div style={{ display: 'inline-block', width: '150px', textAlign: 'center' }}>
                          <label>精積算担当者</label>
                        </div>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" justifyContent="flex-start">
                <Box flex={1} mr={2}></Box>
                <Box flex={1} style={{ marginLeft: '56px', marginRight: '0' }}>
                  <Controller
                    name="fieldCheck"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel
                        control={<Checkbox {...field} checked={field.value} onChange={(e: any) => handleChange(e, field)} />}
                        label=""
                      />
                    )}
                  />
                  <label style={{ fontSize: '12px' }}>精積算作成済の案件を表示する。</label>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebD0010SearchDialog;
