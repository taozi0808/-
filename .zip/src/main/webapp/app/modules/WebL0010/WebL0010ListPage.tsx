import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@mui/material';
import WebL0010SearchDialog from './SearchDialog/WebL0010SearchDialog';
import { DBManager, STORAGE_KEY_SEIKYUSYO, seikyushoDataList } from 'app/shared/util/construction-list';
import { useNavigate } from 'react-router-dom';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { Column, FieldType } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import dayjs from 'dayjs';
import './WebL0010ListPage.scss';

const WebL0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const [selectedId, setSelectedId] = useState('');
  const navigate = useNavigate();
  const onSelectedRowsChanged = (id: string) => {
    setSelectedId(id ? id : '');
  };
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集権限
    hensyuuKengen: true,
    // 参照権限
    sansyouKengen: true,
  });
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'bukkenCode',
      name: '物件コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 100,
      type: FieldType.string,
    },
    {
      id: 'bukkenName',
      name: '物件名',
      field: 'bukkenName',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 130,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'bukkenChakushuDate',
      name: '物件着手日',
      field: 'bukkenChakushuDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'bukkenHikiwatashiDate',
      name: '物件引渡日',
      field: 'bukkenHikiwatashiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'seikyushoNo',
      name: '請求書No',
      field: 'seikyushoNo',
      minWidth: 135,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'shiharaiJyoken',
      name: '支払条件',
      field: 'shiharaiJyoken',
      minWidth: 135,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'seikyuDate',
      name: '請求年月',
      field: 'seikyuDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'ukeoiKingaku',
      name: '請負金額',
      field: 'ukeoiKingakuZeikomi',
      minWidth: 135,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'seikyuzumiKingaku',
      name: '請求済金額',
      field: 'seikyuzumiKingaku',
      minWidth: 135,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'konkaiSeikyuKingaku',
      name: '今回請求金額',
      field: 'konkaiSeikyuKingaku',
      minWidth: 135,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'miseikyuZan',
      name: '未請求残',
      field: 'miseikyuZan',
      minWidth: 135,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const handleSearch = values => {
    // 仮データ作成
    let mockDataList = DBManager.getMockList(STORAGE_KEY_SEIKYUSYO);
    if (mockDataList.length === 0) {
      mockDataList = seikyushoDataList(500);
      // 番号作成
      mockDataList = mockDataList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SEIKYUSYO, JSON.stringify(mockDataList));
    }
    setRowData(mockDataList);
  };
  useEffect(() => {
    handleSearch('');
    setPageTitle('請求書一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="seikyuukanri-list">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webL0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webL0030/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebL0010SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                // navigate(`/webL0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                // navigate(`/webL0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebL0010ListPage;
