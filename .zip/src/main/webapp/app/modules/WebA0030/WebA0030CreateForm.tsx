import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import { Button, TextField, Box, Snackbar, Alert, InputAdornment, IconButton } from '@mui/material';
import './WebA0030CreateForm.scss';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';

const WebA0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [showPassword, setShowPassword] = useState(false);
  const [showPassword1, setShowPassword1] = useState(false);
  const [showPassword2, setShowPassword2] = useState(false);

  const {
    control,
    // handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    defaultValues: {
      password: '',
      password1: '',
      password2: '',
    },
    mode: 'onBlur',
  });

  // 保存
  const onFinish = values => {
    // notify('正常に保存されました');
    navigate(-1);
  };
  useEffect(() => {
    // タイトル
    setPageTitle('個人設定');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webA0030-container">
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit">
              保存
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(-1);
              }}
            >
              戻る
            </Button>
          </div>
        </div>
        <Box component="form" onSubmit={onFinish} display="flex" flexDirection="column" gap={2} className="ad-search-seisekisan">
          {/*  案件コード/案件名 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <label>既存のパスワード</label>
              <TextField
                required
                fullWidth
                size="small"
                name="password"
                type={showPassword ? 'text' : 'password'}
                id="password"
                autoComplete="current-password"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                        {showPassword ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
            <Box flex={2} mr={2} className="ad-search-item"></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <label>新規パスワード</label>
              <TextField
                required
                fullWidth
                size="small"
                name="password1"
                type={showPassword1 ? 'text' : 'password'}
                id="password1"
                autoComplete="current-password"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword1(!showPassword1)} edge="end">
                        {showPassword1 ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
            <Box flex={2} mr={2} className="ad-search-item"></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <label>新規パスワード（確認）</label>
              <TextField
                required
                fullWidth
                size="small"
                name="password2"
                type={showPassword2 ? 'text' : 'password'}
                id="password2"
                autoComplete="current-password"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword2(!showPassword2)} edge="end">
                        {showPassword2 ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
            <Box flex={2} mr={2} className="ad-search-item"></Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebA0030CreateForm;
