/** 定义表单各字段的数据类型 */
export interface SateiTourokuFormValues {
  genbaCode: string;
  genbaName: string;
  genbaCanaName: string;
  koujiKoutei: string;
  genbaChakushuNichi: string;
  genbaBikiWataruNichi: string;
  jikkouYosanKingaku: string;
  hatchuuKingaku: string;
  miHatchuuKingaku: string;
  zengetsuMadeSateiKingaku: string;
  zengetsuSateiKingaku: string;
  sateiSayamaGoukeiKingaku: string;
  miSateiZan: string;
  zentaiShinchokuRitsu: string;
  miSateiZan1: string;
  sateiShouninNichi: string;
  meisaiHyoji: string;
}
