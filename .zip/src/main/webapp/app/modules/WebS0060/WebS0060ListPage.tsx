import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0060ListPage.scss';
import dayjs from 'dayjs';
import { STORAGE_KEY_SHONIN_BAKEIHI, DBManager, genbaKeihiDataList } from 'app/shared/util/construction-list';
import WebS0060SearchDialog from './SearchDialog/WebS0060SearchDialog';
import { Column, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const WebS0060ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  // 選択行
  const [selectedId, setSelectedId] = useState('');
  const LinkFormatter: Formatter = (_, __, value) => {
    return value ? `<a style="text-decoration: underline">あり</a>` : '';
  };
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      sortable: true,
      filterable: true,
      minWidth: 150,
      cssClass: 'left',
    },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      minWidth: 300,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'genbaChakushuDate',
      name: '現場着手日',
      field: 'genbaChakushuDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'genbahikiwatashiDate',
      name: '現場引渡日',
      field: 'genbahikiwatashiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 70,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 検索イベント
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    let contractList = DBManager.getShoninBakeihiDataList();
    if (contractList.length === 0) {
      contractList = genbaKeihiDataList(500);
      localStorage.setItem(STORAGE_KEY_SHONIN_BAKEIHI, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  useEffect(() => {
    setPageTitle('承認一覧（現場経費管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0060-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            <WebS0060SearchDialog onSearch={handleSearch} />
          </div>
        </div>
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webM0020/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0060ListPage;
