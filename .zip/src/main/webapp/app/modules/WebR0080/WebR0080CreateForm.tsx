import { Box, Button, FormControlLabel, MenuItem, Radio, RadioGroup, Select } from '@mui/material';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import React, { useState, FC, useEffect, useRef, useMemo, useCallback, StrictMode } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebR0080CreateForm.scss';
import { Controller, useForm } from 'react-hook-form';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import {
  ColDef,
  ColGroupDef,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);

/**
 * Web-R-0080
 * 単価登録
 */
const WebR0080CreateForm: FC = () => {
  const navigate = useNavigate();
  const { control, handleSubmit, watch } = useForm();
  const [data, setData] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState<number>(0); // 用于跟踪选中的地域

  const defaultColDef = useMemo(() => {
    return {
      // flex: 1,
      editable: true,
    };
  }, []);

  const largeConstructions = [
    { label: '工事1', value: 0 },
    { label: '工事2', value: 1 },
    { label: '工事3', value: 2 },
    { label: '工事4', value: 3 },
    { label: '工事5', value: 4 },
    { label: '工事6', value: 5 },
    { label: '工事7', value: 6 },
    { label: '工事8', value: 7 },
    { label: '工事9', value: 8 },
    { label: '工事10', value: 9 },
  ];

  const smallOccupations = [
    { label: '工種1', value: 0 },
    { label: '工種2', value: 1 },
    { label: '工種3', value: 2 },
    { label: '工種4', value: 3 },
    { label: '工種5', value: 4 },
    { label: '工種6', value: 5 },
    { label: '工種7', value: 6 },
    { label: '工種8', value: 7 },
    { label: '工種9', value: 8 },
    { label: '工種10', value: 9 },
  ];
  const units = [
    { label: 'kg', value: 1 },
    { label: '式', value: 2 },
    { label: '箱', value: 3 },
  ];

  const requestColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '',
      field: 'key',
      width: 50,
      cellEditor: 'agTextCellEditor',
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
      valueFormatter: params => {
        if (params.data.key === '0') {
          return '-';
        } else {
          return '';
        }
      },
    },
    {
      headerName: 'コード',
      field: 'conditionName',
      width: 110,
      cellEditor: 'agTextCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
    {
      headerName: '大工事',
      field: 'percentage',
      width: 190,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: largeConstructions.map(opt => opt.value),
      },
      valueFormatter: params => {
        const option = largeConstructions.find(opt => opt.value === params.value);
        return option.label;
      },
      valueParser: params => {
        return params.newValue;
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
    {
      headerName: '小工種',
      field: 'requestAmount',
      width: 190,
      cellEditor: 'agSelectCellEditor',
      sortable: false,
      cellEditorParams: {
        values: smallOccupations.map(opt => opt.value),
      },
      valueFormatter: params => {
        const option = smallOccupations.find(opt => opt.value === params.value);
        return option.label;
      },
      valueParser: params => {
        return params.newValue;
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
    {
      headerName: '規格',
      field: 'taxRate',
      width: 190,
      cellEditor: 'agTextCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
    {
      headerName: '単価',
      field: 'taxAmount',
      width: 100,
      cellEditor: 'agTextCellEditor',
      cellClass: 'center-cell',
      cellEditorParams: {
        maxLength: 20,
      },
      valueFormatter: params => {
        return Intl.NumberFormat('en-US', {
          // style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        }).format(params.data.taxAmount);
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
    {
      headerName: '単位',
      field: 'totalAmount',
      width: 100,
      cellEditor: 'agSelectCellEditor',
      spanRows: true,
      sortable: false,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      cellEditorParams: {
        values: units.map(opt => opt.value),
      },
      valueFormatter: params => {
        const option = units.find(opt => opt.value === params.value);
        return option.label;
      },
      valueParser: params => {
        return params.newValue;
      },
      cellStyle: params => {
        if (params.data.key === '0') {
          return { backgroundColor: 'green' };
        }
        return null;
      },
    },
  ]);

  // 监听地域名的变化
  const chiikiMei = watch('chiikiMei');

  useEffect(() => {
    setSelectedRegion(chiikiMei);
  }, [chiikiMei]);

  // 画面名
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    const tempData = [];
    for (let i = 0; i < 10; i++) {
      if (i === 0) {
        tempData.push({
          id: i + 1,
          conditionName: '000' + (i + 1) + '00' + i + '0' + (i + 1),
          requestAmount: i,
          percentage: i,
          taxRate: '0' + (i + 1),
          taxAmount: 1001 + i,
          totalAmount: 1,
          key: '0',
        });
      } else {
        tempData.push({
          id: i + 1,
          conditionName: '000' + (i + 1) + '00' + i + '0' + (i + 1),
          requestAmount: i,
          percentage: i,
          taxRate: '0' + (i + 1),
          taxAmount: 1001 + i,
          totalAmount: 1,
          key: '1',
        });
      }
    }
    setData(tempData);
    setPageTitle('単価登録');
    return () => setPageTitle('');
  }, []);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.name === 'riyouKinouKubun') {
      event.target.value = '';
    }
  };

  // 保存
  const onSave = values => {
    navigate('/webR0080');
  };

  // 印刷
  const onPrint = values => {
    navigate('/webR0080');
  };

  // CSV出力
  const onCsv = () => {
    navigate('/webR0080');
  };

  // 地域コピーボタン
  const onCopy = () => {
    navigate('/webR0080');
  };

  // 大工事追加ボタン
  const onAdd = () => {
    navigate('/webR0080');
  };

  const getRowStyle = (params: any) => {
    if (params.data.gyoushaCode === '0') {
      return { backgroundColor: 'green' };
    }
    return null;
  };

  return (
    <div>
      <div className="webr0080-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onSave}>
              保存
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onPrint}>
              印刷
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCsv}>
              CSV出力
            </Button>
          </div>
        </div>
        <form>
          <Box className="box-class">
            {/* 利用機能 */}
            <Box className="box-row-class">
              <Box flex={1} className="box-col1-class">
                <Controller
                  name="riyouKinouKubun"
                  control={control}
                  render={({ field }) => (
                    <div className="box-col1-class">
                      <label style={{ paddingTop: '4px' }}>利用機能</label>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange}>
                        <FormControlLabel value={0} control={<Radio />} label="概算" />
                        <FormControlLabel value={1} control={<Radio />} label="精積算" />
                      </RadioGroup>
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/* 地域名 */}
            <Box className="box-row-class">
              <Box flex={2} className="box-col1-class">
                <Controller
                  name="chiikiMei"
                  control={control}
                  render={({ field }) => (
                    <div className="box-col1-class">
                      <label>地域名</label>
                      <Select {...field} size="small" style={{ width: '220px' }}>
                        <MenuItem value={0}></MenuItem>
                        <MenuItem value={1}>本社</MenuItem>
                        <MenuItem value={2}>東京</MenuItem>
                        <MenuItem value={3}>千葉</MenuItem>
                        <MenuItem value={4}>神奈川</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={5}></Box>
            </Box>
            {/* コピー元地域名 */}
            {selectedRegion !== 1 && (
              <Box className="box-row-class">
                <Box flex={2} className="box-col1-class">
                  <Controller
                    name="copyChiikiMei"
                    control={control}
                    render={({ field }) => (
                      <div className="box-col1-class">
                        <Select {...field} size="small" style={{ width: '220px' }}>
                          <MenuItem value={0}></MenuItem>
                          <MenuItem value={2}>東京</MenuItem>
                          <MenuItem value={3}>千葉</MenuItem>
                          <MenuItem value={4}>神奈川</MenuItem>
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} className="box-col2-class">
                  <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96, left: '24px' }} onClick={onCopy}>
                    地域コピー
                  </Button>
                </Box>
                <Box flex={4}></Box>
              </Box>
            )}
            {/* 大工事追加 */}
            {selectedRegion === 1 && (
              <Box className="box-row-class">
                <Box flex={1} className="box-col1-class">
                  <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96, left: '24px' }} onClick={onAdd}>
                    大工事追加
                  </Button>
                </Box>
                <Box flex={6}></Box>
              </Box>
            )}
          </Box>
          <Box display="flex" justifyContent="space-between" mt={2}>
            <Box flex={1} mr={2} className="ag-theme-alpine" style={{ width: '100%', height: '260px' }}>
              <AgGridReact
                rowData={data}
                theme={AGGridTheme}
                columnDefs={requestColumns.current}
                defaultColDef={defaultColDef}
                getRowStyle={getRowStyle}
              />
            </Box>
          </Box>
        </form>
      </div>
    </div>
  );
};

export default WebR0080CreateForm;
