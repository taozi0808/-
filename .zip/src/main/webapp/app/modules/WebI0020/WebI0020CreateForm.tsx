// import React, { FC, useEffect, useRef, useState, useCallback } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';
// import { useForm, Controller } from 'react-hook-form';
// import { DialogContent, TextField, Button, Box, IconButton } from '@mui/material';
// import { ColDef } from 'ag-grid-community';
// import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
// import { AgGridReact } from 'ag-grid-react';
// import { AGGridTheme } from 'app/app';
// import './WebI0020CreateForm.scss';
// import InputLabel from '@mui/material/InputLabel';
// import CustomHeader from './CustomeHeader/CustomHeader';
// import CustomSplitHeader from './CustomeHeader/CustomSplitHeader';
// import SplitFormatCellRender from './CustomeCellRender/SplitFormatCellRender';
// import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
// import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
// import { displayFormatCurrentDate } from '../../shared/util/date-utils';

// const WebI0020CreateForm: FC = () => {
//   const { id, type } = useParams();
//   const navigate = useNavigate();
//   const { setPageTitle } = usePageTitleStore();
//   const [startDate, setStartDate] = useState(displayFormatCurrentDate('YYYY-MM'));
//   const [isDisabledLeft, setIsDisableLeft] = useState(false);
//   const [isDisabledRight, setIsDisabledRight] = useState(false);
//   const tempCount = useRef(0);

//   const {
//     control,
//     handleSubmit,
//     formState: { errors },
//     setError,
//     setValue,
//   } = useForm({
//     defaultValues: {
//       siteCode: '000001-000-01',
//       date: '2025年5月2日',
//       siteName: '〇〇ビル建設工事',
//       siteTypeName: 'マルマルビルケンセツコウジ',
//       startDate: '上棟検査',
//       endDate: '2025年3月31日',
//       saleAmountUp: '498,746,291',
//       saleAmountDown: '411,746,291',
//     },
//     mode: 'onBlur',
//   });

//   useEffect(() => {
//     setPageTitle('出来高シュミレーション登録');
//     return () => setPageTitle('');
//   }, [setPageTitle]);

//   const compareYearAndMonth = inputYM => {
//     const [yearStr, monthStr] = inputYM.replace('年', '-').replace('月', '').split('-');
//     const inputYear = parseInt(yearStr, 10);
//     const inputMonth = parseInt(monthStr, 10);

//     const currentDate = new Date();
//     const currentYear = currentDate.getFullYear();
//     const currentMonth = currentDate.getMonth() + 1;

//     if (inputYear > currentYear) {
//       return false;
//     } else if (inputYear === currentYear) {
//       return inputMonth < currentMonth;
//     }
//     return true;
//   };

//   const handleValueUpdate = useCallback((rowId: any, field: string, newValue: number) => {
//     setRowData(prev => {
//       const newData = [...prev];
//       newData.find(data => data.id === rowId)[field] = newValue;
//       return newData;
//     });
//   }, []);

//   /** テンポラリメソッド */
//   const tempGenerateColumnObject = () => {
//     const generateNumber = () => {
//       return Math.floor(Math.random() * 900000) + 100000;
//     };

//     const result = {};

//     for (let col = 1; col <= 18; col++) {
//       const upKey = `col${col}up`;
//       const downKey = `col${col}down`;

//       result[upKey] = Math.random() > 0.5 ? generateNumber() : '';
//       result[downKey] = '';
//     }

//     return result;
//   };

//   const generateMonths = () => {
//     const months = [];
//     const date = new Date(2025, 0);
//     for (let i = 0; i < 18; i++) {
//       months.push(`${date.getFullYear()}年${date.getMonth() + 1}月`);
//       date.setMonth(date.getMonth() + 1);
//     }
//     return months;
//   };

//   const generateAllColumnConfigs = () => {
//     const months = generateMonths();
//     const allConfigs = [];
//     for (let col = 1; col <= 18; col++) {
//       const displayName = months[col - 1];
//       const config = {
//         field: `col${col}`,
//         headerComponent: CustomHeader,
//         headerComponentParams: {
//           displayName: displayName,
//           type: 'default',
//         },
//         cellRenderer: SplitFormatCellRender,
//         cellStyle: { padding: 0 },
//         cellRendererParams: {
//           keys: [`col${col}up`, `col${col}down`],
//           upperType: 'span',
//           lowerType: data => (data[`col${col}up`] ? 'input' : 'span'),
//           prefix: '￥',
//           upFormat: 'currency',
//           downFormat: 'currency',
//           lessThanCurrentMonth: compareYearAndMonth(displayName),
//           onValueChange: handleValueUpdate,
//         },
//         width: 120,
//       };
//       allConfigs.push(config);
//     }
//     return allConfigs;
//   };

//   const getColumnsStartingFrom = (sDate: string) => {
//     const [yearStr, monthStr] = sDate.split('-');
//     const year = parseInt(yearStr, 10);
//     const month = parseInt(monthStr, 10);

//     const startCol = (year - 2025) * 12 + month;
//     if (startCol < 1 || startCol > 16) return [];

//     const allConfigs = generateAllColumnConfigs();
//     const startIndex = startCol - 1;
//     const endIndex = Math.min(startCol + 11, 16) - 1;
//     const filteredConfigs = allConfigs.slice(startIndex, endIndex + 1);

//     filteredConfigs.forEach((config, index) => {
//       const displayOrder = index + 1;

//       config.headerComponentParams.type = displayOrder % 6 === 1 ? 'left' : displayOrder % 6 === 0 ? 'right' : 'default';

//       if (displayOrder === 3) {
//         config.headerComponentParams.firstName = '2025年度工期（上半期）';
//         config.headerComponentParams.lastName = '金額';
//       } else if (displayOrder === 9) {
//         config.headerComponentParams.firstName = '2025年度工期（下半期）';
//         config.headerComponentParams.lastName = '金額';
//       }

//       config.cellRendererParams.isFirst = index === 0;
//     });

//     return filteredConfigs;
//   };

//   const [rowData, setRowData] = useState([
//     {
//       ...{
//         id: 1,
//         field1up: '共通仮設工事',
//         field1down: '2025年4月~2025年5月',
//         field2up: '12345',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 2,
//         field1up: '直接仮設工事',
//         field1down: '2025年5月~2025年8月',
//         field2up: '2234',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 3,
//         field1up: '共同贩卖工事3',
//         field1down: '2025年6月~2025年7月',
//         field2up: '4234',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 4,
//         field1up: '土工事',
//         field1down: '2025年7月~2025年8月',
//         field2up: '2234',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 5,
//         field1up: '杭地業工事',
//         field1down: '2025年8月~2025年9月',
//         field2up: '2234',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 6,
//         field1up: 'コンクリート工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '2234',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 7,
//         field1up: '型枠工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '2242334',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 8,
//         field1up: '鉄筋工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '131186',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 9,
//         field1up: '防水工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '14012',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 10,
//         field1up: '石タイル工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '44424',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 11,
//         field1up: '木工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '675840',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 12,
//         field1up: '金属工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '3242334',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 13,
//         field1up: '左官工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '4323543',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 14,
//         field1up: '塗装工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '23523435',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//     {
//       ...{
//         id: 15,
//         field1up: '電気設備工事',
//         field1down: '2025年9月~2025年10月',
//         field2up: '874154',
//         field2down: '-',
//         field3up: '実績',
//         field3down: '調整',
//       },
//       ...tempGenerateColumnObject(),
//     },
//   ]);

//   const [columnDefs, setColumnDefs] = useState<ColDef[]>([]);

//   useEffect(() => {
//     const generatedColumns = getColumnsStartingFrom(startDate);
//     const column = [
//       {
//         field: '',
//         headerName: '予算項目/該当工期',
//         headerClass: 'default-header-border-right',
//         cellRenderer: SplitFormatCellRender,
//         cellStyle: { padding: 0 },
//         cellRendererParams: {
//           keys: ['field1up', 'field1down'],
//         },
//       },
//       {
//         field: 'field2',
//         headerName: '',
//         headerComponent: CustomSplitHeader,
//         headerComponentParams: {
//           upperText: '実行予算',
//           lowerText: '差額',
//         },
//         headerClass: 'default-header-border-right',
//         cellRenderer: SplitFormatCellRender,
//         cellStyle: { padding: 0 },
//         cellRendererParams: {
//           keys: ['field2up', 'field2down'],
//           prefix: '￥',
//           upFormat: 'currency',
//           lowerStyle: { textAlign: 'left' },
//           defaultValue: '-',
//         },
//         width: 140,
//       },
//       {
//         field: 'field3',
//         headerName: '',
//         headerComponent: CustomSplitHeader,
//         headerComponentParams: {
//           upperText: '',
//           lowerText: '',
//         },
//         headerClass: 'default-header-border-right',
//         cellRenderer: SplitFormatCellRender,
//         cellStyle: { padding: 0 },
//         cellRendererParams: {
//           keys: ['field3up', 'field3down'],
//         },
//         width: 80,
//       },
//       ...generatedColumns,
//     ];
//     setColumnDefs(column);
//   }, [startDate]);

//   const shiftMonths = (direction: 'left' | 'right') => {
//     const [yearStr, monthStr] = startDate.split('-');
//     let year = parseInt(yearStr, 10);
//     let month = parseInt(monthStr, 10);

//     if (direction === 'left') {
//       month -= 1;
//       tempCount.current -= 1;

//       if (month < 1) {
//         year -= 1;
//         month = 12;
//       }
//     } else {
//       tempCount.current += 1;

//       month += 1;
//       if (month > 12) {
//         year += 1;
//         month = 1;
//       }
//     }
//     if (tempCount.current <= -3) {
//       setIsDisableLeft(true);
//     } else {
//       setIsDisableLeft(false);
//     }
//     if (tempCount.current >= 3) {
//       setIsDisabledRight(true);
//     } else {
//       setIsDisabledRight(false);
//     }

//     const newDate = `${year}-${month.toString().padStart(2, '0')}`;
//     setStartDate(newDate);
//   };

//   return (
//     <>
//       <DialogContent className="webI0020-container">
//         <div className="top-operation">
//           <div>
//             <Button
//               onClick={() => console.log(rowData)}
//               variant="contained"
//               size="small"
//               style={{ marginRight: '8px', minWidth: 120, height: 40 }}
//             >
//               保存
//             </Button>
//           </div>
//           <div style={{ marginRight: '12%' }}>
//             <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 120, height: 40 }}>
//               印刷
//             </Button>
//           </div>
//         </div>
//         <form>
//           <Box display="flex" flexDirection="column" gap={2} className="ad-search-estimate">
//             <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
//               <Box mr={2}>
//                 <Controller
//                   name="siteCode"
//                   control={control}
//                   render={({ field }) => (
//                     <div className="ad-search-item">
//                       <label>現場コード</label>
//                       <TextField {...field} size="small" sx={{ width: '300px' }} />
//                     </div>
//                   )}
//                 />
//               </Box>
//               <Box display="flex" justifyContent="space-between">
//                 <Box flex={1}>
//                   <Controller
//                     name="date"
//                     control={control}
//                     render={({ field }) => (
//                       <div className="ad-search-item">
//                         <label>日付</label>
//                         <TextField {...field} size="small" sx={{ width: '300px' }} />
//                       </div>
//                     )}
//                   />
//                 </Box>
//               </Box>
//             </Box>

//             <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
//               <Box mr={2}>
//                 <Controller
//                   name="siteName"
//                   control={control}
//                   render={({ field }) => (
//                     <div className="ad-search-item">
//                       <label>現場名</label>
//                       <TextField {...field} size="small" sx={{ width: '300px' }} />
//                     </div>
//                   )}
//                 />
//               </Box>
//               <Box display="flex" justifyContent="space-between">
//                 <Box flex={1}>
//                   <Controller
//                     name="siteTypeName"
//                     control={control}
//                     render={({ field }) => (
//                       <div className="ad-search-item">
//                         <label>現場カナ名</label>
//                         <TextField {...field} size="small" sx={{ width: '300px' }} />
//                       </div>
//                     )}
//                   />
//                 </Box>
//               </Box>
//             </Box>

//             <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
//               <Box mr={2}>
//                 <Controller
//                   name="startDate"
//                   control={control}
//                   render={({ field }) => (
//                     <div className="ad-search-item">
//                       <label>現場着工日</label>
//                       <TextField {...field} size="small" sx={{ width: '300px' }} />
//                     </div>
//                   )}
//                 />
//               </Box>
//               <Box display="flex" justifyContent="space-between">
//                 <Box flex={1}>
//                   <Controller
//                     name="endDate"
//                     control={control}
//                     render={({ field }) => (
//                       <div className="ad-search-item">
//                         <label>現場完工日</label>
//                         <TextField {...field} size="small" sx={{ width: '300px' }} />
//                       </div>
//                     )}
//                   />
//                 </Box>
//               </Box>
//             </Box>
//             <Box display="flex" sx={{ width: '60%', marginTop: '3%' }} justifyContent={'space-between'} alignItems={'end'}>
//               <Box mr={2}>
//                 <Controller
//                   name="saleAmountUp"
//                   control={control}
//                   render={({ field }) => (
//                     <div>
//                       <InputLabel sx={{ marginLeft: '24%', marginBottom: '2%' }}>2025年度(上半期)</InputLabel>
//                       <div className="ad-search-item">
//                         <label>売上高</label>
//                         <TextField {...field} size="small" sx={{ width: '240px' }} />
//                       </div>
//                     </div>
//                   )}
//                 />
//               </Box>
//               <Box display="flex" justifyContent="space-between">
//                 <Box flex={1}>
//                   <Controller
//                     name="saleAmountDown"
//                     control={control}
//                     render={({ field }) => (
//                       <div style={{ marginLeft: '-10%' }}>
//                         <InputLabel sx={{ marginLeft: '24%', marginBottom: '2%' }}>2025年度(下半期)</InputLabel>
//                         <div className="ad-search-item">
//                           <label>売上高</label>
//                           <TextField {...field} size="small" sx={{ width: '240px' }} />
//                         </div>
//                       </div>
//                     )}
//                   />
//                 </Box>
//               </Box>
//               <Box>
//                 <Button variant="contained" size="small" style={{ minWidth: 120, marginLeft: '7%', height: 40 }}>
//                   按分
//                 </Button>
//               </Box>
//             </Box>
//             <div className="ag-theme-alpine" style={{ width: '100%', height: '421px' }}>
//               <AgGridReact rowData={rowData} theme={AGGridTheme} columnDefs={columnDefs} headerHeight={90} rowHeight={60} />
//             </div>
//             <div style={{ display: 'flex', justifyContent: 'center' }}>
//               <IconButton
//                 size="small"
//                 onClick={() => {
//                   shiftMonths('left');
//                 }}
//                 disabled={isDisabledLeft}
//               >
//                 <KeyboardArrowLeftIcon />
//               </IconButton>
//               <IconButton
//                 size="small"
//                 onClick={() => {
//                   shiftMonths('right');
//                 }}
//                 disabled={isDisabledRight}
//               >
//                 <KeyboardArrowRightIcon />
//               </IconButton>
//             </div>
//           </Box>
//         </form>
//       </DialogContent>
//     </>
//   );
// };

// export default WebI0020CreateForm;
