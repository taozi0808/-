import React from 'react';
import type { IHeaderParams } from 'ag-grid-community';
import './CustomHeader.scss';

type HeaderType = 'left' | 'default' | 'right';

// eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
const CustomHeader: React.FC<IHeaderParams & any> = props => {
  const { type = 'default', firstName = '', lastName = '' } = props;

  return (
    <div className="custom-header">
      <div className={`custom-header-container ${type}-type`}>
        <div className="header-layer top-layer">
          <span className="header-text">{firstName}</span>
        </div>

        <div className="header-layer middle-layer">
          <span className="header-text">{props.displayName}</span>
        </div>

        <div className="header-layer bottom-layer">
          <span className="header-text" style={{ marginLeft: '80%' }}>
            {lastName}
          </span>
        </div>
      </div>
    </div>
  );
};

export default CustomHeader;
