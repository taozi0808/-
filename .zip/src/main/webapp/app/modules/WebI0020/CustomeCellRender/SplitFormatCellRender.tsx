// import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
// import { ICellRendererParams } from 'ag-grid-community';
// import './SplitFormatCellRender.scss';
// import { debounce } from 'lodash';

// interface SplitCellParams extends ICellRendererParams {
//   keys: any[];

//   upperStyle?: React.CSSProperties | ((param) => React.CSSProperties);
//   lowerStyle?: React.CSSProperties | ((param) => React.CSSProperties);

//   upperType?: 'span' | 'input' | ((param) => 'span' | 'input');
//   lowerType?: 'span' | 'input' | ((param) => 'span' | 'input');

//   prefix?: string;
//   upFormat?: 'currency' | 'percentage' | 'default';
//   downFormat?: 'currency' | 'percentage' | 'default';

//   lessThanCurrentMonth?: boolean;
//   onValueChange?: (id: any, key: string, rawValue: any) => void;
//   defaultValue: string;
// }

// const SplitFormatCellRender = forwardRef((props: SplitCellParams, ref) => {
//   const {
//     upperStyle,
//     lowerStyle,
//     upperType,
//     lowerType,
//     prefix,
//     upFormat,
//     downFormat,
//     keys,
//     lessThanCurrentMonth,
//     node,
//     onValueChange,
//     defaultValue = '',
//   } = props;
//   const id = node.data.id;

//   const formatDisplayValue = (value: any, format: string) => {
//     if (format === 'currency') {
//       if (!value) {
//         return prefix && defaultValue ? prefix + defaultValue : defaultValue;
//       } else {
//         const num = Number(value);
//         return prefix ? prefix + new Intl.NumberFormat().format(num) : new Intl.NumberFormat().format(num);
//       }
//     } else if (format === 'percentage') {
//       if (!value) {
//         return prefix && defaultValue ? prefix + defaultValue : defaultValue;
//       } else {
//         const num = Number(value);
//         return (num * 100).toFixed(2) + '%';
//       }
//     } else {
//       if (!value) {
//         return prefix && defaultValue ? prefix + defaultValue : defaultValue;
//       } else {
//         return prefix ? `${prefix}${value}` : value;
//       }
//     }
//   };

//   const parseRawValue = (displayValue: string, format: string) => {
//     if (!displayValue) return '';

//     if (format === 'currency') {
//       const value = displayValue.replaceAll(prefix, '').replaceAll(/[^0-9.]/g, '');
//       return parseFloat(value);
//     } else if (format === 'percentage') {
//       const value = displayValue.replaceAll(prefix, '').replaceAll(/[^0-9.]/g, '');
//       return parseFloat(value) / 100;
//     } else {
//       return displayValue;
//     }
//   };

//   const [displayValues, setDisplayValues] = useState({
//     upper: formatDisplayValue(node.data[keys[0]], upFormat),
//     lower: formatDisplayValue(node.data[keys[1]], downFormat),
//   });

//   const debouncedUpdate = useCallback(
//     debounce((key: string, displayValue: string) => {
//       const rawValue = parseRawValue(displayValue, key === keys[0] ? upFormat : downFormat);

//       onValueChange?.(id, key, rawValue);
//     }, 300),
//     [keys, upFormat, downFormat, onValueChange, props.api, props.column],
//   );

//   const handleValueChange = (key: string, displayValue: string) => {
//     setDisplayValues(prev => ({
//       ...prev,
//       [key === keys[0] ? 'upper' : 'lower']: displayValue,
//     }));

//     debouncedUpdate(key, displayValue);
//   };

//   useEffect(() => {
//     return () => {
//       debouncedUpdate.cancel();
//     };
//   }, [debouncedUpdate]);

//   const renderContent = (type: 'span' | 'input' | ((param) => 'span' | 'input') = 'span', displayValue: any, key: string) => {
//     const renderType = typeof type === 'function' ? type(node.data) : type;
//     return renderType === 'span' || lessThanCurrentMonth ? (
//       <span className="cell-span">{displayValue}</span>
//     ) : (
//       <input
//         type="text"
//         className="cell-input"
//         value={displayValue}
//         style={{ background: 'lightsalmon' }}
//         onChange={e => handleValueChange(key, e.target.value)}
//       />
//     );
//   };

//   const renderStyle = (style: React.CSSProperties | ((param) => React.CSSProperties)) => {
//     if (!style) return {};
//     return typeof style === 'function' ? style(node.data) : style;
//   };

//   return (
//     <div className="split-format-cell-container" style={lessThanCurrentMonth ? { background: 'gray' } : {}}>
//       <div className="upper-cell" style={renderStyle(upperStyle)}>
//         {renderContent(upperType, displayValues.upper, keys[0])}
//       </div>
//       <div className="cell-divided"></div>
//       <div className="lower-cell" style={renderStyle(lowerStyle)}>
//         {renderContent(lowerType, displayValues.lower, keys[1])}
//       </div>
//     </div>
//   );
// });

// export default SplitFormatCellRender;
