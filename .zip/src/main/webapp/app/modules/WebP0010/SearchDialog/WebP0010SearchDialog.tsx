import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box,
  IconButton,
  Select,
  MenuItem,
  Typography,
  ListItemText,
} from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebP0010SearchDialog.scss';
import '../../../app.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebP0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedValue, setSelectedValue] = useState('');

  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 業者コード
      gyoushaCode1: '',
      // 業者コード
      gyoushaCode2: '',
      // 業者名
      gyoushaName: '',
      // 業種
      gyoushuList: [],
      // 解体登録
      kaitaiTouroku: {
        '1': true,
        '2': false,
      },
      // 警備認定
      keibiNintei: {
        '1': true,
        '2': false,
      },
      // 産廃許可
      sanpaiKyoka: {
        '1': true,
        '2': false,
      },
      // 産廃許可期限
      sanpaiKyokaKigen: true,
      ankenCode: '',
      ankenName: '',
    },
  });

  const options1 = ['Option 1', 'Option 2', 'Option 3', 'Option 4', 'Option 5'];

  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  const gyoushuList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '住宅建築業', code: 'gyoushu1' },
    { id: 2, name: '土木工事業', code: 'gyoushu2' },
    { id: 3, name: '設備工事業', code: 'gyoushu3' },
    { id: 4, name: '海洋建設工事業', code: 'gyoushu4' },
    { id: 5, name: '建築装飾業', code: 'gyoushu5' },
  ];

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '400px',
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="webP0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <div className="webP0010-search-item">
                    <label>業者コード</label>
                    <Controller
                      name="gyoushaCode1"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '150px' }} size="small" />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="gyoushaCode2"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '100px' }} size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Box flex={1} mr={6}>
                    <Controller
                      name="gyoushuList"
                      control={control}
                      render={({ field }) => (
                        <div className="webP0010-search-item">
                          <label>業種</label>
                          <Select
                            value={selectedValue}
                            label=""
                            onChange={e => setSelectedValue(e.target.value)}
                            fullWidth
                            MenuProps={{
                              PaperProps: {
                                width: '100%',
                                style: {
                                  maxHeight: 200,
                                  overflow: 'auto',
                                },
                              },
                            }}
                            size="small"
                          >
                            {gyoushuList.map(item => (
                              <MenuItem key={item.id} value={item.code} sx={{ minHeight: '200px' }}>
                                {item.name}
                              </MenuItem>
                            ))}
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenName"
                    control={control}
                    render={({ field }) => (
                      <div className="webP0010-search-item">
                        <label>業者名(ｶﾅ含む)</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <div className="webP0010-search-item">
                    <label>解体登録</label>
                    <Controller
                      name="kaitaiTouroku.1"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              defaultChecked={true}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>有</Typography>}
                        />
                      )}
                    />
                    <Controller
                      name="kaitaiTouroku.2"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>無</Typography>}
                        />
                      )}
                    />
                  </div>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2} display="flex" justifyContent="center" alignItems="center">
                  <Typography sx={{ fontSize: '13px', color: '#F00' }}>
                    ※再下請負業者を追加したい一次の協力会社様を検索してください。
                  </Typography>
                </Box>
                <Box flex={1}>
                  <div className="webP0010-search-item">
                    <label>警備認定</label>
                    <Controller
                      name="keibiNintei.1"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              defaultChecked={true}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>有</Typography>}
                        />
                      )}
                    />
                    <Controller
                      name="keibiNintei.2"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>無</Typography>}
                        />
                      )}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebP0010SearchDialog;
