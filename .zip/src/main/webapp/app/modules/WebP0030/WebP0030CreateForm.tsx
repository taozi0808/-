import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import React, { useState, FC, useEffect, useRef, useMemo, useCallback, StrictMode } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebP0030CreateForm.scss';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import AddIcon from '@mui/icons-material/Add';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { MenuItem, Menu, Button, Box } from '@mui/material';
import {
  CellContextMenuEvent,
  GridReadyEvent,
  ColDef,
  ColGroupDef,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);
import { debounce } from 'lodash';

interface IRow {
  id: string;
  conditionName1: string;
  conditionName2: string;
  conditionName3: string;
  conditionName4: string;
  conditionName11: string;
  conditionName12: string;
  country: string;
  group: number;
  isColoe: number;
  level: 1 | 2 | 3;
}

/**
 * Web-P-0030
 * 下請登録
 */
const WebP0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const [columnApi, setColumnApi] = useState<any>(null);
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');
  const navigate = useNavigate();
  const gridRef = useRef();
  const [data, setData] = useState<IRow[]>([
    {
      id: '1',
      conditionName1: '000001-001',
      conditionName11: '',
      conditionName12: '',
      conditionName2: '000001-xxx',
      conditionName3: '涩谷区',
      conditionName4: '佐藤',
      country: '0001-xxx-xxx',
      group: 1,
      level: 1,
      isColoe: 1,
    },
    {
      id: '2',
      conditionName1: '000001-001',
      conditionName11: '000002-002',
      conditionName12: '',
      conditionName2: '0002-xxx',
      conditionName3: '中野区',
      conditionName4: '鈴木',
      country: '0002-xxx-xxx',
      group: 2,
      level: 2,
      isColoe: 2,
    },
    {
      id: '3',
      conditionName1: '000001-001',
      conditionName11: '000002-002',
      conditionName12: '000003-003',
      conditionName2: '0003-xxx',
      conditionName3: '千代田区',
      conditionName4: '岡本',
      country: '0003-xxx-xxx',
      group: 3,
      level: 3,
      isColoe: 2,
    },
    {
      id: '4',
      conditionName1: '000001-001',
      conditionName11: '000002-002',
      conditionName12: '000004-004',
      conditionName2: '0004-xxx',
      conditionName3: '新宿区',
      conditionName4: '小林',
      country: '0004-xxx-xxx',
      group: 4,
      level: 3,
      isColoe: 2,
    },
    {
      id: '5',
      conditionName1: '000001-001',
      conditionName11: '000005-005',
      conditionName12: '',
      conditionName2: '0005-xxx',
      conditionName3: '麻布区',
      conditionName4: '長野',
      country: '0005-xxx-xxx',
      group: 5,
      level: 2,
      isColoe: 3,
    },
    {
      id: '6',
      conditionName1: '000001-001',
      conditionName11: '000005-005',
      conditionName12: '000006-006',
      conditionName2: '0006-xxx',
      conditionName3: '中央区',
      conditionName4: '鳥居',
      country: '0006-xxx-xxx',
      group: 6,
      level: 3,
      isColoe: 3,
    },
    {
      id: '7',
      conditionName1: '000001-001',
      conditionName11: '000005-005',
      conditionName12: '000007-007',
      conditionName2: '0007-xxx',
      conditionName3: '旭川市',
      conditionName4: '後藤',
      country: '0007-xxx-xxx',
      group: 7,
      level: 3,
      isColoe: 3,
    },
  ]);
  const [contextMenu, setContextMenu] = useState<{
    mouseX: number;
    mouseY: number;
    rowData: any;
  } | null>(null);

  const onGridReady = (params: GridReadyEvent) => {
    setColumnApi(params.api);
    (window as any).aller = params.api;
  };

  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      editable: type !== 'preview',
    };
  }, []);

  const handleValueUpdate = useCallback((rowId: any, field: string, newValue: number) => {
    setData(prev => {
      const newData = [...prev];
      // eslint-disable-next-line @typescript-eslint/no-shadow
      newData.find(data => data.id === rowId)[field] = newValue;
      return newData;
    });
  }, []);

  const UserIdNameRender = params => {
    const handleAdd = () => {
      if (params.data.level === 1) {
        const newRow = { ...params.data, level: 2, id: `${parseInt(params.data.id, 10) + 1}` };
        params.addRow(newRow);
      } else {
        const newRow = { ...params.data, level: 3, id: `${parseInt(params.data.id, 10) + 1}` };
        params.addRow(newRow);
      }
    };
    const { level, conditionName1, conditionName11, conditionName12, conditionName2 } = params.data;
    if (level === 1) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <AddIcon onClick={!isHensyuuKengen ? handleAdd : null} />
          </Box>
          <Box flex={8}>
            <div style={{ height: '30px' }}>{conditionName1}</div>
            <div className="render-cellClass">{conditionName2}</div>
          </Box>
        </div>
      );
    } else if (level === 2) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <AddIcon onClick={!isHensyuuKengen ? handleAdd : null} />
          </Box>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <PlayArrowIcon />
          </Box>
          <Box flex={6}>
            <div style={{ height: '30px' }}>{conditionName11}</div>
            <div className="render-cellClass">{conditionName2}</div>
          </Box>
        </div>
      );
    }
    return (
      <div style={{ display: 'flex', width: '100%' }}>
        <Box flex={2} className="render-button-cellClass"></Box>
        <Box flex={3} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
          <PlayArrowIcon />
        </Box>
        <Box flex={5}>
          <div style={{ height: '30px' }}>{conditionName12}</div>
          <div className="render-cellClass">{conditionName2}</div>
        </Box>
      </div>
    );
  };

  const UserIdNameRender1 = params => {
    // eslint-disable-next-line @typescript-eslint/no-shadow
    const { country, conditionName4, id } = params.data;
    const { onValueChange } = params;
    const [displayValues, setDisplayValues] = useState({
      country,
      conditionName4,
    });

    const debouncedUpdate = useCallback(
      // eslint-disable-next-line @typescript-eslint/no-shadow
      debounce((id, key: string, displayValue: string) => {
        onValueChange(id, key, displayValue);
      }, 500),
      [],
    );

    // eslint-disable-next-line @typescript-eslint/no-shadow
    const handleValueChange = (id, key: string, displayValue: string) => {
      setDisplayValues(prev => ({
        ...prev,
        [key]: displayValue,
      }));
      debouncedUpdate(id, key, displayValue);
    };
    return (
      <div style={{ width: '100%' }}>
        <div style={{ height: '30px' }}>
          <input
            style={{ width: '100%', height: '30px', lineHeight: '30px', border: 'none' }}
            type="text"
            value={displayValues.country}
            onChange={e => handleValueChange(id, 'country', e.target.value)}
          />
        </div>
        <div style={{ height: '38px' }}>
          <input
            type="text"
            style={{ width: '100%', height: '30px', lineHeight: '30px', border: 'none', borderTop: '1px solid black' }}
            value={displayValues.conditionName4}
            onChange={e => handleValueChange(id, 'conditionName4', e.target.value)}
          />
        </div>
      </div>
    );
  };
  const headerComponentRender = params => {
    return (
      <div style={{ width: '100%' }}>
        <div style={{ width: '100%' }}>
          <div
            style={{
              width: '100%',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottom: '1px solid',
            }}
          >
            業者コード-業者支店コード
          </div>
          <div style={{ width: '100%', height: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            業者名‐業者支店名
          </div>
        </div>
      </div>
    );
  };

  const headerComponentRender1 = params => {
    return (
      <div style={{ width: '100%' }}>
        <div style={{ width: '100%' }}>
          <div
            style={{
              width: '100%',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottom: '1px solid',
            }}
          >
            電話番号
          </div>
          <div style={{ width: '100%', height: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>代表者名</div>
        </div>
      </div>
    );
  };

  const sortData = (dataList: IRow[]) => {
    const dataList1 = [...dataList].sort((a, b) => {
      if (a.isColoe < b.isColoe) return -1;
      if (a.isColoe > b.isColoe) return 1;
      if (a.group < b.group) return -1;
      if (a.group > b.group) return 1;
      return parseInt(a.id, 10) - parseInt(b.id, 10);
    });
    for (let i = 0; i < dataList1.length; i++) {
      dataList1[i].id = i + 1 + '';
    }
    return dataList1;
  };

  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      minWidth: 50,
      maxWidth: 80,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '業者コード-業者支店コード',
      headerComponent: headerComponentRender,
      field: '',
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      minWidth: 180,
      maxWidth: 300,
      cellRenderer: UserIdNameRender,
      cellRendererParams: {
        addRow: row => {
          setData(prev => {
            const newData = [...prev, row];
            return sortData(newData);
          });
        },
      },
    },
    {
      headerName: '住所',
      field: 'conditionName3',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      // spanRows: true,
      minWidth: 400,
      maxWidth: 500,
    },
    {
      headerName: '',
      field: '',
      headerComponent: headerComponentRender1,
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      minWidth: 140,
      maxWidth: 200,
      cellRenderer: UserIdNameRender1,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        onValueChange: handleValueUpdate,
      },
    },
  ]);

  // 画面名
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('下請登録');
    return () => setPageTitle('');
  }, []);

  // 处理右击事件
  const onCellContextMenu = (event: CellContextMenuEvent) => {
    event.event.preventDefault();
    if (type !== 'preview') {
      setContextMenu({
        mouseX: (event.event as any).clientX,
        mouseY: (event.event as any).clientY,
        rowData: event.data,
      });
    } else {
      handleClose();
    }
  };

  // 关闭菜单
  const handleClose = () => {
    setContextMenu(null);
  };

  // 处理菜单项点击
  const handleMenuItemClick = (action: string) => {
    if (contextMenu) {
      switch (action) {
        case 'add':
          // sortData(contextMenu.rowData.originIndex);
          break;
        case 'delete':
          // deleteSubSupplier(contextMenu.rowData.index, contextMenu.rowData.originIndex);
          break;
        default:
      }
      handleClose();
    }
  };
  // 保存
  const onSave = values => {
    navigate('/webP0010');
  };

  // キャンセル
  const onCancel = () => {
    navigate('/webP0010');
  };

  // 印刷
  const onPrint = values => {
    navigate('/webP0010');
  };

  return (
    <div>
      <div className="webp0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
            <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={onSave}
              disabled={isHensyuuKengen}
            >
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCancel}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={onPrint}
              disabled={isHensyuuKengen}
            >
              印刷
            </Button>
          </div>
        </div>
        <div
          className="ag-theme-alpine column-group-table"
          style={{
            padding: 16,
            width: 'auto',
            height: '76%', // 动态设置高度
            overflowY: 'auto', // 确保显示垂直滚动条
          }}
          onContextMenu={e => {
            e.preventDefault();
          }}
        >
          <AgGridReact
            rowData={data}
            theme={AGGridTheme}
            columnDefs={columnRef.current}
            headerHeight={60}
            rowHeight={60}
            defaultColDef={defaultColDef}
            onCellContextMenu={onCellContextMenu}
            domLayout="autoHeight"
          />
          <Menu
            open={contextMenu !== null}
            onClose={handleClose}
            anchorReference="anchorPosition"
            anchorPosition={contextMenu ? { top: contextMenu.mouseY, left: contextMenu.mouseX } : undefined}
          >
            <MenuItem onClick={() => handleMenuItemClick('add')}>追加</MenuItem>
            {contextMenu?.rowData?.isSubSupplier && <MenuItem onClick={() => handleMenuItemClick('delete')}>削除</MenuItem>}
          </Menu>
        </div>
      </div>
    </div>
  );
};
export default WebP0030CreateForm;
