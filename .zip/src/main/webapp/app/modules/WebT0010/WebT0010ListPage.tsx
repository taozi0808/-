import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebT0010ListPage.scss';
import '../../app.scss';
import dayjs from 'dayjs';
import { DBManager, sagyouInMeiboData } from 'app/shared/util/construction-list';
import { Column, Filters } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import WebT0010SearchDialog from './SearchDialog/WebT0010SearchDialog';
const WebT0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 48,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    { id: 'genbaCode', name: '現場コード', field: 'genbaCode', minWidth: 160, sortable: true, filterable: true },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      width: 298,
      sortable: true,
      filterable: true,
    },
    {
      id: 'genbaChakushuNichi',
      name: '現場着手日',
      field: 'genbaChakushuNichi',
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
    {
      id: 'genbaBikiWataruNichi',
      name: '現場引渡日',
      field: 'genbaBikiWataruNichi',
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');

  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let genbaList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY988');
    // const genbaList = generatGyoushaData(500);
    if (genbaList.length === 0) {
      genbaList = sagyouInMeiboData(500);
      // 番号作成
      genbaList = genbaList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY988', JSON.stringify(genbaList));
    }
    console.log('genbaList', genbaList);
    setRowData(genbaList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('現場一覧');
    handleSearch('true');
    return () => setPageTitle('');
  }, []);
  return (
    <div>
      <div className="webT0010-list" id="webT0010-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webT0020/preview/${selectedId}`);
              }}
            >
              参照
            </Button>
          </div>
          <div>
            <WebT0010SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(``);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebT0010ListPage;
