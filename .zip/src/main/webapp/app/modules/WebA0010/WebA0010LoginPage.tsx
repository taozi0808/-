import { Button, TextField, Box, Snackbar, Alert, InputAdornment, IconButton } from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import { STORAGE_KEY, STORAGE_KEY_CUSTOMER } from 'app/shared/util/construction-list';
import React, { useEffect, useState } from 'react';
import useAccountStore from 'app/shared/zustandStore/account';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import './WebA0010LoginPage.scss';

const Login = () => {
  const navigate = useNavigate();
  const { setUserName, setToken } = useAccountStore();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<'success' | 'error'>('success');
  const [showPassword, setShowPassword] = useState(false);

  const onFinish = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const values = {
      username: formData.get('username') as string,
      password: formData.get('password') as string,
    };

    console.log('values', values);

    if (values.username && values.password) {
      // API実装後使う
      // const user = await agent.Account.login(values);
      // if (user) {
      //   setMessage('ログイン成功');
      //   setSeverity('success');
      //   setOpen(true);
      //   window.localStorage.CONSTRUCTION_MANAGEMENT_LOGIN_USER = user.username;
      //   setUserName(user.username);
      //   setToken(user.token);
      //   navigate('/contractList');
      // }

      setMessage('ログイン成功');
      setSeverity('success');
      setOpen(true);
      window.localStorage.CONSTRUCTION_MANAGEMENT_LOGIN_USER = values.username;
      // mockデータのクリア
      window.localStorage.removeItem(STORAGE_KEY);
      window.localStorage.removeItem(STORAGE_KEY_CUSTOMER);
      setUserName(values.username);
      setToken('test');
      navigate('/webA0040');
    } else {
      setMessage('IDとPWDを入力してください');
      setSeverity('error');
      setOpen(true);
    }
  };

  useEffect(() => {
    window.localStorage.CONSTRUCTION_MANAGEMENT_LOGIN_USER = '';
  }, []);

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  return (
    <div className="webA0010-container">
      <h4 className="company-name">大東建設株式会社</h4>
      <h4 className="title">施工管理システム</h4>
      <Box component="form" onSubmit={onFinish} noValidate sx={{ mt: 1, maxWidth: '16%' }}>
        <TextField
          className="loginLable"
          margin="normal"
          required
          fullWidth
          id="username"
          label="ID"
          name="username"
          autoComplete="username"
          autoFocus
        />
        <TextField
          className="loginLable"
          margin="normal"
          required
          fullWidth
          name="password"
          label="PWD"
          type={showPassword ? 'text' : 'password'}
          id="password"
          autoComplete="current-password"
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  {showPassword ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <div className="password">
          <Button type="submit" fullWidth variant="contained" className="bnt_login">
            ログイン
          </Button>
        </div>
      </Box>

      <div className="bottom-notice">
        パスワードを忘れた方は
        <Button
          color="primary"
          variant="text"
          onClick={() => {
            navigate('/webA0020');
          }}
          style={{ padding: '4px 6px', fontSize: '10px' }}
        >
          こちらから
        </Button>
        お問い合わせください。
      </div>

      {/* 底部ボックスの内容 */}
      <div className="footer-box">
        <p>
          <strong>[お知らせ]</strong>
        </p>
        <ul>
          <li>ログインできない等のお問い合わせは、最寄りの弊社営業所及び社員までお問い合わせください。</li>
          <li>
            <span className="red-text">2026年05月31日（日）18:00～20:00</span>
            、メンテナンスのためシステムがご使用なれません。 ご不便をお掛けしますが、何卒ご理解のほどよろしくお願い致します。
          </li>
        </ul>

        {/* Link追加 */}
        <div className="right-bottom-element">
          <Link to="https://www.daito-j.com/privacy">ブライバシーボリシー</Link>
        </div>
      </div>

      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity={severity} sx={{ width: '100%' }}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default Login;
