import React, { FC, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import dayjs from 'dayjs';
import './WebR0060Table.scss';

interface Column {
  bukkenCode: string; // 物件コード
  bukkenName: string; // 物件名
  chumonShoNumber: string; // 注文書番号
  juchuKingaku: number | string; // 受注金額
  nyukinKingaku: number | string; // 入金金額
  hatchuHikiwatashiTanka: string; // 発注引き渡し単価
  status: string; // 状態
  keiyakuBi: string; // 契約日
  saishuBi: string; // 最終日
}

interface Props {
  rowData: Column[];
}

const Table: FC<Props> = ({ rowData }) => {
  const columnDefs = useMemo(() => {
    return [
      { headerName: '物件コード', field: 'bukkenCode', width: 120 },
      { headerName: '物件名', field: 'bukkenName', width: 160 },
      { headerName: '注文書番号', field: 'chumonShoNumber', width: 180 },
      {
        headerName: '受注金額',
        field: 'juchuKingaku',
        width: 140,
        valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
        cellClass: 'text-right',
      },
      {
        headerName: '入金金額',
        field: 'nyukinKingaku',
        width: 140,
        valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
        cellClass: 'text-right',
      },
      {
        headerName: '発注引き渡し単価',
        field: 'hatchuHikiwatashiTanka',
        width: 120,
        valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
        cellClass: 'text-right',
      },
      { headerName: '状態', field: 'status', width: 120 },
      {
        headerName: '契約日',
        field: 'keiyakuBi',
        width: 140,
        valueFormatter: params => (params.value ? dayjs(params.value).format('YYYY年MM月') : ''),
        cellClass: 'text-right',
      },
      {
        headerName: '最終日',
        field: 'saishuBi',
        width: 140,
        valueFormatter: params => (params.value ? dayjs(params.value).format('YYYY年MM月') : ''),
        cellClass: 'text-right',
      },
    ];
  }, []);

  const gridStyle = useMemo(() => {
    return {
      width: '90%',
      height: '260px',
    };
  }, []);

  return (
    <div
      className="webR0060-conditions-table"
      onContextMenu={e => {
        e.preventDefault();
      }}
      style={{ width: '100%', height: '260px', paddingLeft: '40px' }}
    >
      <AgGridReact
        rowData={rowData}
        columnDefs={columnDefs as any}
        theme={AGGridTheme}
        headerHeight={30}
        rowHeight={30}
        enableCellSpan
        gridOptions={{
          defaultColDef: {
            resizable: false,
            sortable: false,
          },
          autoSizeStrategy: {
            type: 'fitGridWidth',
          },
        }}
      />
    </div>
  );
};

export default Table;
