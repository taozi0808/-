import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebN0010ListPage.scss';
import dayjs from 'dayjs';
import { bukkenDataList } from 'app/shared/util/construction-list';
import WebN0010SearchDialog from './SearchDialog/WebN0010SearchDialog';
import { Column } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager } from 'app/shared/util/construction-list';

const WebF0010ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'bukkenCode',
      name: '現場コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 150,
      cssClass: 'left',
    },
    {
      id: 'gaitouArea',
      name: '現場名',
      field: 'gaitouArea',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'bukkenName',
      name: '業者名',
      field: 'bukkenName',
      minWidth: 313,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'juchuYmd',
      name: '予実作成日',
      field: 'juchuYmd',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'sekoTantoSha',
      name: '入力担当者',
      field: 'sekoTantoSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'chakkouDate',
      name: '現場着手日',
      field: 'chakkouDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'kankoDate',
      name: '現場引渡日',
      field: 'kankoDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
  ]);
  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });
  // 行を選択
  const [selectedId, setSelectedId] = useState('');
  // 選択行変更イベント
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 検索イベント
  const handleSearch = values => {
    // TODO API呼び出し
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // let contractList = DBManager.getList();
    // if (contractList.length === 0) {

    // モックデータ
    const contractList = bukkenDataList(500);
    //   localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    // }

    const contractList1 = contractList.filter(item => {
      // 現場コード检索 bukkenCode bukkenCode1 bukkenCode2
      const bukkenCode3 = '' + values.bukkenCode + values.bukkenCode1 + values.bukkenCode2;
      if (bukkenCode3 && !item.bukkenCode.includes(bukkenCode3)) {
        return false;
      }

      // 現場名
      if (values.bukkenName && !item.gaitouArea.includes(values.bukkenName)) {
        return false;
      }

      // 業者名检索
      if (values.kokyakuCode && !item.bukkenName.includes(values.kokyakuCode)) {
        return false;
      }

      // 入力担当者
      if (values.sekoTantoSha && !item.sekoTantoSha.includes(values.sekoTantoSha)) {
        return false;
      }

      // 現場引渡日 日区间检索
      if (values.kankoDateStart && values.kankoDateEnd) {
        const kankoDate = new Date(item.kankoDate);
        const startkankoDate = new Date(values.kankoDateStart);
        const endkankoDate = new Date(values.kankoDateEnd);

        if (kankoDate < startkankoDate || kankoDate > endkankoDate) {
          return false;
        }
      }

      // 現場着手日 日区间检索
      if (values.chakkouDateStart && values.chakkouDateEnd) {
        const chakkouDate = new Date(item.chakkouDate);
        const startchakkouDate = new Date(values.chakkouDateStart);
        const endchakkouDate = new Date(values.chakkouDateEnd);

        if (chakkouDate < startchakkouDate || chakkouDate > endchakkouDate) {
          return false;
        }
      }

      // 予実作成日日区间检索
      if (values.jtYmdStart && values.jtYmdEnd) {
        const jyucyuuDate = new Date(item.jyucyuuMikomiYMD);
        const startDate = new Date(values.jtYmdStart);
        const endDate = new Date(values.jtYmdEnd);

        if (jyucyuuDate < startDate || jyucyuuDate > endDate) {
          return false;
        }
      }
      // 検索条件に満たすデータのみ表示する
      return true;
    });
    // データを設定
    setRowData(contractList1);
  };

  useEffect(() => {
    // タイトルを設定
    setPageTitle('工事予実一覧');
    let sateiList = DBManager.getMockList('webn0010');
    // const contractList = bukkenDataList(500);
    if (sateiList.length === 0) {
      sateiList = bukkenDataList(500);
      localStorage.setItem('webn0010', JSON.stringify(sateiList));
    }
    // localStorage.setItem('webn0010', JSON.stringify(contractList));
    setRowData(sateiList);
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webF0010-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webN0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webN0030/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebN0010SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webN0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webN0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebF0010ListPage;
