/* eslint-disable no-irregular-whitespace */
import React, { FC, useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebQ0070CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Button, Radio, RadioGroup, FormControlLabel } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const WebQ0070CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();

  const [startDate, setStartDate] = useState('< < < 1/5 > > > ');
  const [startSubDate, setStartSubDate] = useState('< < < 1/3 > > > ');
  const [jzData, setJzData] = useState([]);
  const [jzData_1, setJzData_1] = useState([]);
  const [jzData_2, setJzData_2] = useState([]);
  const [zxqfgx_Data, setZxqfgxData] = useState([{}, {}]);
  const [zxqfgx_Data_1, setZxqfgxData1] = useState([{}, {}]);
  const [zxqfgx_Data_2, setZxqfgxData2] = useState([{}, {}]);
  const [isCollapse, setIsCollapse] = useState(false);
  const [isCollapse1, setIsCollapse1] = useState(false);

  useEffect(() => {
    setPageTitle('再下請通知書');
    const tempData = [];
    for (let i = 0; i < 4; i++) {
      tempData.push({
        id: i + 1,
        xkName: '東京都知事許可',
        gz: '建築',
        fh_1: '般 - ' + (i + 1),
        fh_2: (i + 1) * 10000 + '号',
        date: '2026年4月' + (i + 1) + '日',
        zxqfgx_xkName: '東京都知事許可',
        zxqfgx_gz: '建築',
        zxqfgx_fh_1: '般 - ' + (i + 1),
        zxqfgx_fh_2: (i + 1) * 10000 + '号',
        zxqfgx_date: '2026年4月' + (i + 1) + '日',
      });
    }
    setJzData(tempData);
    setZxqfgxData(tempData);
    setJzData_1([
      {
        name: '宮川　千尋',
        zgContent: '事務経験（10年・管）',
        gzContent: '冷暖房設備工事',
      },
      {
        name: '',
        zgContent: '',
        gzContent: '',
      },
    ]);
    setZxqfgxData1([
      {
        zxqfgx_name: '黒田　智和',
        zxqfgx_zgContent: '事務経験（10年・管）',
        zxqfgx_gzContent: '冷暖房設備工事',
      },
      {
        zxqfgx_name: '',
        zxqfgx_zgContent: '',
        zxqfgx_gzContent: '',
      },
    ]);
    setJzData_2([
      {
        qf: '元請契約',
        yyName: '大東建設（株）',
        jkbx: '○×健康保険組合XX-XXXX',
        njbx: 'XX-XXXX',
        gybx: 'XX-XXXX',
      },
      {
        qf: '下請契約',
        yyName: '〇〇工務店',
        jkbx: '同上',
        njbx: '同上',
        gybx: '同上',
      },
    ]);
    setZxqfgxData2([
      {
        zxqfgx_qf: '元請契約',
        zxqfgx_yyName: '大東建設（株）',
        zxqfgx_jkbx: '健康保険組合XX-XXXX',
        zxqfgx_njbx: 'XX-XXXX',
        zxqfgx_gybx: 'XX-XXXX',
      },
      {
        zxqfgx_qf: '下請契約',
        zxqfgx_yyName: '〇〇工務店',
        zxqfgx_jkbx: '同上',
        zxqfgx_njbx: '同上',
        zxqfgx_gybx: '同上',
      },
    ]);
    return () => setPageTitle('');
  }, [setPageTitle]);

  const columnRefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      spanRows: true,
      width: 60,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '許可・認定',
      field: 'xkName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '業者',
      field: 'gz',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '',
      field: 'fh_1',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header hide-header-after',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '番号',
      field: 'fh_2',
      cellEditor: 'agTextCellEditor',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '許可日・認定日',
      field: 'date',
      cellEditor: 'agDateCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs4 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      spanRows: true,
      width: 60,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '許可・認定',
      field: 'zxqfgx_xkName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '業者',
      field: 'zxqfgx_gz',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '',
      field: 'zxqfgx_fh_1',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header hide-header-after',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '番号',
      field: 'zxqfgx_fh_2',
      cellEditor: 'agTextCellEditor',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '許可日・認定日',
      field: 'zxqfgx_date',
      cellEditor: 'agDateCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs1 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '*専門技術者名',
      field: 'name',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*資格内容',
      field: 'zgContent',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*担当工事内容',
      field: 'gzContent',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs5 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '*専門技術者名',
      field: 'zxqfgx_name',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*資格内容',
      field: 'zxqfgx_zgContent',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*担当工事内容',
      field: 'zxqfgx_gzContent',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs2 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '区分',
      field: 'qf',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'cell-gray',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '営業所の名称',
      field: 'yyName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '健康保険',
      field: 'jkbx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '厚生年金保険',
      field: 'njbx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '雇用保険',
      field: 'gybx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs6 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '区分',
      field: 'zxqfgx_qf',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'cell-gray',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '営業所の名称',
      field: 'zxqfgx_yyName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '健康保険',
      field: 'zxqfgx_jkbx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '厚生年金保険',
      field: 'zxqfgx_njbx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '雇用保険',
      field: 'zxqfgx_gybx',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<CustomerManagementFormValues>({
    defaultValues: {
      sqDate: '202年10月10日 15:00',
      crDate: '202年10月15日 15:00',
      zwzName: '大東建設株式会社',
      syzID_zwz: '4654546541',
      dlrName: '田中　太郎',
      companyName: '〇〇工務店',
      syzID_company: '16516546545',
      dbName: '藤木　聡',
      yzId_1: '000',
      yzId_2: '001',
      address1: '東京都〇〇区〇〇町1-2-3',
      address2: '〇〇ビル',
      tel1: '000',
      tel2: '000',
      tel3: '000',
      fax1: '000',
      fax2: '000',
      fax3: '000',
      zsxg_zwsgz: '土工事',
      zsxg_detail: `△△ビル新築工事　直接仮設工事
地上4～6階　延べ床面積9,600㎡`,
      zsxg_startDate: '2025年4月1日',
      zsxg_endDate: '2025年12月31日',
      zsxg_qyDate: '2023年12月1日',
      zsxg_jdName: '神田　隼人',
      zsxg_jdscFunction: '請負契約書第〇〇条掲載の通り',
      zsxg_xcdlName: '上田　雄二',
      zsxg_scdlscFunction: '請負契約書第〇〇条掲載の通り',
      zsxg_zrLevel: '専任',
      zsxg_zgName: '夏目　次郎',
      zsxg_zgContent: '一級建築士',
      zsxg_aqzrName: '福沢　英治',
      zsxg_aqtjName: '山田　太郎',
      zsxg_gyglName: '花沢　花子',
      zsxg_dljnzName: '',
      zsxg_yhwgrStatus: true,
      zsxg_wgjszStatus: true,
      zsxg_wgsxsStatus: true,
      zsxg_jkbx: '加入',
      zsxg_njbx: '加入',
      zsxg_gybx: '加入',
      zxqfgx_companyName: '△△工務店',
      zxqfgx_syzID_company: '456465465454',
      zxqfgx_dbName: '蟹江　修司',
      zxqfgx_yzId_1: '000',
      zxqfgx_yzId_2: '1111',
      zxqfgx_address1: '東京都〇〇区1-2-3',
      zxqfgx_address2: '〇〇ビル',
      zxqfgx_tel1: '000',
      zxqfgx_tel2: '0001',
      zxqfgx_tel3: '0002',
      zxqfgx_zwsgz: '土工事',
      zxqfgx_detail: `△△ビル新築工事　直接仮設工事
地上4～6階　延べ床面積9,600㎡`,
      zxqfgx_startDate: '2025年4月1日',
      zxqfgx_endDate: '2025年12月31日',
      zxqfgx_qyDate: '2023年12月1日',
      zxqfgx_xcdlName: '佐久間　礼二',
      zxqfgx_scdlscFunction: '請負契約書第〇〇条掲載の通り',
      zxqfgx_zrLevel: '専任',
      zxqfgx_zgName: '藤原　浩一',
      zxqfgx_zgContent: '一級建築士',
      zxqfgx_aqzrName: '合田　武',
      zxqfgx_aqtjName: '北条　麻紀',
      zxqfgx_gyglName: '源　芳明',
      zxqfgx_dljnzName: '黒田　智和',
      zxqfgx_yhwgrStatus: true,
      zxqfgx_wgjszStatus: true,
      zxqfgx_wgsxsStatus: true,
      zxqfgx_jkbx: '加入',
      zxqfgx_njbx: '加入',
      zxqfgx_gybx: '加入',
    },
    mode: 'onBlur',
  });

  const renderTextField = (
    label: string,
    name: keyof CustomerManagementFormValues,
    required: boolean = false,
    width = '100%',
    multiRow?: boolean,
    labelMinLabel = 150,
  ) => (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Box display="flex">
          {label ? (
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: labelMinLabel, lineHeight: '40px', textAlign: 'center' }}>
              {required ? '* ' : ''}
              {label}
            </Box>
          ) : null}
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width,
            }}
            {...(multiRow && { multiline: true, rows: 4 })}
          />
        </Box>
      )}
    />
  );

  return (
    <div>
      <div className="webq0070-container">
        <div className="top">
          <span>{startDate}</span>
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%' }}>
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                承認
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ margin: '8px 8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webQ0010`);
                }}
              >
                キャンセル
              </Button>
            </div>
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                印刷
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96, margin: '0 8px' }} type="submit">
                作業員名簿
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                下請契約台帳
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '20px',
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', width: '60%' }}>
              {renderTextField('申請日', 'sqDate', true)}
              <div style={{ display: 'flex', gap: 4 }}>
                <span style={{ color: 'red', fontWeight: 'bold', margin: '0 10px', fontSize: '0.7re,' }}>{'【承認】'}</span>
                <span style={{ fontSize: '0.6rem' }}>{startSubDate}</span>
              </div>
            </Box>
            <Box>{renderTextField('承認日', 'crDate', true)}</Box>
          </Box>
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '10px',
            }}
          >
            <Box sx={{ width: '60%' }}>{renderTextField('直近上位の注文者名', 'zwzName', false)}</Box>
            <Box>{renderTextField('事業者ID', 'syzID_zwz')}</Box>
          </Box>
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '10px',
            }}
          >
            <Box sx={{ width: '60%' }}>{renderTextField('現場代理人名（所長名）', 'dlrName', false)}</Box>
            <Box></Box>
          </Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【報告下請業者】'}
          </Button>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '50%' }}>{renderTextField('会社名', 'companyName', false)}</Box>
          <Box>{renderTextField('事業者ID', 'syzID_company')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '50%' }}>{renderTextField('代表者名', 'dbName', false)}</Box>
          <Box></Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ display: 'flex' }}>{renderTextField('郵便番号', 'yzId_1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'yzId_2', false, '80px')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '70%' }}>{renderTextField('住所1', 'address1', false)}</Box>
          <Box />
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '70%' }}>{renderTextField('住所2', 'address2', false)}</Box>
          <Box />
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ display: 'flex' }}>{renderTextField('電話番号', 'tel1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'tel2', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'tel3', false, '80px')}</Box>
          <Box sx={{ display: 'flex', marginLeft: '10%' }}>{renderTextField('FAX番号', 'fax1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'fax2', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'fax3', false, '80px')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【自社に関する事項】'}
          </Button>
        </Box>
        <div style={{ display: 'flex', marginLeft: '-24px' }}>
          <div
            onClick={() => {
              setIsCollapse(!isCollapse);
            }}
          >
            {isCollapse ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
          </div>
          {isCollapse ? (
            <Box sx={{ border: '2px solid black', width: '100%', mt: '20px' }}>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'*工事名称及び工事内容'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('注文書工種', 'zsxg_zwsgz', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '158px' }} />
                <Box sx={{ width: '40%' }}>{renderTextField('', 'zsxg_detail', false, '100%', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ display: 'flex' }}>{renderTextField('工期', 'zsxg_startDate', false, '170px')}</Box>
                <Box sx={{ fontSize: '2rem', margin: '0 4px' }}>
                  <span>~</span>
                </Box>
                <Box>{renderTextField('', 'zsxg_endDate', false, '170px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('契約日', 'zsxg_qyDate', true, '170px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 150, lineHeight: '40px', textAlign: 'center' }}>{'建設業許可'}</Box>
                <div style={{ width: '100%', height: '218px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData} theme={AGGridTheme} columnDefs={columnRefs.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('監督員名', 'zsxg_jdName', true)}</Box>
                <Box sx={{ width: '60%', marginLeft: '1%' }}>
                  {renderTextField('権限及び意見申出方法', 'zsxg_jdscFunction', true, '100%', false, 180)}
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('現場代理人名', 'zsxg_xcdlName', true)}</Box>
                <Box sx={{ width: '60%', marginLeft: '1%' }}>
                  {renderTextField('権限及び意見申出方法', 'zsxg_scdlscFunction', true, '100%', false, 180)}
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('主任技術者名', 'zsxg_zrLevel', true, '100px')}</Box>
                <Box sx={{ width: '10px' }}></Box>
                <Box>{renderTextField('', 'zsxg_zgName', false, '200px')}</Box>
                <Box sx={{ width: '42%' }}>{renderTextField('資格内容', 'zsxg_zgContent', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('安全衛生責任者名', 'zsxg_aqzrName', true)}</Box>
                <Box sx={{ width: '40%' }}>{renderTextField('安全衛生推進者名', 'zsxg_aqtjName')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('雇用管理責任者名', 'zsxg_gyglName', true)}</Box>
                <Box sx={{ width: '40%' }}></Box>
              </Box>
              <Box
                sx={{
                  width: '90%',
                  mt: '10px',
                }}
              >
                <div style={{ width: 'calc( 100% - 158px)', height: '134px', marginLeft: '158px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData_1} theme={AGGridTheme} columnDefs={columnRefs1.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ marginLeft: '160px' }}>
                  {renderTextField('登録基幹技能者名・種類', 'zsxg_dljnzName', true, '100%', false, 180)}
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '160px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '240px' }}>
                    {'* 一号特定技能外国人の従事の状況'}
                  </Box>
                  <Controller
                    name={'zsxg_yhwgrStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '240px' }}>
                    {'* 外国人建設就労者の従事の状況'}
                  </Box>
                  <Controller
                    name={'zsxg_wgjszStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '160px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', width: '240px', lineHeight: '40px', textAlign: 'center' }}>
                    {'* 外国人技能実習生の従事の状況'}
                  </Box>
                  <Controller
                    name={'zsxg_wgsxsStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'健康保険の加入状況'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('健康保険', 'zsxg_jkbx', false)}</Box>
                <Box sx={{ width: '30%' }}>{renderTextField('厚生年金保険', 'zsxg_njbx', false)}</Box>
                <Box sx={{ width: '30%', mr: '16px' }}>{renderTextField('雇用保険', 'zsxg_gybx', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'*事業所整理記号等'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '90%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '100px' }}></Box>
                <div style={{ width: '100%', height: '134px', marginBottom: '2rem' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData_2} theme={AGGridTheme} columnDefs={columnRefs2.current} />
                </div>
              </Box>
            </Box>
          ) : null}
        </div>
        <Box
          sx={{
            display: 'flex',
            width: '80%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【再下請負関係】'}
          </Button>
        </Box>
        <div style={{ display: 'flex', marginLeft: '-24px' }}>
          <div
            onClick={() => {
              setIsCollapse1(!isCollapse1);
            }}
          >
            {isCollapse1 ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
          </div>
          {isCollapse1 ? (
            <Box sx={{ border: '2px solid black', width: '100%', mt: '20px' }}>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '50%' }}>{renderTextField('会社名', 'zxqfgx_companyName', false)}</Box>
                <Box>{renderTextField('事業者ID', 'zxqfgx_syzID_company', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('代表者名', 'zxqfgx_dbName', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('郵便番号', 'zxqfgx_yzId_1', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_yzId_2', false, '80px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '60%' }}>{renderTextField('住所1', 'zxqfgx_address1', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '60%' }}>{renderTextField('住所2', 'zxqfgx_address2', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('電話番号', 'zxqfgx_tel1', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_tel2', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_tel3', false, '80px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '80%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'*工事名称及び工事内容'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('代表者名', 'zxqfgx_zwsgz', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '158px' }} />
                <Box sx={{ width: '40%' }}>{renderTextField('', 'zxqfgx_detail', false, '100%', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ display: 'flex' }}>{renderTextField('工期', 'zxqfgx_startDate', false, '170px')}</Box>
                <Box sx={{ fontSize: '2rem', margin: '0 4px' }}>
                  <span>~</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_endDate', false, '170px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('契約日', 'zxqfgx_qyDate', true, '170px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 150, lineHeight: '40px', textAlign: 'center' }}>{'建設業許可'}</Box>
                <div style={{ width: '100%', height: '218px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={zxqfgx_Data} theme={AGGridTheme} columnDefs={columnRefs4.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('現場代理人名', 'zxqfgx_xcdlName', true)}</Box>
                <Box sx={{ width: '60%', marginLeft: '1%' }}>
                  {renderTextField('権限及び意見申出方法', 'zsxg_scdlscFunction', true, '100%', false, 180)}
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('主任技術者名', 'zxqfgx_zrLevel', true, '100px')}</Box>
                <Box sx={{ width: '10px' }}></Box>
                <Box>{renderTextField('', 'zsxg_zgName', false, '200px')}</Box>
                <Box sx={{ width: '42%' }}>{renderTextField('資格内容', 'zsxg_zgContent', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('安全衛生責任者名', 'zxqfgx_aqzrName', true)}</Box>
                <Box sx={{ width: '40%' }}>{renderTextField('安全衛生推進者名', 'zxqfgx_aqtjName')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('雇用管理責任者名', 'zxqfgx_gyglName', true)}</Box>
                <Box sx={{ width: '40%' }}></Box>
              </Box>
              <Box
                sx={{
                  width: '90%',
                  mt: '10px',
                }}
              >
                <div style={{ width: 'calc( 100% - 158px)', height: '134px', marginLeft: '158px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={zxqfgx_Data_1} theme={AGGridTheme} columnDefs={columnRefs5.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ marginLeft: '160px' }}>
                  {renderTextField('登録基幹技能者名・種類', 'zxqfgx_dljnzName', true, '100%', false, 180)}
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '160px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '240px' }}>
                    {'* 一号特定技能外国人の従事の状況'}
                  </Box>
                  <Controller
                    name={'zxqfgx_yhwgrStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '240px' }}>
                    {'* 外国人建設就労者の従事の状況'}
                  </Box>
                  <Controller
                    name={'zsxg_wgjszStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '160px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', width: '240px', lineHeight: '40px', textAlign: 'center' }}>
                    {'* 外国人技能実習生の従事の状況'}
                  </Box>
                  <Controller
                    name={'zxqfgx_wgsxsStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="無" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'健康保険の加入状況'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('健康保険', 'zsxg_jkbx', false)}</Box>
                <Box sx={{ width: '30%' }}>{renderTextField('厚生年金保険', 'zsxg_njbx', false)}</Box>
                <Box sx={{ width: '30%', mr: '16px' }}>{renderTextField('雇用保険', 'zsxg_gybx', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'*事業所整理記号等'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '90%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '100px' }}></Box>
                <div style={{ width: '100%', height: '134px', marginBottom: '2rem' }} className="ag-theme-alpine">
                  <AgGridReact rowData={zxqfgx_Data_2} theme={AGGridTheme} columnDefs={columnRefs6.current} />
                </div>
              </Box>
            </Box>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default WebQ0070CreateForm;
