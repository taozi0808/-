import React, { useState, useRef, useEffect, useImperativeHandle, forwardRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import { CellContextMenuEvent, ColDef, ColGroupDef, GridReadyEvent } from 'ag-grid-community';
import { Menu, MenuItem } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

const initRow = {
  majorCategory: '',
  subCategory: '',
  specification: '',
  quantity: 1,
  unit: '式',
  unitPrice: 1,
  budgetAmount: 0,
  unorderedItems: 0,
  orderAmount: 0,
  orderNo: '',
  supplierCode: '',
  supplierName: '',
  approvedAmount: 0,
  pendingApprovalAmount: 0,
  possibleReductionAmount: 0, // 减额可能额
  reductionAmount: 0, // 减额金额
};

const ReductionTable = forwardRef(({ data = [initRow] }: { data: any }, ref) => {
  const [columnApi, setColumnApi] = useState<any>(null);
  const [originRowData, setOriginRowData] = useState(data);
  const originRowDataRef = useRef(data);
  const [rowData, setRowData] = useState([]);
  const [contextMenu, setContextMenu] = useState<{
    mouseX: number;
    mouseY: number;
    rowData: any;
  } | null>(null);

  useImperativeHandle(ref, () => ({
    getOriginRowData: () => originRowData,
  }));

  const onGridReady = (params: GridReadyEvent) => {
    setColumnApi(params.api);
    (window as any).aller = params.api;
  };

  const onGridSizeChanged = () => {
    columnApi?.sizeColumnsToFit();
  };

  const generateTableRenderData = () => {
    const newArr = [];
    let no = 0;
    for (let i = 0; i < originRowData.length; i++) {
      no += 1;
      const curData: any = originRowData[i];
      curData.no = no;
      curData.originIndex = i;

      newArr.push(curData);
      newArr.push({
        ...curData,
        id: curData.id + '1',
      });
    }

    // 统计合计金额
    const total = originRowData.reduce((acc, row) => acc + row.reductionAmount, 0);
    newArr.push({
      no: 'total',
      reductionAmount: total,
    });
    setRowData(newArr);
  };

  const addNewRow = (index: number) => {
    const copyOriginRowData = [...originRowDataRef.current];
    copyOriginRowData.splice(index + 1, 0, initRow);
    setOriginRowData(copyOriginRowData);
    originRowDataRef.current = copyOriginRowData;
  };

  const deleteRow = (index: number) => {
    const copyOriginRowData = [...originRowData];
    copyOriginRowData.splice(index, 1);

    setOriginRowData(copyOriginRowData);
    originRowDataRef.current = copyOriginRowData;
  };

  const getRowStyle = params => {
    if (params.data.budgetChangeStatus) {
      return { background: '#ccc' };
    }
  };

  const onCellEdit = (params, key) => {
    // eslint-disable-next-line no-prototype-builtins
    if (params.data.hasOwnProperty(key)) {
      params.data[key] = params.newValue;

      setOriginRowData(pre => {
        const list = [...pre];
        list[params.data.originIndex] = params.data;
        originRowDataRef.current = list;
        return list;
      });

      return false;
    }
    return false;
  };

  // 处理右击事件
  const onCellContextMenu = (event: CellContextMenuEvent) => {
    event.event.preventDefault();
    setContextMenu({
      mouseX: (event.event as any).clientX,
      mouseY: (event.event as any).clientY,
      rowData: event.data,
    });
  };

  // 关闭菜单
  const handleClose = () => {
    setContextMenu(null);
  };

  // 处理菜单项点击
  const handleMenuItemClick = (action: string) => {
    if (contextMenu) {
      switch (action) {
        case 'add':
          addNewRow(contextMenu.rowData.originIndex);
          break;
        case 'delete':
          deleteRow(contextMenu.rowData.originIndex);
          break;
        default:
      }
      handleClose();
    }
  };

  useEffect(() => {
    generateTableRenderData();
  }, [originRowData]);

  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '',
      field: 'no',
      width: 70,
      spanRows: true,
      cellClass: params => (params.data.no === 'total' ? 'cell-end' : 'cell-center'),
      cellStyle: params => (params.data.no === 'total' ? { backgroundColor: '#ccc' } : {}),
      cellRenderer: params =>
        params.data.no === 'total' ? (
          '減額金額合計'
        ) : (
          <AddIcon
            onClick={() => {
              addNewRow(params.data.originIndex);
            }}
            sx={{ cursor: 'pointer' }}
          />
        ),
      colSpan: params => (params.data.no === 'total' ? 10 : 1),
    },
    {
      headerName: 'No',
      field: 'no',
      width: 70,
      spanRows: true,
      cellClass: 'cell-center',
      cellStyle: params => (params.data.budgetChangeStatus ? { backgroundColor: '#ccc' } : {}),
    },

    {
      headerName: '大工種',
      field: 'majorCategory',
      width: 180,
      children: [
        {
          headerName: '小工種',
          field: 'subCategory',
          width: 180,
          valueFormatter: params => (params?.node?.rowIndex % 2 === 0 ? params?.data?.majorCategory : params?.data?.subCategory),
          cellClass: 'add-arrow-icon',
          editable: true,
          valueGetter: params => {
            return params?.node?.rowIndex % 2 === 0 ? params.data.majorCategory : params.data.subCategory;
          },
          valueSetter: params => onCellEdit(params, params?.node?.rowIndex % 2 === 0 ? 'majorCategory' : 'subCategory'),
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: [
              '直接仮設工事',
              '水盛り・遣り方',
              '掘削',
              '基礎工事',
              'コンクリート工事',
              '鉄筋工事',
              '外部工事',
              '内部工事',
              '設備工事',
              'その他',
            ],
          },
        },
      ],
    },
    {
      headerName: '規格',
      field: 'specification',
      width: 180,
      cellClass: 'cell-align-center',
      valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.specification : ''),
      editable: params => params.node.rowIndex % 2 === 0,
      valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'specification' : ''),
      cellEditor: 'agTextCellEditor',
    },
    {
      headerName: '数量',
      field: 'quantity',
      width: 90,
      children: [
        {
          headerName: '単価',
          field: 'unitPrice',
          width: 90,
          headerClass: 'budget-detail-special-header',
          cellClass: 'cell-end',
          valueFormatter: params =>
            params.node.rowIndex % 2 === 0
              ? params.data.quantity
              : new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.data.unitPrice),
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 2),
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.quantity : params.data.unitPrice;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'quantity' : 'unitPrice'),
          cellEditor: 'agNumberCellEditor',
        },
      ],
    },
    {
      headerName: '単位',
      field: 'unit',
      width: 90,
      children: [
        {
          headerName: '',
          field: 'unit',
          width: 90,
          valueFormatter: params => (params?.node?.rowIndex % 2 === 0 ? params?.data?.unit : ''),
          cellClass: params => (params?.node?.rowIndex % 2 === 0 ? 'add-arrow-icon' : ''),
          editable: params => params?.node?.rowIndex % 2 === 0,
          valueSetter: params => onCellEdit(params, params?.node?.rowIndex % 2 === 0 ? 'unit' : ''),
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: ['式', 'm2', 'm3', 't', '本', '台'],
          },
        },
      ],
    },
    {
      headerName: '実行予算金額',
      field: 'budgetAmount',
      width: 180,
      children: [
        {
          headerName: '未発注残',
          field: 'unorderedItems',
          width: 180,
          cellClass: 'cell-end',
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.budgetAmount : params.data.unorderedItems;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'budgetAmount' : 'unorderedItems'),
          cellEditor: 'agNumberCellEditor',
          valueFormatter: params =>
            new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(
              params.node.rowIndex % 2 === 0 ? params.data.budgetAmount : params.data.unorderedItems,
            ),
        },
      ],
    },
    {
      headerName: '注文書No.',
      field: 'orderNo',
      width: 180,
      children: [
        {
          headerName: '発注金額',
          field: 'orderAmount',
          width: 180,
          cellClass: 'cell-end',
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.orderNo : params.data.orderAmount;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'orderNo' : 'orderAmount'),
          cellEditor: 'agTextCellEditor',
          valueFormatter: params =>
            params.node.rowIndex % 2 === 0
              ? params.data.orderNo
              : new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.data.orderAmount),
        },
      ],
    },
    {
      headerName: '協力業者コード.',
      field: 'supplierCode',
      width: 180,
      children: [
        {
          headerName: '協力業者名',
          field: 'supplierName',
          width: 180,
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.supplierCode : params.data.supplierName;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'supplierCode' : 'supplierName'),
          cellEditor: 'agTextCellEditor',
          cellEditorParams: {
            useFormatter: true,
          },
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.supplierCode : params.data.supplierName),
        },
      ],
    },
    {
      headerName: '査定済金額',
      field: 'approvedAmount',
      width: 180,
      children: [
        {
          headerName: '未査定残',
          field: 'pendingApprovalAmount',
          width: 180,
          cellClass: 'cell-end',
          valueFormatter: params =>
            new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(
              params.node.rowIndex % 2 === 0 ? params.data.approvedAmount : params.data.pendingApprovalAmount,
            ),
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.approvedAmount : params.data.pendingApprovalAmount;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'approvedAmount' : 'pendingApprovalAmount'),
          cellEditor: 'agNumberCellEditor',
        },
      ],
    },
    {
      headerName: '減額可能金額',
      field: 'possibleReductionAmount',
      width: 180,
      children: [
        {
          headerName: '減額金額',
          field: 'reductionAmount',
          width: 180,
          cellClass: 'cell-end',
          valueFormatter: params =>
            new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(
              params.node.rowIndex % 2 === 1 || params.data.no === 'total'
                ? params.data.reductionAmount
                : params.data.possibleReductionAmount,
            ),
          editable: true,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.possibleReductionAmount : params.data.reductionAmount;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'possibleReductionAmount' : 'reductionAmount'),
          cellEditor: 'agNumberCellEditor',
        },
      ],
    },
  ]);

  return (
    <>
      <div
        className="ag-theme-alpine budget-detail-list"
        style={{ height: '100%', width: '100%', overflow: 'auto' }}
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        {rowData.length > 0 && (
          <AgGridReact
            columnDefs={columnRef.current}
            onGridReady={onGridReady}
            onGridSizeChanged={onGridSizeChanged}
            onCellContextMenu={onCellContextMenu}
            getRowStyle={getRowStyle}
            rowData={rowData}
            domLayout="autoHeight"
            theme={AGGridTheme}
            headerHeight={30}
            rowHeight={30}
            enableCellSpan
            gridOptions={{
              defaultColDef: {
                resizable: false,
                sortable: false,
              },
              autoSizeStrategy: {
                type: 'fitGridWidth',
              },
            }}
          />
        )}
        <Menu
          open={contextMenu !== null}
          onClose={handleClose}
          anchorReference="anchorPosition"
          anchorPosition={contextMenu ? { top: contextMenu.mouseY, left: contextMenu.mouseX } : undefined}
        >
          <MenuItem onClick={() => handleMenuItemClick('add')}>追加</MenuItem>
          <MenuItem onClick={() => handleMenuItemClick('delete')} disabled={originRowData.length === 1}>
            削除
          </MenuItem>
        </Menu>
      </div>
    </>
  );
});

export default ReductionTable;
