import React, { useEffect, useMemo, useRef, useState } from 'react';
import BasicAgGridTable from 'app/components/BasicAgGridTable';
import CollapsePanel from 'app/components/CollapsePanel';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const SummaryTable = ({ rowData }: { rowData: any }) => {
  const gridRef = useRef<AgGridReact>(null);
  const [summaryData, setSummaryData] = useState([]);

  const formatCurrency = (params: { value: number }) => {
    return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value);
  };

  const columnDefsRef = useRef([
    {
      headerName: 'No',
      field: 'no',
      width: 80,
      cellClass: 'cell-center',
      colSpan: params => (params.data.no === '総合計' ? 2 : 1),
    },
    { headerName: '大工程', field: 'majorCategory', width: 150 },
    { headerName: '実行予算金額', field: 'budgetAmount', width: 150, cellClass: 'cell-end', valueFormatter: formatCurrency },
    { headerName: '発注金額', field: 'orderAmount', width: 150, cellClass: 'cell-end', valueFormatter: formatCurrency },
    { headerName: '未発注金額', field: 'unorderedItems', width: 150, cellClass: 'cell-end', valueFormatter: formatCurrency },
    { headerName: '査定済金額', field: 'approvedAmount', width: 150, cellClass: 'cell-end', valueFormatter: formatCurrency },
    { headerName: '未査定残', field: 'pendingApprovalAmount', width: 150, cellClass: 'cell-end', valueFormatter: formatCurrency },
  ]);

  useEffect(() => {
    // 首先使用明细表格里的每条数据，按照大工种做聚合；
    const categoryMap = {};
    rowData.forEach(item => {
      if (categoryMap[item.majorCategory]) {
        categoryMap[item.majorCategory].push(item);
      } else {
        categoryMap[item.majorCategory] = [item];
      }
    });

    // 计算每个大工种的汇总数据
    const list = [];
    for (const category in categoryMap) {
      const totalRow = categoryMap[category].reduce(
        (acc, row) => {
          // 子供应商中存在的三个值，若存在子供应商，则需要深入计算；
          let needContinueCalculating = {
            orderAmount: row.orderAmount,
            approvedAmount: row.approvedAmount,
            pendingApprovalAmount: row.pendingApprovalAmount,
          };

          if (row?.subSupplierList?.length) {
            needContinueCalculating = row.subSupplierList.reduce((subAcc, subRow) => {
              return {
                orderAmount: subAcc.orderAmount + subRow.orderAmount,
                approvedAmount: subAcc.approvedAmount + subRow.approvedAmount,
                pendingApprovalAmount: subAcc.pendingApprovalAmount + subRow.pendingApprovalAmount,
              };
            }, needContinueCalculating);
          }

          return {
            budgetAmount: acc.budgetAmount + row.budgetAmount,
            unorderedItems: acc.unorderedItems + row.unorderedItems,
            orderAmount: acc.orderAmount + needContinueCalculating.orderAmount,
            approvedAmount: acc.approvedAmount + needContinueCalculating.approvedAmount,
            pendingApprovalAmount: acc.pendingApprovalAmount + needContinueCalculating.pendingApprovalAmount,
          };
        },
        { budgetAmount: 0, unorderedItems: 0, orderAmount: 0, approvedAmount: 0, pendingApprovalAmount: 0 },
      );

      list.push({
        no: list.length.toString(),
        majorCategory: category,
        ...totalRow,
      });
    }

    // 计算表格最后一行汇总数据；
    const lastTotalRow = list.reduce(
      (acc, row) => ({
        budgetAmount: acc.budgetAmount + row.budgetAmount,
        unorderedItems: acc.unorderedItems + row.unorderedItems,
        orderAmount: acc.orderAmount + row.orderAmount,
        approvedAmount: acc.approvedAmount + row.approvedAmount,
        pendingApprovalAmount: acc.pendingApprovalAmount + row.pendingApprovalAmount,
      }),
      { budgetAmount: 0, unorderedItems: 0, orderAmount: 0, approvedAmount: 0, pendingApprovalAmount: 0 },
    );
    list.push({ no: '総合計', majorCategory: '', ...lastTotalRow });
    setSummaryData(list);
  }, [rowData]);

  return (
    <CollapsePanel defaultOpen={true} style={{ marginTop: 24 }}>
      <div
        style={{
          width: '100%',
          height: '100%',
        }}
        className="ag-theme-alpine budget-summary-table"
      >
        <AgGridReact
          ref={gridRef}
          columnDefs={columnDefsRef.current}
          getRowStyle={params => {
            if (params.data.no === '総合計') {
              return { fontWeight: 'bold', backgroundColor: '#f5f5f5' };
            }
            return null;
          }}
          rowData={summaryData}
          domLayout="autoHeight"
          theme={AGGridTheme}
          headerHeight={30}
          rowHeight={30}
          enableCellSpan
          suppressRowTransform
          gridOptions={{
            defaultColDef: {
              resizable: false,
              sortable: false,
            },
            autoSizeStrategy: {
              type: 'fitGridWidth',
            },
          }}
        />
      </div>
    </CollapsePanel>
  );
};

export default SummaryTable;
