import React, { FC } from 'react';
import { Box, TextField } from '@mui/material';
import CollapsePanel from 'app/components/CollapsePanel';

const SiteInfo = ({ data }: { data: any }) => {
  const renderTextField = (label: string, value: string) => (
    <Box display="flex" flex={1}>
      <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
      <TextField
        value={value}
        size="small"
        sx={{
          width: '100%',
        }}
        disabled
      />
    </Box>
  );

  const renderArea = (label: string, value1: string, value2: string) => (
    <Box display="flex" flex={1}>
      <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
      <Box sx={{ mr: 1, display: 'flex' }}>
        <TextField
          value={value1}
          size="small"
          sx={{
            width: '100%',
          }}
          disabled
        />
        <Box sx={{ lineHeight: '40px' }}>㎡</Box>
      </Box>
      <Box sx={{ display: 'flex' }}>
        <TextField
          value={value2}
          size="small"
          sx={{
            width: '100%',
          }}
          disabled
        />
        <Box sx={{ lineHeight: '40px' }}>坪</Box>
      </Box>
    </Box>
  );

  return (
    <Box className="site-info">
      <Box sx={{ mb: 2, mt: 4 }}>現場情報</Box>
      <CollapsePanel defaultOpen={true}>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderTextField('現場コード', data.siteCode)}
          <span />
        </Box>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderTextField('現場名', data.siteName)}
          {renderTextField('現場カナ名', data.siteNameKana)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderArea('建築面積', data.buildingAreaSqm, data.buildingAreaTsubo)}
          {renderArea('建築面積', data.buildingAreaSqm, data.buildingAreaTsubo)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderArea('施工床面積', data.constructionFloorAreaSqm, data.constructionFloorAreaTsubo)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
            mt: 4,
          }}
        >
          {renderTextField('構造区分', data.structureType)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
            mt: 4,
          }}
        >
          {renderTextField('現場着手日', data.siteStartDate)}
          {renderTextField('現場引渡日', data.siteHandoverDate)}
        </Box>
        <Box display="flex" flex={1}>
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>メモ</Box>
          <TextField
            value={data.memo}
            multiline
            size="small"
            sx={{
              width: '100%',
            }}
            disabled
          />
        </Box>
      </CollapsePanel>
    </Box>
  );
};

export default SiteInfo;
