/** 定义表单各字段的数据类型 */
export interface WebN0030FormValues {
  genbaCode: string;
  genbaName: string;
  genbaCanaName: string;
  genbaChakushuNichi: string;
  genbaBikiWataruNichi: string;
  nyuuryokuTantouMono: string;
  keihiShinseiNichi: string;
  hihyoujiKoumoku: string;
}
