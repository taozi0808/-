import React, { FC, useEffect, useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebN0030CreateForm.scss';
import dayjs from 'dayjs';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useForm, Controller } from 'react-hook-form';
import { Box, TextField, Button, Select, MenuItem, FormControlLabel, Radio, RadioGroup } from '@mui/material';
import { WebN0030FormValues } from './types';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ColGroupDef, ICellRendererParams, themeQuartz } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, bukkenDataList } from 'app/shared/util/construction-list';
import { CustomButtonRender } from 'app/components/CustomRender/customButtonRender';
import { CustomDateCellRender } from 'app/components/CustomRender/customDateCellRender';
import { generateDynamicColumns } from './generateDynamicColumns';
import CustomKoushikoujiRender from './CustomKoushikoujiRender';

const WebN0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');

  const [dateRange, setDateRange] = useState({ start: '2023-12', end: '2024-01' });

  const AGGridTheme = themeQuartz.withParams({
    borderColor: '#000',
    headerRowBorder: '1px solid #000',
    rowBorder: '1px solid #000',
    headerColumnBorder: '1px solid #000',
    columnBorder: '1px solid #000',
    headerBackgroundColor: '#9BC2E6',
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<WebN0030FormValues>({
    defaultValues: {
      genbaCode: '',
      genbaName: '',
      genbaCanaName: '',
      genbaChakushuNichi: '',
      genbaBikiWataruNichi: '',
      nyuuryokuTantouMono: '',
      keihiShinseiNichi: '',
      hihyoujiKoumoku: '0',
    },
    mode: 'onBlur',
  });

  const clear = () => {
    setValue('genbaCode', '');
    setValue('genbaName', '');
    setValue('genbaCanaName', '');
    setValue('genbaChakushuNichi', '');
    setValue('genbaBikiWataruNichi', '');
    setValue('nyuuryokuTantouMono', '');
    setValue('keihiShinseiNichi', '');
    setValue('hihyoujiKoumoku', '0');
  };

  useEffect(() => {
    // モックデータ
    let sagyouInList = DBManager.getMockList('webn0010');
    if (sagyouInList.length === 0) {
      sagyouInList = bukkenDataList(500);
      localStorage.setItem('webn0010', JSON.stringify(sagyouInList));
    }

    if (id === undefined) {
      console.log('データ異常');
    } else {
      const editData = sagyouInList.find(item => item.id === id) || null;
      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('genbaCode', editData.bukkenCode);
        setValue('genbaName', editData.bukkenName);
        setValue('genbaCanaName', 'アイウエオ');
        setValue('genbaChakushuNichi', dayjs(editData.chakkouDate).format('YYYY年MM月DD日'));
        setValue('genbaBikiWataruNichi', dayjs(editData.kankoDate).format('YYYY年MM月DD日'));
        setValue('nyuuryokuTantouMono', '01');
        setValue('keihiShinseiNichi', '2025-03-21');
        setValue('hihyoujiKoumoku', '0');
        setDateRange({ start: editData.chakkouDate, end: editData.kankoDate });
      }
    }

    setPageTitle('工事予実入力');
    return () => setPageTitle('');
  }, []);

  /** TODO:「非表示項目」 */
  const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新ステータスオブジェクト
    setValue('hihyoujiKoumoku', (event.target as HTMLInputElement).value);
  };

  const dynamicColumns = generateDynamicColumns(dateRange.start, dateRange.end, true);

  const staticColumns: (ColDef | ColGroupDef)[] = [
    {
      headerName: '表示切替',
      field: 'isVisible',
      width: 90,
      cellClass: 'cell-center',
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomButtonRender params={params} />;
      },
      cellRendererParams: {
        buttonName: (rowData: any) => {
          return rowData.isVisible ? `表示` : `非表示`;
        },
        buttonStyle: {
          backgroundColor: `purple`,
          color: `white`,
          '&:hover': {
            backgroundColor: '#7276E2',
          },
        },
        onButtonClick: (rowData: any) => {
          console.log(`add logic in this line`);
        },
      },
    },
    {
      headerName: '工事工程',
      field: 'koushikouji',
      width: 160,
      cellRenderer: CustomKoushikoujiRender,
      autoHeight: false,
      cellClass: 'cell-border',
    },
    {
      headerName: '業者名',
      field: 'gyoushaName',
      width: 140,
      autoHeight: false,
      cellClass: 'cell-center',
    },
    {
      headerName: '着手日',
      field: '',
      width: 190,
      // cellClass: 'end-cell',
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomDateCellRender params={params} />;
      },
      cellRendererParams: {
        keys: ['plannedStartDate', 'actualStartDate'],
        onChange: (rowId: number, newRowData: any) => {
          setRowData(prev => {
            return prev.map(item => {
              if (item.id === rowId) {
                return { ...item, ...newRowData };
              }
              return item;
            });
          });
        },
        disabled: isHensyuuKengen,
      },
      cellStyle: {
        padding: 0,
      },
    },
    {
      headerName: '完了日',
      field: '',
      width: 190,
      // cellClass: 'end-cell',
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomDateCellRender params={params} />;
      },
      cellRendererParams: {
        keys: ['plannedEndDate', 'actualEndDate'],
        onChange: (rowId: number, newRowData: any) => {
          setRowData(prev => {
            return prev.map(item => {
              if (item.id === rowId) {
                return { ...item, ...newRowData };
              }
              return item;
            });
          });
        },
        disabled: isHensyuuKengen,
      },
      cellStyle: {
        padding: 0,
      },
    },
  ];

  const finalColumn = [...staticColumns, ...dynamicColumns];

  const [rowData, setRowData] = useState([
    {
      id: 1,
      isVisible: true,
      koushikouji: '外工着工最早',
      plannedStartDate: '2024-01-01',
      actualStartDate: '2024-01-05',
      plannedEndDate: '2024-04-02',
      actualEndDate: '2024-04-05',
      '2023-12-p-1': 1000,
      '2023-12-a-1': 2000,
      '2023-12-p-2': 1200,
      '2023-12-a-2': 2200,
      '2023-12-p-3': 1300,
      '2023-12-a-3': 2300,
      '2024-1-p-1': 2100,
      '2024-1-a-1': 1100,
      '2024-1-p-2': 2560,
      '2024-1-a-2': 1560,
      '2024-1-p-3': 2850,
      '2024-1-a-3': 1850,
    },
    {
      id: 2,
      isVisible: false,
      koushikouji: '本体着工',
      plannedStartDate: '2024-02-16',
      actualStartDate: '2024-03-21',
      plannedEndDate: '2024-04-22',
      actualEndDate: '2024-05-25',
      '2023-12-p-1': 11000,
      '2023-12-a-1': 21000,
      '2023-12-p-2': 11200,
      '2023-12-a-2': 21200,
      '2023-12-p-3': 11300,
      '2023-12-a-3': 21300,
      '2024-1-p-1': 21100,
      '2024-1-a-1': 11100,
      '2024-1-p-2': 25160,
      '2024-1-a-2': 15160,
      '2024-1-p-3': 28150,
      '2024-1-a-3': 18150,
    },
  ]);

  return (
    <div>
      <div className="webn0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'auto' }}>
          <div className="top-operation">
            <div>
              <Button
                variant="contained"
                size="small"
                disabled={isHensyuuKengen}
                style={{ marginRight: '8px', minWidth: 96 }}
                type="submit"
              >
                保存
              </Button>
              <Button
                variant="contained"
                size="small"
                disabled={isHensyuuKengen}
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  clear();
                }}
              >
                クリア
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webN0010`);
                }}
              >
                キャンセル
              </Button>
            </div>
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} disabled={isHensyuuKengen}>
                印刷
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="genbaCode"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '100%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場コード</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '40%',
                    }}
                  />
                </Box>
              )}
            />
            <Controller
              name="genbaName"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '120%', marginLeft: '-30%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'flex',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              marginLeft: '36.2%',
              maxWidth: '59%',
            }}
          >
            <Controller
              name="genbaCanaName"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '100%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場カナ名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '120%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box sx={{ maxWidth: '95.2%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="genbaChakushuNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場着手日</Box>
                    <TextField
                      {...field}
                      size="small"
                      style={{ minWidth: '75.8%', textAlignLast: 'end' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="genbaBikiWataruNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', marginLeft: '100px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場引渡日</Box>
                    <TextField
                      {...field}
                      size="small"
                      style={{ minWidth: '75.8%', textAlignLast: 'end' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="nyuuryokuTantouMono"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', marginLeft: '70px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>入力担当者</Box>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="01">佐藤 愛菜</MenuItem>
                      <MenuItem value="02">吉田 美</MenuItem>
                    </Select>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box display="flex" sx={{ mb: 2, width: '100%' }}>
              <Controller
                name="keihiShinseiNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box display="flex" className="cell-date-picker">
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>経費申請日</Box>
                    <DatePicker
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{ width: '60%', textAlignLast: 'end' }}
                      format="YYYY年MM月DD日"
                      value={field.value ? dayjs(field.value) : null}
                    />
                  </Box>
                )}
              />
            </Box>
          </LocalizationProvider>

          <Box sx={{ maxWidth: '95.2%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="hihyoujiKoumoku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>非表示項目</Box>
                    <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange4}>
                      <FormControlLabel value={0} control={<Radio />} label="表示しない" />
                      <FormControlLabel value={1} control={<Radio />} label="表示する" />
                    </RadioGroup>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <div style={{ width: '100%', marginBottom: '20px' }}>
            <AgGridReact
              rowData={rowData}
              columnDefs={finalColumn}
              suppressCellFocus={true}
              rowHeight={80}
              domLayout="autoHeight"
              theme={AGGridTheme}
              enableCellSpan
            ></AgGridReact>
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebN0030CreateForm;
