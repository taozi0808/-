import React from 'react';

const CustomKoushikoujiRender = props => {
  return (
    <div
      style={{
        display: 'flex',
        height: '100%',
        width: '100%',
        boxSizing: 'border-box',
      }}
    >
      <div
        style={{
          flex: 7,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '0 8px',
        }}
      >
        <span>{props.value}</span>
      </div>

      <div
        style={{
          flex: 3,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#9BC2E6',
          color: 'black',
          height: '100%',
          fontSize: '12px',
          borderLeft: '1px solid #000',
        }}
      >
        <div style={{ textAlign: 'center', borderBottom: '1px solid #000', width: '100%' }}>予定</div>
        <div style={{ textAlign: 'center' }}>実績</div>
      </div>
    </div>
  );
};

export default CustomKoushikoujiRender;
