import React, { useState, useEffect, useRef } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Box,
  IconButton,
  Select,
  MenuItem,
  FormHelperText,
  Menu,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useForm, Controller } from 'react-hook-form';
import { generateUUID } from 'app/shared/util/construction-list';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import { NodeRendererProps, Tree } from 'react-arborist';
import RemoveCircleOutlinedIcon from '@mui/icons-material/RemoveCircleOutlined';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OrgNode } from './initData';
import { debounce } from 'lodash';

const INDENT_STEP = 35;

const OrganizationTree = ({
  disabled = false,
  treeData,
  onChange,
}: {
  disabled?: boolean;
  treeData: any[];
  onChange?: (newTreeData: any[]) => void;
}) => {
  const notify = useNotify();
  const { control, handleSubmit, setValue, reset } = useForm({
    // TODO: API実装後フィールド名を変更します
    defaultValues: {
      name: '',
      codePart1: '',
      codePart2: '',
      order: '',
    },
  });
  const [layout, setLayout] = useState({ height: 800, width: 400 });
  const [visible, setVisible] = useState(false);
  const [editNode, setEditNode] = useState(null);
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    node: null,
  });
  const nodeLineMapRef = useRef(new Map());

  // 再帰的に親ノード
  const findParentNode = (nodes, childKey) => {
    for (const node of nodes) {
      if (node.children?.some(child => child.key === childKey)) {
        return node;
      }
      if (node.children) {
        const parent = findParentNode(node.children, childKey);
        if (parent) return parent;
      }
    }
    return null;
  };

  const handleAddNode = parentNode => {
    setEditNode({ parent: parentNode, node: null });
    // form.resetFields();
    // form.setFieldsValue({
    //   order: parentNode.children.length + 1,
    // });
    setVisible(true);
  };

  const handleEditNode = node => {
    const [codePart1, codePart2] = node.code.split('-');
    const parent = findParentNode(treeData, node.key);

    setValue('name', node.name);
    setValue('codePart1', codePart1);
    setValue('codePart2', codePart2);
    setValue('order', parent.children.findIndex(child => child.key === node.key) + 1);

    setEditNode({ parent, node });
    setVisible(true);
  };

  const handleDeleteNode = nodeKey => {
    const parent = findParentNode(treeData, nodeKey);
    if (!parent) {
      notify('この組織は削除を禁止します', 'warning');
      return;
    }
    const parentChildren = parent.children ?? treeData;

    const currentNodeIndex = parentChildren.findIndex(item => item.key === nodeKey);
    parentChildren.splice(currentNodeIndex, 1);

    onChange?.(treeData);
  };

  // ノードを右クリックすると、クリック位置と現在クリックされたノードのデータを保存します
  const handleContextMenu = (event, node) => {
    if (disabled) return;
    event.preventDefault();
    setContextMenu({
      visible: true,
      x: event.pageX,
      y: event.pageY,
      node: node.data,
    });
  };

  // 右クリックメニューボタンのクリック
  const handleMenuClick = key => {
    switch (key) {
      case 'add':
        handleAddNode(contextMenu.node);
        break;
      case 'edit':
        handleEditNode(contextMenu.node);
        break;
      case 'delete':
        handleDeleteNode(contextMenu.node.key);
        break;
      default:
    }
    setContextMenu({ visible: false, x: 0, y: 0, node: null });
  };

  // 編集または新規追加の提出
  const onSubmit = values => {
    const { name, codePart1, codePart2, order } = values;

    const parentChildren = editNode.parent.children ?? treeData;
    /**
     * 編集：現在のノードを親ノードから切り取り、次に「order」の位置に現在のノードを挿入します。
     * 新規：直接「order」の位置に現在のノードを挿入します。
     */
    if (editNode.node) {
      // 編集
      Object.assign(editNode.node, {
        name,
        code: `${codePart1}-${codePart2}`,
      });
      const currentNodeIndex = parentChildren.findIndex(item => item.key === editNode.node.key);

      if (currentNodeIndex !== order - 1) {
        const currentNode = parentChildren.splice(currentNodeIndex, 1);
        parentChildren.splice(order - 1, 0, currentNode[0]);
      }
    } else {
      // 新規
      const newNode = {
        key: generateUUID(),
        name,
        code: `${codePart1}-${codePart2}`,
        children: [],
      };
      parentChildren.splice(order - 1, 0, newNode);
    }

    onChange?.(treeData);
    handleClose();
  };

  // 新規追加または編集時に順序ドロップダウンボックスのデータを取得する
  const getOrderOptions = () => {
    let length;

    if (editNode?.parent) {
      length = editNode?.parent?.children.length;

      if (!editNode?.node) {
        // 新規ノードを追加する
        length++;
      }
    } else {
      // ルートノード
      length = treeData.length;
    }

    return new Array(length).fill('-').map((_, index) => (
      <MenuItem value={index + 1} key={index}>
        {index + 1}
      </MenuItem>
    ));
  };

  const handleClose = () => {
    setEditNode(null);
    setVisible(false);
    reset();
  };

  const onMove = params => {
    const { dragNodes, index, parentNode } = params;
    const node = dragNodes[0];
    const copyNode = JSON.parse(JSON.stringify(node.data));
    handleDeleteNode(copyNode.key);
    parentNode.data.children.splice(index, 0, copyNode);
    onChange?.(treeData);
  };

  const NodeComponent = ({ node, style, dragHandle }: NodeRendererProps<OrgNode>) => {
    let lineList = [];
    if (nodeLineMapRef.current.has(node.data.code)) {
      lineList = nodeLineMapRef.current.get(node.data.code);
    } else {
      // 現在のノードに隣接する最初の縦線を処理します
      if (node.parent && !node.parent.isRoot) {
        lineList.push(node.nextSibling ? 1 : 0.5);
      }

      let curNode = node.parent;
      while (!curNode.isRoot) {
        if (curNode.parent && !curNode.parent.isRoot) {
          lineList.unshift(curNode.nextSibling ? 1 : 0);
        }
        curNode = curNode.parent;
      }
    }

    return (
      <div
        style={{ ...style, cursor: 'pointer', display: 'flex', alignItems: 'center', height: '100%' }}
        onContextMenu={e => handleContextMenu(e, node)}
        ref={dragHandle}
        onClick={() => node.isInternal && node.toggle()}
        className="tree-item"
      >
        <div className="indent-lines">
          {lineList.map((line, index) => {
            return <div key={index} style={{ height: `${line * 100}%` }} className="col-line" />;
          })}
          <div className="row-line" />
        </div>
        {node?.children?.length > 0 ? <AddCircleOutlinedIcon color="warning" /> : <RemoveCircleOutlinedIcon color="primary" />}
        <span className="tree-node" style={{ marginLeft: 4 }}>{`${node.data.name}(${node.data.code})`}</span>
      </div>
    );
  };

  useEffect(() => {
    const onResize = debounce(() => {
      setLayout({
        height: document.documentElement.clientHeight - 198,
        width: (document.documentElement.clientWidth - 332) / 2,
      });
    }, 200);
    window.addEventListener('resize', onResize);
    onResize();

    return () => {
      window.removeEventListener('resize', onResize);
    };
  }, []);
  return (
    <div onClick={() => setContextMenu({ visible: false, x: 0, y: 0, node: null })} style={{ height: '100vh' }} className="org-tree">
      {treeData.length > 0 && (
        <Tree
          data={treeData}
          width={layout.width}
          height={layout.height}
          rowHeight={40}
          indent={INDENT_STEP}
          childrenAccessor="children"
          idAccessor="key"
          openByDefault={true}
          disableMultiSelection
          disableDrag={disabled}
          onMove={onMove}
        >
          {NodeComponent}
        </Tree>
      )}
      <Menu
        open={contextMenu.visible}
        onClose={() => setContextMenu({ ...contextMenu, visible: false })}
        anchorReference="anchorPosition"
        anchorPosition={{ top: contextMenu.y, left: contextMenu.x }}
      >
        <MenuItem
          onClick={() => {
            handleMenuClick('edit');
          }}
        >
          編集
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleMenuClick('add');
          }}
        >
          追加
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleMenuClick('delete');
          }}
        >
          削除
        </MenuItem>
      </Menu>
      <Dialog open={visible} onClose={handleClose} fullWidth maxWidth="md">
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={theme => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '20px 8px 0 0' }}>
              <Button type="submit" variant="contained">
                決定
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="organization-tree-dialog">
              <div className="form-item" style={{ width: '100%', marginTop: 10 }}>
                <label>{'<上位組織名>'}</label>
                <div>{editNode?.parent ? `${editNode?.parent?.name}(${editNode?.parent?.code})` : '---'}</div>
              </div>
              <Box display="flex" justifyContent="flex-start">
                <Controller
                  name="name"
                  control={control}
                  rules={{ required: '<組織名>が入力されていません。' }}
                  render={({ field, fieldState }) => (
                    <div className="form-item" style={{ width: '100%' }}>
                      <label>{'<組織名>'}</label>
                      <TextField
                        {...field}
                        fullWidth
                        inputProps={{ maxLength: 255 }}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        size="small"
                      />
                    </div>
                  )}
                />
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2} className="form-item">
                  <label>{'<組織コード>'}</label>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                    <Controller
                      name="codePart1"
                      control={control}
                      rules={{ required: '<組織コード>が入力されていません' }}
                      render={({ field, fieldState }) => (
                        <TextField
                          {...field}
                          size="small"
                          error={!!fieldState.error}
                          helperText={fieldState.error ? fieldState.error.message : ''}
                          sx={{
                            width: 'calc(50% - 8px)',
                          }}
                        />
                      )}
                    />
                    <span>-</span>
                    <Controller
                      name="codePart2"
                      control={control}
                      rules={{ required: '<組織コード>が入力されていません' }}
                      render={({ field, fieldState }) => (
                        <TextField
                          {...field}
                          size="small"
                          error={!!fieldState.error}
                          helperText={fieldState.error ? fieldState.error.message : ''}
                          sx={{
                            width: 'calc(50% - 8px)',
                          }}
                        />
                      )}
                    />
                  </Box>
                </Box>
                <Box flex={1}>
                  <Controller
                    name="order"
                    control={control}
                    rules={{ required: '<表示順>が入力されていません。' }}
                    render={({ field, fieldState }) => (
                      <div className="form-item">
                        <label>{'<表示順>'}</label>
                        <Box sx={{ width: '100%' }}>
                          <Select
                            {...field}
                            size="small"
                            error={!!fieldState.error}
                            sx={{
                              width: '100%',
                            }}
                            displayEmpty
                          >
                            {getOrderOptions()}
                          </Select>
                          {fieldState.error && (
                            <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>
                          )}
                        </Box>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OrganizationTree;
