import React, { useState } from 'react';
import { Box, IconButton, TextField, Typography, Stack } from '@mui/material';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@mui/icons-material';

interface PaginationProps {
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination = ({ totalPages = 10, onPageChange }: PaginationProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [inputValue, setInputValue] = useState(currentPage.toString());

  const handlePrev = () => {
    if (currentPage > 1) {
      const newPage = currentPage - 1;
      setCurrentPage(newPage);
      onPageChange(newPage);
      setInputValue(newPage.toString());
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      const newPage = currentPage + 1;
      setCurrentPage(newPage);
      onPageChange(newPage);
      setInputValue(newPage.toString());
    }
  };

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1 }}>
      <IconButton onClick={handlePrev} disabled={currentPage === 1} aria-label="<">
        <KeyboardArrowLeft />
      </IconButton>
      <Typography variant="subtitle1">{currentPage}</Typography>

      <IconButton onClick={handleNext} disabled={currentPage === totalPages} aria-label=">">
        <KeyboardArrowRight />
      </IconButton>
    </Box>
  );
};

export default Pagination;
