import './WebR0020CreateForm.scss';
import OrganizationTree from './OrganizationTree';
import React, { useEffect, useState } from 'react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { Box, Button } from '@mui/material';
import useAccountStore from 'app/shared/zustandStore/account';
import dayjs from 'dayjs';
import { organizationInitData } from './initData';
import { organizationNextData } from './nextData';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { jaJP } from '@mui/x-date-pickers/locales';
const localStorageKey = 'CONSTRUCTION_MANAGEMENT_ORGANIZATION_KEY_5';

const pageMap = {
  pre: 1,
  current: 2,
  next: 3,
};

const pageNumberMap = {
  1: 'pre',
  2: 'current',
  3: 'next',
};

const OrganizationManage = () => {
  const { setPageTitle } = usePageTitleStore();
  const { userName } = useAccountStore();

  const [originalTreeData, setOriginalTreeData] = useState([]);
  const [treeData, setTreeData] = useState([]);
  const [currentPage, setCurrentPage] = useState('current');
  const [storeData, setStoreData] = useState<any>({});
  const [beginTime, setBeginTime] = useState(null);

  const onSave = () => {
    const lastUpdateInfo = {
      lastUpdateUserId: userName,
      lastUpdateTime: dayjs(new Date().toISOString()).format('YYYY-MM-DD HH:mm:ss'),
    };

    const newStoreData = {
      ...storeData,
      next: {
        treeData: treeData,
        lastUpdateInfo,
        beginTime,
      },
    };

    localStorage.setItem(localStorageKey, JSON.stringify(newStoreData));
    setStoreData(newStoreData);
    setCurrentPage('next');
    setOriginalTreeData(JSON.parse(JSON.stringify(treeData)));
  };

  const onPageChange = (type: string) => {
    const nextPageNum = type === 'pre' ? pageMap[currentPage] - 1 : pageMap[currentPage] + 1;
    console.log('nextPageNum:' + nextPageNum);
    const newData = storeData[pageNumberMap[nextPageNum]];
    setBeginTime(newData.beginTime);
    setTreeData(JSON.parse(JSON.stringify(newData.treeData)));
    setCurrentPage(pageNumberMap[nextPageNum]);
    setOriginalTreeData(JSON.parse(JSON.stringify(newData.treeData)));
  };

  useEffect(() => {
    setPageTitle('組織管理');

    let localStoreData = JSON.parse(localStorage.getItem(localStorageKey) || '{}');
    if (!localStoreData.current) {
      const lastUpdateInfo = {
        lastUpdateUserId: userName,
        lastUpdateTime: dayjs(new Date().toISOString()).format('YYYY-MM-DD HH:mm:ss'),
      };
      localStoreData = {
        current: {
          treeData: organizationInitData,
          lastUpdateInfo,
          beginTime: dayjs().format('YYYY-MM-DD'),
        },
        next: {
          treeData: organizationNextData,
          lastUpdateInfo,
          beginTime: dayjs().add(5, 'day').format('YYYY-MM-DD'),
        },
      };
      localStorage.setItem(localStorageKey, JSON.stringify(localStoreData));
    }

    if (new Date(localStoreData.next.beginTime) <= new Date()) {
      localStoreData = {
        current: localStoreData.next,
        pre: localStoreData.current,
      };
      localStorage.setItem(localStorageKey, JSON.stringify(localStoreData));
    }

    setStoreData(localStoreData);
    setBeginTime(localStoreData.current.beginTime);
    setTreeData(JSON.parse(JSON.stringify(localStoreData.current.treeData)));
    setOriginalTreeData(JSON.parse(JSON.stringify(localStoreData.current.treeData)));
  }, []);

  return (
    <div className="webR0020-container">
      {storeData?.[currentPage]?.lastModifyInfo?.lastUpdateUserId && (
        <LastUpdateInfo userId={storeData?.[currentPage]?.lastModifyInfo?.lastUpdateUserId} />
      )}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 4 }}>
        <Box sx={{ display: 'flex' }}>
          <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onSave}>
            保存
          </Button>
          <Button
            variant="contained"
            size="small"
            style={{ marginRight: '8px', minWidth: 96 }}
            onClick={() => {
              setTreeData(JSON.parse(JSON.stringify(originalTreeData)));
            }}
          >
            キャンセル
          </Button>
        </Box>
        <Box>
          <Button
            variant="text"
            onClick={() => {
              onPageChange('pre');
            }}
            disabled={!storeData[pageNumberMap[pageMap[currentPage] - 1]]}
          >
            {'≪<'}
          </Button>
          <span>{pageMap[currentPage]}</span>
          <Button
            variant="text"
            onClick={() => {
              onPageChange('next');
            }}
            disabled={!storeData[pageNumberMap[pageMap[currentPage] + 1]]}
          >
            {'>≫'}
          </Button>
        </Box>
        <Box sx={{ display: 'flex' }}>
          <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
            CSV出力
          </Button>
          <Button variant="contained" size="small" style={{ minWidth: 96 }}>
            印刷
          </Button>
        </Box>
      </Box>
      <div className="tree-content">
        <div className="tree-left">
          <OrganizationTree disabled treeData={originalTreeData} />
        </div>
        <div className="tree-right">
          <div className="update-time">{`<更新後日付>`}</div>
          <div className="begin-time">
            {`<通用開始日付>`}
            <LocalizationProvider
              dateAdapter={AdapterDayjs}
              adapterLocale="ja"
              localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
            >
              <DesktopDatePicker
                value={beginTime ? dayjs(beginTime) : dayjs()}
                slotProps={{ calendarHeader: { format: 'MM/YYYY' } }}
                format="YYYY年MM月DD日"
                minDate={dayjs().add(1, 'day')}
                onChange={(val, text) => {
                  console.log('111', val, dayjs(val).format('YYYY年MM月DD日'));
                  setBeginTime(dayjs(val).format('YYYY-MM-DD'));
                }}
              />
            </LocalizationProvider>
          </div>
          <OrganizationTree
            onChange={newData => {
              setTreeData([...newData]);
            }}
            treeData={treeData}
          />
        </div>
      </div>
    </div>
  );
};

export default OrganizationManage;
