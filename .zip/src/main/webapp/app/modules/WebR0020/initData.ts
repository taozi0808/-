export interface OrgNode {
  key: string;
  name: string;
  code: string;
  order?: number;
  children?: OrgNode[];
}

export const organizationInitData: Array<OrgNode> = [
  {
    key: 'ac3d9f60a836',
    name: '大東建設株式会社',
    code: '027-000',
    children: [
      { key: 'y5z6a7b8c9d011', name: '契約11課', code: '001-0061', children: [] },
      {
        key: 'f84012b4ebd4',
        name: '代表取締役社長',
        code: '027-001',
        children: [
          {
            key: 'f98785ede749',
            name: '取締役',
            code: '001-001',
            children: [
              {
                key: 'a1b2c3d4e5f6',
                name: '総務部',
                code: '001-002',
              },
              { key: 'g7h8i9j0k1l2', name: '人事課', code: '001-003', children: [] },
              // { key: 'm3n4o5p6q7r8', name: '経理課', code: '001-004', children: [] },
              // { key: 'y5z6a7b8c9d0', name: '契約課', code: '001-006', children: [] },
              // { key: 'e1f2g3h4i5j6', name: '訴訟課', code: '001-007', children: [] },
              // {
              //   key: 's9t0u1v2w3x4',
              //   name: '法務部',
              //   code: '001-005',
              // },
            ],
          },
        ],
      },

      {
        key: '47ef2f21f8fc',
        name: '関東工事部',
        code: '027-002',
        children: [
          {
            key: 'ff2a3e34acc7',
            name: '千葉営業所',
            code: '002-001',
            children: [
              {
                key: 'k9l0m1n2o3p4',
                name: '施工部',
                code: '002-002',
                children: [
                  { key: 'q5r6s7t8u9v0', name: '現場管理課', code: '002-003', children: [] },
                  { key: 'w1x2y3z4a5b6', name: '品質保証課', code: '002-004', children: [] },
                ],
              },
              {
                key: 'c6d7e8f9g0h1',
                name: '技術支援部',
                code: '002-005',
                children: [
                  { key: 'i2j3k4l5m6n7', name: '技術開発課', code: '002-006', children: [] },
                  { key: 'o8p9q0r1s2t3', name: '施工技術課', code: '002-007', children: [] },
                ],
              },
            ],
          },
          {
            key: 'u4v5w6x7y8z9',
            name: '東京営業所',
            code: '002-008',
            children: [
              {
                key: 'a0b1c2d3e4f5',
                name: '営業部',
                code: '002-009',
                children: [
                  { key: 'g6h7i8j9k0l1', name: '顧客管理課', code: '002-010', children: [] },
                  { key: 'm2n3o4p5q6r7', name: '販売促進課', code: '002-011', children: [] },
                ],
              },
            ],
          },
        ],
      },
      {
        key: 's8t9u0v1w2x3',
        name: '技術管理部',
        code: '027-003',
        children: [
          {
            key: 'y4z5a6b7c8d9',
            name: '研究開発課',
            code: '003-001',
            children: [
              { key: 'e0f1g2h3i4j5', name: '新技術開発室', code: '003-002', children: [] },
              { key: 'k6l7m8n9o0p1', name: '応用研究室', code: '003-003', children: [] },
            ],
          },
          {
            key: 'q2r3s4t5u6v7',
            name: '品質管理課',
            code: '003-004',
            children: [
              { key: 'w8x9y0z1a2b3', name: '材料管理課', code: '003-005', children: [] },
              { key: 'c4d5e6f7g8h9', name: '検査管理課', code: '003-006', children: [] },
            ],
          },
        ],
      },
      {
        key: 'i9j0k1l2m3n4',
        name: '大阪営業部',
        code: '027-004',
        children: [
          {
            key: 'o5p6q7r8s9t0',
            name: '関西支店',
            code: '004-001',
            children: [
              {
                key: 'u1v2w3x4y5z6',
                name: '設計部',
                code: '004-002',
                children: [
                  { key: 'a3b4c5d6e7f8', name: '意匠設計課', code: '004-003', children: [] },
                  { key: 'g9h0i1j2k3l4', name: '構造設計課', code: '004-004', children: [] },
                ],
              },
              {
                key: 'm5n6o7p8q9r0',
                name: '施工管理部',
                code: '004-005',
                children: [
                  { key: 's1t2u3v4w5x6', name: '安全管理課', code: '004-006', children: [] },
                  { key: 'y7z8a9b0c1d2', name: '予算管理課', code: '004-007', children: [] },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
];
