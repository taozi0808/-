import React, { useState, useEffect, useCallback } from 'react';
import { ICellRendererParams } from 'ag-grid-community';
import './ThreeFloorCellRender.scss';
import { debounce } from 'lodash';

interface ThreeFloorCellParams extends ICellRendererParams {
  topKey?: string;
  midDivide?: number[];
  midKeys?: string[];
  lastDivide?: number[];
  lastKeys?: string[];
  midStyle?: any[];
  lastStyle?: any[];
  topStyle?: any;
  node: any;
}

const ThreeFloorCellRender = (props: ThreeFloorCellParams) => {
  const {
    topKey = '',
    midDivide = [],
    midKeys = [],
    lastDivide = [],
    lastKeys = [],
    midStyle = [],
    lastStyle = [],
    topStyle = {},
    node,
  } = props;

  const data = node.data;

  const renderSpanLayer = (flexNum: number[], keys: string[], layer: 'top' | 'mid' | 'last', styles: any[]) => {
    if (flexNum.length === 0) {
      const style = styles[0] || {};
      return (
        <div className={`${layer}-item`} style={{ flex: 1, ...style }}>
          <span className="header-text">{data[keys[0]] || ''}</span>
        </div>
      );
    }

    return flexNum.map((fn, index) => {
      const style = styles[index] || {};
      return (
        <div key={`${layer}-${index}`} className={`${layer}-item`} style={{ flex: fn, ...style }}>
          <span className="header-text">{data[keys[index]] || ''}</span>
        </div>
      );
    });
  };

  return (
    <div className="threeFloorCell">
      <div className="top-layer">{renderSpanLayer([], [topKey], 'top', [topStyle])}</div>

      <div className="middle-layer">{renderSpanLayer(midDivide, midKeys, 'mid', midStyle)}</div>

      <div className="bottom-layer">{renderSpanLayer(lastDivide, lastKeys, 'last', lastStyle)}</div>
    </div>
  );
};
export default ThreeFloorCellRender;
