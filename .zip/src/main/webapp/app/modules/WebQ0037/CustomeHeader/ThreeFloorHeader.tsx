import React from 'react';
import type { IHeaderParams } from 'ag-grid-community';
import './ThreeFloorHeader.scss';

// eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
const ThreeFloorHeader: React.FC<IHeaderParams & any> = props => {
  const {
    firstValue = '',
    topStyle = {},
    midDivide = [],
    midValue = [],
    midStyle = [],
    lastDivide = [],
    lastValue = [],
    lastStyle = [],
  } = props;

  const renderLayer = (flexNum: number[], values: any[], styles: any[], layerType: 'top' | 'mid' | 'bot') => {
    if (!flexNum.length) {
      const style = styles[0] || {};
      return (
        <div className={`${layerType}-item`} style={{ flex: 1, ...style }}>
          <span className="header-text">{values[0] || ''}</span>
        </div>
      );
    }

    return flexNum.map((fn, index) => {
      const style = styles[index] || {};
      return (
        <div key={`${layerType}-${index}`} className={`${layerType}-item`} style={{ flex: fn, ...style }}>
          <span className="header-text">{values[index] || ''}</span>
        </div>
      );
    });
  };

  return (
    <div className="threeFloorHeader">
      <div className="top-layer" style={topStyle}>
        {renderLayer([], [firstValue], [{}], 'top')}
      </div>

      <div className="middle-layer">{renderLayer(midDivide, midValue, midStyle, 'mid')}</div>

      <div className="bottom-layer">{renderLayer(lastDivide, lastValue, lastStyle, 'bot')}</div>
    </div>
  );
};

export default ThreeFloorHeader;
