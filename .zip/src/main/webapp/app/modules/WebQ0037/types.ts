/** 定义表单各字段的数据类型 */
export interface CustomerManagementFormValues {
  // 現場コード
  genbaCode: string;
  // 現場名
  genbaName: string;
  // 現場カナ名
  genbaKanaName: string;
  // 一次業者コード
  ichijigyoushaCode: string;
  // 業者名
  gyoushaName: string;
  // 業者カナ名
  gyoushaKanaName: string;
  // 初回入場
  syokainyuujyou: string;

  // agtable1
  table1: {
    id: string;
    field1: string;
    name: string;
    techId: string;
    birthday: string;
    age: string;
    bloodTyle: string;
    healthDDay: string;
    bloodP: string;
    workTyle: string;
    specHealthDDay: string;
    type: string;
    workLength: string;
    jkbx: string;
    hsnj: string;
    gybx: string;
    lztbjoin: string;
    glzDay: string;
    free: string;
    initJoinDay: string;
    newJoinDay: string;
    xxxxxDay: string;
  }[];
}
