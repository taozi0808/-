import React, { FC, useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebQ0037CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Button, FormControlLabel, Checkbox } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import ConfirmationDialog from 'app/components/ConfirmationDialog';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import ThreeFloorHeader from './CustomeHeader/ThreeFloorHeader';
import ThreeFloorCellRender from './CustomeCellRender/ThreeFloorCellRender';

const WebQ0037CreateForm: FC = () => {
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const { control, handleSubmit } = useForm<CustomerManagementFormValues>({
    mode: 'onBlur',
  });

  const onSave: SubmitHandler<CustomerManagementFormValues> = values => {
    console.log('提出完了:', values);
  };

  const renderTextField = (label: string, name: keyof CustomerManagementFormValues, required: boolean, disabled: boolean) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex" flex={1}>
          <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
            disabled={disabled}
          />
        </Box>
      )}
    />
  );

  const columnRefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      spanRows: true,
      width: 60,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: 'フりがナ',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['氏名'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [1],
        lastValue: ['技术者ID'],
        lastStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'field1',
        midKeys: ['name'],
        lastKeys: ['techId'],
      },
      cellStyle: { padding: 0, borderRight: 'none' },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '生年月日',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1, 2],
        midValue: ['年龄', '血液型'],
        midStyle: [
          { borderLeft: '1px solid black', textAlign: 'center' },
          { borderLeft: '1px solid black', textAlign: 'center' },
        ],
        lastDivide: [1],
        lastValue: ['　'],
        lastStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'birthday',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midKeys: ['age', 'bloodTyle'],
        lastKeys: ['workType'],
        midDivide: [1, 2],
        midStyle: [
          { borderLeft: '1px solid black', textAlign: 'center' },
          { borderLeft: '1px solid black', textAlign: 'center' },
        ],
      },
      cellStyle: { padding: 0, borderRight: 'none' },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '健康诊断日',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['血压'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [1],
        lastValue: ['职业'],
        lastStyle: [{ marginLeft: '10px' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'healthDDay',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midKeys: ['bloodP'],
        lastKeys: [''],
        midDivide: [1],
        midStyle: [
          { borderLeft: '1px solid black', textAlign: 'center' },
          { borderLeft: '1px solid black', textAlign: 'center' },
        ],
      },
      cellStyle: { padding: 0, borderRight: 'none' },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '特别健康诊断日',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['种类'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [2, 1],
        lastValue: [' ', '职长'],
        lastStyle: [{}, { borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'specHealthDDay',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midKeys: ['type'],
        lastKeys: ['', 'workLength'],
        midDivide: [1],
        lastDivide: [2, 1],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastStyle: [{}, { borderLeft: '1px solid black', textAlign: 'center' }],
      },
      cellStyle: { padding: 0 },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '健康保险',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['厚生年金'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [1],
        lastValue: ['雇佣保险'],
        lastStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'jkbx',
        topStyle: { textAlign: 'center' },
        midKeys: ['hsnj'],
        lastKeys: ['gybx'],
        midDivide: [1],
        lastDivide: [1],
        midStyle: [{ textAlign: 'center' }],
        lastStyle: [{ textAlign: 'center' }],
      },
      cellStyle: { padding: 0 },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '特别加入',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['高龄教育实施日'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [1],
        lastValue: ['免许'],
        lastStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'lztbjoin',
        topStyle: { textAlign: 'center' },
        midKeys: ['glzDay'],
        lastKeys: ['free'],
        midDivide: [1],
        lastDivide: [1],
        midStyle: [{ textAlign: 'center' }],
        lastStyle: [{ textAlign: 'center' }],
      },
      cellStyle: { padding: 0 },
      width: 140,
    },
    {
      headerName: '',
      field: '',
      headerComponent: ThreeFloorHeader,
      headerComponentParams: {
        firstValue: '初回入场年月日',
        topStyle: { borderLeft: '1px solid black', textAlign: 'center' },
        midDivide: [1],
        midValue: ['新规入场年月日'],
        midStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
        lastDivide: [1],
        lastValue: ['教育实施日'],
        lastStyle: [{ borderLeft: '1px solid black', textAlign: 'center' }],
      },
      headerStyle: { padding: 0 },
      cellRenderer: ThreeFloorCellRender,
      cellRendererParams: {
        topKey: 'initJoinDay',
        topStyle: { textAlign: 'center' },
        midKeys: ['newJoinDay'],
        lastKeys: ['xxxxxDay'],
        midDivide: [1],
        lastDivide: [1],
        midStyle: [{ textAlign: 'center' }],
        lastStyle: [{ textAlign: 'center' }],
      },
      cellStyle: { padding: 0 },
      width: 140,
    },
  ]);

  const [rowData, setRowData] = useState([
    {
      id: 1,
      field1: 'カタカタぅrか',
      name: '田中 太郎',
      techId: '13215165161651',
      birthday: '1990年12月31日',
      age: '33',
      bloodTyle: 'A-',
      healthDDay: '2024年12月31日',
      bloodP: '130-85',
      workType: '土木工事业，建筑工事业，大公共事业',
      specHealthDDay: '2025年5月23日',
      type: '高气压业务',
      workLength: '15年',
      jkbx: '加入',
      hsnj: '加入',
      gybx: '加入',
      lztbjoin: '没有',
      glzDay: '2025年4月7日',
      free: '普通自动车免',
      initJoinDay: '2025年4月7日',
      newJoinDay: '2025年4月7日',
      xxxxxDay: '2025年4月7日',
    },
  ]);

  useEffect(() => {
    setPageTitle('作業員名簿登録');
    return () => setPageTitle('');
  }, [setPageTitle]);
  return (
    <div className="create-work-budget-WebQ0037">
      <div className="top">
        <div className="top-item">
          <LastUpdateInfo userId={'J123456789012'} userName={'桐生　一馬'} />
        </div>
      </div>
      <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '100%', overflowY: 'auto' }} className="basic-form">
        {/* ボタンエリア */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          {/* 左側部: 保存 キャンセル */}
          <Box sx={{ display: 'flex', columnGap: 1, paddingTop: 2, paddingBottom: 0 }}>
            <Button variant="contained" size="small" style={{ marginRight: '20px', minWidth: 96 }} type="submit">
              保存
            </Button>
            <ConfirmationDialog
              buttonText="キャンセル"
              title="キャンセル確認"
              content="編集内容を破棄します。よろしいでしょうか？（Yes/No）"
              primaryButtonText="No"
              secondaryButtonText="Yes"
              onSecondaryButtonClick={() => {
                navigate('/webQ0036');
              }}
              showSecondaryButton={true}
            />
          </Box>
          {/* 右側部: 印刷 下請契約台帳 再下請負通知書 */}
          <Box sx={{ display: 'flex', paddingTop: 2, paddingBottom: 0 }}>
            <Button variant="contained" size="small" style={{ marginRight: '20px', minWidth: 96 }}>
              印刷
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '20px', minWidth: 96 }}
              onClick={() => {
                navigate(`/webQ0050/add`);
              }}
            >
              下請契約台帳
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '20px', minWidth: 96 }}
              onClick={() => {
                navigate(`/webQ0070`);
              }}
            >
              再下請負通知書
            </Button>
          </Box>
        </Box>
        <Box sx={{ display: 'grid', justifyContent: 'flex-end' }}>
          <label>{`<<  < 1/1 >  >>`}</label>
        </Box>
        {/* 編集・参照エリア */}
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 3fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('現場コード', 'genbaCode', false, false)}
          {renderTextField('現場名', 'genbaName', false, false)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 3fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <span />
          {renderTextField('現場カナ名', 'genbaKanaName', false, false)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 3fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <span />
          <Controller
            name="syokainyuujyou"
            control={control}
            render={({ field }) => (
              <FormControlLabel
                sx={{
                  justifyContent: 'center',
                  margin: 0,
                }}
                control={<Checkbox color="default" {...field} defaultChecked />}
                label="初回入場年月日入力済みのみ表示"
              />
            )}
          />
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 3fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('一次業者コード', 'ichijigyoushaCode', false, false)}
          {renderTextField('業者名', 'gyoushaName', false, false)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 3fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <span />
          {renderTextField('業者カナ名', 'gyoushaKanaName', false, false)}
          <span />
        </Box>
      </Box>
      <div className="ag-theme-alpine" style={{ width: '100%', height: '421px' }}>
        <AgGridReact rowData={rowData} theme={AGGridTheme} columnDefs={columnRefs.current} headerHeight={90} rowHeight={90} />
      </div>
    </div>
  );
};

export default WebQ0037CreateForm;
