import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebG0010ListPage.scss';
import { STORAGE_KEY_JIKKOYOSAN, DBManager, jikkoYosanDataList } from 'app/shared/util/construction-list';
import WebG0010SearchDialog from './SearchDialog/WebG0010SearchDialog';
import { Column, FieldType } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import dayjs from 'dayjs';

const WebG0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集権限
    hensyuuKengen: true,
    // 参照権限
    sansyouKengen: true,
  });
  // 列の定義
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      minWidth: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'jikkoYosanCode',
      name: '実行予算コード',
      field: 'jikkoYosanCode',
      minWidth: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'yosanSinseiDate',
      name: '予算申請日',
      field: 'yosanSinseiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'yosanShoninDate',
      name: '予算承認日',
      field: 'yosanShoninDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'yosanSakuseiBumon',
      name: '予算作成部門',
      field: 'yosanSakuseiBumon',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'yosanSakuseiSha',
      name: '予算作成者',
      field: 'yosanSakuseiSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'jikkoYosanKingaku',
      name: '実行予算金額',
      field: 'jikkoYosanKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'hatchuuKingaku',
      name: '発注金額',
      field: 'hatchuuKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'mihatchuuKingaku',
      name: '未発注金額',
      field: 'mihatchuuKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'sateizumiKingaku',
      name: '査定済金額',
      field: 'sateizumiKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'misateiZan',
      name: '未査定残',
      field: 'misateiZan',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
  ]);

  const handleSearch = value => {
    // 仮データ作成
    let contractList = DBManager.getJikkoYosanList();
    if (contractList.length === 0) {
      contractList = jikkoYosanDataList(500);
      // 番号作成
      contractList = contractList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_JIKKOYOSAN, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    handleSearch('');
    setPageTitle('実行予算一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webG0010-container">
        {/* ボタンエリア */}
        <div className="top-operation">
          <div>
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  // navigate(`/contractEntry/preview/${selectedId}`);
                  navigate(`/webG0030/123`);
                }}
              >
                編集
              </Button>
            )}

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                // disabled={!selectedId}
                onClick={() => {
                  // navigate(`/contractEntry/edit/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebG0010SearchDialog />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                // navigate(`/webG0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                // navigate(`/webG0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebG0010ListPage;
