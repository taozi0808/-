import React, { FC, useMemo, useRef, useState } from 'react';
import BasicAgGridTable from 'app/components/BasicAgGridTable';
// import { AgGridReact } from 'ag-grid-react';

interface Column {
  seq: number;
  bukkenCode: string; // 物件コード
  bukkenName: string; // 物件名
  chumonShoNumber: string; // 注文書番号
  juchuKingaku: number | string; // 受注金額
  nyukinKingaku: number | string; // 入金金額
  hatchuHikiwatashiTanka: string; // 発注引き渡し単価
  status: string; // 状態
  keiyakuBi: string; // 契約日
  saishuBi: string; // 最終日
}

interface Props {
  rowData: Column[];
}

const Table: FC<Props> = ({ rowData }) => {
  const [rowDisData, setRowDisData] = useState<Column[]>(rowData);
  const columnDefs = useMemo(() => {
    return [
      {
        headerName: '操作',
        field: 'action',
        width: 120,
        cellRenderer: ActionButtonRenderer,
        cellRendererParams: {
          onClick: handleAppendRow,
        },
      },
      { name: 'Seq', field: 'seq', width: 120 },
      { name: '物件コード', field: 'bukkenCode', width: 120 },
      { name: '物件名', field: 'bukkenName', width: 200 },
      { name: '注文書番号', field: 'chumonShoNumber', width: 120 },
      { name: '受注金額', field: 'juchuKingaku', width: 120 },
      { name: '入金金額', field: 'nyukinKingaku', width: 120 },
      { name: '発注引き渡し単価', field: 'hatchuHikiwatashiTanka', width: 120 },
      { name: '状態', field: 'status', width: 120 },
      { name: '契約日', field: 'keiyakuBi', width: 120 },
      { name: '最終日', field: 'saishuBi', width: 120 },
    ];
  }, []);

  const gridRef = useRef<HTMLDivElement>(null);

  // 自定义按钮渲染器
  const ActionButtonRenderer = React.useCallback(
    ({ onClick, data }: { onClick: (rowIndex: number) => void; data: Column }) => (
      <button onClick={() => onClick(data.seq)} style={{ padding: '8px', cursor: 'pointer' }}>
        追加
      </button>
    ),
    [],
  );

  // 处理追加行
  const handleAppendRow = (originalSeq: number) => {
    const rowIndex = rowData.findIndex(row => row.seq === originalSeq);
    if (rowIndex === -1) return;

    // 深拷贝原数据
    const newRow = { ...rowData[rowIndex] };

    // 更新序号（根据实际需求调整）
    newRow.seq = rowData[rowIndex].seq + 1;

    // 插入新行到当前行下方
    setRowDisData(prev => {
      const newRows = [...prev];
      newRows.splice(rowIndex + 1, 0, newRow);
      return newRows;
    });
  };

  const gridStyle = useMemo(() => {
    return {
      width: '90%',
      height: '400px',
    };
  }, []);

  return (
    <div style={gridStyle} className="ag-theme-alpine">
      {/* <AgGridTable ref={gridRef} data={rowDisData} columns={columnDefs as any} disabledPagination /> */}
      <BasicAgGridTable data={rowDisData} columns={columnDefs as any} disabledPagination />
    </div>
  );
};

export default Table;
