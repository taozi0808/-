import { Box, Button, TextField, FormControlLabel, Checkbox } from '@mui/material';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { FormValues } from './types';
import React, { useState, useEffect } from 'react';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import './WebL0030CreateForm.scss';
import ConfirmationDialog from 'app/components/ConfirmationDialog';
import RequestConditionsTable from './RequestConditionsTable/RequestConditionsTable';
import { DBManager, STORAGE_KEY_SEIKYUSYO } from 'app/shared/util/construction-list';
import dayjs from 'dayjs';
import { mockTableData } from './initData';

const WebL0030CreateForm = () => {
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // 画面パラメータ
  const { id, type } = useParams();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(false);

  const onSubmit = values => {
    console.log(values);
    navigate('/webL0010');
  };

  const handleCancel = () => {
    navigate('/webL0010');
  };

  const { control, handleSubmit, setValue, reset } = useForm({
    defaultValues: {
      // 顧客コード
      kokyakuCode: '',
      // 顧客名
      kokyakuName: '',
      // 顧客カナ名
      kokyakuKanaName: '',
      // 案件コード
      ankenCode: '',
      // 案件名
      ankenName: '',
      // 案件カナ名
      ankenKanaName: '',
      // 物件コード
      bukenCode: '',
      // 物件名
      bukenName: '',
      // 物件カナ名
      bukenKanaName: '',
      // 物件着手日
      bukenChakushuDate: '',
      // 物件引渡日
      bukenHikiwatashiDate: '',
      //  請負金額（税抜）
      ukeoiKingakuZeinuki: '',
      // 消費税金額
      shohizeiKingaku: '',
      // 請負金額（税込）
      ukeoiKingakuZeikomi: '',
      // 郵便番号
      yubinCode1: '',
      yubinCode2: '',
      // 顧客管理使用
      kokyakuKanriShiyou: false,
      // 住所1
      jusho1: '',
      // 住所2
      jusho2: '',
      // 請求書No
      seikyuushoNo: '',
      // 請求書日付
      seikyuushoDate: '',
      // 入金予定日
      nyuukinYoteiDate: '',
      // 請求済金額
      seikyuuZumiKingaku: '',
      // 未請求残
      miseikyuuZan: '',
      // 今回請求額
      konkaiSeikyuuGaku: '',
    },
  });

  const clear = () => {
    reset();
  };

  const onSave: SubmitHandler<FormValues> = data => {
    console.log('保存処理を行う');
    console.log(data);
    console.log(rowData);
  };

  const renderTextField = (label: string, name: keyof FormValues, required: boolean = false, disabled: boolean = false) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      disabled={disabled}
      render={({ field, fieldState }) => (
        <Box display="flex" flex={1}>
          <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
          />
        </Box>
      )}
    />
  );

  useEffect(() => {
    // デーブルのデータを準備する
    setRowData(mockTableData);
    // 仮データを取得
    const mockData = DBManager.getMockList(STORAGE_KEY_SEIKYUSYO);
    const seikyusho = mockData.find(item => item.id.toString() === id);
    console.log(seikyusho);
    if (seikyusho) {
      setValue('kokyakuCode', seikyusho.kokyakuCode);
      setValue('kokyakuName', seikyusho.kokyakuName);
      setValue('kokyakuKanaName', seikyusho.kokyakuKanaName);
      setValue('ankenCode', seikyusho.ankenCode);
      setValue('ankenName', seikyusho.ankenName);
      setValue('ankenKanaName', seikyusho.ankenKanaName);
      setValue('bukenCode', seikyusho.bukkenCode);
      setValue('bukenName', seikyusho.bukkenName);
      setValue('bukenKanaName', seikyusho.bukkenKanaName);
      setValue('bukenChakushuDate', dayjs(seikyusho.bukkenChakushuDate).format('YYYY-MM-DD'));
      setValue('bukenHikiwatashiDate', dayjs(seikyusho.bukkenHikiwatashiDate).format('YYYY-MM-DD'));
      setValue('ukeoiKingakuZeinuki', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.ukeoiKingakuZeinuki));
      setValue('shohizeiKingaku', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.shohizeiKingaku));
      setValue('ukeoiKingakuZeikomi', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.ukeoiKingakuZeikomi));
      setValue('yubinCode1', '537');
      setValue('yubinCode2', '0003');
      setValue('jusho1', '大阪府大阪市東成区');
      setValue('jusho2', '新深江神路三丁目');
      setValue('seikyuushoNo', seikyusho.seikyushoNo);
      setValue('seikyuushoDate', dayjs(seikyusho.seikyuDate).format('YYYY-MM-DD'));
      setValue('nyuukinYoteiDate', dayjs(seikyusho.nyuukinYoteiDate).format('YYYY-MM-DD'));
      setValue('seikyuuZumiKingaku', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.seikyuzumiKingaku));
      setValue('miseikyuuZan', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.miseikyuZan));
      setValue('konkaiSeikyuuGaku', new Intl.NumberFormat('en-US', { style: 'decimal' }).format(seikyusho.konkaiSeikyuKingaku));
    }

    // タイトル設定
    setPageTitle('請求書作成');
    // この画面は編集画面の場合、編集できること
    if (type === 'edit') {
      setIsHensyuuKengen(true);
    }
  }, []);

  return (
    <div className="webl0030-create-container">
      <div className="top" style={{ display: id ? '' : 'none' }}>
        <div className="top-item">
          <LastUpdateInfo userId={'J123456789012'} userName={'桐生　一馬'} />
          <LastUpdateInfo userId={'J123456789011'} title="【承認者】" userName={'真島　吾郎'} />
        </div>
        <div className="top-item">
          <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
            <div style={{ width: 100 }}>{'【最終更新日】'}</div>
            <div>{`2024/02/01`}</div>
          </div>
          <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
            <div style={{ width: 100 }}>{'【承認日】'}</div>
            <div>{`2025/02/01`}</div>
          </div>
        </div>
      </div>
      <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '100%', overflowY: 'auto' }} className="basic-form">
        {/* ボタンエリア */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          {/* 左側部: 保存 申請 クリア キャンセル */}
          <Box sx={{ display: 'flex', columnGap: 1, margin: '16px 0' }}>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit" disabled={!isHensyuuKengen}>
              保存
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}} disabled={!isHensyuuKengen}>
              申請
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}} disabled={!isHensyuuKengen}>
              クリア
            </Button>
            <ConfirmationDialog
              buttonText="キャンセル"
              title="キャンセル確認"
              content="編集内容を破棄します。よろしいでしょうか？（Yes/No）"
              primaryButtonText="No"
              secondaryButtonText="Yes"
              onSecondaryButtonClick={() => {
                navigate('/webL0010');
              }}
              showSecondaryButton={true}
            />
          </Box>
          {/* 右側部: 印刷 */}
          <Box sx={{ display: 'flex', margin: '16px 0' }}>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              印刷
            </Button>
          </Box>
        </Box>
        {/* 編集・参照エリア */}
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
            mt: 4,
          }}
        >
          {renderTextField('顧客コード', 'kokyakuCode', false, !isHensyuuKengen)}
          {renderTextField('顧客名', 'kokyakuName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <span />
          {renderTextField('顧客カナ名', 'kokyakuKanaName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('案件コード', 'ankenCode', false, !isHensyuuKengen)}
          {renderTextField('案件名', 'ankenName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <Button variant="contained" style={{ minWidth: 96, marginLeft: 16 }} disabled={!isHensyuuKengen}>
              案件参照
            </Button>
          </Box>
          {renderTextField('案件カナ名', 'ankenKanaName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('物件コード', 'bukenCode', false, !isHensyuuKengen)}
          {renderTextField('物件名', 'bukenName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <span />
          {renderTextField('物件カナ名', 'bukenKanaName', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <LocalizationProvider
              dateAdapter={AdapterDayjs}
              adapterLocale="ja"
              localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
            >
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>物件着手日</Box>
              <Box>
                <Controller
                  name="bukenChakushuDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      disabled={!isHensyuuKengen}
                      {...field}
                      sx={{ width: '100%' }}
                      format="YYYY年MM月DD日"
                      value={field.value ? dayjs(field.value) : null}
                    />
                  )}
                />
              </Box>
            </LocalizationProvider>
          </Box>
          <Box sx={{ display: 'flex' }}>
            <LocalizationProvider
              dateAdapter={AdapterDayjs}
              adapterLocale="ja"
              localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
            >
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>物件引渡日</Box>
              <Box>
                <Controller
                  name="bukenHikiwatashiDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      disabled={!isHensyuuKengen}
                      {...field}
                      sx={{ width: '100%' }}
                      format="YYYY年MM月DD日"
                      value={field.value ? dayjs(field.value) : null}
                    />
                  )}
                />
              </Box>
            </LocalizationProvider>
          </Box>
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('請負金額（税抜）', 'ukeoiKingakuZeinuki', false, !isHensyuuKengen)}
          {renderTextField('消費税金額', 'shohizeiKingaku', false, !isHensyuuKengen)}
          {renderTextField('請負金額（税込）', 'ukeoiKingakuZeikomi', false, !isHensyuuKengen)}
        </Box>

        <div className="form-item" style={{ marginTop: 40 }}>
          <div className="title">送付先住所</div>
        </div>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>郵便番号</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="yubinCode1"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(50% - 8px)',
                    }}
                    disabled={!isHensyuuKengen}
                  />
                )}
              />
              <span>-</span>
              <Controller
                name="yubinCode2"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(50% - 8px)',
                    }}
                    disabled={!isHensyuuKengen}
                  />
                )}
              />
            </Box>
            <Button variant="contained" style={{ minWidth: 96, margin: '0px 8px' }} disabled={!isHensyuuKengen}>
              住所検索
            </Button>
          </Box>
          <Box>
            <Controller
              name="kokyakuKanriShiyou"
              control={control}
              render={({ field }) => (
                <FormControlLabel
                  control={<Checkbox color="default" disabled={!isHensyuuKengen} {...field} defaultChecked />}
                  label="顧客管理の住所を使用する"
                />
              )}
            />
          </Box>
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr',
            mb: 2,
          }}
        >
          {renderTextField('住所1', 'jusho1', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr',
            mb: 2,
          }}
        >
          {renderTextField('住所2', 'jusho2', false, !isHensyuuKengen)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            columnGap: 3,
            mt: 6,
            mb: 2,
          }}
        >
          {renderTextField('請求書No', 'seikyuushoNo', false, !isHensyuuKengen)}
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box sx={{ marginLeft: '6px' }}>【承認】</Box>
            <Box sx={{ marginLeft: '16px' }}>{`<<<1 / 3>>>`}</Box>
          </Box>
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <LocalizationProvider
              dateAdapter={AdapterDayjs}
              adapterLocale="ja"
              localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
            >
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>請求書日付</Box>
              <Box>
                <Controller
                  name="seikyuushoDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      disabled={!isHensyuuKengen}
                      {...field}
                      sx={{ width: '100%' }}
                      format="YYYY年MM月DD日"
                      value={field.value ? dayjs(field.value) : null}
                    />
                  )}
                />
              </Box>
            </LocalizationProvider>
          </Box>
          <Box sx={{ display: 'flex' }}>
            <LocalizationProvider
              dateAdapter={AdapterDayjs}
              adapterLocale="ja"
              localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
            >
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>入金予定日</Box>
              <Box>
                <Controller
                  name="nyuukinYoteiDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      disabled={!isHensyuuKengen}
                      {...field}
                      sx={{ width: '100%' }}
                      format="YYYY年MM月DD日"
                      value={field.value ? dayjs(field.value) : null}
                    />
                  )}
                />
              </Box>
            </LocalizationProvider>
          </Box>
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            columnGap: 3,
            mb: 2,
          }}
        >
          {renderTextField('請求済金額', 'seikyuuZumiKingaku', false, !isHensyuuKengen)}
          {renderTextField('未請求残', 'miseikyuuZan', false, !isHensyuuKengen)}
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 2fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderTextField('今回請求額', 'konkaiSeikyuuGaku', false, !isHensyuuKengen)}
          <span />
        </Box>
      </Box>
      <Box sx={{ display: 'flex' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100 }}>請求条件</Box>
        <Box sx={{ width: '100%' }}>
          <RequestConditionsTable rowData={rowData} />
        </Box>
      </Box>
    </div>
  );
};

export default WebL0030CreateForm;
