import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import dayjs from 'dayjs';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { Column, FieldType } from 'slickgrid-react';
import WebC0010SearchDialog from './SearchDialog/WebC0010SearchDialog';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { STORAGE_KEY_GAISAN, DBManager, gaisanDataList } from 'app/shared/util/construction-list';
import { useNavigate } from 'react-router-dom';
import './WebC0010ListPage.scss';

const WebC0010 = () => {
  const { setPageTitle } = usePageTitleStore();
  // 画面遷移関数を引用する
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集権限
    hensyuuKengen: true,
    // 参照権限
    sansyouKengen: true,
  });
  const [selectedId, setSelectedId] = useState('');
  // 列定義
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'ankenCode',
      name: '案件コード',
      field: 'ankenCode',
      minWidth: 135,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanCode',
      name: '概算コード',
      field: 'gaisanCode',
      minWidth: 110,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaJusho',
      name: '現場住所',
      field: 'genbaJusho',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'mitsumoriTeishutsuKigen',
      name: '見積提出期限',
      field: 'mitsumoriTeishutsuKigen',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'gaisanKingaku',
      name: '概算金額',
      field: 'gaisanKingaku',
      minWidth: 120,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'chakkoKiboJiki',
      name: '着工希望時期',
      field: 'chakkoKiboJiki',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'kankoKiboJiki',
      name: '完工希望時期',
      field: 'kankoKiboJiki',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'gaisanBumon',
      name: '概算部門',
      field: 'gaisanBumon',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanTantousya',
      name: '概算担当者',
      field: 'gaisanTantousya',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
  ]);

  const onSelectedRowsChanged = (id: string) => {
    setSelectedId(id ? id : '');
  };

  const handleSearch = values => {
    // 仮データ作成
    let contractList = DBManager.getGaisanList();
    if (contractList.length === 0) {
      contractList = gaisanDataList(500);
      // 番号作成
      contractList = contractList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_GAISAN, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  useEffect(() => {
    handleSearch('');
    setPageTitle('概算一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div className="webC0010-container">
      {/* ボタンエリア */}
      <div className="top-operation">
        <div>
          {permissionInfo.hensyuuKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webC0030/edit/${selectedId}`);
              }}
            >
              編集
            </Button>
          )}
          {permissionInfo.sansyouKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webC0030/preview/${selectedId}`);
              }}
            >
              参照
            </Button>
          )}
        </div>
        <div>
          <WebC0010SearchDialog onSearch={handleSearch} />
          <>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              印刷
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }}>
              CSV出力
            </Button>
          </>
        </div>
      </div>

      {/* テーブルエリア */}
      <BasicSlickGridTable
        columns={columnRef.current}
        data={rowData}
        onSelectionChanged={onSelectedRowsChanged}
        enableContextMenu
        contextMenuItems={[
          {
            title: '編集',
            command: 'edit',
            action: (_, callbackArgs) => {
              // navigate(`/webB0030/edit/${callbackArgs.dataContext.id}`);
            },
          },
          {
            title: '参照',
            command: 'preview',
            action: (_, callbackArgs) => {
              // navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
            },
          },
        ]}
      />
    </div>
  );
};

export default WebC0010;
