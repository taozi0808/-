import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import './WebD0030CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { Box, TextField, Select, MenuItem, Menu, Button, Collapse, FormControlLabel, Checkbox } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import { CellContextMenuEvent, ColDef, ColGroupDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import dayjs from 'dayjs';
import { WebD0010, DBManager } from 'app/shared/util/construction-list';

const WebD0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');
  const [dataSource, setDataSource] = useState([]);
  const [dataSource1, setDataSource1] = useState([]);
  const [dataSource2, setDataSource2] = useState([]);
  // 案件情報
  const [isCollapse, setIsCollapse] = useState(false);

  const [contextMenu, setContextMenu] = useState<{
    mouseX: number;
    mouseY: number;
    rowData: any;
  } | null>(null);

  const onFinish = values => {
    // navigate('/contractList');
  };

  /** TODO: 参照 */
  const ankenSanshou = () => {};

  let gaisanTotal = 0;
  let seiSekisanTotal = 0;

  const seikyuuJoukenNameParams = ['信用状支払い', '延期付款', '(other)'];
  const taniParams = ['式', '式1', '式2', '式3', '(other)'];
  const daikushuParams = ['土工事', '鉄筋工', '配管工', '電気工', '(other)'];
  const shoukoushuParams = ['配管工', '鉄筋工', '電気工', '(other)'];

  const {
    control,
    // handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    defaultValues: {
      ankenCode: '',
      ankenName: '',
      gaisanCodePart1: '',
      gaisanCodePart2: '',
      ankenKanaName: '',
      seisekisanCodePart1: '',
      seisekisanCodePart2: '',
      seisekisanBumon: '',
      seisekisanHizuke: '',
      seisekisanTantoumono: '',
      listJyucyuuJyoutai: '',
      tenpuFile: '',
      elia: '',
      sekisanKingaku: true,
      gaisanGoukeiKingaku: '',
      seiSekisanGoukeiKingaku: '',
      yuubinBangouPart1: '',
      yuubinBangouPart2: '',
      bukkenJuusho: '愛知県名古屋市中村区名駅南1-1-1',
      kokyakuCode: '0606',
      kokyakuName: '高橋太郎',
      yuubinBangouPart3: '060606',
      yuubinBangouPart4: '070707',
      kokyakuJuusho: '北海道札幌市中央区北1条西1-1-1',
      kanminKubun: '20250303',
      kanchouBunrui: '080808',
      teishutsuKigen: '20250505',
      shikichiMenseki1: '10',
      shikichiMenseki2: '20',
      kenchikuMenseki1: '30',
      kenchikuMenseki2: '10',
      enyukaMenseki1: '50',
      enyukaMenseki2: '60',
      sekouyukaMenseki1: '70',
      sekouyukaMenseki2: '80',
      senyuuMenseki1: '90',
      senyuuMenseki2: '00',
      kosuu: '22',
      chijou: '33',
      chika: '44',
      juchuuMikomiNichi1: '',
      juchuuMikomiNichi2: '',
      eigyouBumon: '',
      eigyouKanrishoku: '',
      eigyouTantouMono: '',
      sekkeiGyousha: '田中美咲',
      sekkeiTantouMono: '田中美咲',
      items: [{ value: '' }],
    },
    mode: 'onBlur',
  });

  // 添加/削除行
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items',
  });

  // ID並び替える
  const idSorting = (copyData: any, action: boolean) => {
    const dataList1 = [...copyData].sort((a, b) => {
      if (a.id < b.id) return -1;
      if (a.id > b.id) return 1;
      if (a.key < b.key) return -1;
      if (a.key > b.key) return 1;
      return parseInt(a.id, 10) - parseInt(b.id, 10);
    });
    for (let i = 0; i < dataList1.length; i++) {
      dataList1[i].id = i + 1;
      dataList1[i].key = i + 1;
    }
    setDataSource1(dataList1);
    if (action) {
      const newCurData1 = [];
      for (let i = 0; i < dataList1.length; i++) {
        newCurData1.push(dataList1[i]);
        newCurData1.push(dataList1[i]);
      }
      setDataSource(newCurData1);
    } else {
      totalAmountCompute(dataList1);
    }
  };

  // 合計計算
  const totalAmountCompute = (tempDataSource: any) => {
    const newDate = [];
    for (let i = 0; i < tempDataSource.length; i++) {
      if (tempDataSource[i].isSubSupplier) {
        newDate.push(tempDataSource[i]);
      }
    }
    // まず、明細表の各データを使用して、大工種に従って集約する；
    const categoryMap = {};
    newDate.forEach(item => {
      if (categoryMap[item.daikushu]) {
        categoryMap[item.daikushu].push(item);
      } else {
        categoryMap[item.daikushu] = [item];
      }
    });
    // 大工種の集計データを計算する
    const newCurData = [];
    const list = [];
    for (const category in categoryMap) {
      const firstTotalRow = categoryMap[category].reduce(
        (acc, row) => ({
          seisekisanKingaku: acc.seisekisanKingaku + row.seisekisanKingaku,
          gaisanKingaku: acc.gaisanKingaku + row.gaisanKingaku,
        }),
        { seisekisanKingaku: 0, gaisanKingaku: 0 },
      );
      list.push({
        no: list.length.toString(),
        daikushu: category,
        ...firstTotalRow,
      });
    }

    // 概算合計金額/精積算合計金額
    for (let i = 0; i < list.length; i++) {
      gaisanTotal = gaisanTotal + list[i].gaisanKingaku;
      seiSekisanTotal = seiSekisanTotal + list[i].seisekisanKingaku;
    }
    // 概算合計金額/精積算合計金額
    setValue('gaisanGoukeiKingaku', Intl.NumberFormat('en-US').format(gaisanTotal));
    setValue('seiSekisanGoukeiKingaku', Intl.NumberFormat('en-US').format(seiSekisanTotal));

    // IDを再計算する
    let tableID = 1;
    let dateFlg = true;
    for (let i = 0; i < newDate.length; i++) {
      if (i !== 0 && newDate[i].daikushu !== newDate[i - 1].daikushu) {
        dateFlg = true;
      }
      for (let x = 0; x < list.length; x++) {
        if (list[x].daikushu === newDate[i].daikushu && dateFlg) {
          newCurData.push({
            id: i + tableID,
            daikushu: list[x].daikushu,
            seisekisanKingaku: list[x].seisekisanKingaku,
            gaisanKingaku: list[x].gaisanKingaku,
          });
          dateFlg = false;
          tableID = tableID + 1;
        }
      }
      const newTempDataSource = newDate[i];
      newTempDataSource.id = i + tableID;
      newCurData.push(newTempDataSource);
    }
    setDataSource1(newCurData);
    // データ設定
    const newCurData1 = [];
    for (let i = 0; i < newCurData.length; i++) {
      newCurData1.push(newCurData[i]);
      newCurData1.push(newCurData[i]);
    }
    setDataSource(newCurData1);
  };

  // 合計行
  const totalRowData = (totalData: any) => {
    const newDate = [];
    for (let i = 0; i < totalData.length; i++) {
      if (totalData[i].shiharaiJoukenName !== '合計') {
        newDate.push(totalData[i]);
      }
    }
    const lastTotalRow = newDate.reduce(
      (acc, row) => ({
        kakuGou: acc.kakuGou + row.kakuGou,
        shiharaiKingaku: acc.shiharaiKingaku + row.shiharaiKingaku,
        shouhizeiKingaku: acc.shouhizeiKingaku + row.shouhizeiKingaku,
      }),
      { kakuGou: 0, shiharaiKingaku: 0, shouhizeiKingaku: 0 },
    );
    newDate.push({ shiharaiJoukenName: '合計', ...lastTotalRow });
    setDataSource2(newDate);
  };

  const onCellEditingStopped = (params: any) => {
    totalAmountCompute(dataSource1);
  };

  const onCellEditingStopped1 = (params: any) => {
    totalRowData(dataSource2);
  };

  // 右クリックイベントを処理する
  const onCellContextMenu = (event: CellContextMenuEvent) => {
    event.event.preventDefault();
    if (event.data.isSubSupplier) {
      setContextMenu({
        mouseX: (event.event as any).clientX,
        mouseY: (event.event as any).clientY,
        rowData: event.data,
      });
    } else {
      handleClose();
    }
  };

  // 追加
  const addSubSupplier = (rowData: any) => {
    const copyOriginRowData = [...dataSource1];
    const newSupplier = {
      id: rowData.id,
      key: 0,
      daikushu: rowData.daikushu,
      shoukoushu: rowData.shoukoushu,
      kikaku: '',
      suuryou: '',
      tani: '',
      tanka: 0,
      seisekisanKingaku: 0,
      gaisanKingaku: 0,
      bikou: '',
      isSubSupplier: true,
    };
    copyOriginRowData.push(newSupplier);
    idSorting(copyOriginRowData, true);
  };

  // 削除
  const deleteSubSupplier = (index: number) => {
    const copyDeleteRowData = [...dataSource1];
    const newDeleteRowData = [];
    copyDeleteRowData.forEach((item, i) => {
      if (copyDeleteRowData[i].id !== index) {
        newDeleteRowData.push(item);
      }
    });
    idSorting(newDeleteRowData, false);
  };

  // メニュー項目のクリックを処理する
  const handleMenuItemClick = (action: string) => {
    if (contextMenu) {
      switch (action) {
        case 'add':
          addSubSupplier(contextMenu.rowData);
          break;
        case 'delete':
          deleteSubSupplier(contextMenu.rowData.id);
          break;
        default:
      }
      handleClose();
    }
  };

  // メニューを閉じる
  const handleClose = () => {
    setContextMenu(null);
  };

  const defaultColDef = useMemo(() => {
    return {
      editable: type === 'edit',
      singleClickEdit: true,
    };
  }, []);

  const getRowStyle = (params: any) => {
    if (!params.data.shoukoushu) {
      return { backgroundColor: '#BCF5D6' };
    }
    return null;
  };

  // 明細項目定義
  const table1ColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
      editable: false,
      cellClass: 'center-cell',
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
    },
    {
      headerName: '区分/大工種',
      field: 'daikushu',
      width: 160,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: daikushuParams,
      },
      children: [
        {
          headerName: '小工種',
          field: 'shoukoushu',
          width: 160,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: shoukoushuParams,
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.daikushu : params.data.shoukoushu;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikushu = params.newValue;
            } else {
              params.data.shoukoushu = params.newValue;
            }
            return true;
          },
          editable: params => {
            if (!params.data.isSubSupplier || type !== 'edit') {
              return false;
            } else {
              return true;
            }
          },
        },
      ],
    },
    {
      headerName: '規格',
      field: 'kikaku',
      width: 145,
      spanRows: true,
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
      editable: params => {
        if (!params.data.isSubSupplier || type !== 'edit') {
          return false;
        } else {
          return true;
        }
      },
    },
    {
      headerName: '数量',
      field: 'suuryou',
      width: 100,
      children: [
        {
          headerName: '単位',
          field: 'tani',
          width: 100,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: taniParams,
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.suuryou : params.data.tani;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.suuryou = params.newValue;
            } else {
              params.data.tani = params.newValue;
            }
            return true;
          },
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'center-cell'),
          editable: params => {
            if (!params.data.isSubSupplier || type !== 'edit') {
              return false;
            } else {
              return true;
            }
          },
        },
      ],
    },
    {
      headerName: '単価',
      field: 'tanka',
      width: 180,
      cellClass: 'end-cell',
      children: [
        {
          headerName: '合計金額/精積算金額',
          field: 'seisekisanKingaku',
          cellClass: 'end-cell',
          width: 180,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.tanka : params.data.seisekisanKingaku;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.tanka = Number(params.newValue);
            } else {
              params.data.seisekisanKingaku = Number(params.newValue);
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
          editable: params => {
            if (!params.data.isSubSupplier || type !== 'edit') {
              return false;
            } else {
              return true;
            }
          },
        },
      ],
    },
    {
      headerName: '',
      field: '',
      width: 180,
      children: [
        {
          headerName: '合計金額/概算金額',
          field: 'gaisanKingaku',
          cellClass: 'end-cell',
          width: 180,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? '' : params.data.gaisanKingaku;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              // params.data.tanka = params.newValue;
            } else {
              params.data.gaisanKingaku = Number(params.newValue);
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
          cellStyle: params => {
            if (params.node.rowIndex % 2 === 0 && params.data.shoukoushu) {
              return { backgroundColor: '#EEEBEB' };
            }
            return null;
          },
          editable: params => {
            if (!params.data.isSubSupplier || type !== 'edit') {
              return false;
            } else {
              return true;
            }
          },
        },
      ],
    },
    {
      headerName: '備考',
      field: 'bikou',
      width: 150,
      spanRows: true,
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
      editable: params => {
        if (!params.data.isSubSupplier || type !== 'edit') {
          return false;
        } else {
          return true;
        }
      },
    },
  ]);

  // 支払条件明細項目定義
  const requestColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '支払条件名',
      field: 'shiharaiJoukenName',
      width: 200,
      cellClass: 'center-cell',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: seikyuuJoukenNameParams,
      },
    },
    {
      headerName: '隔合',
      field: 'kakuGou',
      width: 150,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          Intl.NumberFormat('en-US').format(params.value);
          return params.value + '%';
        } else {
          return '%';
        }
      },
    },
    {
      headerName: '支払金額',
      field: 'shiharaiKingaku',
      width: 215,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('en-US').format(params.value);
        }
      },
    },
    {
      headerName: '消費税金額',
      field: 'shouhizeiKingaku',
      width: 215,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('en-US').format(params.value);
        }
      },
    },
  ]);

  useEffect(() => {
    const sagyouInList = DBManager.getMockList(WebD0010);
    if (id) {
      const editData = sagyouInList.find(item => item.id.toString() === id) || null;
      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('ankenCode', editData.ankenCode);
        setValue('ankenName', editData.ankenName);
        setValue('gaisanCodePart1', editData.gaisanCode);
        setValue('gaisanCodePart2', '00');
        setValue('ankenKanaName', 'アイウエオ');
        setValue('seisekisanCodePart1', editData.seisekisanCode);
        setValue('seisekisanCodePart2', '01');
        setValue('seisekisanBumon', '財務部');
        setValue('seisekisanHizuke', '2025-03-21');
        setValue('seisekisanTantoumono', '佐藤 愛菜');
        setValue('items.0.value', '添付ファイル.png');
        setValue('elia', 'typeA');
        setValue('yuubinBangouPart1', '01001');
        setValue('yuubinBangouPart2', '0001');
        setValue('juchuuMikomiNichi1', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
        setValue('juchuuMikomiNichi2', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
        setValue('eigyouBumon', '01');
        setValue('eigyouKanrishoku', '01');
        setValue('eigyouTantouMono', '01');
        setValue('kanminKubun', '民間');
        setValue('teishutsuKigen', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
      }
    }

    // 精積算明細のデータ
    const tempDataSource = [];
    for (let i = 0; i < 5; i++) {
      if (i < 2) {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          daikushu: '土工事',
          shoukoushu: '配管工',
          kikaku: 'メートル' + (i + 1),
          suuryou: '1.00',
          tani: '式',
          tanka: 400000,
          seisekisanKingaku: 1100000,
          gaisanKingaku: 1000000,
          bikou: '備考内容' + (i + 1),
          isSubSupplier: true,
        });
      } else {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          daikushu: '鉄筋工',
          shoukoushu: '配管工',
          kikaku: 'メートル' + (i + 1),
          suuryou: '1.00',
          tani: '式',
          tanka: 400000,
          seisekisanKingaku: 1100000,
          gaisanKingaku: 1000000,
          bikou: '備考内容' + (i + 1),
          isSubSupplier: true,
        });
      }
    }
    setDataSource(tempDataSource);

    // 合計生成
    totalAmountCompute(tempDataSource);

    // 案件情報のデータ
    const tempDataSource2 = [];
    for (let i = 0; i < 4; i++) {
      tempDataSource2.push({
        shiharaiJoukenName: '延期付款',
        kakuGou: 2 + i,
        shiharaiKingaku: i + 600000,
        shouhizeiKingaku: i + 500000,
      });
    }
    setDataSource2(tempDataSource2);
    const newCurData2 = [];
    for (let i = 0; i < tempDataSource2.length; i++) {
      newCurData2.push(tempDataSource2[i]);
      newCurData2.push(tempDataSource2[i]);
    }
    setDataSource2(newCurData2);

    // 合計行
    totalRowData(tempDataSource2);

    // データ保存
    const contractList = [];
    contractList.push({ ...dataSource, ...dataSource2 });
    localStorage.setItem('WebD0030', JSON.stringify(contractList));

    // タイトル
    setPageTitle('精積算作成');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webd0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{`【最終更新日】`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit" disabled={isHensyuuKengen}>
              保存
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {}}
              disabled={isHensyuuKengen}
            >
              申請
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {}}
              disabled={isHensyuuKengen}
            >
              クリア
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {}}
              disabled={isHensyuuKengen}
            >
              削除
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/WebD0010`);
              }}
            >
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              印刷
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/WebE0010/${type}/webD/${id}`);
              }}
              disabled={isHensyuuKengen}
            >
              見積書印刷
            </Button>
          </div>
        </div>
        <Box component="form" onSubmit={onFinish} display="flex" flexDirection="column" gap={2} className="ad-search-seisekisan">
          {/*  案件コード/案件名 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="ankenCode"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>案件コード</label>
                    <TextField
                      {...field}
                      fullWidth
                      disabled
                      size="small"
                      sx={{
                        width: '227px',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      disabled={isHensyuuKengen}
                      style={{ minWidth: 96, height: 30.75, marginLeft: 6, whiteSpace: 'nowrap', marginTop: '3px' }}
                      onClick={ankenSanshou}
                    >
                      参照
                    </Button>
                  </div>
                )}
              />
            </Box>
            <Box flex={2} display="flex" justifyContent="space-between" sx={{ minWidth: '48%' }}>
              <Box flex={1}>
                <Controller
                  name="ankenName"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>案件名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={1} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  概算コード/案件カナ名 */}
          <Box display="flex" justifyContent="space-between">
            <Box className="ad-search-item" flex={2} mr={2}>
              <Box>
                <Controller
                  name="gaisanCodePart1"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>概算コード</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '165px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box>
                <Controller
                  name="gaisanCodePart2"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '65px' }} />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} display="flex" justifyContent="space-between" sx={{ marginLeft: '7.7%', minWidth: '48%' }}>
              <Box flex={1}>
                <Controller
                  name="ankenKanaName"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>案件カナ名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={1} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  精積算コード */}
          <Box display="flex" justifyContent="space-between">
            <Box className="ad-search-item" flex={2} mr={2}>
              <Box flex={4}>
                <Controller
                  name="seisekisanCodePart1"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>精積算コード</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '165px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="seisekisanCodePart2"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '100px' }} />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={3} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  精積算日付 */}
          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box display="flex" sx={{ mb: 2, maxWidth: '76.5%', marginBottom: '0px', height: 40 }} className="ad-search-container">
              <Box flex={1}>
                <Controller
                  name="seisekisanHizuke"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item cell-date-picker">
                      <label>精積算日付</label>
                      <DatePicker
                        label=""
                        {...field}
                        disableFuture={!!fieldState.error}
                        sx={{
                          width: '30%',
                          textAlignLast: 'end',
                          height: 7,
                        }}
                        format="YYYY年MM月DD日"
                        value={field.value ? dayjs(field.value) : null}
                      />
                      {/* <TextField
                      {...field}
                      size="small"
                      style={{ width: '30%', textAlignLast: 'end' }}
                      type="date"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      InputLabelProps={{ shrink: true }}
                    /> */}
                    </div>
                  )}
                />
              </Box>
            </Box>
          </LocalizationProvider>

          {/*  精積算部門 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="seisekisanBumon"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>精積算部門</label>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '300px',
                      }}
                    />
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  精積算担当者 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="seisekisanTantoumono"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>精積算担当者</label>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '227px',
                      }}
                    />
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  添付ファイル */}
          <Box display="flex" gap={2} justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <label>添付ファイル</label>
              <div className="margin-left-36">
                {fields.map((item, index) => (
                  <Collapse in={true} key={item.id}>
                    {index === fields.length - 1 && (
                      <div
                        onClick={() => append({ value: '' })}
                        color="primary"
                        style={{ marginTop: '6px', pointerEvents: isHensyuuKengen ? 'none' : 'all' }}
                      >
                        <AddCircleOutlineIcon />
                      </div>
                    )}
                    <Controller
                      name={`items.${index}.value`}
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item cell-date-picker">
                          <TextField
                            {...field}
                            fullWidth
                            variant="outlined"
                            error={!!errors.items?.[index]?.value}
                            sx={{
                              width: '300px',
                              marginLeft: '12px',
                              marginBottom: '12px',
                            }}
                          />
                          <Button
                            size="small"
                            variant="contained"
                            onClick={() => remove(index)}
                            disabled={isHensyuuKengen}
                            // prettier-ignore
                            style={{ minWidth: 96, height: '30.75px',  marginLeft: '2rem', marginTop: '3px'}}
                          >
                            削除
                          </Button>
                        </div>
                      )}
                    />
                  </Collapse>
                ))}
              </div>
            </Box>
          </Box>
          {/*  エリア */}
          <Box display="flex" justifyContent="space-between" sx={{ marginTop: '-12px' }}>
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="elia"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>エリア</label>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '227px',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">エリア A</MenuItem>
                      <MenuItem value="typeB">エリア B</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  積算入力済項目切替 */}
          <Box display="flex" justifyContent="space-between" marginLeft={'50px'}>
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="sekisanKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="積算金額が入力済みの項目のみ表示" />
                )}
              />
            </Box>
          </Box>
          {/* 明細テーブル */}
          <div
            className="ag-theme-alpine column-group-table"
            style={{ width: '100%' }}
            onContextMenu={e => {
              e.preventDefault();
            }}
          >
            <AgGridReact
              rowData={dataSource}
              theme={AGGridTheme}
              columnDefs={table1ColumnDefs.current}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              onCellContextMenu={onCellContextMenu}
              onCellEditingStopped={onCellEditingStopped}
              enableCellSpan
              domLayout="autoHeight"
            />
            <Menu
              open={contextMenu !== null}
              onClose={handleClose}
              anchorReference="anchorPosition"
              anchorPosition={contextMenu ? { top: contextMenu.mouseY, left: contextMenu.mouseX } : undefined}
            >
              {contextMenu?.rowData?.isSubSupplier && <MenuItem onClick={() => handleMenuItemClick('add')}>追加</MenuItem>}
              {contextMenu?.rowData?.isSubSupplier && <MenuItem onClick={() => handleMenuItemClick('delete')}>削除</MenuItem>}
            </Menu>
          </div>
          {/*  概算合計金額/精積算合計金額 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2}>
              <Controller
                name="gaisanGoukeiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item" style={{ width: '78%', marginLeft: '40%' }}>
                    <label style={{ minWidth: '110px' }}>概算合計金額</label>
                    <TextField {...field} fullWidth size="small" style={{ textAlignLast: 'end' }} />
                  </div>
                )}
              />
            </Box>
            <Box flex={2} mr={2}>
              <Controller
                name="seiSekisanGoukeiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item" style={{ width: '67.5%', marginLeft: '22%' }}>
                    <label style={{ minWidth: '110px' }}>精積算合計金額</label>
                    <TextField {...field} fullWidth size="small" style={{ textAlignLast: 'end' }} />
                  </div>
                )}
              />
            </Box>
            <Box flex={1} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  案件情報 */}
          <div style={{ marginLeft: '40px' }}>
            <div
              onClick={() => {
                setIsCollapse(!isCollapse);
              }}
            >
              {isCollapse ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
              <label style={{ marginLeft: '5px' }}>案件情報</label>
            </div>
          </div>
          <Box display="flex" justifyContent="space-between">
            <Box flex={1}></Box>
            <Box flex={12}>
              <Box style={{ border: '2px solid black' }} className={isCollapse ? 'hidden-seisekisan' : ''}>
                <Box display="flex" flexDirection="column" mt={2} mr={2} gap={2}>
                  {/*  郵便番号 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart1"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item2">
                              <label>郵便番号</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart2"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item1">
                              <label>-</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  物件住所 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2}>
                      <Controller
                        name="bukkenJuusho"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>物件住所</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  顧客コード/顧客様名 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="kokyakuCode"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>顧客コード</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="kokyakuName"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>顧客様名</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  郵便番号 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart3"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item2">
                              <label>郵便番号</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart4"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item1">
                              <label>-</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  顧客住所 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2}>
                      <Controller
                        name="kokyakuJuusho"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>顧客住所</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  官民区分/官庁分類 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="kanminKubun"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>官民区分</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="kanchouBunrui"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>官庁分類</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  見積提出期限 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={1} mr={2} className="ad-search-item">
                      <Controller
                        name="teishutsuKigen"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>見積提出期限</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px', textAlignLast: 'end' }} />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  敷地面積/建築面積 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="shikichiMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%' }}>
                            <label>敷地面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="shikichiMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="kenchikuMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%', marginLeft: '15%' }}>
                            <label>建築面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="kenchikuMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  延床面積/施工床面積 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="enyukaMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%' }}>
                            <label>延床面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="enyukaMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="sekouyukaMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%', marginLeft: '15%' }}>
                            <label>施工床面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="sekouyukaMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  専有面積 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="senyuuMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%' }}>
                            <label>専有面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="senyuuMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  戸数 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={3} mr={2} sx={{ minWidth: '30.4%' }}>
                      <Controller
                        name="kosuu"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>戸数</label>
                            <TextField {...field} fullWidth size="small" />
                            <label style={{ minWidth: '24px' }}>戸</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} mr={2}>
                      <Controller
                        name="chijou"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1">
                            <label style={{ textAlign: 'start', minWidth: '37px' }}>地上</label>
                            <TextField {...field} size="small" />
                            <div className="ad-search-item1">
                              <label>階</label>
                            </div>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} mr={2}>
                      <Controller
                        name="chika"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1">
                            <label style={{ textAlign: 'start', minWidth: '37px' }}>地下</label>
                            <TextField {...field} size="small" />
                            <div className="ad-search-item1">
                              <label>階</label>
                            </div>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={4}></Box>
                  </Box>
                  {/*  受注見込日 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="juchuuMikomiNichi1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>受注見込日</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                                textAlignLast: 'end',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="juchuuMikomiNichi2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>受注見込日</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                                textAlignLast: 'end',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  営業部門 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="eigyouBumon"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field, fieldState }) => (
                            <div className="ad-search-item2">
                              <label>営業部門</label>
                              <Select
                                {...field}
                                size="small"
                                error={!!fieldState.error}
                                sx={{
                                  width: '280px',
                                }}
                                displayEmpty
                              >
                                <MenuItem value="01">東京工事部門 - 営業部</MenuItem>
                                <MenuItem value="02">旧工事部門 - 営業部</MenuItem>
                              </Select>
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  営業管理職/営業担当者 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="eigyouKanrishoku"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>営業管理職</label>
                            <Select
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                              }}
                              displayEmpty
                            >
                              <MenuItem value="01">鈴木 太郎</MenuItem>
                              <MenuItem value="02">田中 嶽</MenuItem>
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="eigyouTantouMono"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>営業担当者</label>
                            <Select
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                              }}
                              displayEmpty
                            >
                              <MenuItem value="01">保手 橋本</MenuItem>
                              <MenuItem value="02">楽天 湯村</MenuItem>
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  設計業者/設計担当者 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="sekkeiGyousha"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>設計業者</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="sekkeiTantouMono"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>設計担当者</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>

                  <Box display="flex" justifyContent="space-between">
                    <Box flex={1} mr={2} className="ad-search-item">
                      <div className="ad-search-item2">
                        <label style={{ paddingTop: '4px' }}>支払条件</label>
                      </div>
                    </Box>
                    <Box flex={6}></Box>
                  </Box>
                  <div
                    className="ag-theme-alpine column-group-table"
                    style={{ width: '100%', paddingLeft: '100px', marginTop: '-20px', marginBottom: '20px' }}
                  >
                    <AgGridReact
                      rowData={dataSource2}
                      theme={AGGridTheme}
                      columnDefs={requestColumns.current}
                      defaultColDef={defaultColDef}
                      onCellEditingStopped={onCellEditingStopped1}
                      getRowStyle={params => {
                        if (params.data.shiharaiJoukenName === '合計') {
                          return { fontWeight: 'bold', backgroundColor: '#f5f5f5' };
                        }
                        return null;
                      }}
                      domLayout="autoHeight"
                      enableCellSpan
                      suppressRowTransform
                      gridOptions={{
                        defaultColDef: {
                          resizable: false,
                          sortable: false,
                        },
                        autoSizeStrategy: {
                          type: 'fitGridWidth',
                        },
                      }}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebD0030CreateForm;
