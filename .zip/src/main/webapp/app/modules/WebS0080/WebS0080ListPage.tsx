import React, { useRef, useState, useEffect } from 'react';
import '../../app.scss';
import './WebS0080ListPage.scss';
import WebS0080SearchDialog from './SearchDialog/WebS0080SearchDialog';
import { STORAGE_KEY_SHONIN_GYOSHA, DBManager, shoninGyoshaList } from 'app/shared/util/construction-list';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import { Column, FieldType, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';

const WebS0080ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });
  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';
  const [rowData, setRowData] = useState([]);

  // 列の設定
  const columnRef = useRef<Array<Column>>([
    {
      id: 'No',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'gyoushaCode',
      name: '業者コード',
      field: 'gyoushaCode',
      width: 130,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gyoushaName',
      name: '業者名・業者支店名',
      field: 'gyoushaName',
      width: 270,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kaitaiTouroku',
      name: '解体登録',
      field: 'kaitaiTouroku',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'keibiNintei',
      name: '警備認定',
      field: 'keibiNintei',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'sanpaiKyoka',
      name: '産廃許可',
      field: 'sanpaiKyoka',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      width: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 60,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'text-align-center',
    },
  ]);
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let gyoushaList = DBManager.getShoninGyoshaList();
    // const gyoushaList = generatGyoushaData(500);
    if (gyoushaList.length === 0) {
      gyoushaList = shoninGyoshaList(500);
      // 番号作成
      gyoushaList = gyoushaList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SHONIN_GYOSHA, JSON.stringify(gyoushaList));
    }
    setRowData(gyoushaList);
  };
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('承認一覧（協力業者管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div className="webS0080-list" id="webS0080-list-container">
      <div className="top-operation">
        <div>
          <WebS0080SearchDialog onSearch={handleSearch} />
        </div>
      </div>

      {/* テーブルエリア */}
      <BasicSlickGridTable
        columns={columnRef.current}
        data={rowData}
        onSelectionChanged={onSelectedRowsChanged}
        enableContextMenu
        contextMenuItems={[
          // TODO:正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
          {
            title: '参照',
            command: 'preview',
            action: (_, callbackArgs) => {
              navigate(`/webO0030/preview/${callbackArgs.dataContext.id}`);
            },
          },
        ]}
      />
    </div>
  );
};

export default WebS0080ListPage;
