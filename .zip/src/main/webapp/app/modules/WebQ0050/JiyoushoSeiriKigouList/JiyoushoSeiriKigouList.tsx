import React, { useRef, useState } from 'react';
import { CellContextMenuEvent, ColDef, ColGroupDef, GridReadyEvent, IHeaderParams } from 'ag-grid-community';
import dayjs from 'dayjs';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import './JiyoushoSeiriKigouList.scss';
import CustomCellEditor from '../CustomCellEditor';

const JiyoushoSeiriKigouList = ({ rowData }: { rowData: any }) => {
  // useEffect(() => {}, []);

  // 列の定義
  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    // 区分
    {
      headerName: '区分',
      field: 'kubun',
      width: 110,
      cellClass: 'text-center',
      editable: false,
      cellStyle: {
        backgroundColor: '#e7e7e7', // 背景色强调
      },
    },
    // 営業所の名称
    {
      headerName: '営業所の名称',
      field: 'eigyojoNomMisho',
      width: 190,
    },
    // 健康保険
    {
      headerName: '健康保険',
      field: 'kenkouhoken',
      width: 220,
    },
    // 厚生年金保険
    {
      headerName: '厚生年金保険',
      field: 'kyokabiSetteibihoken',
      width: 165,
      cellClass: 'text-right',
    },
    // 雇用保険
    {
      headerName: '雇用保険',
      field: 'koyouhoken',
      width: 164,
      cellClass: 'text-right',
    },
  ]);

  return (
    <>
      <div
        className="jiyoushoSeiriKigou-table"
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        <AgGridReact
          columnDefs={columnRef.current}
          domLayout="normal"
          theme={AGGridTheme}
          rowData={rowData}
          headerHeight={30}
          rowHeight={30}
          gridOptions={{
            defaultColDef: {
              // flex: 1,
              // resizable: false,
              // sortable: false,
              editable: true,
            },
            components: {
              customCellEditor: CustomCellEditor, // 注册自定义编辑器
            },
          }}
        />
      </div>
    </>
  );
};

export default JiyoushoSeiriKigouList;
