import React, { useState, useEffect } from 'react';

// 自定义单元格编辑器组件
const CustomCellEditor = props => {
  const { value, api, column, colDef, node } = props;

  // 初始值处理
  const [input1, setInput1] = useState(value ? value.charAt(0) : ''); // 第一个输入框（汉字）
  const [input2, setInput2] = useState(value ? value.slice(1) : ''); // 第二个输入框（字符）

  // 处理用户输入变化
  const handleInput1Change = e => {
    setInput1(e.target.value);
  };

  const handleInput2Change = e => {
    setInput2(e.target.value);
  };

  // 当用户结束编辑时，保存值
  const saveValue = () => {
    const finalValue = input1 + '-' + input2;
    props.setValue(finalValue); // 设置最终的单元格值
    api.stopEditing(); // 停止编辑并保存数据
  };

  // 使用 Enter 或 Tab 键结束编辑
  const handleKeyDown = event => {
    if (event.key === 'Enter') {
      saveValue();
    }
  };

  // 设置焦点
  useEffect(() => {
    setTimeout(() => {
      // 给第一个输入框设置焦点
      document.getElementById('input1').focus();
    }, 0);
  }, []);

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <input
        id="input1"
        type="text"
        value={input1}
        onChange={handleInput1Change}
        maxLength={1} // 限制输入1个字符（汉字）
        style={{ width: '30px', marginRight: '5px' }}
      />
      <span>-</span>
      <input
        id="input2"
        type="text"
        value={input2}
        onChange={handleInput2Change}
        maxLength={5} // 限制输入最多5个字符
        style={{ width: '50px', marginLeft: '5px' }}
        onKeyDown={handleKeyDown} // 按回车保存
      />
    </div>
  );
};

export default CustomCellEditor;
