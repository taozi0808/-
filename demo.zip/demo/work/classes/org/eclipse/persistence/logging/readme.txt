http://wiki.eclipse.org/EclipseLink/Examples/Foundation/Logging#Using_Log4J

How to use Log4J :

- add apache commons logging 1.1 & log4J libraries in your classpath

- add the sample log4.xml in your classpath : log4j.xml template

- add the following classes in the org.eclipse.persistence.logging package of your own project : CommonsLoggingSessionLog class : FastLogFormatter class

- add the property eclipselink.logging.logger to your persistence.xml :
<property name="eclipselink.logging.logger" value="org.eclipse.persistence.logging.CommonsLoggingSessionLog"/>

- add the property eclipselink.logging.level to your persistence.xml :
<property name="eclipselink.logging.level" value="severe" />
<!--
    # -----------------------------------------------------------------------------
    # Logging level :
    #        OFF : disables logging
    #        SEVERE : logs exceptions indicating EclipseLink cannot continue, as well as any exceptions generated during login. This includes a stack trace.
    #        WARNING : logs exceptions that do not force EclipseLink to stop, including all exceptions not logged with severe level. This does not include a stack trace.
    #        INFO : logs the login/logout per sever session, including the user name. After acquiring the session, detailed information is logged.
    #        CONFIG : logs only login, JDBC connection, and database information.
    #        FINE : logs SQL.
    #        FINER : similar to warning. Includes stack trace.
    #        FINEST : includes additional low level information. 
    #
    # -----------------------------------------------------------------------------
   -->
