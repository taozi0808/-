
//　初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();

    // ラベル編集
	editLabelText();
	
	// 一覧のラベルの折り返しで表示
	editTableLabelCss();
};

// ラベル編集
function editLabelText (){
	
	const ids = ["sidJYUKOUSHA_FURIGANA_SEI_label", "sidJYUKOUSHA_SEINENGAPPI_label", "sidWEB_TEL_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
	
	const now = new Date();
	const year = now.getFullYear();
	const month = now.getMonth() + 1;
	const day = now.getDate();
	// システム日
	const today = `${year}/${month}/${day}`;
	const count = disp.get("ROW_CNT");
	// 有効期限
	for(i = 0; i< count; i++) {
		const el = document.getElementById("g[" + i + "].sidG_YUKO_KIGEN");
		if (el && el.textContent < today) {
			el.innerHTML = `<FONT COLOR="RED">${el.textContent}</FONT>`;
		}
	}
	
	// 固定文字列１
	var context = disp.get("CONST1");
	const elem = document.getElementById("sidCONST1");
	if (elem) {
		elem.innerHTML = context;
	}
	
	// 説明文言
	var context2 = disp.get("lbl_3");
	const elem2 = document.getElementById("sidlbl_3");
	if (elem2) {
		elem2.innerHTML = context2;
	}
}

//　検索結果と一覧を非表示にする
function isDisplay() {
    var colText1 = document.getElementById( "PART_sidlbl" );
    var colText2 = document.getElementById( "PART_sidG" );
    var colRowCnt = disp.getElement( "ROW_CNT" );
    
    if( colRowCnt.value == 0 ){
		// 件数 が「0」のとき非表示にする
        colText1.style.display = "none";  
        colText2.style.display = "none";
    }else{
        colText1.style.display = "block";
        colText2.style.display = "block";
    }
}

// 一覧のラベルの折り返しで表示
function editTableLabelCss() {

	// 一覧タイトル要素の取得
	const elems = document.querySelectorAll('table#TH_g thead tr th');
	// style属性を外す
	elems.forEach(elem => {
		elem.removeAttribute('style');
	});
}


