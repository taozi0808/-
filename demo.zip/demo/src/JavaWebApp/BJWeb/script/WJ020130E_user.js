
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	// メッセージ1~5
	for(i = 1; i< 6; i++) {
		let str = '0';
		var context = disp.get("BQ_WEB5_NOTE" + str + i + "_VALUE");
		const elem = document.getElementById("sidBQ_WEB5_NOTE" + str + i);
		if (elem) {
			elem.innerHTML = context;
		}
	}
	
	// 申込情報キャンセル完了コメントメッセージ1~5
	for(j = 1; j< 6; j++) {
		var context2 = disp.get("BQ_WEB26_NOTE" + j + "_VALUE");
		const elem2 = document.getElementById("sidBQ_WEB26_NOTE" + j);
		if (elem2) {
			elem2.innerHTML = context2;
		}
	}
	
	// 持ち物
	var mochimo = disp.get("MOCHIMO_VALUE");
	const el = document.getElementById("sidMOCHIMO");
	if (el) {
		el.innerHTML = mochimo;
	}
	
	// 服装
	var fukuzou = disp.get("FUKUZOU_VALUE");
	const ele = document.getElementById("sidFUKUZOU");
	if (ele) {
		ele.innerHTML = fukuzou;
	}
	
	// 注意事項1~5
	var content = disp.get("CHOYOU_VALUE");
	const e = document.getElementById("sidCHOYOU");
	if (e) {
		e.innerHTML = content;
	}
	
	const elYMD = document.getElementById("sidJISSHI_YMD");
	if (elYMD) {
		elYMD.innerHTML = highlightWeekendDates(elYMD.textContent);
	}
	
	let hiddenIds = [];
	var gamennId = disp.get("GAMENN_ID");
	// 事前学習資料
	var soufuFlag = disp.get("JIZENGAKU");
	// 配送を希望しません
	if (soufuFlag != '1') {
		hiddenIds = hiddenIds.concat(["PART_sidSOUFUSAKI_NO", "PART_sidSOUFUSAKI_JUSHO1", "PART_sidSOUFUSAKI_JUSHO2", "PART_sidSOUFUSAKI_JUSHO3"]);
	}
	var type = disp.get("KOSHU_SHUBETSU_ID");
	// 講習会申込画面遷移
	if (gamennId == 'WJ020110E') {
		// 患者搬送基礎を除く
		if (type != '41') {
			hiddenIds = hiddenIds.concat(["PART_sidJIZENGAKU"]);
			// 患者搬送・現場派遣を除く
			if (type != '43' && type != '31' && type != '33') {
				hiddenIds = hiddenIds.concat(["PART_sidKIMU_NAME"]);
		    }
		}
		// 申込情報検索画面遷移
	} else {
		hiddenIds = hiddenIds.concat(["PART_sidJIZENGAKU", "PART_sidKIMU_NAME"]);
	}
	
	var flag = disp.get("KYASEIRU_FLAG");
	// 申込
	if (flag == '0') {
		// 行政手続URL
		var link = disp.get("KYOSEI_URL");
		const elink = document.getElementById("sidKYOSEI_URL");
		if (elink) {
			elink.innerHTML = link;
		}
		// 教材購入URL
		var shopLink = disp.get("KIYO_SEI_URL");
		const eShopLink = document.getElementById("sidKIYO_SEI_URL");
		if (eShopLink) {
			eShopLink.innerHTML = shopLink;
		}
		// 事前学習用PDFのURL
		var pdfLink = disp.get("KIYO_SEI_PDF_URL");
		const ePdfLink = document.getElementById("sidKIYO_SEI_PDF_URL");
		if (ePdfLink) {
			ePdfLink.innerHTML = pdfLink;
		}
		hiddenIds = hiddenIds.concat(["PART_sidBQ_WEB26_NOTE1", "PART_sidBQ_WEB26_NOTE2", "PART_sidBQ_WEB26_NOTE3"
		           , "PART_sidBQ_WEB26_NOTE4", "PART_sidBQ_WEB26_NOTE5", "PART_sidUTSUKE_NO", "PART_sidDEIKI_NO"]);
	  // 空席連絡待ち           
	} else {
		hiddenIds = hiddenIds.concat(["PART_sidBQ_WEB5_NOTE01", "PART_sidBQ_WEB5_NOTE02", "PART_sidBQ_WEB5_NOTE03"
		           , "PART_sidBQ_WEB5_NOTE04", "PART_sidBQ_WEB5_NOTE05", "PART_sidBQ_WEB5_NOTE06"
		           , "PART_sidBQ_WEB5_NOTE07", "PART_sidBQ_WEB5_NOTE08", "PART_sidBQ_WEB5_NOTE09"
		           , "PART_sidBQ_WEB5_NOTE10", "PART_sidDEIKI_NO", "PART_sidMOCHIMO"
		           , "PART_sidCHOYOU", "PART_sidKIYO_SEI", "PART_sidKYOSEI_URL", "PART_sidKIYO_SEI_URL"]);
	}
	
	
    // ラベル要素取得
	hiddenIds.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = 'none';
		}
	});
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, `<FONT COLOR="RED">$1</FONT>`);
}
