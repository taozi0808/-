
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	// メッセージ1~5
	for(i = 1; i< 6; i++) {
		var context = disp.get("BQ_WEBD6_NOTE" + i + "_VALUE");
		const elem = document.getElementById("sidBQ_WEBD6_NOTE" + i);
		if (elem) {
			elem.innerHTML = context;
		}
	}
	
	// 持ち物
	var mochimo = disp.get("MOCHIMO_VALUE");
	const el = document.getElementById("sidMOCHIMO");
	if (el) {
		el.innerHTML = mochimo;
	}
	
	// 服装
	var fukuzou = disp.get("FUKUZOU_VALUE");
	const ele = document.getElementById("sidFUKUZOU");
	if (ele) {
		ele.innerHTML = fukuzou;
	}
	
	// 注意事項1~5
	var content = disp.get("CHOYOU_VALUE");
	const e = document.getElementById("sidCHOYOU");
	if (e) {
		e.innerHTML = content;
	}
	
	// 行政手続URL
	var link = disp.get("KYOSEI_URL");
	const elink = document.getElementById("sidKYOSEI_URL");
	if (elink) {
		elink.innerHTML = link;
	}
	
	// 教材購入URL
	var shopLink = disp.get("KIYO_SEI_URL");
	const eShopLink = document.getElementById("sidKIYO_SEI_URL");
	if (eShopLink) {
		eShopLink.innerHTML = shopLink;
	}
	
	// 事前学習用PDFのURL
	var pdfLink = disp.get("KIYO_SEI_PDF_URL");
	const ePdfLink = document.getElementById("sidKIYO_SEI_PDF_URL");
	if (ePdfLink) {
		ePdfLink.innerHTML = pdfLink;
	}
	
	// 講習実施日
	const elYMD = document.getElementById("sidJISSHI_YMD");
	if (elYMD) {
		elYMD.innerHTML = highlightWeekendDates(elYMD.textContent);
	}
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}
