
//　初期表示
window.onload = function() {

    // ラベル編集
	editLabelText();
	
	// 講習会開始日の入力欄の初期化	
	copyElements();
};

// ラベル編集
function editLabelText (){
	
	const ids = ["sidWEB_DANTAI_SHOBOSYO_label", "sidWEB_DANTAI_NAME_label", "sidWEB_DANTAI_MAILADDRESS_label"
	, "sidWEB_DANTAI_TEL_label", "sidDANTAIMEI_USER_label", "sidDANTAIMEI_REQ_label", "sidJISSHI_YMD_ST_label"
	, "sidKOSHU_SHUBETSU_ID_label", "sidKOSHU_JIKAN_FROM_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
	
	// メッセージ1~5
	for(i = 1; i< 6; i++) {
		var context = disp.get("BQ_WEBD1_NOTE_VALUE" + i);
		const el = document.getElementById("sidBQ_WEBD1_NOTE" + i);
		if (el) {
			el.innerHTML = context;
		}
	}
}

/* 講習開始時間 */
var elem = disp.getElement("KOSHU_JIKAN_FROM");
addEventHandler(elem, "onblur", setKOSHU_FROM_VALUE);
function setKOSHU_FROM_VALUE() {
    let value = elem.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        elem.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

function copyElements(){
	const oldElem1 = document.getElementById("sid_WAREKI_Y_LABEL_f");
	const oldElem2 = document.getElementById("sid_WAREKI_M_f");
	const oldElem3 = document.getElementById("sid_WAREKI_M_LABEL_f");
	const oldElem4 = document.getElementById("sid_WAREKI_D_f");
	const oldElem5 = document.getElementById("sid_WAREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_WAREKI_Y_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);	
}

