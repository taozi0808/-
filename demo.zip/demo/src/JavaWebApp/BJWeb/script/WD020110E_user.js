//　初期表示
window.onload = function() {
	 
	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	const type = disp.get("TYPE");
	typeList = ["新規登録", "削除"];
	// コメント1,2,6,7,8
	for(i = 1; i< 9; i++) {
		if (i == 3 || i == 4 || i == 5) {
			continue;
		}
		var context = disp.get("BQ_WEB5_NOTE" + i);
		// 現在の処理：新規登録 || 削除
		if (i == 8 && type) {
			context = context.replace('{1}', typeList[type - 1]);
		}
		const elem = document.getElementById("sidBQ_WEB5_NOTE" + i);
		if (elem) {
			elem.innerHTML = context;
		}
	}
	
	const count = disp.get("ROW_CNT");
	// 講習実施日
	for(j = 0; j < 8; j++) {
		const el = document.getElementById("g[" + j + "].sidG_JISSHI_YMD");
		if (el) {
			el.innerHTML = highlightWeekendDates(el.textContent);
		}
	}
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}
