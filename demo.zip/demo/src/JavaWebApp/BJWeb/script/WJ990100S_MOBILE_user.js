//　初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();

    // ラベル編集
	editLabelText();
	
	// 講習会開始日の入力欄の初期化	
	copyElements();
};

// ラベル編集
function editLabelText (){
	
	const ids = ["sidJYUKOUSHA_FURIGANA_SEI_label", "sidJYUKOUSHA_SEINENGAPPI_label", "sidWEB_TEL_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
}

//　検索結果と一覧を非表示にする
function isDisplay() {
    var colText1 = document.getElementById( "sid_lbl_f" );
    var colText2 = document.getElementById( "sid_lbl_2_f" );
    var colText3 = document.getElementById( "L_G" );
    var colRowCnt = disp.getElement( "ROW_CNT" );
    
    if( colRowCnt.value == 0 ) {
		// 件数 が「0」のとき非表示にする
        colText1.style.display = "none";  
        colText2.style.display = "none";  
        colText3.style.display = "none";    
    } else {
        colText1.style.display = "block";
        colText2.style.display = "block";
        colText3.style.display = "block"; 
    }
}

// 一覧のラベルの折り返しで表示
function editTableLabelCss() {

	// 一覧タイトル要素の取得
	const elems = document.querySelectorAll('table#TH_g thead tr th');
	// style属性を外す
	elems.forEach(elem => {
		elem.removeAttribute('style');
	});
}

function copyElements(){
	const oldElem1 = document.getElementById("sid_WAREKI_Y_f");
	const oldElem2 = document.getElementById("sid_WAREKI_Y_LABEL_f");
	const oldElem3 = document.getElementById("sid_WAREKI_M_f");
	const oldElem4 = document.getElementById("sid_WAREKI_M_LABEL_f");
	const oldElem5 = document.getElementById("sid_WAREKI_D_f");
	const oldElem6 = document.getElementById("sid_WAREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_WAREKI_NENGOU_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);
	toDiv.appendChild(oldElem6);
}




