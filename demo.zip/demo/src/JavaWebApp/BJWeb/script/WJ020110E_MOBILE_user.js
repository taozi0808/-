
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();

	// 西暦と和暦の入力欄の初期化	
	copyElements();
	copyElements_Seireki();
};

function copyElements(){
	const oldElem1 = document.getElementById("sid_WAREKI_Y_f");
	const oldElem2 = document.getElementById("sid_WAREKI_Y_LABEL_f");
	const oldElem3 = document.getElementById("sid_WAREKI_M_f");
	const oldElem4 = document.getElementById("sid_WAREKI_M_LABEL_f");
	const oldElem5 = document.getElementById("sid_WAREKI_D_f");
	const oldElem6 = document.getElementById("sid_WAREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_WAREKI_NENGOU_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);
	toDiv.appendChild(oldElem6);	
}


function copyElements_Seireki(){
	const oldElem1 = document.getElementById("sid_SEIREKI_Y_LABEL_f");
	const oldElem2 = document.getElementById("sid_SEIREKI_M_f");
	const oldElem3 = document.getElementById("sid_SEIREKI_M_LABEL_f");
	const oldElem4 = document.getElementById("sid_SEIREKI_D_f");
	const oldElem5 = document.getElementById("sid_SEIREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_SEIREKI_Y_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);
}

// ラベル編集
function editLabelText (){
	
	const ids = ["sidJYUKOUSHA_HOYU_NINTEISHO_NO_label", "label sidJYUKOUSHA_FURIGANA_SEI_label", "sidJYUKOUSHA_SEINENGAPPI_label" , 
					"sidJYUKOUSHA_SEIBETSU_label", "sidJYUKOUSHA_TEL_label", "sidJYUKOUSHA_MAIL_ADDRESS_label",
					"sidJYUKOUSHA_MAIL_ADDRESS_KAKUNI_label", "sidKIMU_NAME_label", "sidKIMUSHA_TEL_label",
					"sidJITAKU_JYUKOUSHA_JUSHO1_label", "sidJITAKU_JYUKOUSHA_JUSHO2_label", "sidJYUKOUSHA_SEI_label", "sidJYUKOUSHA_FURIGANA_SEI_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
	var type = disp.get("KOSHU_SHUBETSU_ID");
	if (type != 41 && type != 43 && type != 31 && type != 33 ) {
		const hiddenIds = ["PART_sidJYUKOUSHA_SEI", "PART_sidJITAKU_JYUKOUSHA_JUSHO1", "PART_sidJITAKU_JYUKOUSHA_JUSHO2",
		             "PART_sidJITAKU_KINMUSAKI_JUSHO", "PART_sidKIMU_NAME", "PART_sidKIMUSHA_TEL"];
		
		// ラベル要素取得
		hiddenIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.style.display = 'none';
			}
		});
	}
	var flag = disp.get("KYASEIRU_FALG");
	if (flag != '0') {
		const readonlyIds = ["sidJYUKOUSHA_HOYU_NINTEISHO_NO", "sidBANNGO_SEARCH", "sidJYUKOUSHA_SEI_VALUE"
		                   , "sidJYUKOUSHA_MEI_VALUE", "sidJITAKU_JYUKOUSHA_JUSHO1", "sidJITAKU_JYUKOUSHA_JUSHO2"
		                   , "sidJITAKU_KINMUSAKI_JUSHO", "sidJYUKOUSHA_TEL", "sidKIMU_NAME"
		                   , "sidKIMUSHA_TEL", "sidKIYO_SEI_field"];
		                   
	    // ラベル要素取得
		readonlyIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.classList.add('item__COM_DISABLE');
			}
		});
	}
}

