
//　初期表示
window.onload = function() {

    // ラベル編集
	editLabelText();
	
	// 西暦と和暦の入力欄の初期化	
	copyElements();
	copyElements_Seireki();
};

function copyElements(){
	const oldElem1 = document.getElementById("sid_WAREKI_Y_f");
	const oldElem2 = document.getElementById("sid_WAREKI_Y_LABEL_f");
	const oldElem3 = document.getElementById("sid_WAREKI_M_f");
	const oldElem4 = document.getElementById("sid_WAREKI_M_LABEL_f");
	const oldElem5 = document.getElementById("sid_WAREKI_D_f");
	const oldElem6 = document.getElementById("sid_WAREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_WAREKI_NENGOU_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);
	toDiv.appendChild(oldElem6);	
}


function copyElements_Seireki(){
	const oldElem1 = document.getElementById("sid_SEIREKI_Y_LABEL_f");
	const oldElem2 = document.getElementById("sid_SEIREKI_M_f");
	const oldElem3 = document.getElementById("sid_SEIREKI_M_LABEL_f");
	const oldElem4 = document.getElementById("sid_SEIREKI_D_f");
	const oldElem5 = document.getElementById("sid_SEIREKI_D_LABEL_f");
	const toDiv =  document.getElementById("sid_SEIREKI_Y_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);
}


// ラベル編集
function editLabelText (){
	
	const ids = ["sidO_YM_label", "sidKOSHU_SHUBETSU_ID_label", "sidJYUKOUSHA_FURIGANA_SEI_label" , 
					"sidJYUKOUSHA_FURIGANA_MEI_label", "sidJYUKOUSHA_SEINENGAPPI_label" , "sidJYUKOUSHA_SEIBETSU_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
}

