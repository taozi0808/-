// 初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();
};

//　検索結果と一覧を非表示にする
function isDisplay() {
	var radio1 = disp.get("DANTAIMEI_USER");
	var radio2 = disp.get("DANTAIMEI_REQ");
	// 隠す要素のIDリスト
	hiddenIds = ["PART_sidlbl_11", "PART_sidlbl_13"];
	
	// ラジオボタンの選択肢に基づいてカラムの表示/非表示を制御
	// 個人登録 + 個人払い
    if (radio1 == '1' && radio2 == '1') {
   		hideColumn([3, 5, 6, 7, 10]);
   		// ラベル要素取得
		hiddenIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.style.display = 'none';
			}
		});
	// 個人登録 + 団体一括払い
    } else if (radio1 == '1' && radio2 == '2') {
   		hideColumn([3, 5, 6, 7, 8, 9]);
   		// ラベル要素取得
		hiddenIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.style.display = 'none';
			}
		});
	// 団体一括登録 + 個人払い
    } else if (radio1 == '2' && radio2 == '1') {
   		hideColumn([2, 10]);
   	// 団体一括登録 + 団体一括払い
    } else if (radio1 == '2' && radio2 == '2') {
   		hideColumn([2, 9, 10]);
    }
    // colgroup の特定のカラムを削除
    var cols = document.querySelectorAll("col[id='sidG_status_COLGROUP']");
	cols.forEach(function(col) {
	    col.remove();
	});
	var table = document.getElementById("TH_g");
	var ths = table.querySelectorAll("th:first-child");
    ths.forEach(function(th) {
        th.remove();
    });
    
	var table2 = document.getElementById("TB_g");
    var tds = table2.querySelectorAll("td:nth-child(2)");
    tds.forEach(function(td) {
        td.remove();
    });
    // チェックボックスをラジオボタンに変換する処理
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
	checkboxes.forEach(checkbox => {
	const parentSpan = checkbox.parentElement;
	if (parentSpan.classList.contains('BOOL')) {
	    checkbox.type = 'radio';
	    const labelSpan = parentSpan.querySelector('.checkbox_label');
	    if (labelSpan) {
	      labelSpan.className = 'radio_label';
	    }
	  }
	});
	
	// 新しく追加した行の内容を設定
	var table = document.getElementById("TB_g");
	var firstRow = table.getElementsByTagName("tbody")[0];
	var trRow = firstRow.getElementsByTagName("tr")[0];
	var newRow = trRow.cloneNode(true);
	firstRow.appendChild(newRow);
	const tdRow = firstRow.getElementsByTagName("tr")[1].querySelectorAll('td');
    tdRow[1].querySelector('span').textContent = 'B.xlsx';
    tdRow[2].querySelector('span').textContent = '2025/11/26 10:00';
    tdRow[3].querySelector('span').textContent = '4';
    tdRow[4].querySelector('span').textContent = '確定';
}

function hideColumn(colIndex) {
    var table = document.getElementById("TH_g_2");
    var selectorName = ["col[id='sidROWNO_COLGROUP']", "col[id='sidG_UKETSUKE_NO_COLGROUP']", "col[id='sidG_NINTEISHO_NO_COLGROUP']"
    , "col[id='sidG_JYUKOUSHA_NAME_COLGROUP']", "col[id='sidG_SEINENGAPPI_COLGROUP']", "col[id='sidG_TEL_COLGROUP']", "col[id='sidG_MAIL_ADDRESS_COLGROUP']"
    , "col[id='sidG_KIYO_SEI_COLGROUP']", "col[id='sidG_NYUKIN_KBN_COLGROUP']", "col[id='sidG_DELETE_COLGROUP']"];
    let num = 0;
    for(let i = 0; i < colIndex.length; i++) {
		var cols = document.querySelectorAll(selectorName[colIndex[i] - 1]);
		cols.forEach(function(col) {
		    col.remove();
		});
		
	    var ths = table.querySelectorAll("th:nth-child(" + (colIndex[i] - num) + ")");
	    ths.forEach(function(th) {
	        th.remove();
	    });
	    
	    var table2 = document.getElementById("TB_g_2");
	
	    var tds = table2.querySelectorAll("td:nth-child(" + (colIndex[i] + 1 - num) + ")");
	    tds.forEach(function(td) {
	        td.remove();
	    });
	    
	    num = num + 1;
    }

}

