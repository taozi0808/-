//　初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();
	 
	// ラベル編集
	editLabelText();
	
	const dateIds = ["MOUSHIKOMI_FROM", "MOUSHIKOMI_TO", "JISSHI_FROM", "JISSHI_TO"];
	
	dateIds.forEach(function(name) {
		// 申込受付期間、実施年月日の入力欄の初期化	
		copyElements(name);
	});
};

// 選択リストの選択状態をクリア
function clearSelect(selCtrl) {
  if (selCtrl.multiple) {
    // 複数選択の場合
    for (let option of selCtrl.options) {
      option.selected = false;
    }
  } else {
    // 単一選択の場合
    selCtrl.selectedIndex = -1;
  }
}

//　検索結果と一覧を非表示にする
function isDisplay() {
    var colText1 = document.getElementById( "sid_lbl_f" );
    var colText2 = document.getElementById( "sid_lbl_2_f" );
    var colText3 = document.getElementById( "sid_NOTE1_f" );
    var colText4 = document.getElementById( "sid_NOTE2_f" );
    var colText5 = document.getElementById( "sid_NOTE3_f" );
    var colText6 = document.getElementById( "sid_NOTE4_f" );
    var colText7 = document.getElementById( "sid_NOTE5_f" );
    var colText8 = document.getElementById( "sid_NOTE6_f" );
    var colText8 = document.getElementById( "sid_NOTE7_f" );
    var colText9 = document.getElementById( "G_listview_label" );
    var colText10 = document.getElementById( "L_G" );
    var colRowCnt = disp.getElement( "ROW_CNT" );
    
    //console.log(disp.get( "sidROW_CNT" ));
    if( colRowCnt.value == 0 ){
		// 件数 が「0」のとき非表示にする
        colText1.style.display = "none";  
        colText2.style.display = "none";  
        colText3.style.display = "none";  
        colText4.style.display = "none";  
        colText5.style.display = "none";  
        colText6.style.display = "none";  
        colText7.style.display = "none";  
        colText8.style.display = "none";    
        colText10.style.display = "none";  
        
        //一覧タイトルの非表示
        if (colText9 != null)
        {
			colText9.style.display = "none";
		}
		         
    }else{
        colText1.style.display = "block";
        colText2.style.display = "block";
        colText3.style.display = "block"; 
        colText4.style.display = "block";  
        colText5.style.display = "block";  
        colText6.style.display = "block";  
        colText7.style.display = "block";  
        colText8.style.display = "block";  
        colText9.style.display = "block"; 
        colText10.style.display = "block"; 
    }
}

// ラベル編集
function editLabelText (){
	
	const ids = ["sidKOSHU_SHUBETSU_ID_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
	
	var flag = disp.get("SENNTAKU_FLAG");
	if (flag != '0') {
		const readonlyIds = ["sidKOSHU_SHUBETSU_ID"];
		                   
	    // ラベル要素取得
		readonlyIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.classList.add('item__COM_DISABLE');
			}
		});
		
		const els = document.getElementsByClassName('ui-checkbox');
		Array.from(els).forEach(function(e) {
			e.classList.add('item__COM_DISABLE');
		})
	}
	
	const count = disp.get("ROW_CNT");
	console.log(count);
	for(i = 0; i< count; i++) {
		const el = document.getElementById("g[" + i + "].sidG_JISSHI_YMD");
		console.log(el);
		if (el) {
			el.innerHTML = highlightWeekendDates(el.textContent);
		}
	}
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}

// 一覧のラベルの折り返しで表示
function editTableLabelCss() {

	// 一覧タイトル要素の取得
	const elems = document.querySelectorAll('table#TH_g thead tr th');
	// style属性を外す
	elems.forEach(elem => {
		elem.removeAttribute('style');
	});
}

function copyElements(name){
	const oldElem1 = document.getElementById("sid_" + name + "_Y_LABEL_f");
	const oldElem2 = document.getElementById("sid_" + name + "_M_f");
	const oldElem3 = document.getElementById("sid_" + name + "_M_LABEL_f");
	const oldElem4 = document.getElementById("sid_" + name + "_D_f");
	const oldElem5 = document.getElementById("sid_" + name + "_D_LABEL_f");
	const toDiv =  document.getElementById("sid_" + name + "_Y_f");
	
	toDiv.appendChild(oldElem1);
	toDiv.appendChild(oldElem2);
	toDiv.appendChild(oldElem3);
	toDiv.appendChild(oldElem4);
	toDiv.appendChild(oldElem5);	
}