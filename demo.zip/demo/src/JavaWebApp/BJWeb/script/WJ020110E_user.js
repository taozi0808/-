//　初期表示
window.onload = function() {
	const checkElement = document.querySelectorAll('input[type="checkbox"][name="_jizengaku_Choicelist_list"]');
    checkElement.forEach(function(checkbox) {
        checkbox.addEventListener('change', handleChange);
    });

	// ラベル編集
	editLabelText();
};

function handleChange() {
	var soufuFlag = disp.get("JIZENGAKU");
	const soufuIds = ["sidSOUFUSAKI_NO_label", "sidSOUFUSAKI_JUSHO1_label", "sidSOUFUSAKI_JUSHO2_label", "sidSOUFUSAKI_JUSHO3_label"];
	soufuIds.forEach(function(id) {
		const el = document.getElementById(id);
		const newId = id.replace('_label', '');
		if (el) {
			if (soufuFlag == '1') {
				// *スタイル追加	
			 	const span = document.createElement("span");
				span.textContent = "*";
				span.style.color = "red";
				span.style.fontWeight = "bold";
				span.style.fontSize = "10pt";
				 
				el.insertBefore(span, el.firstChild);
				const enableElem = document.getElementById(newId);
			    if (enableElem) {
			    	enableElem.classList.remove('item__COM_DISABLE');
				}
			} else {
				const elem = document.getElementById(id);
			    if (elem) {
			        const existingSpan = elem.querySelector('span');
			        if (existingSpan) {
			            elem.removeChild(existingSpan);
			        }
			    }
			    const disableElem = document.getElementById(newId);
			    if (disableElem) {
			    	disableElem.classList.add('item__COM_DISABLE');
				}
			}
		}
	});
}


// ラベル編集
function editLabelText (){
	
	var type = disp.get("KOSHU_SHUBETSU_ID");
	
	var ids = ["sidJYUKOUSHA_FURIGANA_SEI_label", "sidJYUKOUSHA_SEINENGAPPI_label" , "sidJYUKOUSHA_SEIBETSU_label"
	         , "sidJYUKOUSHA_TEL_label", "sidJYUKOUSHA_MAIL_ADDRESS_label","sidJYUKOUSHA_MAIL_ADDRESS_KAKUNI_label"
	         , "sidKIMU_NAME_label", "sidKIMUSHA_TEL_label", "sidJYUKOUSHA_SEI_label"];
	const labels = [];
	
	// 再講習を除く
	if (type == '3' || type == '13' || type == '23' || type == '43' || type == '53' || type == '63') {
		ids = ids.concat(["sidJYUKOUSHA_HOYU_NINTEISHO_NO_label"]);
	}
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});
	}
	
	// メッセージ1~3
	for(i = 1; i< 4; i++) {
		var context = disp.get("NOTE" + i);
		const el = document.getElementById("sidNOTE" + i);
		if (el) {
			el.innerHTML = context;
		}
	}
	
	// 教材購入説明文言
	var context2 = disp.get("NOTE17");
	const el2 = document.getElementById("sidNOTE17");
	if (el2) {
		el2.innerHTML = context2;
	}
	
	// 事前学習資料説明文言
	var context3 = disp.get("NOTE18");
	const el3 = document.getElementById("sidNOTE18");
	if (el3) {
		el3.innerHTML = context3;
	}
	
	// 講習実施日
	const elYMD = document.getElementById("sidJISSHI_YMD");
	if (elYMD) {
		elYMD.innerHTML = highlightWeekendDates(elYMD.textContent);
	}
	
	// 申込締切日
	const elelYMDEnd = document.getElementById("sidMOSHIKOMI_KIKAN_TO");
	if (elelYMDEnd) {
		elelYMDEnd.innerHTML = highlightWeekendDates(elelYMDEnd.textContent);
	}
	
	var hiddenIds = [];
	var flag = disp.get("KYASEIRU_FLAG");
	// 患者搬送基礎を除く
	if (type != '41') {
		hiddenIds = hiddenIds.concat(["PART_sidNOTE18", "PART_sidJIZENGAKU", "PART_sidSOUFUSAKI_NO",
		 "PART_sidSOUFUSAKI_JUSHO1", "PART_sidSOUFUSAKI_JUSHO2", "PART_sidSOUFUSAKI_JUSHO3"]);
		 // 患者搬送・現場派遣を除く
	    if (type != '43' && type != '31' && type != '33') {
			hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_SEI", "PART_sidKIMU_NAME", "PART_sidNOTE3", "PART_sidJIZENGAKU"]);
		}
	}
	// 空席連絡待ち
	if (flag != '0') {
		hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_HOYU_NINTEISHO_NO", "PART_sidJYUKOUSHA_TEL", "PART_sidKIYO_SEI", "PART_sidKIMUSHA_TEL", "PART_sidNOTE17"]);
	}
	// ラベル要素取得
	hiddenIds.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = 'none';
		}
	});
	
	// 再講習を除く
	if (type != '3' && type != '13' && type != '23' && type != '43' && type != '53' && type != '63') {
		const readonlyIds = ["sidJYUKOUSHA_HOYU_NINTEISHO_NO", "sidBANNGO_SEARCH"];
		                   
	    // ラベル要素取得
		readonlyIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.classList.add('item__COM_DISABLE');
			}
		});
	}
	handleChange();
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}
