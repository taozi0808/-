
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText () {
	// メッセージ1~3
	for(i = 1; i< 4; i++) {
		var context = disp.get("NOTE" + i);
		const el = document.getElementById("sidNOTE" + i);
		if (el) {
			el.innerHTML = context;
		}
	}
	
	// 講習実施日
	const elYMD = document.getElementById("sidJISSHI_YMD");
	if (elYMD) {
		elYMD.innerHTML = highlightWeekendDates(elYMD.textContent);
	}
	
	// 登録締切日
	const elelYMDEnd = document.getElementById("sidMOSHIKOMI_KIKAN_TO");
	if (elelYMDEnd) {
		elelYMDEnd.innerHTML = highlightWeekendDates(elelYMDEnd.textContent);
	}
	
	var hiddenIds = [];
	var type = disp.get("KOSHU_SHUBETSU_ID");
	// 患者搬送・現場派遣を除く
	if (type != '41' && type != '43' && type != '31' && type != '33' ) {
		hiddenIds = ["PART_sidJYUKOUSHA_S", "PART_sidKIMU_NAME", "PART_sidKIMUSHA_TEL"];
	}
	
    // ラベル要素取得
	hiddenIds.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = 'none';
		}
	});
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}
