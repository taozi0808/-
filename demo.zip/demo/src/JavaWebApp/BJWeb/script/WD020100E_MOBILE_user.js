
//　初期表示
window.onload = function() {

    // ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	
	const ids = ["sidTYPE_label", "sidUPLOAD_label", "sidWEB_DANTAI_MAILADDRESS_label" , 
					"sidWEB_DANTAI_PASSWORD_label"];
	const labels = [];
	
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			labels.push(elem);
		}
	});
	
	if (labels) {
		labels.forEach(function(label) {
			// *スタイル追加	
		 	const span = document.createElement("span");
			 span.textContent = "*";
			 span.style.color = "red";
			 span.style.fontWeight = "bold";
			 span.style.fontSize = "10pt";
			 
			 label.insertBefore(span, label.firstChild);
		});		
	}
}

