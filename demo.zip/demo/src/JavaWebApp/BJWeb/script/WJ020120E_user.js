
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	// 教材購入URL
	var link = disp.get("KIYO_SEI_URL");
	const elink = document.getElementById("sidKIYO_SEI_URL");
	if (elink) {
		elink.innerHTML = link;
	}
	// 講習実施日
	const elYMD = document.getElementById("sidJISSHI_YMD");
	if (elYMD) {
		elYMD.innerHTML = highlightWeekendDates(elYMD.textContent);
	}
	
	// 申込締切日
	const elelYMDEnd = document.getElementById("sidMOSHIKOMI_KIKAN_TO");
	if (elelYMDEnd) {
		elelYMDEnd.innerHTML = highlightWeekendDates(elelYMDEnd.textContent);
	}
	
	var hiddenIds = [];
	var gamennId = disp.get("GAMENN_ID");
	var flag = disp.get("KYASEIRU_FLAG");
	// 講習会申込画面遷移
	if (gamennId == 'WJ020110E') {
		hiddenIds = ["PART_sidINCOME_CD", "PART_sidDEIKI_NO"];
		// 空席連絡待ち
		if (flag != '0') {
			hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_HOYU_NINTEISHO_NO", "PART_sidJYUKOUSHA_TEL_TEXT", "PART_sidKIYO_SEI"]);
		}
		// 患者搬送基礎を除く
		if (type != '41') {
			hiddenIds = hiddenIds.concat(["PART_sidJIZENGAKU", "PART_sidSOUFUSAKI_NO", "PART_sidSOUFUSAKI_JUSHO1", "PART_sidSOUFUSAKI_JUSHO2", "PART_sidSOUFUSAKI_JUSHO3"]);
		}
	// 申込情報検索画面遷移
	} else {
		hiddenIds = ["PART_sidJYUKOUSHA_HOYU_NINTEISHO_NO", "PART_sidJIZENGAKU", "PART_sidSOUFUSAKI_NO", "PART_sidSOUFUSAKI_JUSHO1"
		, "PART_sidSOUFUSAKI_JUSHO2", "PART_sidSOUFUSAKI_JUSHO3"];
		// 空席連絡待ち
		if (flag != '0') {
			hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_TEL_TEXT"
			, "PART_sidINCOME_CD", "PART_sidKIMU_NAME", "PART_sidKIYO_SEI"]);
		} else {
		    hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_MAIL_ADDRESS_TEXT", "PART_sidDEIKI_NO"]);
		}
	}
	var type = disp.get("KOSHU_SHUBETSU_ID");
	// 患者搬送・現場派遣を除く
	if (type != '41' && type != '43' && type != '31' && type != '33' ) {
		hiddenIds = hiddenIds.concat(["PART_sidJYUKOUSHA_S", "PART_sidKIMU_NAME"]);
	}
	
    // ラベル要素取得
	hiddenIds.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = 'none';
		}
	});
	
	// 事前学習資料
	var soufuFlag = disp.get("JIZENGAKU");
	const soufuIds = ["PART_sidSOUFUSAKI_NO", "PART_sidSOUFUSAKI_JUSHO1", "PART_sidSOUFUSAKI_JUSHO2", "PART_sidSOUFUSAKI_JUSHO3"];
	soufuIds.forEach(function(id) {
		const el = document.getElementById(id);
		if (el) {
			if (soufuFlag == '1') {
				el.style.display = 'block';
			} else {
				el.style.display = 'none';
			}
		}
	});
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}
