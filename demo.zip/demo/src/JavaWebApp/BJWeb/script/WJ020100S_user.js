//　初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();
	 
	// ラベル編集
	editLabelText();
	
	// 一覧のラベルの折り返しで表示
	editTableLabelCss();
};

// 選択リストの選択状態をクリア
function clearSelect(selCtrl) {
  if (selCtrl.multiple) {
    // 複数選択の場合
    for (let option of selCtrl.options) {
      option.selected = false;
    }
  } else {
    // 単一選択の場合
    selCtrl.selectedIndex = -1;
  }
}

//　検索結果と一覧を非表示にする
function isDisplay() {
    var colText1 = document.getElementById( "PART_sidlbl" );
    var colText2 = document.getElementById( "PART_sidNOTE1" );
    var colText3 = document.getElementById( "PART_sidG" );
    var colRowCnt = disp.getElement( "ROW_CNT" );
    
    //console.log(disp.get( "sidROW_CNT" ));
    if( colRowCnt.value == 0 ){
		// 件数 が「0」のとき非表示にする
        colText1.style.display = "none";  
        colText2.style.display = "none";  
        colText3.style.display = "none";  
    }else{
        colText1.style.display = "block";
        colText2.style.display = "block";
        colText3.style.display = "block";
    }
}

// ラベル編集
function editLabelText (){
	var flag = disp.get("SENNTAKU_FLAG");
	if (flag != '0') {
		const readonlyIds = ["sidKOSHU_BUNRUI_ID", "sidKOSHU_SHUBETSU_ID", "sidMOUSHIKOMI_STATUS_field"];
		                   
	    // ラベル要素取得
		readonlyIds.forEach(function(id) {
			const elem = document.getElementById(id);
			if (elem) {
				elem.classList.add('item__COM_DISABLE');
			}
		});
	}
	
	const count = disp.get("ROW_CNT");
	for(i = 0; i< count; i++) {
		// 講習実施日
		const el = document.getElementById("g[" + i + "].sidG_JISSHI_YMD");
		if (el) {
			el.innerHTML = highlightWeekendDates(el.textContent);
		}
		// 申込締切日
		const el2 = document.getElementById("g[" + i + "].sidG_MOSHIKOMI_KIKAN_ED");
		if (el2) {
			el2.innerHTML = highlightWeekendDates(el2.textContent);
		}
	}
}

function highlightWeekendDates(str) {
    const regex = /(\d{4}年\d{2}月\d{2}日\((土|日)\))/g;
    return str.replace(regex, (match) => {
        return `<FONT COLOR="RED">${match}</FONT>`;
    });
}

// 一覧のラベルの折り返しで表示
function editTableLabelCss() {

	// 一覧タイトル要素の取得
	const elems = document.querySelectorAll('table#TH_g thead tr th');
	// style属性を外す
	elems.forEach(elem => {
		elem.removeAttribute('style');
	});
}
