// 初期表示
window.onload = function() {
	
	// 初期表示を空白にする
	isDisplay();
	
    // ラベル編集
    editLabelText();
};

// ラベル編集
function editLabelText() {
    // 初期の ids 配列
    let ids = ["sidJYUKOUSHA_FURIGANA_SEI_label"
             , "sidJYUKOUSHA_FURIGANA_MEI_label","sidJYUKOUSHA_SEINENGAPPI_label"];
    // 検索方法
    var text = disp.get("KANSAKU_METHOD");
    // 講習会番号と受付番号で検索
    if (text == '1') {
		ids = ids.concat(["sidKOSHUKAI_CD_label", "sidUKETSUKE_NO_label"]);
		removeStars(["sidO_YM_label", "sidKOSHU_SHUBETSU_ID_label"]);
	// 講習実施月と講習種別で検索  
	} else {
		ids = ids.concat(["sidO_YM_label", "sidKOSHU_SHUBETSU_ID_label"]);
		removeStars(["sidKOSHUKAI_CD_label", "sidUKETSUKE_NO_label"]);
	}
	updateLabels(ids);
    // ラジオボタンの取得
    const radioButtons = document.querySelectorAll('input[type="radio"][name="_kansaku_method_str"]');
    radioButtons.forEach(function(radio) {
        radio.addEventListener('change', handleRadioChange);
    });
}

//　検索結果と一覧を非表示にする
function isDisplay() {
    var colText1 = document.getElementById( "PART_sidlbl" );
    var colText2 = document.getElementById( "PART_sidG" );
    var colRowCnt = disp.getElement( "ROW_CNT" );
    
    if( colRowCnt.value == 0 ){
		// 件数 が「0」のとき非表示にする
        colText1.style.display = "none";  
        colText2.style.display = "none";
    }else{
        colText1.style.display = "block";
        colText2.style.display = "block";
    }
}

function handleRadioChange(event) {
    const selectedValue = event.target.value;
    // 講習会番号と受付番号で検索
    if (selectedValue == '1') {
		ids = ["sidKOSHUKAI_CD_label", "sidUKETSUKE_NO_label"];
		removeStars(["sidO_YM_label", "sidKOSHU_SHUBETSU_ID_label"]);
	  // 講習実施月と講習種別で検索
    } else if (selectedValue == '2') {
		ids = ["sidO_YM_label", "sidKOSHU_SHUBETSU_ID_label"];
		removeStars(["sidKOSHUKAI_CD_label", "sidUKETSUKE_NO_label"]);
    }
    updateLabels(ids);
}

// ラベル更新の関数
function updateLabels(ids) {
    // ラベル要素の配列を初期化
    const labels = [];

    // ids 配列を基にラベル要素を取得
    ids.forEach(function(id) {
        const elem = document.getElementById(id);
        if (elem) {
            labels.push(elem);
        }
        newId = id.replace('_label', '');
        const disableElem = document.getElementById(newId);
        if (disableElem) {
        	disableElem.classList.remove('item__COM_DISABLE');
        }
    });

    // すべてのラベルに対して '*'
    labels.forEach(function(label) {
        // まず前回挿入した '*' を削除する
        const existingSpan = label.querySelector('span');
        if (existingSpan) {
            label.removeChild(existingSpan);  // 削除する
        }

        // '*' スタイルを追加
        const span = document.createElement("span");
        span.textContent = "*";
        span.style.color = "red";
        span.style.fontWeight = "bold";
        span.style.fontSize = "10pt";

        // ラベルの先頭に '*' を挿入
        label.insertBefore(span, label.firstChild);
    });
}

function removeStars(ids) {
    ids.forEach(function(id) {
        const elem = document.getElementById(id);
        if (elem) {
            const existingSpan = elem.querySelector('span');
            if (existingSpan) {
                elem.removeChild(existingSpan);
            }
        }
        newId = id.replace('_label', '');
        const disableElem = document.getElementById(newId);
        if (disableElem) {
        	disableElem.classList.add('item__COM_DISABLE');
		}
    });
}
