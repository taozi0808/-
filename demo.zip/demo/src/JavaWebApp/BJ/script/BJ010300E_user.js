var elemSansyo = disp.getElement("A_SANSYO");
var elemTorokomi = disp.getElement("A_TOROKOMI");
addEventHandler(elemSansyo, "onclick", clickSANSYO);
addEventHandler(elemTorokomi, "onclick", clickTOROKOMI);

function clickSANSYO() {
	disp.sync_refresh();
	if (!('showDirectoryPicker' in window)) {
		return;
	}
	window.showDirectoryPicker().then(dirHandle => {
		window.selectedDirectoryHandle = dirHandle;
		disp.set("FILE_PATH", dirHandle.name);
	}).catch(err => {
		console.log('Directory picker cancelled or error:', err);
	});
}

function clickTOROKOMI() {
	if (window.selectedDirectoryHandle) {
		readDirectoryContents(window.selectedDirectoryHandle);
		return;
	}
}

function readDirectoryContents(dirHandle) {
	const files = [];
	function processDirectory(handle, path = '') {
		const iterator = handle.entries();

		function processNext() {
			return iterator.next().then(result => {
				if (result.done) {
					return Promise.resolve();
				}

				const [name, fileHandle] = result.value;
				const fullPath = path ? `${path}/${name}` : name;

				if (fileHandle.kind === 'file') {
					return fileHandle.getFile().then(file => {
						files.push({
							name: file.name,
							size: file.size,
							type: file.type,
							lastModified: file.lastModified,
							path: fullPath,
							file: file
						});
						return processNext();
					});
				} else if (fileHandle.kind === 'directory') {
					return processDirectory(fileHandle, fullPath).then(() => {
						return processNext();
					});
				} else {
					return processNext();
				}
			});
		}

		return processNext();
	}

	processDirectory(dirHandle).then(() => {
		
		console.log(files);

	}).catch(err => {

	});
}



