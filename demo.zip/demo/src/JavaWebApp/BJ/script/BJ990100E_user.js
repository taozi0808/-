function InitCursorID()
{
  var elms = document.getElementsByClassName('errors-text');
  
  if(elms.length == 0){
      var rows = disp.get_G_count();
      
      if ( rows > 0 ) {
          disp.setCur_index(0);
          
          const fstRow = document.querySelector('tr.even');
          if (fstRow){
              fstRow.focus();
              fstRow.click();
          }
      }
   }
}

function UserOnLoad()
{
    setTimeout(InitCursorID, 100);
    return true;
}

/*addLoadEvent(UserOnLoad);*/

const tableRows = document.querySelectorAll('tr.scrollodd, tr.scrolleven');

tableRows.forEach(row => {
    row.addEventListener('click', function() {
		document.getElementById('a_insert_item').style.display = 'none';
		document.getElementById('a_update_item').style.display = 'block';
		const input1 = document.getElementById('sidG_HOUMEN_TANTO_NM');
		const input2 = document.getElementById('sidG_KENGEN_KBN');
		const input3 = document.getElementById('sidG_LOGIN_ID');
        input1.classList.add('item__COM_DISABLE');
        input2.classList.add('item__COM_DISABLE');
        input3.classList.add('item__COM_DISABLE');
        //const houmenTantoNm =  row.querySelector('[id*="sidHOUMEN_TANTO_NM"]')?.textContent.trim();
        const houmenId =  row.querySelector('[id*="sidHOUMEN_ID"]')?.getAttribute("value").trim();
        const loginNm = row.querySelector('[id*="sidLOGIN_NM"]')?.textContent.trim();
        const kengenKbn = row.querySelector('[id*="sidKENGEN_KBN"]')?.getAttribute("value").trim();
        const loginId = row.querySelector('[id*="sidLOGIN_ID"]')?.textContent.trim();
        //const sPassword = row.querySelector('[id*="sidLOGIN_PASSWORD"]')?.textContent.trim();
        const sPassword = row.querySelector('[id*="sidLOGIN_PASSWORD"]')?.getAttribute("value").trim();
        const passwordHenkobi = row.querySelector('[id*="sidPASSWORD_HENKOBI"]')?.textContent.trim();
//        
        //var setHoumenTantoNm = document.getElementById('sidG_HOUMEN_TANTO_NM');
        //setHoumenTantoNm.value = ` ${houmenTantoNm} `;
        disp.set('G_HOUMEN_TANTO_NM',houmenId);
        var setLoginNm = document.getElementById('sidG_LOGIN_NM');    
        setLoginNm.value =  loginNm;
        var setKengenKbn = document.getElementById('sidG_KENGEN_KBN');
        setKengenKbn.value = kengenKbn; 
        var setLoginId = document.getElementById('sidG_LOGIN_ID');
        setLoginId.value = loginId; 
        disp.set('G_LOGIN_PASSWORD',sPassword);
        var setPasswordHenkobi = document.getElementById('sidG_PASSWORD_HENKOBI');
        setPasswordHenkobi.value = passwordHenkobi; 
        const date = new Date(passwordHenkobi);
        date.setDate(date.getDate() + 90);
        const pad = n => n.toString().padStart(2, '0');
        newDate = `${date.getFullYear()}/${pad(date.getMonth()+1)}/${pad(date.getDate())}`;
        var setYokouki = document.getElementById('sidG_YUKOUKI');
        setYokouki.value = newDate; 
        
    });
});

function clearItems(){
//    var houmenId =  disp.getElement("G_HOUMEN_TANTO_NM");
//    var loginNm =  disp.getElement("G_LOGIN_NM");
//    var kengenKbn = disp.getElement("G_KENGEN_KBN");
//    var sLoginId = disp.getElement("G_LOGIN_ID");
//    var sPassword = disp.getElement("G_LOGIN_PASSWORD");
//    var passwordHenkobi = disp.getElement("G_PASSWORD_HENKOBI");
//    var validFlag = disp.getElement("G_FLAG");
//    
//    houmenId.selectedIndex = -1;
//    loginNm.value = "";
//    kengenKbn.selectedIndex = -1;
//    sLoginId.value = "";
//    sPassword.value = """;
//    passwordHenkobi.value = """;
//    validFlag.value = 0;

    disp.set("G_HOUMEN_TANTO_NM", "");
    disp.set("G_LOGIN_NM","");
    disp.set("G_KENGEN_KBN","");
    disp.set("G_LOGIN_ID","");
    disp.set("G_LOGIN_PASSWORD","");
    disp.set("G_PASSWORD_HENKOBI","");
    disp.set("G_YUKOUKI","");

	document.getElementById('a_insert_item').style.display = 'block';
	document.getElementById('a_update_item').style.display = 'none';
	document.querySelectorAll('table#TB_g tr').forEach(row => {
      row.classList.remove('tr-active');
    });
    
	const input1 = document.getElementById('sidG_HOUMEN_TANTO_NM');
	const input2 = document.getElementById('sidG_KENGEN_KBN');
	const input3 = document.getElementById('sidG_LOGIN_ID');
    input1.classList.remove('item__COM_DISABLE');
    input2.classList.remove('item__COM_DISABLE');
    input3.classList.remove('item__COM_DISABLE');
}

var elem = disp.getElement("A_NEW");
addEventHandler(elem, "onclick", clearItems);

document.querySelectorAll('table#TB_g tr').forEach((tr, index) => {
  if (index === 0) return;

  tr.addEventListener('click', () => {
    document.querySelectorAll('table#TB_g tr').forEach(row => {
      row.classList.remove('tr-active');
    });
    tr.classList.add('tr-active');
  });
});

