
const hiddenIds = ["PART_sidYMDFROM", "PART_sidKOSHU_SHUBETSU_ID", "PART_sidSHOZOKU_ID",
		           "PART_sidKOSHU_JIKAN_FROM", "PART_sidKOSHU_JIKAN_TO", "PART_sidBIKO",
		            "PART_sidDANTAIMEI_STATUS", "PART_sidDANTAIMEI_USER", "PART_sidDANTAIMEI_REQ"];
		           
const showIds = ["PART_sidSEIKINO_FROM", "PART_sidSEIKINO_FROM", "PART_sidSEIKI_YMD_ST", 
                 "PART_sidJYUKOUSHA_ZIP", "PART_sidSEIKI_NM", "PART_sidSEIKI_STATUS",
                 "PART_sidSEIKI_METHOD", "PART_sidRUKI_YMD_ST"];
                 
const elements = ["a_search_by_seiki_item", "a_search_by_koshu_item"];
elements.forEach(e => {
	replaceAction(e);
})

/*タプの<a>を<span>に置き換え、画面リフレッシュを防止*/
function replaceAction(str) {
	const tab = document.getElementById(str);
	if (tab) {
		const aTags = tab.getElementsByTagName('a');
		const aTagsArray = Array.from(aTags);
		aTagsArray.forEach((aTag) => {	
			const spanElement = document.createElement('span');
			spanElement.setAttribute('id', 'sid' + str);
			spanElement.innerHTML = aTag.innerHTML;
			/*選択CSS*/
			if (str == 'a_search_by_seiki_item') {
				spanElement.style.cssText = `
				left: -1px;
			    position: relative;
			    top: -1px;
			    border-width: 1px;
			    margin: 0px 20px;
			    color: #ffffff;
			    font-size: 0.8em;`;
			    /*未選択CSS*/
		    } else {
				tab.classList.replace('tab_active', 'tab_inactive');
				spanElement.style.cssText = `
				color: #187ca9;
			    font-size: 0.8em;
			    margin: 0px 20px;`;
			}
			aTag.parentNode.replaceChild(spanElement, aTag);
		})
	}
}

window.addEventListener('load', editLabelText(hiddenIds, 'none'));

/*請求情報で検索するTABのclick*/
document.querySelector('#a_search_by_seiki_item').addEventListener('click', function() {
	setStyle('a_search_by_seiki_item', 'a_search_by_koshu_item');
	var index = $(this).index();
    if (index == 0) {
		editLabelText(hiddenIds, 'none');
		editLabelText(showIds, 'block');
	}
});

/*講習会情報で検索するTABのclick*/
document.querySelector('#a_search_by_koshu_item').addEventListener('click', function() {
	setStyle('a_search_by_koshu_item', 'a_search_by_seiki_item');
	var index = $(this).index();
    if (index == 1) {
		editLabelText(showIds, 'none');
		editLabelText(hiddenIds, 'block');
	}
});

// ラベル編集
function editLabelText(ids, status) {
		
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = status;
		}
	});
}

function setStyle(str1, str2) {
	const tab1 = document.getElementById(str1);
	const tab2 = document.getElementById(str2);
	const span1 = document.getElementById('sid' + str1);
	const span2 = document.getElementById('sid' + str2);
	if (tab1 && tab1.classList && tab1.classList.contains('tab_inactive')) {	
		tab1.classList.replace('tab_inactive', 'tab_active');
		tab2.classList.replace('tab_active', 'tab_inactive');
		span1.style.cssText = `
				left: -1px;
			    position: relative;
			    top: -1px;
			    border-width: 1px;
			    margin: 0px 20px;
			    color: #ffffff;
			    font-size: 0.8em;`;
	    span2.style.cssText = `
				color: #187ca9;
			    font-size: 0.8em;
			    margin: 0px 20px;`;
	}
}