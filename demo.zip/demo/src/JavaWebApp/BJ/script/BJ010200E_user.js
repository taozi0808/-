/* 講習開始時間 */
var elem = disp.getElement("KOSHU_TIME_ST");
addEventHandler(elem, "onblur", setKOSHU_FROM_VALUE);
function setKOSHU_FROM_VALUE() {
    let value = elem.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        elem.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/* 講習受付開始時間 */
var el = disp.getElement("KOSHU_FU_TIME_ST");
addEventHandler(el, "onblur", setKOSHU_FU_VALUE);
function setKOSHU_FU_VALUE() {
    let value = el.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        el.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/* 申込受付期間 */
var e = disp.getElement("MOSHIKOMI_KIKAN_FROM_TIME");
addEventHandler(e, "onblur", setKOSHU_TIME_VALUE);
function setKOSHU_TIME_VALUE() {
    let value = e.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        e.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/*
　団体検索ボタン押下 
var e = disp.getElement("DANTAI_SEARCH");
addEventHandler(e, "onclick", onClickDANTAI_SEARCH);

function onClickDANTAI_SEARCH() {
	const url = getContextPath() + "/BJ990300S.do";
	const windowName = "popupWindow"; 
	const windowFeatures = "width=1500,height=1000,scrollbars=yes,resizable=yes"; 
	 
	window.open(url, windowName, windowFeatures);
}
*/