
/*　チェックボックス　値変更　*/
addLoadEvent( addActEventHandler );

function addActEventHandler(){

  //全体件数の参照 Gはグループの入出力項目コード
  var rows = disp.get_G_count();

  for( var i = 0; i<  rows; i++ ) {
   disp.setCur_index(i);
   //イベントを取得するエレメントを取得 NUM1は値を取得する入出力項目コード
   var elem = disp.getElement("G_SELECT");
   //イベントの設定
   addEventHandler(elem, "onchange", setSENTAKU_VALUE);
 }
 return true;
}

/*　選択行の値取得　*/
function setSENTAKU_VALUE() {

	// 一覧行数取得
	var cnt = disp.get_G_count();
	console.log("cnt:" + cnt);
	if (cnt <= 0) {return true;}	
	
	// イベント発生行の値
	var currentIndex = disp.get__SRC_EVENT_ROWS(event);
	console.log("currentIndex:" + currentIndex);	
	disp.setCur_index(currentIndex);
	disp.set("O_HOUMEN_ID","");
	disp.set("O_SHOZOKU_ID","");
	disp.set("O_KAIJYO_CD","");
	disp.set("O_KAIJYO_NM","");
	
	// 選択値取得
	var value = disp.get_G_SELECT();
	var houmen_id = disp.get_G_HOUMEN_ID();
	var shozoku_id = disp.get_G_SHOZOKU_ID();
	var kaijyo_cd = disp.get_G_KAIJYO_CD();
	var kaijyo_nm = disp.get_G_KAIJYO_NM();
	console.log("value:" + value );	
	console.log("houmen_id:" + houmen_id + "shozoku_id:" + shozoku_id);	
	console.log("kaijyo_cd:" + kaijyo_cd + "kaijyo_nm:" + kaijyo_nm);	
	
	if (value == 1)
	{
		disp.set("O_HOUMEN_ID",houmen_id);
		disp.set("O_SHOZOKU_ID",shozoku_id);
		disp.set("O_KAIJYO_CD", kaijyo_cd);
		disp.set("O_KAIJYO_NM", kaijyo_nm);
	}
	
	return true;
}
