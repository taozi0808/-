window.addEventListener('load', setButtonDisabled());

function setButtonDisabled() {
	const elements = document.querySelectorAll('table#TB_g_juko tbody tr');
	elements.forEach((el, index) => {
		const tdElement = el.querySelectorAll('td');
		if (index < 3) {
			tdElement.forEach((e, i) => {
				e.style.cssText = `
						background-color: rgb(118 118 118 / 50%); !important;
						pointer-events: none;
						cursor: not-allowed;`;
			})
		}
	})
}