/* 実施年月日FROM入力確定時処理 */
var elem = disp.getElement("JISSHI_YMD_ST");
addEventHandler(elem, "onchange", setJISSHI_YMD_ED);

function setJISSHI_YMD_ED() {
	
	disp.sync_refresh();
	
	var ymdFrom = disp.get("JISSHI_YMD_ST");
	var ymdTo = disp.get("JISSHI_YMD_ED");
	
	if (!isNullOrEmpty(ymdFrom)) {
		if (isNullOrEmpty(ymdTo) || ymdFrom > ymdTo) {
			disp.set("JISSHI_YMD_ED", ymdFrom);
		}
	}
}

/* 実施年月日TO入力確定時処理 */
var elem = disp.getElement("JISSHI_YMD_ED");
addEventHandler(elem, "onchange", setJISSHI_YMD_ST);

function setJISSHI_YMD_ST() {
	
	disp.sync_refresh();
	
	var ymdFrom = disp.get("JISSHI_YMD_ST");
	var ymdTo = disp.get("JISSHI_YMD_ED");
	
	if (!isNullOrEmpty(ymdTo)) {
		if (isNullOrEmpty(ymdFrom) || ymdFrom > ymdTo) {
			disp.set("JISSHI_YMD_ST", ymdTo);
		}
	}
}

/* 文字列判定 */
function isNullOrEmpty(value) {
  return value === null || value === undefined || value === "";
}

/* 講習開始時間 */
var elem = disp.getElement("KOSHU_JIKAN_FROM");
addEventHandler(elem, "onblur", setKOSHU_FROM_VALUE);
function setKOSHU_FROM_VALUE() {
    let value = elem.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        elem.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/* 講習終了時間 */
var el = disp.getElement("KOSHU_JIKAN_TO");
addEventHandler(el, "onblur", setKOSHU_TO_VALUE);
function setKOSHU_TO_VALUE() {
    let value = el.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        el.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/*
　検索ボタン押下　
var elem = disp.getElement("KENSAKU");
addEventHandler(elem, "onclick", doSearch);

function doSearch() {
	disp.trigger('GROUP_COUNT');
	disp.sync_refresh();
	
	// 一覧件数
	var groupCount = disp.getElement("GROUP_COUNT").value;
	//　照会Max件数
	var groupMaxCount = disp.getElement("GROUP_MAX_COUNT").value;
	if ((+groupCount || 0) > (+groupMaxCount || 0)) {
		if (window.confirm(groupMaxCount + "件を超えます。表示しますか？")) {
			return true;
		} else {
			// 方面担当にフォーカスをセットする
			disp.getElement("HOUMEN_ID").focus();
			return false;
		}
	} else {
		// 実施開始日にフォーカスをセットする
		if (groupCount == 0) {
			disp.getElement("JISSHI_YMD_ST").focus();
		}
	}
	return true;
}*/

//　詳細ボタン押下
var elemSyosai = disp.getElement("SYOSAI");
addEventHandler(elemSyosai, "onclick", clickSYOSAI);

function clickSYOSAI() {
	var rowCnt = disp.get_G_KOJU_INFO_count();
	for (i = 0; i < rowCnt; i++) {
		disp.setCur_index(i);
		var gKoshukaiCd = disp.get_G_KOSHUKAI_CD();
		var gSelect = disp.get_G_SELECT();

		if (gSelect == true) {
			disp.set_SENTAKU_CODE(gKoshukaiCd);
			break;
		}
	}
	return true;
}

/*　全選択・全解除ボタン押下　*/
function setG_SELECT(disp) {
	var param = disp.getArgs();
	var inp1 = param[0];
	//表示開始行数の参照
	var rowOff = disp.get_G_KOJU_INFO_offset();
	//表示ページ最終行の参照
	var rowLst = disp.get_G_KOJU_INFO_last();
	while(rowOff<rowLst) {
		disp.setCur_index(rowOff);
		//BOOL型のチェックボックスのセット
		disp.set_G_SELECT(inp1);
		rowOff++;
	}
	return true;
}

/*　チェックボックス　値変更　*/
addLoadEvent( addActEventHandler );

function addActEventHandler(){
  //全体件数の参照 Gはグループの入出力項目コード
  var rows = disp.get_G_KOJU_INFO_count();
  for( var i = 0; i<  rows; i++ ) {
   disp.setCur_index(i);
   //イベントを取得するエレメントを取得 NUM1は値を取得する入出力項目コード
   var elem = disp.getElement("G_SELECT");
   //イベントの設定
   addEventHandler(elem, "onchange", setSENTAKU_CODE);
 }
 return true;
}

/*　選択行の講習会コード取得　*/
function setSENTAKU_CODE() {
	// 一覧行数取得
	var cnt = disp.get_G_KOJU_INFO_count();
	console.log("cnt:" + cnt);
	if (cnt <= 0) {return true;}	
	
	// イベント発生行の値
	var currentIndex = disp.get__SRC_EVENT_ROWS(event);
	console.log("currentIndex:" + currentIndex);	
	disp.setCur_index(currentIndex);
	disp.set("SENTAKU_CODE","0");
	
	// 講習会コード取得
	var value = disp.get_G_SELECT();
	var code = disp.get_G_KOSHUKAI_CD();
	console.log("value:" + value + "code:" + code);	
	
	if (value == 1)
	{
		disp.set("SENTAKU_CODE", code);
	}
	
	return true;
}

