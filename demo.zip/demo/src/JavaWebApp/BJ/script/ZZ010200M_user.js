
/*　タブ　切り替え　*/
addLoadEvent( addActEventHandler );

function addActEventHandler(){
  const tabs = document.querySelectorAll('.sidebar a:not(#Logout)');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', e => {
      e.preventDefault();

      // タブ切り替え
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // 表示内容切り替え
      const target = tab.getAttribute('data-tab');
      contents.forEach(c => {
        c.classList.toggle('active', c.id === target);
      });
    });
  });
  
  // タブ制御
  controlTab();
  
}

/* タブ制御 */
function controlTab() {
	
	const kengen_kbn = disp.get("KENGEN_KBN");
	const tab_TT = document.querySelector('[data-tab="TT"]');	
	const tab_MM = document.querySelector('[data-tab="MM"]');
	
	// 権限＝"3"（方面本部職員）の場合
	// 定型・統計業務タブは非表示とする
	if (tab_TT != null) {
		if (kengen_kbn == 3) {
			tab_TT.style.display = "none";
		}
		else {
			tab_TT.style.display = "block";			
		}
	}
	
	// 権限＝"3"（方面本部職員）の場合
	// マスタメンテナス業務タブは非表示とする
	if (tab_MM != null) {
		if (kengen_kbn == 3) {
			tab_MM.style.display = "none";
		}
		else {
			tab_MM.style.display = "block";			
		}
	}
}
