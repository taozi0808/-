
//　初期表示
window.onload = function() {

	// ラベル編集
	editLabelText();
};

// ラベル編集
function editLabelText (){
	var context = disp.get("TEXT");
	const elem = document.getElementById("sidTEXT");
	if (elem) {
		elem.innerHTML = context;
	}
}
