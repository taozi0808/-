/* 講習開始時間 */
var elem = disp.getElement("KOSHU_JIKAN_FROM");
addEventHandler(elem, "onblur", setKOSHU_FROM_VALUE);
function setKOSHU_FROM_VALUE() {
    let value = elem.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        elem.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/* 講習終了時間 */
var el = disp.getElement("KOSHU_JIKAN_TO");
addEventHandler(el, "onblur", setKOSHU_TO_VALUE);
function setKOSHU_TO_VALUE() {
    let value = el.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        el.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/*　チェックボックス　値変更　*/
addLoadEvent( addActEventHandler );

function addActEventHandler(){
  //全体件数の参照 Gはグループの入出力項目コード
  var rows = disp.get_G_JUKO_count();
  for( var i = 0; i<  rows; i++ ) {
   disp.setCur_index(i);
   //イベントを取得するエレメントを取得 NUM1は値を取得する入出力項目コード
   var elem = disp.getElement("G_SELECT");
   //イベントの設定
   addEventHandler(elem, "onchange", setSENTAKU_CODE);
 }
 return true;
}

/*　選択行の講習会コード取得　*/
function setSENTAKU_CODE() {
	// 一覧行数取得
	var cnt = disp.get_G_JUKO_count();
	console.log("cnt:" + cnt);
	if (cnt <= 0) {return true;}	
	
	// イベント発生行の値
	var currentIndex = disp.get__SRC_EVENT_ROWS(event);
	console.log("currentIndex:" + currentIndex);	
	disp.setCur_index(currentIndex);
	disp.set("PARM_KOSHUKAI_CD","0");
	
	// 講習会コード取得
	var value = disp.get_G_SELECT();
	var code = disp.get_G_KOSHUKAI_CD();
	// 待機番号取得
	var no = disp.get_G_DEIKI_NO();
	console.log("value:" + value + "code:" + code + "no:" + no);	
	
	if (value == 1)
	{
		disp.set("PARM_KOSHUKAI_CD", code);
		disp.set("PARM_DEIKI_NO", no);
	}
	
	return true;
}
