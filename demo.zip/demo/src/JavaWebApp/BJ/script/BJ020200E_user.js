　/*初期ロードイベント*/
addLoadEvent( addActEventHandler );

function addActEventHandler(){
		
	　/*レイアウト調整*/　
	adjustLayout ();
	
	handleChange();
	
	const checkElement = document.querySelectorAll('input[type="checkbox"][name="_jizengaku_Choicelist_list"]');
    checkElement.forEach(function(checkbox) {
        checkbox.addEventListener('change', handleChange);
    });
}

function handleChange() {
	var soufuFlag = disp.get("JIZENGAKU");
	const soufuIds = ["sidSOUFUSAKI_NO", "sidSOUFUSAKI_JUSHO1", "sidSOUFUSAKI_JUSHO2", "sidSOUFUSAKI_JUSHO3"];
	soufuIds.forEach(function(id) {
		if (soufuFlag == '1') {
			const enableElem = document.getElementById(id);
		    if (enableElem) {
		    	enableElem.classList.remove('item__COM_DISABLE');
			}
		} else {
		    const disableElem = document.getElementById(id);
		    if (disableElem) {
		    	disableElem.classList.add('item__COM_DISABLE');
			}
		}
	});
}

　/*レイアウト調整　*/
function adjustLayout () {
	
	　/*移動元1*/ 
	var fieldSetElem = document.getElementById("PART_sidJISSHI_YMD_ST");
	　/*移動元2*/ 
	var fieldSetElem2 = document.getElementById("PART_sidA_DELETE");
	　/*移動先*/ 
    var tableElem = document.querySelector(".tab_table");
    
     /*非空の場合*/ 
    if (fieldSetElem && tableElem) {
    	var parent = tableElem.parentNode;
    	parent.insertBefore(fieldSetElem, tableElem);
	}
	
	if (fieldSetElem2 && tableElem) {
    	var parent = tableElem.parentNode;
    	parent.appendChild(fieldSetElem2, tableElem);
	}
	
    return true;	
}

/* 講習開始時間 */
var elem = disp.getElement("KOSHU_TIME_ST");
addEventHandler(elem, "onblur", setKOSHU_FROM_VALUE);
function setKOSHU_FROM_VALUE() {
    let value = elem.value;
    if (value && value.trim() !== "") {
		let paddedValue;
		value = value.replace(/:/g, '')
		if(value.length > 4) {
			paddedValue = value.substring(0, 4);
		} else {
            paddedValue = value.padEnd(4, '0');
        }
        elem.value = paddedValue.replace(/(\d{2})(\d{2})/, '$1:$2');
    }
}

/*受講者明細*/
const hiddenIds = ["PART_sidJYUKOUSHA_NAME"];

/*受講者明細(追加情報)*/       
const showIds = ["PART_sidJYUKOUSHA_HOYU_NINTEISHO_NO","PART_sidJYUKOUSHA_FURIGANA", "PART_sidJYUKOUSHA_SEINENGAPPI", "PART_sidUKETSUKE_NO",
		           "PART_sidJYUKOUSHA_ADDRESS", "PART_sidJYUKOUSHA_TEL", "PART_sidKYOZAI_KOUNYU",
		            "PART_sidNYUKIN_STATUS", "PART_sidJYUKOUSHA_SEIKYU_DATE", "PART_sidMAIL_SEND_DATE"];
                 
const elements = ["a_jukou_info_item", "a_jukou_append_info_item"];
elements.forEach(e => {
	replaceAction(e);
})

/*タプの<a>を<span>に置き換え、画面リフレッシュを防止*/
function replaceAction(str) {
	const tab = document.getElementById(str);
	if (tab) {
		const aTags = tab.getElementsByTagName('a');
		const aTagsArray = Array.from(aTags);
		aTagsArray.forEach((aTag) => {	
			const spanElement = document.createElement('span');
			spanElement.setAttribute('id', 'sid' + str);
			spanElement.innerHTML = aTag.innerHTML;
			/*選択CSS*/
			if (str == 'a_jukou_info_item') {
				spanElement.style.cssText = `
				left: -1px;
			    position: relative;
			    top: -1px;
			    border-width: 1px;
			    margin: 0px 20px;
			    color: #ffffff;
			    font-size: 0.8em;`;
			    /*未選択CSS*/
		    } else {
				tab.classList.replace('tab_active', 'tab_inactive');
				spanElement.style.cssText = `
				color: #187ca9;
			    font-size: 0.8em;
			    margin: 0px 20px;`;
			}
			aTag.parentNode.replaceChild(spanElement, aTag);
		})
	}
}

window.addEventListener('load', editLabelText(hiddenIds, 'none'));

/*請求情報で検索するTABのclick*/
document.querySelector('#a_jukou_info_item').addEventListener('click', function() {
	setStyle('a_jukou_info_item', 'a_jukou_append_info_item');
	var index = $(this).index();
    if (index == 0) {
		editLabelText(hiddenIds, 'none');
		editLabelText(showIds, 'block');
	}
});

/*講習会情報で検索するTABのclick*/
document.querySelector('#a_jukou_append_info_item').addEventListener('click', function() {
	setStyle('a_jukou_append_info_item', 'a_jukou_info_item');
	var index = $(this).index();
    if (index == 1) {
		editLabelText(showIds, 'none');
		editLabelText(hiddenIds, 'block');
	}
});

// ラベル編集
function editLabelText(ids, status) {
		
	// ラベル要素取得
	ids.forEach(function(id) {
		const elem = document.getElementById(id);
		if (elem) {
			elem.style.display = status;
			elem.style.height = 'none !important';
		}
	});
	
	/*inputにdisableの場合Calendarをdisable*/
	checkInputDisable();
}

function setStyle(str1, str2) {
	const tab1 = document.getElementById(str1);
	const tab2 = document.getElementById(str2);
	const span1 = document.getElementById('sid' + str1);
	const span2 = document.getElementById('sid' + str2);
	if (tab1 && tab1.classList && tab1.classList.contains('tab_inactive')) {	
		tab1.classList.replace('tab_inactive', 'tab_active');
		tab2.classList.replace('tab_active', 'tab_inactive');
		span1.style.cssText = `
				left: -1px;
			    position: relative;
			    top: -1px;
			    border-width: 1px;
			    margin: 0px 20px;
			    color: #ffffff;
			    font-size: 0.8em;`;
	    span2.style.cssText = `
				color: #187ca9;
			    font-size: 0.8em;
			    margin: 0px 20px;`;
	}
}

function checkInputDisable() {
	const inputs = document.getElementsByTagName('input');
	if(!inputs) return false;
	Array.from(inputs).forEach(input=>{
		checkInputAndSetButton(input);
	})
}

function checkInputAndSetButton(inputElement) {
	if (inputElement.classList && inputElement.classList.contains('item__COM_DISABLE')) {
		
	    console.log(inputElement.classList)
		const button = getNextButton(inputElement);
		if (button) {
			setButtonDisabled(button);
		}
	}
}

function getNextButton(inputElement) {
	var nextElement = getNexElementSibling(inputElement);
	console.log('nextElement:' + nextElement)
	if (nextElement) {
		return nextElement;
	}
	return null;
}

function getNexElementSibling(element) {
	if (element.nextElementSibling) {
		return element.nextElementSibling;
	} else {
		var next = element.nextSibling;
		while (next && next.nodeType != 1) {
			next = next.nextSibling;
		}
		return next;
	}
}

function setButtonDisabled(buttonElement) {
	if (buttonElement && buttonElement.classList.contains('ui-datepicker-trigger')) {
		buttonElement.style.cssText = `
				background-color: rgb(225, 225, 225) !important;
				pointer-events: none;
				cursor: not-allowed;`;
	}
}