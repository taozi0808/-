package common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import jp.co.canon_soft.wp.runtime.DispDataQuerier;
import jp.co.canon_soft.wp.runtime.dm.DmBroker;
import jp.co.canon_soft.wp.runtime.dm.DmBrokerFactory;
import jp.co.canon_soft.wp.runtime.dm.DmTransaction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import wpapp.dm.Dm_BeanFactory;
import wpapp.dm.DmM_CONST; // 你的数据模型

/**
 * 研修区分下拉框选项查询
 * 固定查询条件：CONST_ID = 'KoshuKbn' AND DEL_FLG = 0
 */
public class Common extends DispDataQuerier {
    private static final Log log = LogFactory.getLog(Common.class);

    /**
     * 扩展显示查询的入口点
     * @param tran 当前事务
     * @param params 参数列表（本示例不需要参数）
     * @return 数据模型的列表
     */
    @Override
    protected Collection queryDispData(DmTransaction tran, List params) throws Exception {
        // 准备返回用的List
        List results = new ArrayList();

        // 1. 直接在最前面添加空白选项
        DmM_CONST emptyItem = Dm_BeanFactory.createM_CONST();
        emptyItem.setCONST_CD("");              // 空值
        emptyItem.setCONST_NM("");              // 空白显示
        results.add(emptyItem);
        
        // JDBC连接获取
        PreparedStatement stmt = null;
        ResultSet rs = null;
        DmBroker broker = DmBrokerFactory.getBroker(tran);

        try {
            Connection con = broker.getConnection();

            // 取得连接并执行SQL
            // 固定查询：CONST_ID = 'KoshuKbn' 且 删除标志 = 0
            String sql = "SELECT CONST_CD, CONST_NM " +
                         "FROM M_CONST " +
                         "WHERE CONST_ID = 'KoshuKbn' " +
                         "  AND DEL_FLG = '0' " +
                         "ORDER BY CONST_CD ASC"; // 按代码排序

            log.debug("执行SQL: " + sql);
            
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                // 创建数据模型bean并填充结果
                DmM_CONST dm = Dm_BeanFactory.createM_CONST();
                dm.setCONST_CD(rs.getString("CONST_CD"));   // 代码作为value
                dm.setCONST_NM(rs.getString("CONST_NM"));   // 名称作为显示文本

                // 将数据模型bean添加到返回列表
                results.add(dm);
            }

            log.info("研修区分选项查询完成，共" + results.size() + "条记录");

            // 返回结果
            return results;
        }
        catch (SQLException e) {
            log.error("研修区分选项查询失败", e);
            throw e;
        }
        finally {
            // 关闭Statement，不关闭Connection
            if (rs != null) {
                try {
                    rs.close();
                } 
                catch (SQLException e) {
                    log.debug("关闭ResultSet失败", e);
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } 
                catch (SQLException e) {
                    log.debug("关闭Statement失败", e);
                }
            }
            broker.close(); // 必须关闭broker
        }
    }
}