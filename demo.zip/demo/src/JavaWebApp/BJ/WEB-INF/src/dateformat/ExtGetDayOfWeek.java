package dateformat;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import jp.co.canon_soft.wp.runtime.ExtException;

public class ExtGetDayOfWeek {

    /**
     * Format date as yyyy/MM/dd (weekday) in Japanese.
     * @param date Input date (java.sql.Date)
     * @return Formatted string (e.g., "2023/10/05 (木)")
     */
    public String execute(Date date) {
        if (date == null) {
            return null;
        }

        try {
            // Convert java.sql.Date to java.util.Date
            java.util.Date utilDate = new java.util.Date(date.getTime());

            // Format date as yyyy/MM/dd
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            String dateStr = dateFormat.format(utilDate);

            // Get weekday (1=Sunday, 2=Monday, ..., 7=Saturday)
            Calendar cal = Calendar.getInstance();
            cal.setTime(utilDate);
            int weekInt = cal.get(Calendar.DAY_OF_WEEK);

            // Map to Japanese weekday names
            String[] weekDays = {"日", "月", "火", "水", "木", "金", "土"};
            // For full Japanese weekday, use: {"日", "月", "火", "水", "木", "金", "土"};
            String weekDay = weekDays[weekInt - 1];

            return dateStr + " (" + weekDay + ")";

        } catch (Exception e) {
            throw new ExtException("Date format conversion failed", e);
        }
    }
}