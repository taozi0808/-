package ext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.canon_soft.wp.runtime.IoActionExtensionContext;
import jp.co.canon_soft.wp.runtime.IoActionExtension;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.Toolkit;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Paths;

import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;

public class ExtImportExcel implements IoActionExtension {
	private static Log log = LogFactory.getLog(ExtImportExcel.class);
	long begin = System.currentTimeMillis();

	String importPath = "c:\\tmp\\import.xls";

	@Override
	public void execute(final IoActionExtensionContext context) throws Exception {
		Map results = context.callBP();
		System.out.println("ExtImportExcel =====> results Map: " + results);

		importExcel();

		long end = System.currentTimeMillis();
		System.out.println("ExtImportExcel =====> Elapsed time (msec): " + (end - begin));
	}

	/**
	 * Excelファイルからデータを取込します。
	 */
	public void importExcel() throws FileNotFoundException, IOException, Exception {
		long start = System.currentTimeMillis();

		try (FileInputStream fis = new FileInputStream(importPath); Workbook workbook = WorkbookFactory.create(fis)) {

			// 最初のワークシートを取得します
			Sheet sheet = workbook.getSheetAt(0);

			// すべての行を反復処理します
			for (Row row : sheet) {
				// すべてのセルを反復処理します
				for (Cell cell : row) {
					String cellValue = getCellValueAsString(cell, sheet);
					System.out.print(cellValue + "\t");
				}
				// 改行
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.err.println("Filling time : " + (System.currentTimeMillis() - start));
	}

	/**
	 * 結合セルを処理するために、セルの内容を文字列に変換します。
	 */
	private static String getCellValueAsString(Cell cell, Sheet sheet) {
		// セルが結合領域内にあるかどうかを確認します。
		for (int i = 0; i < sheet.getNumMergedRegions(); i++) {
			CellRangeAddress mergedRegion = sheet.getMergedRegion(i);
			if (mergedRegion.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
				// 結合セルの場合は、最初のセルの値を返します。
				Row firstRow = sheet.getRow(mergedRegion.getFirstRow());
				Cell firstCell = firstRow.getCell(mergedRegion.getFirstColumn());
				return getCellValue(firstCell);
			}
		}
		return getCellValue(cell);
	}

	/**
	 * セルの種類に基づいて値を取得します。
	 */
	private static String getCellValue(Cell cell) {
		if (cell == null)
			return "";

		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				return cell.getDateCellValue().toString();
			} else {
				double numericValue = cell.getNumericCellValue();
				if (numericValue == (long) numericValue) {
					return String.valueOf((long) numericValue);
				} else {
					return String.valueOf(numericValue);
				}
			}
		case Cell.CELL_TYPE_BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_FORMULA:
			return cell.getCellFormula();
		default:
			return "";
		}
	}

}