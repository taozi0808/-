package ext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.canon_soft.wp.runtime.IoActionExtensionContext;
import jp.co.canon_soft.wp.runtime.IoActionExtension;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.Toolkit;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.*;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Paths;

import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;

public class ExtExportExcel implements IoActionExtension {
	private static Log log = LogFactory.getLog(ExtExportExcel.class);
	long begin = System.currentTimeMillis();

	String formatPath = "c:\\tmp\\format.xls";
	String exportPath = "c:\\tmp\\export.xls";

	@Override
	public void execute(final IoActionExtensionContext context) throws Exception {
		Map results = context.callBP();
		System.out.println("ExtExportExcel =====> results Map: " + results);

		exportExcel();

		long end = System.currentTimeMillis();
		System.out.println("ExtExportExcel =====> Elapsed time (msec): " + (end - begin));
	}

	/**
	 * Excelファイルにデータを書き込みます。
	 */
	public void exportExcel() throws FileNotFoundException, IOException, Exception {

		long start = System.currentTimeMillis();

		try (FileInputStream fis = new FileInputStream(formatPath);
				Workbook workbook = WorkbookFactory.create(fis)) {

			// 最初のワークシートを取得します
			Sheet sheet = workbook.getSheetAt(0);

			// 行とセルを取得または作成します (例: 行 5、列 2)
			Row row = sheet.getRow(1);
			if (row == null) {
				row = sheet.createRow(1);
			}

			Cell cell = row.getCell(0);
			if (cell == null) {
				cell = row.createCell(0);
			}

			// セルのスタイルを設定（日付形式）
			CellStyle dateStyle = workbook.createCellStyle();
			DataFormat dateFormat = workbook.createDataFormat();
			dateStyle.setDataFormat(dateFormat.getFormat("yyyy/m/d"));
			cell.setCellStyle(dateStyle);

			// セルの値を設定
			cell.setCellValue("2025/9/12");

			Cell cell2 = row.getCell(1);
			if (cell2 == null) {
				cell2 = row.createCell(1);
			}

			cell2.setCellFormula("IF(WEEKDAY(A2, 2)=1, \"月\", IF(WEEKDAY(A2, 2)=2, \"木\", IF(WEEKDAY(A2, 2)=3, \"水\", IF(WEEKDAY(A2, 2)=4, \"火\", IF(WEEKDAY(A2, 2)=5, \"金\", IF(WEEKDAY(A2, 2)=6, \"土\", \"日\"))))))");

			Cell cell3 = row.getCell(2);
			if (cell3 == null) {
				cell3 = row.createCell(2);
			}

			// セルのスタイルを設定（時間形式）
			CellStyle timeStyle = workbook.createCellStyle();
			DataFormat timeFormat = workbook.createDataFormat();
			timeStyle.setDataFormat(timeFormat.getFormat("h:mm"));
			cell3.setCellStyle(timeStyle);

			// セルの値を設定
			cell3.setCellValue("9:00");


			Cell cell4 = row.getCell(3);
			if (cell4 == null) {
				cell4 = row.createCell(3);
			}

			// セルの値を設定
			cell4.setCellValue("上級救命講習");

			// 新しいファイルとして保存
			try (FileOutputStream fos = new FileOutputStream(exportPath)) {
				workbook.write(fos);
			}

			System.out.println("Excelファイルが正常に変更され、保存されました!");
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.err.println("Filling time : " + (System.currentTimeMillis() - start));
	}

}