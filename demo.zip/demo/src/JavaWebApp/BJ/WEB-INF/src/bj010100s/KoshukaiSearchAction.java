package bj010100s;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.canon_soft.wp.runtime.IoActionExtension;
import jp.co.canon_soft.wp.runtime.IoActionExtensionContext;
import jp.co.canon_soft.wp.runtime.dm.DmBroker;
import jp.co.canon_soft.wp.runtime.dm.DmBrokerFactory;
import jp.co.canon_soft.wp.runtime.dm.DmTransaction;

// 导入画面Wrapper类
import wpapp.io.IoBJ010100SWrapper;

// 导入数据模型
import wpapp.dm.DmV_BJ010100S_S01;
import wpapp.dm.Dm_BeanFactory;

public class KoshukaiSearchAction implements IoActionExtension {
    
    private static Log log = LogFactory.getLog(KoshukaiSearchAction.class);
    
    @Override
    public void execute(final IoActionExtensionContext context) throws Exception {
        log.info("=== 講習会検索ボタン押下 開始 ===");
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        DmBroker broker = null;
        List<DmV_BJ010100S_S01> results = new ArrayList<>();  // 添加这行
        
        try {
            // 1. 获取数据库事务
            DmTransaction trans = context.getTransaction();
            broker = DmBrokerFactory.getBroker(trans);
            
            // 2. 获取画面包装类
            IoBJ010100SWrapper io = IoBJ010100SWrapper.get_Io();
            
            // 3. 获取数据库连接
            Connection con = broker.getConnection();
            
            // 4. 构建并执行SQL
            String sql = "SELECT TK.KOSHUKAI_CD AS KOSHUKAI_CD " +
                    "FROM T_KOSHUKAI TK " +
                    "WHERE TK.DEL_FLG <> '1' " +
                    "ORDER BY TK.KOSHUKAI_CD ASC";  // 添加排序
            
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            io.setKoshukai_cd("1");
            io.setG_koshukai_cd(new BigDecimal("1"),0);

//            while (rs.next()) {
//                count++;
//                
//                // 创建数据模型bean并填充结果
//                DmV_BJ010100S_S01 dm = Dm_BeanFactory.createV_BJ010100S_S01();
//                
//                // 注意：您的SQL查询的是 KOSHUKAI_CD，但代码中尝试获取 CONST_CD
//                // 修正为获取正确的列名
//                String koshukaiCd = rs.getString("KOSHUKAI_CD");
//                
//                // 如果KOSHUKAI_CD是数值型，需要转换为BigDecimal
//                // dm.setKOSHUKAI_CD(new BigDecimal(koshukaiCd));
//                // 或者如果是字符串型：
//                // 假设您的数据模型有相应的方法，需要查看DmV_BJ010100S_S01类的定义
//                
//                log.debug("取得レコード[" + count + "]: 講習会コード=" + koshukaiCd);
//                
//                // 将数据模型bean添加到返回列表
//                results.add(dm);
//            }
            
            // 6. 调用业务流程（如果按钮配置了BP）
            // Map<String, Object> bpResults = context.callBP();
            
            // 7. 设置到画面（这里需要根据实际的Wrapper类方法来设置）
            // io.setG_KOJU_INFO(results);  // 假设有这个方法
            
        } catch (SQLException e) {
            throw new Exception("データベース検索エラー", e);
        } catch (Exception e) {
            throw new Exception("講習会検索処理で予期せぬエラーが発生しました", e);
        } finally {
            // 关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                }
            }
            if (broker != null) {
                broker.close();
            }
        }
    }
}
