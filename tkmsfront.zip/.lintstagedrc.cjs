module.exports = {
  '{,**/}*.{md,json,yml,js,cjs,mjs,ts,cts,mts,html,tsx,css,scss}': ['prettier --write'],
};
