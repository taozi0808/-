import React, { FC, useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { DialogContent, TextField, Button, Box, IconButton } from '@mui/material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import './WebI0020CreateForm.scss';
import InputLabel from '@mui/material/InputLabel';
import CustomHeader from './CustomeHeader/CustomHeader';
import CustomSplitHeader from './CustomeHeader/CustomSplitHeader';
import SplitFormatCellRender from './CustomeCellRender/SplitFormatCellRender';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';

const WebI0020CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [startDate, setStartDate] = useState('2024-03');

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {
      siteCode: '000001-000-01',
      date: '2024-05-02',
      siteName: 'xxxxxxx',
      siteTypeName: 'eeeeeeee',
      startDate: 'zzzzz',
      endDate: '2025-03-31',
      saleAmountUp: '498,746,291',
      saleAmountDown: '411,746,291',
    },
    mode: 'onBlur',
  });

  useEffect(() => {
    setPageTitle('出来高シミュレーション入力');
    return () => setPageTitle('');
  }, [setPageTitle]);

  /** テンポラリメソッド */
  const tempGenerateColumnObject = () => {
    const generateNumber = () => {
      return Math.floor(Math.random() * 900000) + 100000;
    };

    const result = {};

    for (let col = 1; col <= 16; col++) {
      for (let g = 1; g <= 2; g++) {
        const upKey = `col${col}_${g}up`;
        const downKey = `col${col}_${g}down`;

        result[upKey] = Math.random() > 0.5 ? generateNumber() : '';
        result[downKey] = '';
      }
    }

    return result;
  };

  const generateMonths = () => {
    const months = [];
    const date = new Date(2024, 0);
    for (let i = 0; i < 16; i++) {
      months.push(`${date.getFullYear()}年${date.getMonth() + 1}月`);
      date.setMonth(date.getMonth() + 1);
    }
    return months;
  };

  const generateAllColumnConfigs = () => {
    const months = generateMonths();
    const allConfigs = [];
    for (let col = 1; col <= 16; col++) {
      const displayName = months[col - 1];
      for (let g = 1; g <= 2; g++) {
        const config = {
          field: `col${col}_g${g}`,
          headerComponent: CustomHeader,
          headerComponentParams: {
            displayName: displayName,
            type: 'default',
          },
          cellRenderer: SplitFormatCellRender,
          cellStyle: { padding: 0 },
          cellRendererParams: {
            keys: [`col${col}_${g}up`, `col${col}_${g}down`],
            upperType: 'span',
            lowerType: data => (data[`col${col}_${g}up`] ? 'input' : 'span'),
            prefix: '￥',
            upFormat: 'thousands',
            isFirst: false, // 初始为false，后续动态设置
          },
          width: 120,
        };
        allConfigs.push(config);
      }
    }
    return allConfigs;
  };

  const getColumnsStartingFrom = (sDate: any) => {
    const [yearStr, monthStr] = sDate.split('-');
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10);
    const startCol = (year - 2024) * 12 + month;
    if (startCol < 1 || startCol > 16) return [];

    const endCol = Math.min(startCol + 11, 16);
    const allConfigs = generateAllColumnConfigs();
    const startIndex = (startCol - 1) * 2;
    const endIndex = (endCol - 1) * 2 + 1;
    const filteredConfigs = allConfigs.slice(startIndex, endIndex + 1);

    const totalDisplayCols = Math.ceil(filteredConfigs.length / 2);
    for (let displayCol = 1; displayCol <= totalDisplayCols; displayCol++) {
      let headerType;
      if (displayCol === 1 || displayCol === 7) headerType = 'left';
      else if (displayCol === 6 || displayCol === 12) headerType = 'right';
      else headerType = 'default';

      const baseIndex = (displayCol - 1) * 2;
      [0, 1].forEach(offset => {
        const configIndex = baseIndex + offset;
        if (configIndex >= filteredConfigs.length) return;

        filteredConfigs[configIndex].headerComponentParams.type = headerType;

        if (displayCol === 1) {
          filteredConfigs[configIndex].cellRendererParams.isFirst = true;
        }
      });
    }

    return filteredConfigs;
  };

  console.log(getColumnsStartingFrom(startDate));

  const [rowData] = useState([
    {
      ...{
        field1up: '共同贩卖工事1',
        field1down: '2024年4月~2024年5月',
        field2up: '12345',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
    {
      ...{
        field1up: '共同贩卖工事2',
        field1down: '2024年5月~2024年8月',
        field2up: '2234',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
    {
      ...{
        field1up: '共同贩卖工事3',
        field1down: '2024年6月~2024年7月',
        field2up: '4234',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
    {
      ...{
        field1up: '共同贩卖工事4',
        field1down: '2024年7月~2024年8月',
        field2up: '2234',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
    {
      ...{
        field1up: '共同贩卖工事5',
        field1down: '2024年8月~2024年9月',
        field2up: '2234',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
    {
      ...{
        field1up: '共同贩卖工事6',
        field1down: '2024年9月~2024年10月',
        field2up: '2234',
        field2down: '-',
        field3up: '实际',
        field3down: '调整',
      },
      ...tempGenerateColumnObject(),
    },
  ]);

  const [columnDefs] = useState<ColDef[]>([
    {
      field: '',
      headerName: '予算项目/该当工期',
      headerClass: 'default-header-border-right',
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['field1up', 'field1down'],
      },
    },
    {
      field: 'field2',
      headerName: '',
      headerComponent: CustomSplitHeader,
      headerComponentParams: {
        upperText: '实行预选',
        lowerText: '差额',
      },
      headerClass: 'default-header-border-right',
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['field2up', 'field2down'],
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 100,
    },
    {
      field: 'field3',
      headerName: '',
      headerComponent: CustomSplitHeader,
      headerComponentParams: {
        upperText: '',
        lowerText: '',
      },
      headerClass: 'default-header-border-right',
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['field3up', 'field3down'],
      },
      width: 80,
    },
    {
      field: 'col1',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年4月',
        type: 'left',
      },
      cellRenderer: SplitFormatCellRender,
      cellRendererParams: {
        keys: ['col1_1up', 'col1_1down'],
        upperType: 'span',
        isFirst: true,
        lowerType: data => {
          if (data['col1_1up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      cellStyle: { padding: 0 },
      width: 120,
    },
    {
      field: 'col2',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年5月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col2_1up', 'col2_1down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col2_1up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col3',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年6月',
        firstName: '2024年度工期(上半期)',
        lastName: '金额',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col3_1up', 'col3_1down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col3_1up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col4',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年7月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col4_1up', 'col4_1down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col4_1up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col5',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年8月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col5_1up', 'col5_1down'],
        upperType: 'span',
        lowerType: data => {
          if (data['co5up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col6',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年9月',
        type: 'right',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col6_1up', 'col6_1down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col6_1up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col1',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年10月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col1_2up', 'col1_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col1_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col2',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年11月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col2_2up', 'col2_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col2_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col3',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2024年12月',
        firstName: '2024年度工期(下半期)',
        lastName: '金额',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col3_2up', 'col3_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col3_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col4',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2025年1月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col4_2up', 'col4_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col4_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col5',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2025年2月',
        type: 'default',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col5_2up', 'col5_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col5_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
    {
      field: 'col6',
      headerComponent: CustomHeader,
      headerComponentParams: {
        displayName: '2025年3月',
        type: 'right',
      },
      cellRenderer: SplitFormatCellRender,
      cellStyle: { padding: 0 },
      cellRendererParams: {
        keys: ['col6_2up', 'col6_2down'],
        upperType: 'span',
        lowerType: data => {
          if (data['col6_2up']) {
            return 'input';
          }
          return 'span';
        },
        prefix: '￥',
        upFormat: 'thousands',
      },
      width: 120,
    },
  ]);

  return (
    <>
      <DialogContent className="webI0020-container">
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 120, height: 40 }}>
              保存
            </Button>
          </div>
          <div style={{ marginRight: '12%' }}>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 120, height: 40 }}>
              印刷
            </Button>
          </div>
        </div>
        <form>
          <Box display="flex" flexDirection="column" gap={2} className="ad-search-estimate">
            <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
              <Box mr={2}>
                <Controller
                  name="siteCode"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>現場コード</label>
                      <TextField {...field} size="small" sx={{ width: '300px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="date"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>日付</label>
                        <TextField {...field} size="small" sx={{ width: '300px' }} />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>

            <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
              <Box mr={2}>
                <Controller
                  name="siteName"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>現場名</label>
                      <TextField {...field} size="small" sx={{ width: '300px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="siteTypeName"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>現場カナ名</label>
                        <TextField {...field} size="small" sx={{ width: '300px' }} />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>

            <Box display="flex" sx={{ width: '60%', justifyContent: 'space-between' }}>
              <Box mr={2}>
                <Controller
                  name="startDate"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>現場着工日</label>
                      <TextField {...field} size="small" sx={{ width: '300px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="endDate"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>場着完工日</label>
                        <TextField {...field} size="small" sx={{ width: '300px' }} />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            <Box display="flex" sx={{ width: '60%', marginTop: '3%' }} justifyContent={'space-between'} alignItems={'end'}>
              <Box mr={2}>
                <Controller
                  name="saleAmountUp"
                  control={control}
                  render={({ field }) => (
                    <div>
                      <InputLabel sx={{ marginLeft: '24%', marginBottom: '2%' }}>2024年度(上半期)</InputLabel>
                      <div className="ad-search-item">
                        <label>売上高</label>
                        <TextField {...field} size="small" sx={{ width: '240px' }} />
                      </div>
                    </div>
                  )}
                />
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <Controller
                    name="saleAmountDown"
                    control={control}
                    render={({ field }) => (
                      <div style={{ marginLeft: '-10%' }}>
                        <InputLabel sx={{ marginLeft: '24%', marginBottom: '2%' }}>2024年度(下半期)</InputLabel>
                        <div className="ad-search-item">
                          <label>売上高</label>
                          <TextField {...field} size="small" sx={{ width: '240px' }} />
                        </div>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box>
                <Button variant="contained" size="small" style={{ minWidth: 120, marginLeft: '7%', height: 40 }}>
                  按分
                </Button>
              </Box>
            </Box>
            <div className="ag-theme-alpine" style={{ width: '100%', height: '421px' }}>
              <AgGridReact rowData={rowData} theme={AGGridTheme} columnDefs={columnDefs} headerHeight={90} rowHeight={60} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <IconButton size="small">
                <KeyboardArrowLeftIcon />
              </IconButton>
              <IconButton size="small">
                <KeyboardArrowRightIcon />
              </IconButton>
            </div>
          </Box>
        </form>
      </DialogContent>
    </>
  );
};

export default WebI0020CreateForm;
