import React from 'react';
import { ICellRendererParams } from 'ag-grid-community';
import './SplitFormatCellRender.scss';

interface SplitCellParams extends ICellRendererParams {
  keys: any[];

  upperStyle?: React.CSSProperties | ((param) => React.CSSProperties);
  lowerStyle?: React.CSSProperties | ((param) => React.CSSProperties);

  upperType?: 'span' | 'input' | ((param) => 'span' | 'input');
  lowerType?: 'span' | 'input' | ((param) => 'span' | 'input');

  prefix?: string;
  upFormat?: 'thousands' | 'percentage' | 'default';
  downFormat?: 'thousands' | 'percentage' | 'default';

  isFirst?: boolean;
}

const SplitFormatCellRender = (props: SplitCellParams) => {
  const { upperStyle, lowerStyle, upperType, lowerType, prefix, upFormat, downFormat, data, keys, isFirst } = props;

  const upperValue = data[keys[0]];
  const lowerValue = data[keys[1]];

  const formatValue = (value: any, format) => {
    if (!value) return value;

    if (format === 'thousands') {
      const returnValue = new Intl.NumberFormat().format(parseInt(value, 10));
      return `${prefix} ${returnValue}`;
    } else if (format === 'percentage') {
      return `${(value * 100).toFixed(2)}%`;
    } else {
      return prefix ? `${prefix} ${value}` : value;
    }
  };

  const renderContent = (type: 'span' | 'input' | ((param) => 'span' | 'input'), value: any) => {
    const renderType = typeof type === 'function' ? type(data) : type;
    return renderType === 'span' ? (
      <span className="cell-span">{value}</span>
    ) : (
      <input type="text" className="cell-input" value={value} style={isFirst ? { background: 'gray' } : { background: 'lightsalmon' }} />
    );
  };

  const renderStyle = (style: React.CSSProperties | ((param) => React.CSSProperties)) => {
    if (!style) return {};
    return typeof style === 'function' ? style(data) : style;
  };

  return (
    <div className="split-format-cell-container" style={isFirst ? { background: 'gray' } : {}}>
      <div className="upper-cell" style={renderStyle(upperStyle)}>
        {renderContent(upperType || 'span', formatValue(upperValue, upFormat))}
      </div>
      <div className="cell-divided"></div>
      <div className="lower-cell" style={renderStyle(lowerStyle)}>
        {renderContent(lowerType || 'span', formatValue(lowerValue, downFormat))}
      </div>
    </div>
  );
};

export default SplitFormatCellRender;
