import React from 'react';
import type { IHeaderParams } from 'ag-grid-community';
import './CustomSplitHeader.scss';

interface CustomerHeaderParams extends IHeaderParams {
  upperText?: string;
  lowerText?: string;
}

const CustomSplitHeader = (props: CustomerHeaderParams) => {
  return (
    <div className="splitContainer">
      <div className="splitUpper">{props.upperText}</div>
      <div className="splitLower">{props.lowerText}</div>
    </div>
  );
};

export default CustomSplitHeader;
