import React, { useState } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box,
  IconButton,
  Select,
  MenuItem,
} from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './index.scss';

const AdvancedSearchDialog = () => {
  const [open, setOpen] = useState(false);
  // ポップアップ開ける処理
  const handleClickOpen = () => setOpen(true);
  // ポップアップ閉じる処理
  const handleClose = () => {
    setOpen(false);
    // ポップアップが閉じる後、データをクリアする
    setTimeout(() => {
      reset();
    }, 0);
  };

  // 仮データ START
  const genjyoCodeList = [
    { value: '1', label: '1234567-000-001', remark: 'なし' },
    { value: '2', label: '1234567-000-002', remark: 'なし' },
    { value: '3', label: '1234567-000-003', remark: 'なし' },
    { value: '4', label: '1234567-000-004', remark: 'なし' },
    { value: '5', label: '1234567-000-005', remark: 'なし' },
    { value: '6', label: '1234567-000-006', remark: 'なし' },
    { value: '7', label: '1234567-000-007', remark: 'なし' },
    { value: '8', label: '1234567-000-008', remark: 'なし' },
    { value: '9', label: '1234567-000-009', remark: 'なし' },
  ];

  const yosansakuseibumonList = [
    { value: '1', label: '管理部' },
    { value: '2', label: '開発部' },
  ];

  const genjyoNameList = [
    { value: '1', label: '現場001' },
    { value: '2', label: '現場002' },
    { value: '3', label: '現場003' },
    { value: '4', label: '現場004' },
  ];

  const yosanSakuseisyaList = [
    { value: '1001', label: '作成001' },
    { value: '1002', label: '作成002' },
    { value: '1003', label: '作成003' },
    { value: '1004', label: '作成004' },
    { value: '1005', label: '作成005' },
  ];

  const jikkoYosanCodeList = [
    { value: '1', label: 'Y1234567-000-001' },
    { value: '2', label: 'Y1234567-000-002' },
    { value: '3', label: 'Y1234567-000-003' },
    { value: '4', label: 'Y1234567-000-004' },
    { value: '5', label: 'Y1234567-000-005' },
  ];
  // 仮データ END

  const { control, handleSubmit, reset } = useForm({
    defaultValues: {
      // 現場コード
      genjyoCode: '',
      // 予算作成部門
      yosansakuseibumon: '',
      // 現場名
      genjyoName: '',
      // 予算作成者
      yosanSakuseisya: '',
      // 実行予算コード
      jikkoYosanCode: '',
      // 予算作成済を表示フラグ
      yosanSakuseiZumiFlg: true,
      // 予算申請日
      yosanSinseiDateFrom: '',
      yosanSinseiDateTo: '',
      // 予算承認日
      yosanSyoninDateFrom: '',
      yosanSyoninDateTo: '',
    },
  });

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <React.Fragment>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleClickOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />

        <DialogContent className="dialog-background-color">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="ad-search-container-jikko-yosan" style={{ margin: '0px 10px' }}>
              {/* 一行目: 現場コード、予算作成部門 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="genjyoCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>現場コード</label>
                        <Select size="small" inputRef={field.ref} fullWidth {...field}>
                          <MenuItem key={''} value={''}></MenuItem>
                          {genjyoCodeList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="yosansakuseibumon"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>予算作成部門</label>
                        <Select size="small" inputRef={field.ref} fullWidth {...field}>
                          <MenuItem key={''} value={''}></MenuItem>
                          {yosansakuseibumonList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              {/* 二行目: 現場名、予算作成者 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="genjyoName"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>現場名</label>
                        <Select size="small" inputRef={field.ref} fullWidth {...field}>
                          <MenuItem key={''} value={''}></MenuItem>
                          {genjyoNameList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="yosanSakuseisya"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>予算作成者</label>
                        <Select size="small" inputRef={field.ref} fullWidth {...field}>
                          <MenuItem key={''} value={''}></MenuItem>
                          {yosanSakuseisyaList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              {/* 三行目 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="jikkoYosanCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>実行予算コード</label>
                        <Select size="small" inputRef={field.ref} fullWidth {...field}>
                          <MenuItem key={''} value={''}></MenuItem>
                          {jikkoYosanCodeList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="yosanSakuseiZumiFlg"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label></label>
                        <FormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              checked={field.value}
                              onChange={e => {
                                field.onChange(e.target.checked);
                              }}
                            />
                          }
                          label="予算作成済の現場を表示する"
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              {/* 四行目 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={0.5} mr={2}>
                  <div className="ad-search-item">
                    <label>予算申請日</label>
                    <Controller
                      name="yosanSinseiDateFrom"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" className="custom-datepicker" {...field} />}
                    />
                    <div className="from-to-tilde">～</div>
                    <Controller
                      name="yosanSinseiDateTo"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" className="custom-datepicker" {...field} />}
                    />
                  </div>
                </Box>
              </Box>
              {/* 五行目 */}
              <Box display="flex" justifyContent="space-between">
                <Box flex={0.5} mr={2}>
                  <div className="ad-search-item">
                    <label>予算承認日</label>
                    <Controller
                      name="yosanSyoninDateFrom"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" className="custom-datepicker" {...field} />}
                    />
                    <div className="from-to-tilde">～</div>
                    <Controller
                      name="yosanSyoninDateTo"
                      control={control}
                      render={({ field }) => <TextField type="date" size="small" className="custom-datepicker" {...field} />}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
};

export default AdvancedSearchDialog;
