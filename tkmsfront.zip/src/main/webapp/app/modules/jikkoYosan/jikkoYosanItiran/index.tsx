import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './index.scss';
import dayjs from 'dayjs';
import { STORAGE_KEY, DBManager, generateRandomData, similarDepartments } from 'app/shared/util/construction-list';
import AdvancedSearchDialog from './AdvancedSearchDialog';
import { Column, FieldType, Filters } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const JikkoYosanItiran = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // TODO: 后续接口对接后，两个权限的默认值都要改为false
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // TODO: 后续下面前三个字段要做替换
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // TODO: 有了接口文档后放开下面的代码
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 临时mock数据
    let contractList = DBManager.getList();
    if (contractList.length === 0) {
      contractList = generateRandomData(500);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const mockRowData = [{ id: 1, name: 'a' }];

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('実行予算一覧');
    // 为了看到印刷和CSV出力按钮, 临时增加一条rowData
    setRowData(mockRowData);
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="jikko-yosan-list">
        <div className="top-operation">
          <div>
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/contractEntry/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                // disabled={!selectedId}
                onClick={() => {
                  // navigate(`/contractEntry/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
          </div>
          <div>
            <AdvancedSearchDialog />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* 表格区域 */}
        {/* <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO: 后期正式对接，需要根据接口返回的权限来控制右击菜单可用性
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/contractEntry/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/contractEntry/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        /> */}
      </div>
    </div>
  );
};

export default JikkoYosanItiran;
