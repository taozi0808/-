import React, { useState, useRef, useEffect } from 'react';
import dayjs from 'dayjs';
import PageTitle from 'app/components/PageTitle';
import { STORAGE_KEY, DBManager, generateRandomData } from 'app/shared/util/construction-list';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import ColumnSpanningTable from 'app/components/ColumnGroupTable';

const BudgetOverview = () => {
  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'no',
      width: 60,
      spanRows: true,
      headerClass: 'center-header',
      cellClass: 'center-cell',
    },
    {
      headerName: '案件コード',
      field: 'ankenCode',
      width: 160,
      cellClass: 'center-cell',
      cellStyle: { backgroundColor: '#ccc' },

      children: [
        {
          headerName: '現場住所',
          field: 'genbaJyuusyo1',
          width: 160,
          // 控制表体单元格的数据渲染，第一行渲染ankenCode，第二行渲染genbaJyuusyo1的数据；
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.ankenCode : params.data.genbaJyuusyo1),
          // 控制表体单元格的跨行合并，第一行不合并，第二行合并2个单元格，也就是”現場住所“字段独占两个单元格；
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 2),
        },
      ],
    },
    {
      headerName: '概算',
      field: 'ankenName',
      width: 160,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      children: [
        {
          headerName: '',
          field: 'hiddenField1',
          headerClass: 'center-header',
          cellClass: 'center-cell',
          width: 160,
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.ankenName : ''),
        },
      ],
    },
    {
      headerName: '顧客名',
      field: 'kokyakuName',
      width: 280,
      spanRows: true,
      headerClass: 'center-header',
      cellClass: 'center-cell',
    },
    {
      headerName: '受注見込',
      field: 'jyucyuuMikomiYMD',
      width: 130,
      children: [
        {
          headerName: '着工希望日',
          field: 'cyakkouKibouYMD',
          width: 130,
          valueFormatter: (params: any) => {
            const val = params.node.rowIndex % 2 === 0 ? params.data.jyucyuuMikomiYMD : params.data.cyakkouKibouYMD;
            return val ? dayjs(val).format('YYYY年MM月DD日') : '';
          },
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 2 : 1),
        },
      ],
    },
    {
      headerName: '',
      field: 'hiddenField2',
      width: 130,
      children: [
        {
          headerName: '営業担当者',
          field: 'eigyouTantousyaShiMei',
          width: 130,
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? '' : params.data.eigyouTantousyaShiMei),
        },
      ],
    },
  ]);

  const [rowData, setRowData] = useState([]);

  const handleSearch = values => {
    // TODO: 后续下面前三个字段要做替换
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // 临时mock数据
    let contractList = DBManager.getList();
    if (contractList.length === 0) {
      contractList = generateRandomData(200);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    }

    setRowData(contractList);
  };

  useEffect(() => {
    handleSearch({});
  }, []);

  return (
    <div>
      <PageTitle title="概算一覧" />
      <ColumnSpanningTable
        data={rowData}
        columns={columnRef.current}
        colSpanMap={[
          {
            mainField: 'genbaJyuusyo1',
            subFields: ['hiddenField1'],
          },
          {
            mainField: 'jyucyuuMikomiYMD',
            subFields: ['hiddenField2'],
          },
        ]}
      />
    </div>
  );
};

export default BudgetOverview;
