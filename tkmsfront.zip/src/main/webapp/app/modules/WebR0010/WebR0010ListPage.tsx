import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { Button, Box, MenuItem, Select } from '@mui/material';
import './WebR0010ListPage.scss';
import { securityDataList1, securityDataList2 } from 'app/shared/util/construction-list';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { AGGridTheme } from 'app/app';
import { SubmitHandler, useForm } from 'react-hook-form';
const WebR0010ListPage = () => {
  // メニュー
  const ContextMenu = ({ x, y, containerRef, onAdd, onDelete, onCopy }) => {
    // メニューがコンテナの境界を超えないようにメニューの位置を計算します
    const calculateMenuPosition = (clientX, clientY) => {
      if (!containerRef?.current) return { x: clientX, y: clientY };

      const gridRect = containerRef.current.getBoundingClientRect();
      // メニューの幅
      const menuWidth = 120;
      // メニューの高
      const menuHeight = 96;

      // メニューが右を越える場合は左に移動します
      if (clientX + menuWidth > gridRect.right) {
        clientX = gridRect.right - menuWidth;
      }
      // メニューが下を越える場合は上に移動します
      if (clientY + menuHeight > gridRect.bottom) {
        clientY = gridRect.bottom - menuHeight;
      }
      return { x: clientX, y: clientY };
    };

    // 最終的なメニュー位置を計算する
    const { x: finalX, y: finalY } = calculateMenuPosition(x, y);
    return (
      <div
        className="menu"
        style={{
          left: finalX,
          top: finalY,
        }}
      >
        <ul>
          <li onClick={onCopy}>コビー</li>
          <li onClick={onDelete}>削除</li>
          <li onClick={onAdd}>追加</li>
        </ul>
      </div>
    );
  };
  // フォーム
  const {
    handleSubmit,
    formState: { errors },
    setValue,
    setError,
  } = useForm({
    defaultValues: {
      // 部門リスト
      bumonKengenList: [],
      // 役職リスト
      yakushokuKengenList: [],
    },
    mode: 'onBlur',
  });
  // 外側コンテナ参照
  const gridOuterContainerRef = useRef(null);
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData1, setRowData1] = useState(securityDataList1(8));
  // データ
  const [rowData2, setRowData2] = useState(securityDataList2(4));
  // AGGridすべての列のデフォルト構成を設定する
  const defaultColDef = useMemo(() => {
    return {
      // 列の内容の編集を許可する
      editable: true,
      // 列はソート不可
      sortable: false,
    };
  }, []);
  // 契約管理リスト
  const [keiyakuManagerList, setKeiyakuManagerList] = useState(['', '建築工事契約', '電気設備契約', '水道工事契約', '外構工事契約']);

  // 予算管理リスト
  const [yosanManagerList, setYosanManagerList] = useState(['', '基本設計予算', '実施設計予算', '施工予算', '予備費']);

  // 発注管理リスト
  const [hatchuManagerList, setHatchuManagerList] = useState(['', '資材発注', '人材発注', '重機リース', '専門業者委託']);

  // 査定/支払/請求管理リスト
  const [sateiShiharaiSeihyuManagerList, setSateiShiharaiSeihyuManagerList] = useState([
    '',
    '出来高査定',
    '進捗支払',
    '最終請求',
    '修正請求',
  ]);

  // 工事経費管理リスト
  const [kojiKeihiManagerList, setKojiKeihiManagerList] = useState(['', '人件費', '資材費', '設備賃借料', '安全管理費']);

  // 工事予実管理リスト
  const [kojiYojitsuManagerList, setKojiYojitsuManagerList] = useState(['', '基礎工事', '躯体工事', '設備工事', '仕上工事']);

  // 業者管理リスト
  const [gyoshaManagerList, setGyoshaManagerList] = useState(['', '建設', '電気', '管工', '資材']);

  // 承認管理リスト
  const [shoninManagerList, setShoninManagerList] = useState(['', '現場承認', '支店長承認', '本社決済', '顧客確認']);

  // マスタ・連携管理リスト
  const [masterManagerList, setMasterManagerList] = useState(['', '資材マスタ', '工程マスタ', 'ERP連携', 'CAD連携']);
  const kenkoushindan = ['', '〇', '✕'];
  // 組織適用開始日付
  const [dateList, setDateList] = useState([
    { id: 1, name: '2025/01/01', code: '0002' },
    { id: 2, name: '2025/01/02', code: '0003' },
    { id: 3, name: '2025/01/03', code: '0004' },
  ]);
  // メッセージ
  const [message, setMessage] = useState('');
  // カラム１
  const columnRef1 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '部門コード',
      field: 'bumonCode',
      width: 106,
      headerClass: 'header-center',
      cellClass: 'center',
      editable: false,
    },
    {
      headerName: '部門名',
      field: 'bumonName',
      width: 90,
      headerClass: 'header-center',
      cellClass: 'center',
      editable: false,
    },
    {
      headerName: '業務内容',
      field: 'info',
      headerClass: 'header-center',
      children: [
        {
          headerName: '契約管理',
          field: 'keiyakuManager',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: keiyakuManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '予算管理',
          field: 'yosanManager',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: yosanManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '発注管理',
          field: 'hatchuManager',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: hatchuManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '査定/支払/請求管理',
          field: 'sateiShiharaiSeihyuManager',
          width: 160,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: sateiShiharaiSeihyuManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '工事経費管理',
          field: 'kojiKeihiManager',
          width: 120,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kojiKeihiManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '工事予実管理',
          field: 'kojiYojitsuManager',
          width: 120,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kojiYojitsuManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '業者管理',
          field: 'gyoshaManager',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: gyoshaManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '承認管理',
          field: 'shoninManager',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: shoninManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: 'マスタ・連携管理',
          field: 'masterManager',
          width: 160,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: masterManagerList,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
      ],
    },
  ]);
  // カラム2
  const columnRef2 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '役職コード',
      field: 'yakushokuCode',
      width: 106,
      cellDataType: 'text',
      headerClass: 'header-center',
      cellClass: 'center',
    },
    {
      headerName: '役職名',
      field: 'yakushokuName',
      width: 90,
      cellDataType: 'text',
      headerClass: 'header-center',
      cellClass: 'center',
    },
    {
      headerName: '権限',
      field: 'kengen',
      headerClass: 'header-center',
      children: [
        {
          headerName: '承認',
          field: 'shonin',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kenkoushindan,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '削除',
          field: 'delete',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kenkoushindan,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '保存',
          field: 'save',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kenkoushindan,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '編集',
          field: 'edit',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kenkoushindan,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
        {
          headerName: '参照',
          field: 'preview',
          width: 90,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: kenkoushindan,
          },
          headerClass: 'header-center',
          cellClass: 'center',
        },
      ],
    },
  ]);
  // テーブルデータ変更処理
  const handleGrid1Change = useCallback(
    params => {
      const newData = rowData1.map(row => (row.id === params.data.id ? params.data : row));
      setRowData1(newData);
    },
    [rowData1],
  );

  const handleGrid2Change = useCallback(
    params => {
      const newData = rowData2.map(row => (row.id === params.data.id ? params.data : row));
      setRowData2(newData);
    },
    [rowData2],
  );

  // テーブルコンテナにバインドする
  const gridContainerRef = useRef<HTMLDivElement>(null);
  // AgGridReact インスタンスにバインドする
  const gridApiRef = useRef<AgGridReact>(null);
  // メニューフック
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; data: any } | null>(null);
  // 右クリックイベント
  const onCellContextMenu = (e: any) => {
    // セットメニュー
    setContextMenu({
      x: e.event.x,
      y: e.event.y,
      data: e.node.data,
    });
  };
  // 追加イベント
  const onAdd = () => {
    const maxId = rowData2.length > 0 ? Math.max(...rowData2.map(item => item.id)) : 0;
    setRowData2([
      ...rowData2,
      {
        id: maxId + 1,
        yakushokuCode: '',
        yakushokuName: '',
        shonin: '',
        delete: '',
        edit: '',
        preview: '',
        save: '',
      },
    ]);
    setContextMenu(null);
  };
  // 削除イベント
  const onDelete = () => {
    setRowData2(rowData2.filter(item => item.id !== contextMenu.data.id));
    setContextMenu(null);
  };

  // コビーイベント
  const onCopy = () => {
    const maxId = rowData2.length > 0 ? Math.max(...rowData2.map(item => item.id)) : 0;
    setRowData2([
      ...rowData2,
      {
        ...contextMenu.data,
        id: maxId + 1,
      },
    ]);
    setContextMenu(null);
  };
  // スクロールするとメニューを閉じるイベント
  const handleScroll = () => {
    setContextMenu(null);
  };
  // 左クリックイベント
  const onRowClicked = (event: any) => {
    if (contextMenu) {
      // 左クリックでメニューを閉じる
      setContextMenu(null);
    }
  };
  const onSave: SubmitHandler<any> = formData => {
    // TODO 保存API
    console.log(`FormData: ${formData}`);
  };
  // ソート
  const sortedList = [...rowData2].sort((a, b) => {
    if (a.dataKbn === 1 && b.dataKbn !== 1) return -1;
    if (b.dataKbn === 1 && a.dataKbn !== 1) return 1;
    return 0;
  });
  useEffect(() => {
    // 役職情報TBLの初期データ区分が"1"のデータを優先的に表示し、
    setRowData2(sortedList);
    // 外側のコンテナ
    const outerContainer = gridOuterContainerRef.current;
    // 外側のコンテナのスクロールイベントを聞く
    if (outerContainer) {
      outerContainer.addEventListener('scroll', handleScroll);
    }
    // タイトル
    setPageTitle('権限管理');
    return () => {
      // ブラウザのスクロールメニューイベントをリッスンする
      window.removeEventListener('scroll', handleScroll);
      // タイトル
      setPageTitle('');
    };
  }, []);
  // テーブルデータをフォームに同期する
  useEffect(() => {
    setValue('bumonKengenList', rowData1);
  }, [rowData1, setValue]);
  // テーブルデータをフォームに同期する
  useEffect(() => {
    setValue('yakushokuKengenList', rowData2);
  }, [rowData2, setValue]);
  return (
    <div>
      <div className="webR0010-container" ref={gridOuterContainerRef} id="contract-list-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
            <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
          </div>
        </div>

        {/* テーブルエリア */}
        <Box
          onContextMenu={e => {
            e.preventDefault();
          }}
          component="form"
          onSubmit={handleSubmit(onSave)}
        >
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit">
                保存
              </Button>
            </div>
          </div>
          <div className="item1">
            <div className="messageDiv">{message}</div>
            <div>
              <label>組織適用開始日付</label>
              <Select style={{ width: '160px' }} size="small">
                {dateList.map(item => (
                  <MenuItem key={item.code} value={item.code}>
                    {item.name}
                  </MenuItem>
                ))}
              </Select>
            </div>
          </div>
          <Box>
            <Box style={{ width: '100%', height: '450px' }}>
              <AgGridReact
                rowData={rowData1}
                theme={AGGridTheme}
                columnDefs={columnRef1.current}
                defaultColDef={defaultColDef}
                enableCellSpan
                alwaysShowVerticalScroll
                alwaysShowHorizontalScroll
                onCellValueChanged={handleGrid1Change}
              />
            </Box>
            <Box mt={2}>
              <div ref={gridContainerRef} style={{ width: '659px', height: '266px' }}>
                <AgGridReact
                  ref={gridApiRef}
                  rowData={rowData2}
                  theme={AGGridTheme}
                  columnDefs={columnRef2.current}
                  defaultColDef={defaultColDef}
                  enableCellSpan
                  onCellContextMenu={onCellContextMenu}
                  onRowClicked={onRowClicked}
                  alwaysShowVerticalScroll
                  onCellValueChanged={handleGrid2Change}
                />
              </div>
              {/* 右クリックメニューを表示 */}
              {contextMenu && contextMenu.data.dataKbn !== 1 && (
                <ContextMenu
                  containerRef={gridContainerRef}
                  x={contextMenu.x}
                  y={contextMenu.y}
                  onAdd={onAdd}
                  onDelete={onDelete}
                  onCopy={onCopy}
                />
              )}
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebR0010ListPage;
