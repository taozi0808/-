import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebH0030CreateForm.scss';
import dayjs from 'dayjs';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, Controller } from 'react-hook-form';
import { Box, TextField, Button, FormControlLabel, Radio, RadioGroup, Menu, MenuItem } from '@mui/material';
import { SateiTourokuFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, sagyouInData } from 'app/shared/util/construction-list';
import { ColDef, ColGroupDef, CellContextMenuEvent } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const WebH0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');
  const [contextMenu, setContextMenu] = useState<{
    mouseX: number;
    mouseY: number;
    rowData: any;
  } | null>(null);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<SateiTourokuFormValues>({
    defaultValues: {
      genbaCode: '',
      genbaName: '',
      genbaCanaName: '',
      koujiKoutei: '',
      genbaChakushuNichi: '',
      genbaBikiWataruNichi: '',
      jikkouYosanKingaku: '',
      hatchuuKingaku: '',
      miHatchuuKingaku: '',
      zengetsuMadeSateiKingaku: '',
      zengetsuSateiKingaku: '',
      sateiSayamaGoukeiKingaku: '',
      miSateiZan: '',
      zentaiShinchokuRitsu: '',
      miSateiZan1: '',
      sateiShouninNichi: '',
      meisaiHyoji: '0',
    },
    mode: 'onBlur',
  });

  const [dataSource, setDataSource] = useState([]);
  const defaultColDef = useMemo(() => {
    return {
      editable: type === 'edit',
      singleClickEdit: true,
    };
  }, []);

  const onCellContextMenu = (event: CellContextMenuEvent) => {
    event.event.preventDefault();
    setContextMenu({
      mouseX: (event.event as any).clientX,
      mouseY: (event.event as any).clientY,
      rowData: event.data,
    });
  };

  // メニューを閉じる
  const handleClose = () => {
    setContextMenu(null);
  };

  // メニュー項目のクリックを処理する
  const handleMenuItemClick = () => {
    if (contextMenu) {
      clearSubSupplier(contextMenu.rowData.index, contextMenu.rowData.originIndex);
      handleClose();
    }
  };

  const clearSubSupplier = (index: number, originIndex: number) => {
    setContextMenu(null);
  };

  // 明細項目定義
  const tableColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '',
      field: 'tag',
      width: 40,
      spanRows: true,
      cellClass: 'center-cell',
      cellStyle: params => {
        if (params.data.gyoushaCode) {
          return { backgroundColor: '#92FF96' };
        }
        return null;
      },
    },
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
      cellClass: 'center-cell',
      cellStyle: params => {
        if (params.data.gyoushaCode) {
          return { backgroundColor: '#92FF96' };
        }
        return null;
      },
    },
    {
      headerName: '業者コード',
      field: 'gyoushaCode',
      width: 130,
      children: [
        {
          headerName: '業者名',
          field: 'gyoushaName',
          width: 130,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.gyoushaCode : params.data.gyoushaName),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.gyoushaCode = params.newValue;
            } else {
              params.data.gyoushaName = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '大工種',
      field: 'daikushu',
      width: 160,
      children: [
        {
          headerName: '小工種',
          field: 'shoukoushu',
          width: 160,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.daikushu : params.data.shoukoushu),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikushu = params.newValue;
            } else {
              params.data.shoukoushu = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '注文書No',
      field: 'chuuBunshoNo',
      width: 155,
      cellClass: 'end-cell',
      children: [
        {
          headerName: '発注金額',
          field: 'hatchuuKingaku',
          width: 155,
          cellClass: 'end-cell',
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.chuuBunshoNo : params.data.hatchuuKingaku),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.chuuBunshoNo = params.newValue;
            } else {
              params.data.hatchuuKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value && params.node.rowIndex % 2 !== 0) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '前月迄査定金額',
      field: 'zengetsuMadeSateiKingaku',
      width: 150,
      cellClass: 'center-cell',
      children: [
        {
          headerName: '当月査定金額',
          field: 'zengetsuSateiKingaku',
          cellClass: 'end-cell',
          width: 150,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.zengetsuMadeSateiKingaku : params.data.zengetsuSateiKingaku),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.zengetsuMadeSateiKingaku = params.newValue;
            } else {
              params.data.zengetsuSateiKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '査定済合計金額',
      field: 'sateiSayamaGoukeiKingaku',
      width: 170,
      cellClass: 'center-cell',
      children: [
        {
          headerName: '未査定残',
          field: 'miSateiZan',
          cellClass: 'end-cell',
          width: 170,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.sateiSayamaGoukeiKingaku : params.data.miSateiZan),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.sateiSayamaGoukeiKingaku = params.newValue;
            } else {
              params.data.miSateiZan = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '進捗率',
      field: 'shinchokuRitsu',
      width: 85,
      spanRows: true,
      cellClass: 'center-cell',
      cellStyle: params => {
        if (params.data.gyoushaCode) {
          return { backgroundColor: '#92FF96' };
        }
        return null;
      },
      valueFormatter: (params: any) => {
        if (params.value) {
          Intl.NumberFormat('en-US').format(params.value);
          return params.value + '%';
        }
      },
    },
  ]);

  const getRowStyle = (params: any) => {
    if (params.data.gyoushaCode) {
      return { backgroundColor: '#92FF96' };
    }
    return null;
  };

  /** TODO: 工事行程 */
  const genbaCodeSearch = () => {};

  /** TODO: 明細表示 */
  const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状態
    setValue('meisaiHyoji', (event.target as HTMLInputElement).value);
  };

  const clear = () => {
    setValue('genbaCode', '');
    setValue('genbaName', '');
    setValue('genbaCanaName', '');
    setValue('koujiKoutei', '');
    setValue('genbaChakushuNichi', '');
    setValue('genbaBikiWataruNichi', '');
    setValue('jikkouYosanKingaku', '');
    setValue('hatchuuKingaku', '');
    setValue('miHatchuuKingaku', '');
    setValue('zengetsuMadeSateiKingaku', '');
    setValue('zengetsuSateiKingaku', '');
    setValue('sateiSayamaGoukeiKingaku', '');
    setValue('miSateiZan', '');
    setValue('zentaiShinchokuRitsu', '');
    setValue('miSateiZan1', '');
    setValue('sateiShouninNichi', '');
    setValue('meisaiHyoji', '0');
    setDataSource(null);
  };

  useEffect(() => {
    // データ
    const tempDataSource = [];
    for (let i = 0; i < 5; i++) {
      if (i < 2) {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          gyoushaCode: '10000',
          gyoushaName: 'A社',
          daikushu: '東京駅舎基礎工事',
          shoukoushu: '仮設足場',
          chuuBunshoNo: 'J000000000001',
          hatchuuKingaku: 100000,
          zengetsuMadeSateiKingaku: 600000,
          zengetsuSateiKingaku: 1800000,
          sateiSayamaGoukeiKingaku: 900000,
          miSateiZan: 300000,
          shinchokuRitsu: 40 + i,
          // tag: i % 2 === 0 ? '-' : '',
        });
      } else {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          gyoushaCode: '10001',
          gyoushaName: 'B社',
          daikushu: '東京駅舎基礎工事',
          shoukoushu: '仮設足場',
          chuuBunshoNo: 'J000000000001',
          hatchuuKingaku: 100000,
          zengetsuMadeSateiKingaku: 600000,
          zengetsuSateiKingaku: 1500000,
          sateiSayamaGoukeiKingaku: 800000,
          miSateiZan: 300000,
          shinchokuRitsu: 50 + i,
          // tag: i % 2 === 0 ? '-' : '',
        });
      }
    }
    setDataSource(tempDataSource);

    // まず、明細表の各データを使用して、業者コードに従って集約する；
    const categoryMap = {};
    tempDataSource.forEach(item => {
      if (categoryMap[item.gyoushaCode]) {
        categoryMap[item.gyoushaCode].push(item);
      } else {
        categoryMap[item.gyoushaCode] = [item];
      }
    });

    // 業者コードの集計データを計算する
    const newCurData = [];
    const list = [];
    for (const category in categoryMap) {
      const firstTotalRow = categoryMap[category].reduce(
        (acc, row) => ({
          gyoushaName: row.gyoushaName,
          hatchuuKingaku: acc.hatchuuKingaku + row.hatchuuKingaku,
          zengetsuMadeSateiKingaku: acc.zengetsuMadeSateiKingaku + row.zengetsuMadeSateiKingaku,
          zengetsuSateiKingaku: acc.zengetsuSateiKingaku + row.zengetsuSateiKingaku,
          sateiSayamaGoukeiKingaku: acc.sateiSayamaGoukeiKingaku + row.sateiSayamaGoukeiKingaku,
          miSateiZan: acc.miSateiZan + row.miSateiZan,
          shinchokuRitsu: (
            ((acc.sateiSayamaGoukeiKingaku + row.sateiSayamaGoukeiKingaku) / (acc.zengetsuSateiKingaku + row.zengetsuSateiKingaku)) *
            100
          ).toFixed(2),
        }),
        {
          hatchuuKingaku: 0,
          zengetsuMadeSateiKingaku: 0,
          zengetsuSateiKingaku: 0,
          sateiSayamaGoukeiKingaku: 0,
          miSateiZan: 0,
          shinchokuRitsu: 0,
        },
      );
      list.push({
        no: list.length.toString(),
        gyoushaCode: category,
        ...firstTotalRow,
      });
    }

    // IDを再計算する
    let tableID = 1;
    let dateFlg = true;
    for (let i = 0; i < tempDataSource.length; i++) {
      if (i !== 0 && tempDataSource[i].gyoushaCode !== tempDataSource[i - 1].gyoushaCode) {
        dateFlg = true;
      }
      for (let x = 0; x < list.length; x++) {
        if (list[x].gyoushaCode === tempDataSource[i].gyoushaCode && dateFlg) {
          newCurData.push({
            id: i + tableID,
            tag: '-',
            gyoushaCode: list[x].gyoushaCode,
            gyoushaName: list[x].gyoushaName,
            hatchuuKingaku: list[x].hatchuuKingaku,
            zengetsuMadeSateiKingaku: list[x].zengetsuMadeSateiKingaku,
            zengetsuSateiKingaku: list[x].zengetsuSateiKingaku,
            sateiSayamaGoukeiKingaku: list[x].sateiSayamaGoukeiKingaku,
            miSateiZan: list[x].miSateiZan,
            shinchokuRitsu: list[x].shinchokuRitsu,
          });
          dateFlg = false;
          tableID = tableID + 1;
        }
      }
      const newTempDataSource = tempDataSource[i];
      newTempDataSource.id = i + tableID;
      newCurData.push(newTempDataSource);
    }

    // データ設定
    const newCurData1 = [];
    for (let i = 0; i < newCurData.length; i++) {
      if (newCurData[i].tag === undefined) {
        newCurData[i].tag = '';
        newCurData[i].gyoushaCode = '';
        newCurData[i].gyoushaName = '';
      }
      newCurData1.push(newCurData[i]);
      newCurData1.push(newCurData[i]);
    }
    setDataSource(newCurData1);

    // 一時的なモックデータ
    let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_SATEI996');
    // let SagyouInList = DBManager.getList();
    if (sagyouInList.length === 0) {
      sagyouInList = sagyouInData(500);
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_SATEI996', JSON.stringify(sagyouInList));
    }

    if (id === undefined) {
      console.log('データ異常');
    } else {
      const editData = sagyouInList.find(item => item.id === id) || null;
      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('genbaCode', editData.genbaCode);
        setValue('genbaName', editData.genbaName);
        setValue('genbaCanaName', 'アイウエオ');
        setValue('koujiKoutei', editData.kojiKotei);
        setValue('genbaChakushuNichi', dayjs('2023-06-22T02:46:43.555Z').format('YYYY年MM月DD日'));
        setValue('genbaBikiWataruNichi', dayjs('2023-06-22T02:46:43.555Z').format('YYYY年MM月DD日'));
        setValue('jikkouYosanKingaku', Intl.NumberFormat('en-US').format(5400000));
        setValue('hatchuuKingaku', Intl.NumberFormat('en-US').format(5400000));
        setValue('miHatchuuKingaku', '0');
        setValue('zengetsuMadeSateiKingaku', Intl.NumberFormat('en-US').format(3240000));
        setValue('zengetsuSateiKingaku', Intl.NumberFormat('en-US').format(98000));
        setValue('sateiSayamaGoukeiKingaku', Intl.NumberFormat('en-US').format(4220000));
        setValue('miSateiZan', Intl.NumberFormat('en-US').format(1180000));
        setValue('zentaiShinchokuRitsu', '80');
        setValue('miSateiZan1', Intl.NumberFormat('en-US').format(1180000));
        setValue('sateiShouninNichi', Intl.NumberFormat('en-US').format(1180000));
        setValue('meisaiHyoji', '0');
      }
    }

    setPageTitle('査定登録');
    return () => setPageTitle('');
  }, []);

  const renderTextField = (label: string, name: keyof SateiTourokuFormValues, required: boolean = false) => (
    <Controller
      name={name}
      control={control}
      disabled={isHensyuuKengen}
      render={({ field, fieldState }) => (
        <Box display="flex" sx={{ width: '95%' }}>
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
          />
        </Box>
      )}
    />
  );

  return (
    <div>
      <div className="webh0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{`【最終更新日】`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <div>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                type="submit"
                disabled={isHensyuuKengen}
              >
                保存
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {}}
                disabled={isHensyuuKengen}
              >
                申請
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  clear();
                }}
                disabled={isHensyuuKengen}
              >
                クリア
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {}}
                disabled={isHensyuuKengen}
              >
                削除
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webH0010`);
                }}
              >
                キャンセル
              </Button>
            </div>
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} disabled={isHensyuuKengen}>
                印刷
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="genbaCode"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場コード</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                  <Button
                    variant="contained"
                    size="small"
                    disabled={isHensyuuKengen}
                    style={{ marginTop: 4, marginBottom: 4, left: '10px', minWidth: 90, maxHeight: '40px' }}
                    onClick={genbaCodeSearch}
                  >
                    参照
                  </Button>
                </Box>
              )}
            />
            {renderTextField('現場名', 'genbaName')}
          </Box>

          <Box
            sx={{
              display: 'flex',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              marginLeft: '50.8%',
              maxWidth: '100%',
            }}
          >
            {renderTextField('現場カナ名', 'genbaCanaName')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="koujiKoutei"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>工事工程</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                  <Button
                    variant="contained"
                    size="small"
                    disabled={isHensyuuKengen}
                    style={{ marginTop: 4, marginBottom: 4, left: '10px', minWidth: 90, maxHeight: '40px' }}
                    onClick={genbaCodeSearch}
                  >
                    工事工程
                  </Button>
                </Box>
              )}
            />
          </Box>

          <Box sx={{ maxWidth: '95.2%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0, width: '68%' }}>
              <Controller
                name="genbaChakushuNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場着手日</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="genbaBikiWataruNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場引渡日</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ maxWidth: '97%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="jikkouYosanKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>実行予算金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="hatchuuKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>発注金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="miHatchuuKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>未発注金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ maxWidth: '97%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="zengetsuMadeSateiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>前月迄査定金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="zengetsuSateiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>当月査定金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="sateiSayamaGoukeiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>査定済合計金額</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ maxWidth: '97%', padding: 0, display: 'flex', mb: 8 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0, width: '66.6%' }}>
              <Controller
                name="miSateiZan"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>未査定残</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="zentaiShinchokuRitsu"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>全体進捗率</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '30%',
                        textAlignLast: 'end',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>%</Box>
                  </Box>
                )}
              />
            </Box>
          </Box>
          <Box sx={{ maxWidth: '97%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0, width: '66.6%' }}>
              <Controller
                name="miSateiZan1"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>未査定残</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '40%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="sateiShouninNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>査定承認日</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '40%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>
          <Box sx={{ maxWidth: '97%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <div className="meisaiHyoji-label">
                <Controller
                  name="meisaiHyoji"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field, fieldState }) => (
                    <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                      <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>明細表示</Box>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange4}>
                        <FormControlLabel disabled={isHensyuuKengen} value={0} control={<Radio />} label="全査定を表示" />
                        <FormControlLabel disabled={isHensyuuKengen} value={1} control={<Radio />} label="100%査定を非表示" />
                        <FormControlLabel disabled={isHensyuuKengen} value={2} control={<Radio />} label="前月査定済みのみ表示" />
                      </RadioGroup>
                    </Box>
                  )}
                />
              </div>
            </Box>
          </Box>
          <div
            className="ag-theme-alpine column-group-table"
            style={{ width: '100%', height: '350px' }}
            onContextMenu={e => {
              e.preventDefault();
            }}
          >
            <AgGridReact
              rowData={dataSource}
              theme={AGGridTheme}
              columnDefs={tableColumnDefs.current}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              onCellContextMenu={onCellContextMenu}
              enableCellSpan
            />
            <Menu
              open={contextMenu !== null}
              onClose={handleClose}
              anchorReference="anchorPosition"
              anchorPosition={contextMenu ? { top: contextMenu.mouseY, left: contextMenu.mouseX } : undefined}
            >
              <MenuItem onClick={() => handleMenuItemClick()}>クリア</MenuItem>
            </Menu>
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebH0030CreateForm;
