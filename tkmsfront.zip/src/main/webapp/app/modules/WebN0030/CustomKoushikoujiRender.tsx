import React from 'react';

const CustomKoushikoujiRender = props => {
  return (
    <div
      style={{
        display: 'flex',
        height: '100%',
        width: '100%',
        boxSizing: 'border-box',
      }}
    >
      <div
        style={{
          flex: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '0 8px',
        }}
      >
        <span>{props.value}</span>
      </div>

      <div
        style={{
          flex: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#9BC2E6',
          color: 'black',
          height: '100%',
          fontSize: '12px',
          borderLeft: '1px solid #000',
        }}
      >
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', borderBottom: '1px solid #000', width: '100%' }}>予定</div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center' }}>実績</div>
      </div>
    </div>
  );
};

export default CustomKoushikoujiRender;
