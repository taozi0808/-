import React, { FC, useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import './WebN0030CreateForm.scss';
import dayjs from 'dayjs';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, Controller } from 'react-hook-form';
import { Box, TextField, Button, Select, MenuItem, FormControlLabel, Radio, RadioGroup } from '@mui/material';
import { WebN0030FormValues } from './types';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ColGroupDef, ICellRendererParams, themeQuartz } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, sagyouInData } from 'app/shared/util/construction-list';
import ColumnSpanningTable from 'app/components/ColumnGroupTable';
import { CustomButtonRender } from 'app/components/CustomRender/customButtonRender';
import { CustomDateCellRender } from 'app/components/CustomRender/customDateCellRender';
import { generateDynamicColumns } from './generateDynamicColumns';
import CustomKoushikoujiRender from './CustomKoushikoujiRender';
import { BorderBottom, BorderTop } from '@mui/icons-material';

const WebN0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(false);

  const gridRef = useRef();
  const [dataSource, setDataSource2] = useState([]);

  const [dateRange, setDateRange] = useState({ start: '2023-12', end: '2024-01' });

  const AGGridTheme = themeQuartz.withParams({
    borderColor: '#000',
    headerRowBorder: '1px solid #000',
    rowBorder: '1px solid #000',
    headerColumnBorder: '1px solid #000',
    columnBorder: '1px solid #000',
    headerBackgroundColor: '#9BC2E6',
  });

  // テーブル
  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      editable: true,
    };
  }, []);

  useEffect(() => {
    setPageTitle('工事予実入力');
    return () => setPageTitle('');
  }, [setPageTitle]);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<WebN0030FormValues>({
    defaultValues: {
      genbaCode: '',
      genbaName: '',
      genbaCanaName: '',
      genbaChakushuNichi: '',
      genbaBikiWataruNichi: '',
      nyuuryokuTantouMono: '',
      keihiShinseiNichi: '',
      hihyoujiKoumoku: '0',
    },
    mode: 'onBlur',
  });

  const clear = () => {
    setValue('genbaCode', '');
    setValue('genbaName', '');
    setValue('genbaCanaName', '');
    setValue('genbaChakushuNichi', '');
    setValue('genbaBikiWataruNichi', '');
    setValue('nyuuryokuTantouMono', '');
    setValue('keihiShinseiNichi', '');
    setValue('hihyoujiKoumoku', '0');
  };

  /** TODO: 点击「非表示項目」按钮时的处理逻辑示例（可根据需要实现） */
  const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状态对象
    setValue('hihyoujiKoumoku', (event.target as HTMLInputElement).value);
  };

  // 临时mock数据
  let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY998');
  // let SagyouInList = DBManager.getList();
  if (sagyouInList.length === 0) {
    sagyouInList = sagyouInData(500);
    localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY998', JSON.stringify(sagyouInList));
  }

  if (id === undefined) {
    console.log('データ異常');
  } else {
    const editData = sagyouInList.find(item => item.id === id) || null;
    if (editData === null) {
      console.log('データ異常');
    } else {
      useEffect(() => {
        setValue('genbaCode', editData.genbaCode);
        setValue('genbaName', editData.genbaName);
        setValue('genbaCanaName', 'アイウエオ');
        setValue('genbaChakushuNichi', dayjs(editData.genbaChakushuNichi).format('YYYY年MM月DD日'));
        setValue('genbaBikiWataruNichi', dayjs(editData.genbaBikiWataruNichi).format('YYYY年MM月DD日'));
        setValue('nyuuryokuTantouMono', '080-1234-5678');
        setValue('keihiShinseiNichi', '080-1234-5678');
        setValue('hihyoujiKoumoku', '0');
      }, []);
    }
  }

  const dynamicColumns = generateDynamicColumns(dateRange.start, dateRange.end, true);

  const staticColumns: (ColDef | ColGroupDef)[] = [
    {
      headerName: '表示切替',
      field: 'isVisible',
      width: 130,
      cellClass: 'cell-center',
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomButtonRender params={params} />;
      },
      cellRendererParams: {
        buttonName: (rowData: any) => {
          return rowData.isVisible ? `表示` : `非表示`;
        },
        buttonStyle: {
          backgroundColor: `purple`,
          color: `white`,
          '&:hover': {
            backgroundColor: '#7276E2',
          },
        },
        onButtonClick: (rowData: any) => {
          console.log(`add logic in this line`);
        },
      },
    },
    {
      headerName: '工事工程',
      field: 'koushikouji',
      width: 160,
      cellRenderer: CustomKoushikoujiRender,
      autoHeight: false,
      cellClass: 'cell-border',
    },
    {
      headerName: '業者名',
      field: 'gyoushaName',
      width: 140,
      autoHeight: false,
      cellClass: 'cell-center',
    },
    {
      headerName: '着手日',
      field: '',
      width: 140,
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomDateCellRender params={params} />;
      },
      cellRendererParams: {
        keys: ['plannedStartDate', 'actualStartDate'],
        onChange: (key: string, value: any, rowData: any) => {
          console.log(`add date logic here`);
        },
      },
      cellStyle: {
        padding: 0,
      },
    },
    {
      headerName: '完了日',
      field: '',
      width: 140,
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomDateCellRender params={params} />;
      },
      cellRendererParams: {
        keys: ['plannedEndDate', 'actualEndDate'],
        onChange: (key: string, value: any, rowData: any) => {
          console.log(`add date logic here`, key, value);
        },
      },
      cellStyle: {
        padding: 0,
      },
    },
  ];

  const finalColumn = [...staticColumns, ...dynamicColumns];

  const rowData = [
    {
      isVisible: true,
      koushikouji: '外工着工最早',
      plannedStartDate: '2024-01-01',
      actualStartDate: '2024-01-05',
      plannedEndDate: '2024-04-02',
      actualEndDate: '2024-04-05',
      '2023-12-p-1': 1000,
      '2023-12-a-1': 2000,
      '2023-12-p-2': 1200,
      '2023-12-a-2': 2200,
      '2023-12-p-3': 1300,
      '2023-12-a-3': 2300,
      '2024-1-p-1': 2100,
      '2024-1-a-1': 1100,
      '2024-1-p-2': 2560,
      '2024-1-a-2': 1560,
      '2024-1-p-3': 2850,
      '2024-1-a-3': 1850,
    },
    {
      isVisible: false,
      koushikouji: '本体着工',
      plannedStartDate: '2024-02-16',
      actualStartDate: '2024-03-21',
      plannedEndDate: '2024-04-22',
      actualEndDate: '2024-05-25',
      '2023-12-p-1': 11000,
      '2023-12-p-2': 12200,
      '2023-12-p-3': 13300,
      '2024-1-p-1': 11400,
      '2024-1-p-2': 15560,
      '2024-1-p-3': 18650,
    },
  ];

  return (
    <div>
      <div className="customer-WebN0030">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit">
                保存
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  clear();
                }}
              >
                クリア
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webM0010ListPage`);
                }}
              >
                キャンセル
              </Button>
            </div>
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} disabled={isHensyuuKengen}>
                印刷
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="genbaCode"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '100%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場コード</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '40%',
                    }}
                  />
                </Box>
              )}
            />
            <Controller
              name="genbaName"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '120%', marginLeft: '-30%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'flex',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              marginLeft: '36.2%',
              maxWidth: '59%',
            }}
          >
            <Controller
              name="genbaCanaName"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '100%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場カナ名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '120%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box sx={{ maxWidth: '95.2%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="genbaChakushuNichi"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場着手日</Box>
                    <TextField
                      {...field}
                      size="small"
                      style={{ minWidth: '75.8%' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="genbaBikiWataruNichi"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', marginLeft: '100px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>現場引渡日</Box>
                    <TextField
                      {...field}
                      size="small"
                      style={{ minWidth: '75.8%' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="nyuuryokuTantouMono"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', marginLeft: '70px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>入力担当者</Box>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">Type A</MenuItem>
                      <MenuItem value="typeB">Type B</MenuItem>
                    </Select>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2, width: '100%' }}>
            <Controller
              name="keihiShinseiNichi"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ minWidth: '32.7%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 120, lineHeight: '40px', textAlign: 'center' }}>経費申請日</Box>
                  <TextField
                    {...field}
                    size="small"
                    type="date"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box sx={{ maxWidth: '95.2%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="hihyoujiKoumoku"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>非表示項目</Box>
                    <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange4}>
                      <FormControlLabel value={0} control={<Radio />} label="表示しない" />
                      <FormControlLabel value={1} control={<Radio />} label="表示する" />
                    </RadioGroup>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <div style={{ width: '100%', height: '360px', marginBottom: '20px' }}>
            <AgGridReact
              rowData={rowData}
              columnDefs={finalColumn}
              suppressCellFocus={true}
              rowHeight={80}
              // domLayout="autoHeight"
              theme={AGGridTheme}
              enableCellSpan
            ></AgGridReact>
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebN0030CreateForm;
