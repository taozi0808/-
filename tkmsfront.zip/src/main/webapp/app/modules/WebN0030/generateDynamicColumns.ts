import { ColGroupDef, ICellRendererParams } from 'ag-grid-community';
import { CustomInputLabelCellRender } from 'app/components/CustomRender/customInputLabelCellRender';

interface ColumnGeneratorOption {
  cellRender?: React.ComponentType<any>;
  cellRenderParams?: Record<string, any>;
}

interface DynamicColumnConfig {
  headerName: string;
  field: string;
  width: number;
  editable?: boolean;
  cellRender?: React.ComponentType<any>;
  cellRenderParams?: Record<string, any>;
}

/**
 * 開始時間と終了時間に基づいた動的列の生成
 * @param start 開始時間(YYYY-MM)
 * @param end 終了時間(YYYY-MM)
 * @param withYear 年の接頭辞を表示するかどうか
 */
export const generateDynamicColumns = (
  start: string,
  end: string,
  withYear: boolean = true,
  width = 90,
  options?: ColumnGeneratorOption,
): ColGroupDef[] => {
  const parseDate = (ym: string): Date => {
    const [year, month] = ym.split('-').map(Number);
    return new Date(year, month - 1);
  };

  const getMonthsInRange = (startDate: Date, endDate: Date): Date[] => {
    const months: Date[] = [];
    const current = new Date(startDate);

    while (current <= endDate) {
      months.push(new Date(current));
      current.setMonth(current.getMonth() + 1);
    }

    return months;
  };

  const startDate = parseDate(start);
  const endDate = parseDate(end);
  const months = getMonthsInRange(startDate, endDate);

  return months.map(date => {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;

    // const baseColumnConfig: DynamicColumnConfig = {
    //   width,
    //   cellRender: options?.cellRender,
    //   cellRenderParams: options.cellRenderParams,
    // };
    return {
      headerName: withYear ? `${year}年${month}月` : `${month}月`,
      marryChildren: true,
      children: [
        {
          headerName: '上旬',
          field: `${year}-${month}-1`,
          width,
          editable: true,
          cellRenderer: CustomInputLabelCellRender,
          cellRendererParams: {
            keys: ['2023-12-p-1', '2023-12-a-1'],
          },
          cellStyle: params => {
            if (Number(params.data.actualStartDate.slice(8, 10)) < 15) {
              return { backgroundColor: '#A9D08E' };
            }
            // if (Number(params.data.plannedEndDate.slice(8, 10)) < 15) {
            //   return { backgroundColor: '#A9D08E' };
            // }
            return null;
          },
        },
        {
          headerName: '中旬',
          field: `${year}-${month}-2`,
          width,
          editable: true,
          cellRenderer: CustomInputLabelCellRender,
          cellRendererParams: {
            keys: ['2023-12-p-2', '2023-12-a-2'],
          },
          cellStyle: params => {
            if (Number(params.data.actualStartDate.slice(8, 10)) > 15 && Number(params.data.actualStartDate.slice(8, 10)) < 20) {
              return { backgroundColor: '#A9D08E' };
            }
            // if (Number(params.data.plannedEndDate.slice(8, 10)) > 15 && Number(params.data.plannedEndDate.slice(8, 10)) < 20) {
            //   return { backgroundColor: '#A9D08E' };
            // }
            return null;
          },
        },
        {
          headerName: '下旬',
          field: `${year}-${month}-3`,
          width,
          editable: true,
          cellRenderer: CustomInputLabelCellRender,
          cellRendererParams: {
            keys: ['2023-12-p-3', '2023-12-a-3'],
          },
          cellStyle: params => {
            if (Number(params.data.actualStartDate.slice(8, 10)) > 20) {
              return { backgroundColor: '#A9D08E' };
            }
            // if (Number(params.data.plannedEndDate.slice(8, 10)) > 20) {
            //   return { backgroundColor: '#A9D08E' };
            // }
            // return null;
          },
        },
      ],
    };
  });
};
