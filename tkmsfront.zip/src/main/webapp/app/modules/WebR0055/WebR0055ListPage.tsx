import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebR0055ListPage.scss';
import dayjs from 'dayjs';
import PageTitle from 'app/components/PageTitle';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { STORAGE_KEY_CUSTOMER, DBManager, generatCustomerData } from 'app/shared/util/construction-list';
import WebR0055SearchDialog from './SearchDialog/WebR0055SearchDialog';
import axios from 'axios';
import { Column, FieldType, Filters } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';

const CustomerList = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const gridRef = useRef(null);
  const columnRef = useRef<Array<Column>>([
    {
      id: 'id',
      name: 'No',
      field: 'no',
      width: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    { id: 'customerCode', name: '顧客コード', field: 'customerCode', width: 130, sortable: true, filterable: true, type: FieldType.string },
    { id: 'customerName', name: '顧客名', field: 'customerName', width: 220, sortable: true, filterable: true, type: FieldType.string },
    { id: 'kuben', name: '取引先区分', field: 'kuben', width: 130, sortable: true, filterable: true, type: FieldType.string },
    {
      id: 'gyousyu',
      name: '業種・業態',
      field: 'gyousyu',
      width: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    { id: 'Jyuusyo', name: '住所', field: 'Jyuusyo', width: 320, sortable: true, filterable: true, type: FieldType.string },
    { id: 'telno', name: '電話番号', field: 'telno', width: 150, sortable: true, filterable: true, type: FieldType.string },
    { id: 'daihyoumei', name: '代表者名', field: 'daihyoumei', width: 160, sortable: true, filterable: true, type: FieldType.string },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // TODO: 后续接口对接后，两个权限的默认值都要改为false
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // TODO: 后续下面前三个字段要做替换
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // TODO: 有了接口文档后放开下面的代码
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 临时mock数据
    let customerList = DBManager.getCustomerList();
    if (customerList.length === 0) {
      customerList = generatCustomerData(500);
      localStorage.setItem(STORAGE_KEY_CUSTOMER, JSON.stringify(customerList));
    }
    setRowData(customerList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('顧客情報一覧');
    return () => setPageTitle('');
  }, [setPageTitle]);

  return (
    <div>
      <div className="contract-list" id="contract-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate('/webR0060/add');
              }}
            >
              新規登録
            </Button>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0060/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0060/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebR0055SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* 表格区域 */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO: 后期正式对接，需要根据接口返回的权限来控制右击菜单可用性
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webR0060/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webR0060/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default CustomerList;
