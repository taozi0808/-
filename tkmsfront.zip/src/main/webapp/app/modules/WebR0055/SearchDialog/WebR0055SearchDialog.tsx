import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box,
  IconButton,
  MenuItem,
  InputLabel,
  ListItemText,
  Select,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useForm, Controller } from 'react-hook-form';
import './WebR0055SearchDialog.scss';
import DialogHead from 'app/components/DialogHead';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebR0055SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  // 选项列表
  const options1 = ['Option 1', 'Option 2', 'Option 3', 'Option 4', 'Option 5'];
  const options2 = ['OptionA', 'Option B', 'Option C', 'Option D', 'Option E'];
  // 统一的宽度
  const inputStyle = {
    width: '100%',
  };

  const { control, handleSubmit, reset } = useForm({
    // TODO: 接口对接时按需修改字段名称，selectedOptions1，selectedOptions2，因为目前还不知道受主状态的枚举值
    defaultValues: {
      ankenCode: '',
      ankenName: '',
      selectedOptions1: [],
      selectedOptions2: [],
    },
  });

  const onSubmit = data => {
    // TODO: 有了接口文档后，按需调整入参数据结构；
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }
    }

    console.log('data:' + data.ankenCode + 'selectedOptions1:' + data.selectedOptions1);
    onSearch(data);
    reset({
      ankenCode: '',
      ankenName: '',
      selectedOptions1: [],
      selectedOptions2: [],
    });
    handleClose();
  };

  useEffect(() => {
    // TODO: 接口对接时按需修改字段名称，尤其是listJyucyuuJyoutai，因为目前还不知道受主状态的枚举值
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />

        <DialogContent className="dialog-background-color">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: '104px' }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="kokya-ad-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="ankenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>顧客コード</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 8 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="ankenName"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>顧客名（カナ含む）</label>
                        <TextField {...field} fullWidth inputProps={{ maxLength: 255 }} size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>

              <Box display="flex" justifyContent="space-between" sx={{ marginBottom: '40px' }}>
                <Box flex={1} mr={2}>
                  <Controller
                    name="selectedOptions1"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>取引先区分</label>
                        <Select
                          {...field}
                          labelId="multi-select-label"
                          id="multi-select"
                          multiple
                          size="small"
                          renderValue={selected => selected.join(', ')}
                          sx={inputStyle}
                        >
                          {options1.map(option => (
                            <MenuItem key={option} value={option}>
                              <Checkbox checked={field.value.indexOf(option) > -1} />
                              <ListItemText primary={option} />
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="selectedOptions2"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>業種・業態</label>
                        <Select
                          {...field}
                          labelId="multi-select-label"
                          id="multi-select"
                          size="small"
                          multiple
                          renderValue={selected => selected.join(', ')}
                          sx={inputStyle}
                        >
                          {options2.map(option => (
                            <MenuItem key={option} value={option}>
                              <Checkbox checked={field.value.indexOf(option) > -1} />
                              <ListItemText primary={option} />
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebR0055SearchDialog;
