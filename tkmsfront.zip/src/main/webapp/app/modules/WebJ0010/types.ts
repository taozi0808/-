/** 定义表单各字段的数据类型 */
export interface WebJ0010FormValues {
  genbaCode: string;
  genbaName: string;
  genbaCanaName: string;
  genbaChakushuNichi: string;
  genbaBikiWataruNichi: string;
  shiharaiNengetsu: string;
  keihiShinseiNichi: string;
  keihiShouninNichi: string;
  saishuuShinseiMono: string;
  meisaiKingakuGoukei: string;
}
