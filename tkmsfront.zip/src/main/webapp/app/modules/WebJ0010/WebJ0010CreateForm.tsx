import React, { FC, useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebJ0010CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import WebJ0010SearchDialog from './SearchDialog/WebJ0010SearchDialog';
import { useForm } from 'react-hook-form';
import { Box, Button } from '@mui/material';
import { ColDef, ColGroupDef, ICellRendererParams } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import { CustomDateCellRender } from 'app/components/CustomRender/customDateCellRender';

const WebJ0010CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [dataSource, setDataSource] = useState([]);

  // 支払条件明細テーブル
  const defaultColDef = useMemo(() => {
    return {
      // flex: 1,
      editable: true,
    };
  }, []);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {},
    mode: 'onBlur',
  });

  const handleSearch = values => {
    const tempDataSource = [];
    for (let i = 0; i < 10; i++) {
      tempDataSource.push({
        id: i + 1,
        kyouryokuGyoushaCode: '100001-000' + i,
        kyouryokuGyoushaName: 'A社',
        genbaCode: '0000001-000-01' + i,
        genbaName: '○○ビル建設工事',
        daikushu: '直接仮設工事',
        shoukoushu: '仮設足場' + i,
        chuuBunshoNo: 'J00000000001' + i,
        hatchuuKingaku: 1000000,
        zengetsuMadeShiharaiKingaku: 600000,
        tougetsuShiharaiKingaku: 700000,
        shiharaiNichi: '2024-11-25',
        henkouShiharaiKingaku: 800000,
        shiharaiSayamaGoukeiKingaku: 900000,
        miHaraiKingaku: 200000,
      });
    }
    setDataSource(tempDataSource);
    const newCurData = [];
    for (let i = 0; i < tempDataSource.length; i++) {
      newCurData.push(tempDataSource[i]);
      newCurData.push(tempDataSource[i]);
    }
    setDataSource(newCurData);
  };

  const tableColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
      cellClass: 'center-cell',
    },
    {
      headerName: '協力業者コード',
      field: 'kyouryokuGyoushaCode',
      width: 170,
      children: [
        {
          headerName: '協力業者名',
          field: 'kyouryokuGyoushaName',
          width: 170,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.kyouryokuGyoushaCode : params.data.kyouryokuGyoushaName),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.kyouryokuGyoushaCode = params.newValue;
            } else {
              params.data.kyouryokuGyoushaName = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '現場コード',
      field: 'genbaCode',
      width: 185,
      children: [
        {
          headerName: '現場名',
          field: 'genbaName',
          width: 185,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.genbaCode : params.data.genbaName),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.genbaCode = params.newValue;
            } else {
              params.data.genbaName = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '大工種',
      field: 'daikushu',
      width: 160,
      children: [
        {
          headerName: '小工種',
          field: 'shoukoushu',
          width: 160,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.daikushu : params.data.shoukoushu),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikushu = params.newValue;
            } else {
              params.data.shoukoushu = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '注文書No',
      field: 'chuuBunshoNo',
      width: 160,
      children: [
        {
          headerName: '発注金額',
          field: 'hatchuuKingaku',
          width: 160,
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'start-cell' : 'end-cell'),
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.chuuBunshoNo : params.data.hatchuuKingaku),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.chuuBunshoNo = params.newValue;
            } else {
              params.data.hatchuuKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.node.rowIndex % 2 !== 0 && params.value) {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '前月迄支払金額',
      field: 'zengetsuMadeShiharaiKingaku',
      width: 160,
      cellClass: 'end-cell',
      editable: false,
      children: [
        {
          headerName: '当月支払金額',
          field: 'tougetsuShiharaiKingaku',
          cellClass: 'end-cell',
          width: 160,
          editable: false,
          valueGetter: params =>
            params.node.rowIndex % 2 === 0 ? params.data.zengetsuMadeShiharaiKingaku : params.data.tougetsuShiharaiKingaku,
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.zengetsuMadeShiharaiKingaku = params.newValue;
            } else {
              params.data.tougetsuShiharaiKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '支払日',
      field: 'shiharaiNichi',
      width: 170,
      children: [
        {
          headerName: '変更支払金額',
          field: 'henkouShiharaiKingaku',
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'start-cell' : 'end-cell'),
          width: 170,
          cellStyle: params => {
            if (params.node.rowIndex % 2 === 0 && params.data.shiharaiNichi) {
              return { backgroundColor: '#FFBE4D', padding: '0px' };
            }
            return null;
          },
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiNichi : params.data.henkouShiharaiKingaku),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiNichi = params.newValue;
            } else {
              params.data.henkouShiharaiKingaku = params.newValue;
            }
            return true;
          },
          cellRenderer: (params: ICellRendererParams) => {
            if (params.node.rowIndex % 2 === 0) {
              return <CustomDateCellRender params={params} />;
            } else {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.data.henkouShiharaiKingaku);
            }
          },
          cellRendererParams: {
            keys: ['shiharaiNichi'],
            onChange: (key: string, value: any, rowData: any) => {
              console.log(`add date logic here`, key, value);
            },
          },
          valueFormatter: (params: any) => {
            if (params.node.rowIndex % 2 !== 0 && params.value) {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '支払済合計金額',
      field: 'shiharaiSayamaGoukeiKingaku',
      width: 160,
      cellClass: 'end-cell',
      editable: false,
      children: [
        {
          headerName: '未払金額',
          field: 'miHaraiKingaku',
          cellClass: 'end-cell',
          editable: false,
          width: 160,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiSayamaGoukeiKingaku : params.data.miHaraiKingaku),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiSayamaGoukeiKingaku = params.newValue;
            } else {
              params.data.miHaraiKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.value);
            }
          },
        },
      ],
    },
  ]);
  useEffect(() => {
    setPageTitle('連携用支払データ作成');
    return () => setPageTitle('');
  }, [setPageTitle]);

  useEffect(() => {
    if (id === undefined) {
      console.log('データ異常');
    } else {
      const tempDataSource = [];
      for (let i = 0; i < 10; i++) {
        tempDataSource.push({
          id: i + 1,
          kyouryokuGyoushaCode: '100001-000' + i,
          kyouryokuGyoushaName: '鈴木' + i,
          genbaCode: '0000001-000-01' + i,
          genbaName: '北海道苫小牧市錦岡' + i,
          daikushu: '配管工' + i,
          shoukoushu: '型枠工' + i,
          chuuBunshoNo: 'J00000000001' + i,
          hatchuuKingaku: Intl.NumberFormat('en-US').format(1000000 + i),
          zengetsuMadeShiharaiKingaku: Intl.NumberFormat('en-US').format(600000 + i),
          tougetsuShiharaiKingaku: Intl.NumberFormat('en-US').format(700000 + i),
          shiharaiNichi: '2025-03-21',
          henkouShiharaiKingaku: Intl.NumberFormat('en-US').format(800000 + i),
          shiharaiSayamaGoukeiKingaku: Intl.NumberFormat('en-US').format(900000 + i),
          miHaraiKingaku: Intl.NumberFormat('en-US').format(200000 + i),
        });
      }
      setDataSource(tempDataSource);
      const newCurData = [];
      for (let i = 0; i < tempDataSource.length; i++) {
        newCurData.push(tempDataSource[i]);
        newCurData.push(tempDataSource[i]);
      }
      setDataSource(newCurData);
    }
  }, []);

  return (
    <div>
      <div className="webj0010-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={() => {}}>
                支払データ作成
              </Button>
            </div>
            <WebJ0010SearchDialog onSearch={handleSearch} />
          </div>

          <div className="ag-theme-alpine column-group-table" style={{ width: '100%', height: '350px' }}>
            <AgGridReact
              rowData={dataSource}
              rowSelection={{ mode: 'multiRow', enableClickSelection: true }}
              theme={AGGridTheme}
              columnDefs={tableColumnDefs.current}
              defaultColDef={defaultColDef}
              enableCellSpan
            />
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebJ0010CreateForm;
