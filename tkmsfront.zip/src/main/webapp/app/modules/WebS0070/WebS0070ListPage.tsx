import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0070ListPage.scss';
import dayjs from 'dayjs';
import WebS0070SearchDialog from './SearchDialog/WebS0070SearchDialog';
import { Column, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { STORAGE_KEY_SHONIN_KOJIYOJITSU, DBManager, shoninKojiYojitsuList } from 'app/shared/util/construction-list';

const WebS0070ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'bukkenCode',
      name: '物件コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 90,
      cssClass: 'left',
    },
    {
      id: 'bukkenName',
      name: '物件名称',
      field: 'bukkenName',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'chakkouDate',
      name: '着工日',
      field: 'chakkouDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'kaiseiHikiwatashiDate',
      name: '完成引渡日',
      field: 'kaiseiHikiwatashiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 80,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 70,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);
  // 行を選択
  const [selectedId, setSelectedId] = useState('');
  // 選択行変更イベント
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 検索イベント
  const handleSearch = values => {
    // TODO API呼び出し
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    let contractList = DBManager.getShoninKojiYojitsuList();
    if (contractList.length === 0) {
      // モックデータ
      contractList = shoninKojiYojitsuList(500);
      localStorage.setItem(STORAGE_KEY_SHONIN_KOJIYOJITSU, JSON.stringify(contractList));
    }

    // データを設定
    setRowData(contractList);
  };

  useEffect(() => {
    // タイトルを設定
    setPageTitle('承認一覧（工事予実管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0070-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            <WebS0070SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webN0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0070ListPage;
