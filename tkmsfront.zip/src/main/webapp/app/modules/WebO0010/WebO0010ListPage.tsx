import React, { useRef, useState, useEffect } from 'react';
import { Button } from '@mui/material';
import '../../app.scss';
import './WebO0010ListPage.scss';
import WebO0010SearchDialog from './SearchDialog/WebO0010SearchDialog';
import { DBManager, generatGyoushaData } from 'app/shared/util/construction-list';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import { Column, FieldType } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';

const WebO0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });
  const [rowData, setRowData] = useState([]);

  // 列の設定
  const columnRef = useRef<Array<Column>>([
    {
      id: 'No',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'gyoushaCode',
      name: '業者コード‐業者支店コード',
      field: 'gyoushaCode',
      minWidth: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gyoushaName',
      name: '業者名‐業者支店名',
      field: 'gyoushaName',
      width: 215,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'address',
      name: '住所',
      field: 'address',
      width: 265,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'representName',
      name: '代表者名',
      field: 'representName',
      width: 125,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'tenwabango',
      name: '電話番号',
      field: 'tenwabango',
      width: 125,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gyoushu',
      name: '業種',
      field: 'gyoushu',
      width: 310,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kaitaiTouroku',
      name: '解体登録',
      field: 'kaitaiTouroku',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'keibiNintei',
      name: '警備認定',
      field: 'keibiNintei',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'sanpaiKyoka',
      name: '産廃許可',
      field: 'sanpaiKyoka',
      width: 90,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'kyokaKigen',
      name: '許可期限',
      field: 'kyokaKigen',
      minWidth: 135,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
    },
  ]);
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let gyoushaList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY999');
    // const gyoushaList = generatGyoushaData(500);
    if (gyoushaList.length === 0) {
      gyoushaList = generatGyoushaData(500);
      // 番号作成
      gyoushaList = gyoushaList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY999', JSON.stringify(gyoushaList));
    }
    setRowData(gyoushaList);
  };
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('業者一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div className="webO0010-list" id="webO0010-list-container">
      <div className="top-operation">
        <div>
          <Button
            variant="contained"
            size="small"
            style={{ marginRight: '8px', minWidth: 96 }}
            onClick={() => {
              navigate('/webO0030/add');
            }}
          >
            新規登録
          </Button>
          <Button
            variant="contained"
            size="small"
            style={{ marginRight: '8px', minWidth: 96 }}
            disabled={!selectedId}
            onClick={() => {
              navigate(`/webO0030/add`);
            }}
          >
            支店作成
          </Button>
          {permissionInfo.hensyuuKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webO0030/edit/${selectedId}`);
              }}
            >
              編集
            </Button>
          )}
          {permissionInfo.sansyouKengen && (
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={!selectedId}
              onClick={() => {
                navigate(`/webO0030/preview/${selectedId}`);
              }}
            >
              参照
            </Button>
          )}
        </div>
        <div>
          <WebO0010SearchDialog onSearch={handleSearch} />
          {rowData.length > 0 && (
            <>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                印刷
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                CSV出力
              </Button>
            </>
          )}
        </div>
      </div>

      {/* テーブルエリア */}
      <BasicSlickGridTable
        columns={columnRef.current}
        data={rowData}
        onSelectionChanged={onSelectedRowsChanged}
        enableContextMenu
        contextMenuItems={[
          // TODO:正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
          {
            title: '支店作成',
            command: 'add',
            action: (_, callbackArgs) => {
              navigate(``);
            },
          },
          {
            title: '編集',
            command: 'edit',
            action: (_, callbackArgs) => {
              navigate(`/webB0030/edit/${callbackArgs.dataContext.id}`);
            },
          },
          {
            title: '参照',
            command: 'preview',
            action: (_, callbackArgs) => {
              navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
            },
          },
        ]}
      />
    </div>
  );
};

export default WebO0010ListPage;
