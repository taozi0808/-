import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Select, MenuItem, Box } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebN0010SearchDialog.scss';
import DialogHead from 'app/components/DialogHead';

const WebN0010SearchDialog = ({ onSearch }) => {
  // TODO
  // const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  // フォーム」
  const { control, handleSubmit, setValue } = useForm({
    defaultValues: {
      bukkenCode: '',
      bukkenCode1: '',
      bukkenCode2: '',
      bukkenName: '',
      kokyakuCode: '',
      jtYmdStart: '',
      jtYmdEnd: '',
      kankoDateEnd: '',
      kankoDateStart: '',
      chakkouDateStart: '',
      chakkouDateEnd: '',
      sekoTantoSha: '',
    },
  });

  const onSubmit = data => {
    onSearch(data);
    handleClose();
  };

  const bukkenNameOptions = [
    { id: 0, name: '', code: 'bukkenName0' },
    { id: 1, name: '物件名1', code: 'bukkenName1' },
    { id: 2, name: '物件名2', code: 'bukkenName2' },
    { id: 3, name: '物件名3', code: 'bukkenName3' },
  ];
  const kokyakuCodeOptions = [
    { id: 0, name: '', code: 'kokyakuCode0' },
    { id: 1, name: '顧客1', code: 'kokyakuCode1' },
    { id: 2, name: '顧客2', code: 'kokyakuCode2' },
    { id: 3, name: '顧客3', code: 'kokyakuCode3' },
  ];

  const koujiBumonOptions = [
    { id: 0, name: '', code: 'koujiBumon0' },
    { id: 1, name: '工事部門1', code: 'koujiBumon1' },
    { id: 2, name: '工事部門2', code: 'koujiBumon2' },
  ];

  const bukkenCode2Options = [
    { id: 0, name: '', code: '00' },
    { id: 1, name: '01', code: '01' },
    { id: 2, name: '02', code: '02' },
  ];

  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)} className="webN0010-search-container">
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" size="small" style={{ minWidth: 96 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" size="small" style={{ minWidth: 96 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between">
              <Box flex={1} mr={2} display="flex">
                <Box flex={1} display="flex">
                  <Box flex={2} display="flex">
                    <Controller
                      name="bukkenCode"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ textAlign: 'center' }}>現場コード</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} display="flex">
                    <Controller
                      name="bukkenCode1"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ minWidth: 20 }}>―</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} display="flex">
                    <Controller
                      name="bukkenCode2"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ minWidth: 20 }}>―</label>
                          <Select
                            {...field}
                            label=""
                            fullWidth
                            MenuProps={{
                              PaperProps: {
                                width: '100%',
                              },
                              PopoverClasses: {
                                root: 'webN0010-search-container',
                              },
                            }}
                            size="small"
                          >
                            {bukkenCode2Options.map(item => (
                              <MenuItem key={item.id} value={item.code}>
                                {item.name}
                              </MenuItem>
                            ))}
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box flex={1} display="flex">
                  <Box flex={2}>
                    <Controller
                      name="chakkouDateStart"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item1">
                          <label style={{ textAlign: 'center' }}>現場着手日</label>
                          <TextField {...field} type="date" size="small" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="chakkouDateEnd"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ minWidth: 20 }}>～</label>
                          <TextField {...field} size="small" type="date" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box flex={1} mr={2} display="flex">
                <Box flex={1}>
                  <Controller
                    name="bukkenName"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>現場名</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webN0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {bukkenNameOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} display="flex">
                  <Box flex={2}>
                    <Controller
                      name="kankoDateStart"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item1">
                          <label style={{ textAlign: 'center' }}>現場引渡日</label>
                          <TextField {...field} type="date" size="small" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="kankoDateEnd"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ minWidth: 20 }}>～</label>
                          <TextField {...field} size="small" type="date" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box flex={1} mr={2} display="flex">
                <Box flex={1}>
                  <Controller
                    name="kokyakuCode"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item">
                        <label style={{ textAlign: 'center' }}>業者名</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webN0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {kokyakuCodeOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="sekoTantoSha"
                    control={control}
                    render={({ field }) => (
                      <div className="bukken-search-item1">
                        <label style={{ textAlign: 'center' }}>入力担当者</label>
                        <Select
                          {...field}
                          label=""
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webN0010-search-container',
                            },
                          }}
                          size="small"
                        >
                          {koujiBumonOptions.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={1} mr={2} display="flex">
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Box flex={2}>
                    <Controller
                      name="jtYmdStart"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ textAlign: 'center' }}>予実作成日</label>
                          <TextField {...field} type="date" size="small" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="jtYmdEnd"
                      control={control}
                      render={({ field }) => (
                        <div className="bukken-search-item">
                          <label style={{ minWidth: 20 }}>～</label>
                          <TextField {...field} size="small" type="date" fullWidth style={{ width: '85%' }} />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box flex={1}></Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebN0010SearchDialog;
