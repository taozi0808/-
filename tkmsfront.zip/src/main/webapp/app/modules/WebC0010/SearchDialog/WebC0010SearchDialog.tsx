import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Checkbox, FormControlLabel, Box, Select, MenuItem } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import DialogHead from 'app/components/DialogHead';
import './WebC0010SearchDialog.scss';
import { DBManager } from 'app/shared/util/construction-list';

const WebC0010SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => {
    setOpen(false);
    // ポップアップが閉じる後、データをクリアする
    setTimeout(() => {
      reset();
    }, 0);
  };
  const [dataList, setDataList] = useState([]);

  const { control, handleSubmit, reset } = useForm({
    defaultValues: {
      // 案件コード
      ankenCode: '',
      // 見積提出期限
      mitsumoriKigenFrom: '',
      mitsumoriKigenTo: '',
      // 概算コード
      gaisanCode: '',
      // 概算部門
      gaisanBumon: '',
      // 顧客コード
      kokyakuCode: '',
      // 概算担当者
      gaisanTantousya: '',
      // 概算作成済みの案件を表示する
      gaisanSakuseiZumiFlg: true,
    },
  });

  // 仮データ
  const bumonName = ['営業部', '人事部', '経理部', '総務部', '開発部', 'IT部', '広報部', '法務部', '生産技術部', 'カスタマーサポート部'];

  const onSubmit = data => {
    handleClose();
  };

  useEffect(() => {
    // 仮データ作成
    setDataList(DBManager.getGaisanList());
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>

      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />

        <DialogContent className="webC0010-search-container">
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* ポップアップボタンエリア */}
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: '104px' }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            {/* ポップアップ検索条件エリア */}
            <Box display="grid" rowGap={2} className="dialog-box">
              <Box display="flex" justifyContent="space-between">
                <Box flex={'45%'}>
                  <Controller
                    name="ankenCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-gaisan">
                        <label>案件コード/案件名</label>
                        <Select
                          {...field}
                          size="small"
                          fullWidth
                          style={{ maxWidth: 251 }}
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                          }}
                        >
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {dataList.map(item => (
                            <MenuItem key={item.id} value={item.ankenCode}>{`${item.ankenCode} ${item.ankenName}`}</MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={'55%'} display="flex" justifyContent="space-between">
                  <Box flex={'50%'}>
                    <Controller
                      name="mitsumoriKigenFrom"
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item-gaisan">
                          <label>見積提出期限</label>
                          <TextField style={{ width: 150 }} {...field} type="date" size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={'50%'}>
                    <Controller
                      name="mitsumoriKigenTo"
                      control={control}
                      render={({ field }) => (
                        <div style={{ display: 'flex' }}>
                          <label style={{ fontWeight: 'bolder', lineHeight: '36px', textAlign: 'center' }}>～</label>
                          <TextField style={{ width: 150 }} {...field} type="date" size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={'45%'}>
                  <Controller
                    name="gaisanCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-gaisan">
                        <label>概算コード</label>
                        <Select
                          {...field}
                          size="small"
                          fullWidth
                          style={{ maxWidth: 251 }}
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                          }}
                        >
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {dataList.map(item => (
                            <MenuItem key={item.id} value={item.gaisanCode}>
                              {item.gaisanCode}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={'32%'}>
                  <Controller
                    name="gaisanBumon"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-gaisan">
                        <label>概算部門</label>
                        <Select
                          {...field}
                          size="small"
                          fullWidth
                          style={{ maxWidth: 150 }}
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                          }}
                        >
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {bumonName.map(item => (
                            <MenuItem key={item} value={item}>
                              {item}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={'23%'}></Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={'45%'}>
                  <Controller
                    name="kokyakuCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-gaisan">
                        <label>顧客コード/顧客名</label>
                        <Select
                          {...field}
                          size="small"
                          fullWidth
                          style={{ maxWidth: 251 }}
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                          }}
                        >
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {dataList.map(item => (
                            <MenuItem key={item.id} value={item.kokyakuCode}>
                              {`${item.kokyakuCode} ${item.kokyakuName}`}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={'32%'}>
                  <Controller
                    name="gaisanTantousya"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item-gaisan">
                        <label>概算担当者</label>
                        <Select
                          {...field}
                          size="small"
                          fullWidth
                          style={{ maxWidth: 150 }}
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                          }}
                        >
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {dataList.map(item => (
                            <MenuItem key={item.id} value={item.kokyakuCode}>
                              {item.gaisanTantousya}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={'23%'}></Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={'45%'}></Box>
                <Box flex={'55%'}>
                  <Controller
                    name="gaisanSakuseiZumiFlg"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label></label>
                        <FormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              checked={field.value}
                              onChange={e => {
                                field.onChange(e.target.checked);
                              }}
                            />
                          }
                          label="概算作成済みの案件を表示する"
                        />
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebC0010SearchDialog;
