import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0030ListPage.scss';
import dayjs from 'dayjs';
import { STORAGE_KEY_SHONIN_BUKKEN, DBManager, shoninBukkenDataList } from 'app/shared/util/construction-list';
import WebS0030SearchDialog from './SearchDialog/WebS0030SearchDialog';
import { Column, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const WebS0030ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  const LinkFormatter: Formatter = (_, __, value) => {
    return value ? `<a style="text-decoration: underline">あり</a>` : '';
  };
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 40,
      cssClass: 'center',
    },
    {
      id: 'bukkenCode',
      name: '物件コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 90,
      cssClass: 'left',
    },
    {
      id: 'bukkenName',
      name: '物件名称',
      field: 'bukkenName',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 90,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'chakkouDate',
      name: '着工日',
      field: 'chakkouDate',
      minWidth: 135,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'kankoDate',
      name: '完工日',
      field: 'kankoDate',
      minWidth: 135,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 85,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 135,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 50,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 60,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);
  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });
  // 行を選択
  const [selectedId, setSelectedId] = useState('');
  // 選択行変更イベント
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 検索イベント
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // TODO API呼び出し
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // 仮データ作成
    let contractList = DBManager.getShoninBukkenDataList();
    if (contractList.length === 0) {
      contractList = shoninBukkenDataList(500);
      // 番号作成
      contractList = contractList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SHONIN_BUKKEN, JSON.stringify(contractList));
    }

    // データを設定
    setRowData(contractList);
  };

  useEffect(() => {
    // タイトルを設定
    setPageTitle('承認一覧（物件管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0030-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            <WebS0030SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webF0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0030ListPage;
