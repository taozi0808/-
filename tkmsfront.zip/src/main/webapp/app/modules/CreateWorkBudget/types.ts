/** 定义表单各字段的数据类型 */
export interface FormValues {
  siteCode: string;
  siteName: string;
  siteName1: string;
  budgetCode: string; // 预算编号
  historyNumber: string; // 番号
  applyDate: string;
  approvalDate: string;
  department: {
    departmentPart1: string;
    departmentPart2: string;
  }; // 部门
  preparer: string; // 作成者
}
