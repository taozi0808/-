import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, MenuItem, Select, Button, Checkbox, FormControlLabel, Box } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebR0040SearchDialog.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import DialogHead from 'app/components/DialogHead';

const WebR0040SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 社員コード
      shainCode: '',
      // 所属部
      shozokuBu: '',
      // 氏名
      shiMei: '',
      // 所属課
      shozokuKa: '',
      // 所属役職
      shozokuYakushoku: '',
      // 職種
      shokushu: '',
      // 退職者チェックボクス
      fieldCheck: false,
    },
  });

  const onSubmit = data => {
    // TODO: 有了接口文档后，按需调整入参数据结构；
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // TODO
    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" onClick={handleOpen} style={{ marginRight: '8px', minWidth: 96 }}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" size="small" style={{ minWidth: 96 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" size="small" style={{ minWidth: 96 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box style={{ height: '250px' }} display="flex" flexDirection="column" gap={2} className="webR0040-search-container">
              {/*  社員コード */}
              <Box display="flex" justifyContent="space-between">
                <Box className="juguoin-search-item" flex={2} mr={2}>
                  {/* <Box> */}
                  <Box flex={1}>
                    <Controller
                      name="shainCode"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>社員コード</label>
                          <TextField {...field} style={{ width: '250px' }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="shozokuBu"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>所属部</label>
                          <TextField {...field} style={{ width: '250px' }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box className="juguoin-search-item" flex={2} mr={2}>
                  {/* <Box> */}
                  <Box flex={1}>
                    <Controller
                      name="shiMei"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>氏名</label>
                          <TextField {...field} style={{ width: '250px' }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="shozokuKa"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>所属課</label>
                          <TextField {...field} style={{ width: '250px' }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box className="juguoin-search-item" flex={2} mr={2}>
                  {/* <Box> */}
                  <Box flex={1}>
                    <Controller
                      name="shokushu"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>職種</label>
                          <TextField {...field} style={{ width: '250px' }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name="shozokuYakushoku"
                      control={control}
                      render={({ field }) => (
                        <div className="juguoin-search-item">
                          <label style={{ textAlign: 'center' }}>役職</label>
                          <Select
                            {...field}
                            size="small"
                            MenuProps={{
                              PaperProps: {
                                style: {
                                  maxHeight: 200,
                                  overflow: 'auto',
                                },
                              },
                              PopoverClasses: {
                                root: 'webR0040-search-container',
                              },
                            }}
                            style={{ width: '250px' }}
                          >
                            <MenuItem value="000"></MenuItem>
                            <MenuItem value="001">一般社員</MenuItem>
                            <MenuItem value="002">主任</MenuItem>
                            <MenuItem value="003">係長</MenuItem>
                            <MenuItem value="004">課長</MenuItem>
                            <MenuItem value="005">次長</MenuItem>
                            <MenuItem value="006">部長</MenuItem>
                            <MenuItem value="007">本部長</MenuItem>
                            <MenuItem value="008">常務取締役</MenuItem>
                            <MenuItem value="009">専務取締役</MenuItem>
                            <MenuItem value="010">代表取締役社長</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
              <Box display="flex" justifyContent="flex-start">
                <Box flex={2} style={{ marginRight: '38px', display: 'flex', justifyContent: 'right' }} className="checkStyle">
                  <Controller
                    name="fieldCheck"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel
                        control={<Checkbox color="default" {...field} defaultChecked={true} checked={field.value} />}
                        label={<span style={{ fontSize: 15, display: 'flex', width: '200px' }}>退職者を検索対象とする</span>}
                      />
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebR0040SearchDialog;
