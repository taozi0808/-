import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebR0040ListPage.scss';
import WebR0040SearchDialog from './SearchDialog/WebR0040SearchDialog';
import { DBManager, STORAGE_KEY_SHAIN, JuguoinDataList } from 'app/shared/util/construction-list';
import { type Column } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
const WebR0040ListPage = () => {
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // 選択行ID
  const [selectedId, setSelectedId] = useState('');
  // ナビゲーション
  const navigate = useNavigate();
  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'shainCode',
      name: '社員コード',
      field: 'shainCode',
      sortable: true,
      filterable: true,
      width: 150,
      cssClass: 'left',
    },
    {
      id: 'shiMei',
      name: '氏名',
      field: 'shiMei',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shokushu',
      name: '職種',
      field: 'shokushu',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
      formatter: (_, __, val) => {
        return val?.label;
      },
    },
    {
      id: 'shozokuBu',
      name: '所属部',
      field: 'shozokuBu',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'left',
      formatter: (_, __, val) => {
        return val?.label;
      },
    },
    {
      id: 'shozokuKa',
      name: '所属課',
      field: 'shozokuKa',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'left',
      formatter: (_, __, val) => {
        return val?.label;
      },
    },
    {
      id: 'shozokuYakushoku',
      name: '所属役職',
      field: 'shozokuYakushoku',
      width: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
      formatter: (_, __, val) => {
        return val?.label;
      },
    },
  ]);
  // データ
  const [rowData, setRowData] = useState([]);
  const handleSearch = values => {
    // TODO: 以下の最初の 3 つのフィールドを置き換える必要があります。
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // TODO
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // TODO mockData
    let contractList = DBManager.getShainList();
    if (contractList.length === 0) {
      contractList = JuguoinDataList(500);
      localStorage.setItem(STORAGE_KEY_SHAIN, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  useEffect(() => {
    setPageTitle('社員一覧');
    return () => setPageTitle('');
  }, []);
  return (
    <div>
      <div className="webR0040-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate('/webR0045/add');
              }}
            >
              新規登録
            </Button>

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0045/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webR0045/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebR0040SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
              </>
            )}
          </div>
        </div>
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO
            {
              title: '編集',
              command: 'edit',
              disabled: selectedId.length === 1,
              action: (_, callbackArgs) => {
                navigate(`/webR0045/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              disabled: selectedId.length === 1,
              action: (_, callbackArgs) => {
                navigate(`/webR0045/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebR0040ListPage;
