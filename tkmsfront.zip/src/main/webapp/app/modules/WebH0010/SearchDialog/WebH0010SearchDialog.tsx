import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box,
  Select,
  MenuItem,
  Typography,
} from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebH0010SearchDialog.scss';
import '../../../app.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebH0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedValue, setSelectedValue] = useState('');

  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 現場コード
      genbaCode1: '',
      // 現場コード
      genbaCode2: '',
      // 現場コードe
      genbaCode3: '',
      // 現場名
      genbaName: '',
      // 予算作成部門
      yosanSakuseiBumon: [],
      // 予算作成者
      yosanSakuseisha: [],
      // 実行予算コード
      jikkouYosanCode: [],
      // 表示対象
      hyojiTaishou: {
        '1': true,
        '2': false,
      },
    },
  });
  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  // 予算作成部門
  const yosanSakuseiBumon = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '予算作成部門1', code: 'yosanSakuseiBumon1' },
    { id: 2, name: '予算作成部門2', code: 'yosanSakuseiBumon2' },
    { id: 3, name: '予算作成部門3', code: 'yosanSakuseiBumon3' },
    { id: 4, name: '予算作成部門4', code: 'yosanSakuseiBumon4' },
    { id: 5, name: '予算作成部門5', code: 'yosanSakuseiBumon5' },
  ];

  // 予算作成者
  const yosanSakuseisha = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '予算作成者1', code: 'yosanSakuseisha1' },
    { id: 2, name: '予算作成者2', code: 'yosanSakuseisha2' },
    { id: 3, name: '予算作成者3', code: 'yosanSakuseisha3' },
    { id: 4, name: '予算作成者4', code: 'yosanSakuseisha4' },
    { id: 5, name: '予算作成者5', code: 'yosanSakuseisha5' },
  ];

  // 実行予算コード
  const jikkouYosanCode = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '実行予算コード1', code: 'jikkouYosanCode1' },
    { id: 2, name: '実行予算コード2', code: 'jikkouYosanCode2' },
    { id: 3, name: '実行予算コード3', code: 'jikkouYosanCode3' },
    { id: 4, name: '実行予算コード4', code: 'jikkouYosanCode4' },
    { id: 5, name: '実行予算コード5', code: 'jikkouYosanCode5' },
  ];

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '400px',
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="webH0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <div className="webH0010-search-item">
                    <label>現場コード</label>
                    <Controller
                      name="genbaCode1"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '130px' }} size="small" />}
                    />
                    <label style={{ minWidth: 20 }}> －</label>
                    <Controller
                      name="genbaCode2"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '74px' }} size="small" />}
                    />
                    <label style={{ minWidth: 20 }}> －</label>
                    <Controller
                      name="genbaCode3"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '74px' }} size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Controller
                    name="yosanSakuseiBumon"
                    control={control}
                    render={({ field }) => (
                      <div className="webH0010-search-item" style={{ width: '400px' }}>
                        <label>予算作成部門</label>
                        <Select
                          value={selectedValue}
                          label=""
                          onChange={e => setSelectedValue(e.target.value)}
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%', // ドロップダウン メニューの同期幅
                              style: {
                                maxHeight: 200, // 最大高さを設定する
                                overflow: 'auto', // コンテンツがオーバーフローした場合の自動スクロール
                              },
                            },
                          }}
                          size="small"
                        >
                          {yosanSakuseiBumon.map(item => (
                            <MenuItem
                              key={item.id}
                              value={item.code} // 実際に保存された値
                            >
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <div className="webH0010-search-item">
                    <label>現場名</label>
                    <Controller
                      name="genbaName"
                      control={control}
                      render={({ field }) => <TextField {...field} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <Controller
                    name="yosanSakuseisha"
                    control={control}
                    render={({ field }) => (
                      <div className="webH0010-search-item" style={{ width: '400px' }}>
                        <label>予算作成者</label>
                        <Select
                          value={selectedValue}
                          label=""
                          onChange={e => setSelectedValue(e.target.value)}
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                              style: {
                                maxHeight: 200,
                                overflow: 'auto',
                              },
                            },
                          }}
                          size="small"
                        >
                          {yosanSakuseisha.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1} mr={2}>
                  <Controller
                    name="jikkouYosanCode"
                    control={control}
                    render={({ field }) => (
                      <div className="webH0010-search-item" style={{ width: '380px' }}>
                        <label>実行予算コード</label>
                        <Select
                          value={selectedValue}
                          label=""
                          onChange={e => setSelectedValue(e.target.value)}
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                              style: {
                                maxHeight: 200,
                                overflow: 'auto',
                              },
                            },
                          }}
                          size="small"
                        >
                          {jikkouYosanCode.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="webH0010-search-item">
                    <label style={{ lineHeight: '40px', width: 100 }}>表示対象</label>
                    <Controller
                      name="hyojiTaishou.1"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              {...field}
                              checked={field.value}
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>当月未査定</Typography>}
                        />
                      )}
                    />
                    <Controller
                      name="hyojiTaishou.2"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              {...field}
                              checked={field.value}
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '16px' }}>当月査定済</Typography>}
                        />
                      )}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebH0010SearchDialog;
