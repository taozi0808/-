/** 定义表单各字段的数据类型 */
export interface WebM0020FormValues {
  genbaCode: string;
  genbaName: string;
  genbaCanaName: string;
  genbaChakushuNichi: string;
  genbaBikiWataruNichi: string;
  shiharaiNengetsu: string;
  keihiShinseiNichi: string;
  keihiShouninNichi: string;
  saishuuShinseiMono: string;
  meisaiKingakuGoukei: string;
}
