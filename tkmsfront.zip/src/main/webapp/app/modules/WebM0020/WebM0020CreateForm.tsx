import React, { FC, useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebM0020CreateForm.scss';
import dayjs from 'dayjs';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useForm, Controller } from 'react-hook-form';
import { Box, TextField, Button } from '@mui/material';
import { WebM0020FormValues } from './types';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, genbaKeihiDataList } from 'app/shared/util/construction-list';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const WebM0020CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [dataSource, setDataSource] = useState([]);
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');

  // 支払条件明細テーブル
  const defaultColDef = useMemo(() => {
    return {
      editable: type === 'edit',
      singleClickEdit: true,
    };
  }, []);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<WebM0020FormValues>({
    defaultValues: {
      genbaCode: '',
      genbaName: '',
      genbaCanaName: '',
      genbaChakushuNichi: '',
      genbaBikiWataruNichi: '',
      shiharaiNengetsu: '',
      keihiShinseiNichi: '',
      keihiShouninNichi: '',
      saishuuShinseiMono: '',
      meisaiKingakuGoukei: '',
    },
    mode: 'onBlur',
  });

  const clear = () => {
    setValue('genbaCode', '');
    setValue('genbaName', '');
    setValue('genbaCanaName', '');
    setValue('genbaChakushuNichi', '');
    setValue('genbaBikiWataruNichi', '');
    setValue('shiharaiNengetsu', '');
    setValue('keihiShinseiNichi', '');
    setValue('keihiShouninNichi', '');
    setValue('saishuuShinseiMono', '');
    setValue('meisaiKingakuGoukei', '');
  };

  const LinkRenderer = (params: any) => {
    const url = `/webM0020/edit/${id}`;
    return (
      // <a href={url} target="_blank" rel="noopener noreferrer" className="custom-link">
      <a target="_blank" rel="noopener noreferrer" className="custom-link">
        {params.value}
      </a>
    );
  };

  const tableColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
    },
    {
      headerName: '支払日',
      field: 'shiharaiNichi',
      width: 155,
      children: [
        {
          headerName: '内訳',
          field: 'uchiwake',
          width: 155,
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'start-cell'),
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiNichi : params.data.uchiwake),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiNichi = params.newValue;
            } else {
              params.data.uchiwake = params.newValue;
            }
            return true;
          },
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 3),
        },
      ],
    },
    {
      headerName: '支払先区分',
      field: 'shiharaiSakiKubun',
      width: 120,
      cellClass: 'start-cell',
      children: [
        {
          headerName: '',
          field: 'hiddenField1',
          cellClass: 'start-cell',
          width: 120,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiSakiKubun : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiSakiKubun = params.newValue;
            } else {
              params.data.hiddenField1 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '支払先',
      field: 'shiharaiSaki',
      width: 120,
      cellClass: 'center-cell',
      children: [
        {
          headerName: '',
          field: 'hiddenField2',
          cellClass: 'center-cell',
          width: 120,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiSaki : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiSaki = params.newValue;
            } else {
              params.data.hiddenField2 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '大工種',
      field: 'daikuShu',
      width: 120,
      cellClass: 'start-cell',
      children: [
        {
          headerName: '備考',
          field: 'bikou',
          cellClass: 'start-cell',
          width: 120,
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 3),
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.daikuShu : params.data.bikou),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikuShu = params.newValue;
            } else {
              params.data.bikou = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '小工種',
      field: 'shouKouShu',
      width: 120,
      cellClass: 'center-cell',
      children: [
        {
          headerName: '',
          field: 'hiddenField3',
          cellClass: 'center-cell',
          width: 120,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shouKouShu : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shouKouShu = params.newValue;
            } else {
              params.data.hiddenField3 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '支払金額（税込）',
      field: 'shiharaiKingaku',
      width: 150,
      children: [
        {
          headerName: '',
          field: 'hiddenField4',
          width: 150,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiKingaku : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiKingaku = params.newValue;
            } else {
              params.data.hiddenField4 = '';
            }
            return true;
          },
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'start-cell'),
        },
      ],
    },
    {
      headerName: '添付',
      field: 'tenpu',
      width: 100,
      cellClass: 'center-cell',
      cellRenderer: LinkRenderer,
      cellStyle: { color: '#1890ff !important' },
    },
  ]);

  useEffect(() => {
    setPageTitle('現場経費入力');
    return () => setPageTitle('');
  }, [setPageTitle]);

  useEffect(() => {
    if (id === undefined) {
      console.log('データ異常');
    } else {
      // 一時のmockデータ
      let sagyouInList = DBManager.getMockList('CONSTRUCTION_WebM0010_DB_SATEI999');
      // let SagyouInList = DBManager.getList();
      if (sagyouInList.length === 0) {
        sagyouInList = genbaKeihiDataList(500);
        localStorage.setItem('CONSTRUCTION_WebM0010_DB_SATEI999', JSON.stringify(sagyouInList));
      }

      // const contractList = genbaKeihiDataList(500);
      const editData = sagyouInList.find(item => item.id === id) || null;

      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('genbaCode', editData.genbaCode);
        setValue('genbaName', editData.genbaName);
        setValue('genbaCanaName', 'アイウエオ');
        setValue('genbaChakushuNichi', dayjs(editData.genbaChakushuDate).format('YYYY年MM月DD日'));
        setValue('genbaBikiWataruNichi', dayjs(editData.genbahikiwatashiDate).format('YYYY年MM月DD日'));
        setValue('shiharaiNengetsu', '2025-03-21');
        setValue('keihiShinseiNichi', dayjs(editData.keihiShinseiDate).format('YYYY-MM-DD'));
        setValue('keihiShouninNichi', editData.keihishoninShaDate ? dayjs(editData.keihishoninShaDate).format('YYYY-MM-DD') : '');
        setValue('saishuuShinseiMono', editData.shoninSha);
        setValue('meisaiKingakuGoukei', Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(898989898));

        const tempDataSource = [];
        for (let i = 0; i < 10; i++) {
          tempDataSource.push({
            id: i + 1,
            shiharaiNichi: '2024年9月10日',
            uchiwake: '移動交通費' + i,
            shiharaiSakiKubun: i % 2 === 0 ? '社員' : '協力業者',
            shiharaiSaki: i % 2 === 0 ? '山田 一郎' : '山本ビル',
            daikuShu: '直接仮設工事',
            bikou: '備考内容' + i,
            shouKouShu: '仮設足場',
            shiharaiKingaku: Intl.NumberFormat('en-US').format(500000 + i),
            tenpu: i % 2 === 0 ? '〇' : '×',
          });
        }
        setDataSource(tempDataSource);
      }
    }
  }, []);

  return (
    <div>
      <div className="webm0020-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{`【最終更新日】`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <div>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                type="submit"
                disabled={isHensyuuKengen}
              >
                保存
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={isHensyuuKengen}
                onClick={() => {}}
              >
                申請
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={isHensyuuKengen}
                onClick={() => {
                  clear();
                }}
              >
                クリア
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webM0010`);
                }}
              >
                キャンセル
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '95%',
            }}
          >
            <Controller
              name="genbaCode"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '95%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>現場コード</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
            <Controller
              name="genbaName"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '100%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>現場名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'flex',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              marginLeft: '48.2%',
            }}
          >
            <Controller
              name="genbaCanaName"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '90.1%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>現場カナ名</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '95%',
            }}
          >
            <Controller
              name="genbaChakushuNichi"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>現場着手日</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                      textAlignLast: 'end',
                    }}
                  />
                </Box>
              )}
            />
            <Controller
              name="genbaBikiWataruNichi"
              control={control}
              disabled={isHensyuuKengen}
              render={({ field, fieldState }) => (
                <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>現場引渡日</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                      textAlignLast: 'end',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                columnGap: 2,
                mb: 2,
                maxWidth: '95%',
              }}
            >
              <Controller
                name="shiharaiNengetsu"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '108.7%' }} className="cell-date-picker">
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>支払年月</Box>
                    <DatePicker
                      label=""
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{ width: '100%', textAlignLast: 'end' }}
                      format="YYYY年MM月"
                      value={field.value ? dayjs(field.value) : null}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 90, lineHeight: '40px', textAlign: 'center', color: '#5E63DE' }}>
                      【承認】
                    </Box>
                  </Box>
                )}
              />
            </Box>
          </LocalizationProvider>

          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                columnGap: 2,
                mb: 2,
                maxWidth: '95%',
              }}
            >
              <Controller
                name="keihiShinseiNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }} className="cell-date-picker">
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>経費申請日</Box>
                    <DateTimePicker
                      label=""
                      // inputFormat="YYYY/MM/DD HH:mm" // 定义输入格式
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                      format="YYYY年MM月DD日 HH:mm"
                      ampm={false}
                      // slotProps={{ calendarHeader: { format: 'MM/YYYY' } }}
                      slotProps={{
                        textField: {
                          variant: 'outlined',
                          InputProps: {
                            readOnly: false, // 允许输入
                          },
                        },
                        actionBar: {
                          actions: ['clear', 'today'], // 显示操作按钮
                        },
                      }}
                      value={field.value ? dayjs(field.value) : null}
                    />
                  </Box>
                )}
              />

              <Controller
                name="saishuuShinseiMono"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>最終申請者</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </LocalizationProvider>

          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                columnGap: 2,
                mb: 2,
                maxWidth: '95%',
              }}
            >
              <Controller
                name="keihiShouninNichi"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }} className="cell-date-picker">
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px', textAlign: 'center' }}>経費承認日</Box>
                    <DateTimePicker
                      label=""
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                      format="YYYY年MM月DD日 HH:mm"
                      ampm={false}
                      slotProps={{ calendarHeader: { format: 'MM/YYYY' } }}
                      value={field.value ? dayjs(field.value) : null}
                    />
                  </Box>
                )}
              />
              <Controller
                name="meisaiKingakuGoukei"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px', width: '87%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 160, lineHeight: '40px', textAlign: 'center' }}>
                      明細金額合計（税込）
                    </Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                        textAlignLast: 'end',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </LocalizationProvider>

          <div className="ag-theme-alpine column-group-table" style={{ width: '100%', height: '100%' }}>
            <AgGridReact
              rowData={dataSource}
              theme={AGGridTheme}
              columnDefs={tableColumnDefs.current}
              defaultColDef={defaultColDef}
              enableCellSpan
            />
            {/* <ColumnSpanningTable
              data={dataSource}
              // theme={AGGridTheme}
              columns={tableColumnDefs.current}
              // defaultColDef={defaultColDef}
              colSpanMap={[
                {
                  mainField: 'uchiwake',
                  subFields: ['hiddenField1'],
                },
                {
                  mainField: 'hiddenField1',
                  subFields: ['hiddenField2'],
                },
                {
                  mainField: 'bikou',
                  subFields: ['hiddenField3'],
                },
                {
                  mainField: 'hiddenField3',
                  subFields: ['hiddenField4'],
                },
              ]}
              disabledPagination={true}
            /> */}
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebM0020CreateForm;
