import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Box, Select, MenuItem } from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebQ0036SearchDialog.scss';
import '../../../app.scss';

const WebQ0036SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedValue, setSelectedValue] = useState('');

  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 業者コード
      gyoushaCode: '',
      // 業者名
      gyoushaName: '',
      // 現場コード
      genbaCode: '',
      // 注文書No
      chuBunshoNo: '',
      // 大工種
      daikuShuList: [],
      // 現場名
      genbaName: '',
      // 該当着手日
      gaitouChakushuNichiStart: '',
      gaitouChakushuNichiEnd: '',
      // 該当引渡日
      gaitouBikiWataruNichiStart: '',
      gaitouBikiWataruNichiEnd: '',
    },
  });
  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  const daikuShuList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '大工種1', code: 'daikuShu1' },
    { id: 2, name: '大工種2', code: 'daikuShu2' },
    { id: 3, name: '大工種3', code: 'daikuShu3' },
    { id: 4, name: '大工種4', code: 'daikuShu4' },
    { id: 5, name: '大工種5', code: 'daikuShu5' },
  ];

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '500px',
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" className="webQ0036-search-container">
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between" style={{ width: '40%' }}>
                <Box flex={1} mr={2}>
                  <Controller
                    name="genbaCode"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>現場コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="chuBunshoNo"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>注文書No</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="daikuShuList"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>大工種</label>
                        <Select
                          value={selectedValue}
                          label=""
                          onChange={e => setSelectedValue(e.target.value)}
                          fullWidth
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                              style: {
                                maxHeight: 200,
                                overflow: 'auto',
                              },
                            },
                          }}
                          size="small"
                        >
                          {daikuShuList.map(item => (
                            <MenuItem key={item.id} value={item.code}>
                              {item.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="gyoushaCode"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>業者コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="gyoushaName"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>業者名(ｶﾅ含む)</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between" style={{ width: '60%' }}>
                <Box flex={1} mr={2}>
                  <Controller
                    name="genbaName"
                    control={control}
                    render={({ field }) => (
                      <div className="webQ0036-search-item">
                        <label>現場名</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <div className="webQ0036-search-item">
                    <label>該当着手日</label>
                    <Controller
                      name="gaitouChakushuNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="gaitouChakushuNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} size="small" type="date" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
                <Box flex={1} mr={2}>
                  <div className="webQ0036-search-item">
                    <label>該当引渡日</label>
                    <Controller
                      name="gaitouBikiWataruNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="gaitouBikiWataruNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
                <Box flex={1} mr={2}></Box>
                <Box flex={1} mr={2}></Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebQ0036SearchDialog;
