import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebM0010ListPage.scss';
import dayjs from 'dayjs';
import { genbaKeihiDataList } from 'app/shared/util/construction-list';
import WebM0010SearchDialog from './SearchDialog/WebM0010SearchDialog';
import { Column } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager } from 'app/shared/util/construction-list';

const WebM0010ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      sortable: true,
      filterable: true,
      width: 150,
      cssClass: 'left',
    },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      minWidth: 300,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'genbaChakushuDate',
      name: '現場着手日',
      field: 'genbaChakushuDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'genbahikiwatashiDate',
      name: '現場引渡日',
      field: 'genbahikiwatashiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'keihiShinseiDate',
      name: '経費申請日',
      field: 'keihiShinseiDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shoninSha',
      name: '承認者',
      field: 'shoninSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'keihishoninShaDate',
      name: '経費承認日',
      field: 'keihishoninShaDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (row, cell, val, columnDef, dataContext) => {
        const value = val ? dayjs(val).format('YYYY年MM月DD日') : '';
        const valueComment = val ? '' : 'red-backgroundColor';
        return `<div class="${valueComment}">${value}</div>`;
      },
    },
    {
      id: 'keihiKingakkuTotal',
      name: '経費金額合計',
      field: 'keihiKingakkuTotal',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
    },
  ]);
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });
  // 行を選択
  const [selectedId, setSelectedId] = useState('');
  // 検索イベント
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // let contractList = DBManager.getList();
    // if (contractList.length === 0) {
    // let contractList = DBManager.getList();
    // if (contractList.length === 0) {
    // const contractList = genbaKeihiDataList(500);
    //   localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    // }
    // モックデータ
    let sateiList = DBManager.getMockList('CONSTRUCTION_WebM0010_DB_SATEI999');
    // const sateiList = generatGyoushaData(500);
    if (sateiList.length === 0) {
      sateiList = genbaKeihiDataList(500);
      sateiList = sateiList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_WebM0010_DB_SATEI999', JSON.stringify(sateiList));
    }
    setRowData(sateiList);
  };

  useEffect(() => {
    setPageTitle('現場経費一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webM0010-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webM0020/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webM0020/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebM0010SearchDialog onSearch={handleSearch} />
          </div>
        </div>
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webM0010/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webM0010/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebM0010ListPage;
