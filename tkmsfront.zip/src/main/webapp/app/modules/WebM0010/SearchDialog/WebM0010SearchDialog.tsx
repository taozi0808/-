import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Select, MenuItem, Box } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebM0010SearchDialog.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import DialogHead from 'app/components/DialogHead';

const WebM0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const genjyoCode3List = [
    { value: '001', label: '001' },
    { value: '002', label: '002' },
    { value: '003', label: '003' },
  ];
  const genbaNameList = [
    { value: '001', label: '東京湾跨海トンネル掘削現場' },
    { value: '002', label: '広島太陽光パネル増設工事現場' },
    { value: '003', label: '福岡地下鉄七隈線防水工事区間' },
  ];
  const shinseiShaList = [
    { value: '001', label: '鈴木 橋本' },
    { value: '002', label: '鈴木 健一' },
    { value: '003', label: '田中 橋本' },
  ];
  const { control, handleSubmit } = useForm({
    defaultValues: {
      genjyoCode1: '',
      genjyoCode2: '',
      genjyoCode3: '',
      genbaChakushuDateFrom: '',
      genbaChakushuDateTo: '',
      genbaName: '',
      genbahikiwatashiDateFrom: '',
      genbahikiwatashiDateTo: '',
      shinseiSha: '',
    },
  });

  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)} style={{ height: '300px' }}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" size="small" style={{ minWidth: 96 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" size="small" style={{ minWidth: 96 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box sx={{ paddingBottom: '30px' }} display="grid" rowGap={2} className="webM0010-search-container">
              <Box display="flex">
                <Box display="flex" width="400px">
                  <Controller
                    name="genjyoCode1"
                    control={control}
                    render={({ field }) => (
                      <div className="item1">
                        <label>現場コード</label>
                        <TextField {...field} style={{ width: 100 }} size="small" />
                      </div>
                    )}
                  />
                  <Controller
                    name="genjyoCode2"
                    control={control}
                    render={({ field }) => (
                      <div className="item2">
                        <label>-</label>
                        <TextField {...field} style={{ width: 50 }} size="small" />
                      </div>
                    )}
                  />
                  <Controller
                    name="genjyoCode3"
                    control={control}
                    render={({ field }) => (
                      <div className="item2">
                        <label>-</label>
                        <div>
                          <Select
                            size="small"
                            inputRef={field.ref}
                            MenuProps={{
                              PaperProps: {
                                width: '100%',
                              },
                              PopoverClasses: {
                                root: 'webM0010-search-container',
                              },
                            }}
                            fullWidth
                            {...field}
                            style={{ width: 80 }}
                          >
                            <MenuItem key={''} value={''}></MenuItem>
                            {genjyoCode3List.map(item => (
                              <MenuItem key={item.value} value={item.value}>
                                {item.label}
                              </MenuItem>
                            ))}
                          </Select>
                        </div>
                      </div>
                    )}
                  />
                </Box>
                <Box display="flex" width="400px">
                  <Controller
                    name="genbaChakushuDateFrom"
                    control={control}
                    render={({ field }) => (
                      <div className="item1">
                        <label>現場着手日</label>
                        <TextField type="date" size="small" {...field} />
                      </div>
                    )}
                  />
                  <Controller
                    name="genbaChakushuDateTo"
                    control={control}
                    render={({ field }) => (
                      <div className="item2">
                        <label>～</label>
                        <TextField type="date" size="small" {...field} />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex">
                <Box display="flex" width="400px">
                  <Controller
                    name="genbaName"
                    control={control}
                    render={({ field }) => (
                      <div className="item1">
                        <label>現場名</label>
                        <Select
                          size="small"
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webM0010-search-container',
                            },
                          }}
                          inputRef={field.ref}
                          fullWidth
                          {...field}
                          style={{ width: 290 }}
                        >
                          <MenuItem key={''} value={''}></MenuItem>
                          {genbaNameList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
                <Box display="flex" width="400px">
                  <Controller
                    name="genbahikiwatashiDateFrom"
                    control={control}
                    render={({ field }) => (
                      <div className="item1">
                        <label>現場引渡日</label>
                        <TextField type="date" size="small" {...field} />
                      </div>
                    )}
                  />
                  <Controller
                    name="genbahikiwatashiDateTo"
                    control={control}
                    render={({ field }) => (
                      <div className="item2">
                        <label>～</label>
                        <TextField type="date" size="small" {...field} />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex">
                <Box display="flex" width="400px">
                  <Controller
                    name="shinseiSha"
                    control={control}
                    render={({ field }) => (
                      <div className="item1">
                        <label>申請者</label>
                        <Select
                          size="small"
                          MenuProps={{
                            PaperProps: {
                              width: '100%',
                            },
                            PopoverClasses: {
                              root: 'webM0010-search-container',
                            },
                          }}
                          inputRef={field.ref}
                          fullWidth
                          {...field}
                          style={{ width: 200 }}
                        >
                          <MenuItem key={''} value={''}></MenuItem>
                          {shinseiShaList.map(item => (
                            <MenuItem key={item.value} value={item.value}>
                              {item.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebM0010SearchDialog;
