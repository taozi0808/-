/** 定义表单各字段的数据类型 */
export interface CustomerManagementFormValues {
  emailAddress: string;
  sagyouInCode: string;
  shimei: string;
  nameCana: string;
  gyoushaCode: string;
  gyoushaName: string;
  shurui: string;
  yatoiNyuuDate: string;
  seiDate: string;
  age: string;
  ketsuekigata: string;
  CCUSkakuninBangou: string;
  gaikokuSeki: boolean;
  kokuseki: string;
  transactionType: string;
  postalCodePart1: string;
  postalCodePart2: string;
  address1: string;
  address2: string;
  phone: {
    part1: string;
    part2: string;
    part3: string;
  };
  renrakuSakiName: string;
  zokugara: string;
  bankName: string;
  address3: string;
  phone1: {
    part1: string;
    part2: string;
    part3: string;
  };
  kenkouShindanNichi: string;
  ketsuatsu: {
    part1: string;
    part2: string;
  };
  TksKenkouShindanNichi: string;
  shurui2: string;
  shikakuMenkyo: string;
  ginouKoushuu: string;
  tokubetsuKyoiku: string;
  koyouKubun: string;
  koyouKyoikuJisshi: string;
  shokuchouKyoikuJisshiDate: string;
  shuninGijutsuMono: string;
  ousaiTokubetsuBangou: string;
  shurui3: {
    part1: string;
    part2: string;
    part3: string;
  };
  bangou: {
    part1: string;
    part2: string;
    part3: string;
  };
  jogaiRiyuu: {
    part1: string;
    part2: string;
    part3: string;
  };
  kakuninTenpu: {
    part1: string;
    part2: string;
    part3: string;
  };
}
