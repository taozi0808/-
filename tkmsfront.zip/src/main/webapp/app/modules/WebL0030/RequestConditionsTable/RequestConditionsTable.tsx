import React, { useRef, useState, useEffect } from 'react';
import { Checkbox } from '@mui/material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import dayjs from 'dayjs';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import './RequestConditionsTable.scss';

const RequestConditionsTable = ({ rowData }: { rowData: any }) => {
  const [totalData, setTotalData] = useState([]);

  const checkboxRenderer = params => {
    if (params.value === '合計金額') {
      return params.value;
    }
    return <Checkbox checked={params.value} color="default" />;
  };

  // 列の定義
  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '',
      field: 'checkboxValue',
      width: 3,
      suppressSizeToFit: true,
      cellClass: 'cell-center',
      colSpan: params => (params.data.checkboxValue === '合計金額' ? 5 : 1),
      cellRenderer: checkboxRenderer,
    },
    {
      headerName: '請求条件名',
      field: 'seikyuJyokenName',
      width: 70,
    },
    {
      headerName: '連番',
      field: 'renban',
      width: 75,
      suppressSizeToFit: true,
      cellClass: 'text-center',
    },
    {
      headerName: '請求年月',
      field: 'seikyuDate',
      width: 70,
      valueFormatter: params => (params.value ? dayjs(params.value).format('YYYY年MM月') : ''),
      cellClass: 'text-right',
    },
    {
      headerName: '割合 %',
      field: 'wariai',
      width: 80,
      valueFormatter: params => (params.value ? `${params.value}%` : ''),
      suppressSizeToFit: true,
      cellClass: 'text-right',
    },
    {
      headerName: '請求金額(税抜)',
      field: 'seikyuKingakuZeinuki',
      width: 75,
      valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
      cellClass: 'text-right',
    },
    {
      headerName: '税率',
      field: 'zeiritsu',
      width: 30,
      valueFormatter: params => (params.value ? `${params.value}%` : ''),
      cellClass: 'text-right',
    },
    {
      headerName: '消費税金額',
      field: 'shohizeiKingaku',
      width: 70,
      valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
      cellClass: 'text-right',
    },
    {
      headerName: '請求金額(税込)',
      field: 'seikyuKingakuZeikomi',
      width: 75,
      valueFormatter: params => new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value),
      cellClass: 'text-right',
    },
  ]);

  useEffect(() => {
    const list = [...rowData];

    // 合計行
    const totalRow = list.reduce(
      (acc, row) => ({
        seikyuKingakuZeinuki: acc.seikyuKingakuZeinuki + row.seikyuKingakuZeinuki,
        shohizeiKingaku: acc.shohizeiKingaku + row.shohizeiKingaku,
        seikyuKingakuZeikomi: acc.seikyuKingakuZeikomi + row.seikyuKingakuZeikomi,
      }),
      { seikyuKingakuZeinuki: 0, shohizeiKingaku: 0, seikyuKingakuZeikomi: 0 },
    );
    list.push({ checkboxValue: '合計金額', seikyuJyokenName: '', renban: '', seikyuDate: '', wariai: '', ...totalRow });
    setTotalData(list);
  }, [rowData]);

  return (
    <>
      <div
        className="request-conditions-table"
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        <AgGridReact
          columnDefs={columnRef.current}
          domLayout="autoHeight"
          getRowStyle={params => {
            if (params.data.checkboxValue === '合計金額') {
              return { fontWeight: 'bold', backgroundColor: '#f5f5f5' };
            }
            return null;
          }}
          theme={AGGridTheme}
          rowData={totalData}
          headerHeight={30}
          rowHeight={30}
          enableCellSpan
          suppressRowTransform
          gridOptions={{
            defaultColDef: {
              resizable: false,
              sortable: false,
            },
            autoSizeStrategy: {
              type: 'fitGridWidth',
            },
          }}
        />
      </div>
    </>
  );
};

export default RequestConditionsTable;
