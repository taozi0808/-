import React, { useEffect, useState } from 'react';
import { Box, Link, Paper, Divider } from '@mui/material';
import './WebA0040ListPage.scss';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';

interface NotificationItem {
  // お知らせ区分
  kubun: string;
  // お知らせ区分名
  kubunName: string;
  // お知らせ番号
  oshiraseNumber: string;
  // お知らせ内容
  oshiraseNaiyou: string;
  // 登録日時
  startNichiji: string;
}

const NotificationSection = ({ items, showAll, onShowAll }) => {
  return (
    <Paper elevation={3} className="notificationSection">
      {/* お知らせ内容 */}
      <Box className="notificationContent">
        {items.slice(0, showAll ? Math.min(items.length, 10) : 5).map((item, index) => (
          <div key={index} className={`notificationItem ${item.kubun === '80' ? 'notificationItem-80' : ''}`}>
            <span className={`categoryLabel categoryLabel-${item.kubun}`}>{item.kubunName}</span>
            {item.kubun === '80' ? <span className="contentText">・</span> : <span className="contentText"></span>}
            <div className={item.kubun === '80' ? 'notificationContentText2' : 'notificationContentText1'}>
              {item.kubun === '80' ? (
                <>
                  <span className="contentText">{item.oshiraseNaiyou}</span>
                </>
              ) : (
                <Link href="#" underline="hover">
                  {item.oshiraseNaiyou} ({item.startNichiji})
                </Link>
              )}
            </div>
          </div>
        ))}
      </Box>
      {items.length > 5 && (
        <Link onClick={onShowAll} className="showMoreLink">
          {showAll ? '戻る' : `...10件表示`}
        </Link>
      )}
    </Paper>
  );
};

const WebA0040 = () => {
  // 画面名
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('ダッシュボード');
    return () => setPageTitle('');
  }, [setPageTitle]);

  const [showAll, setShowAll] = useState({
    notification: false,
    approval: false,
    cooperation: false,
  });

  const handleShowAll = section => {
    setShowAll(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const notifications: NotificationItem[] = [
    {
      kubun: '30',
      kubunName: '社報',
      oshiraseNumber: '001',
      oshiraseNaiyou: '第30期人事異動に関するお知らせ',
      startNichiji: '2025/1/29',
    },
    {
      kubun: '10',
      kubunName: '通知',
      oshiraseNumber: '002',
      oshiraseNaiyou: '社内規定変更に伴う、徹底事項について',
      startNichiji: '2025/1/25',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
    {
      kubun: '20',
      kubunName: '通達',
      oshiraseNumber: '003',
      oshiraseNaiyou: '社内研修会のお知らせ',
      startNichiji: '2025/1/21',
    },
  ];

  const approvals: NotificationItem[] = [
    {
      kubun: '50',
      kubunName: '申請',
      oshiraseNumber: '004',
      oshiraseNaiyou: '〇〇〇〇様現場（我孫子市）破損箇所補修に関する申請について',
      startNichiji: '2025/2/12',
    },
    {
      kubun: '50',
      kubunName: '申請',
      oshiraseNumber: '004',
      oshiraseNaiyou: '〇〇〇〇様現場（我孫子市）破損箇所補修に関する申請について',
      startNichiji: '2025/2/12',
    },
    {
      kubun: '50',
      kubunName: '申請',
      oshiraseNumber: '004',
      oshiraseNaiyou: '〇〇〇〇様現場（我孫子市）破損箇所補修に関する申請について',
      startNichiji: '2025/2/12',
    },
    {
      kubun: '50',
      kubunName: '申請',
      oshiraseNumber: '004',
      oshiraseNaiyou: '〇〇〇〇様現場（我孫子市）破損箇所補修に関する申請について',
      startNichiji: '2025/2/12',
    },
    {
      kubun: '50',
      kubunName: '申請',
      oshiraseNumber: '004',
      oshiraseNaiyou: '〇〇〇〇様現場（我孫子市）破損箇所補修に関する申請について',
      startNichiji: '2025/2/12',
    },
  ];

  const cooperations: NotificationItem[] = [
    {
      kubun: '80',
      kubunName: '協力会',
      oshiraseNumber: '005',
      oshiraseNaiyou: '2025年05月12日（月）に、支払査定情報がWEB上に公開されますのでご確認ください。',
      startNichiji: '2025/2/3',
    },
    {
      kubun: '80',
      kubunName: '協力会',
      oshiraseNumber: '005',
      oshiraseNaiyou:
        '（工程会議）弊社千葉事業所の工程会議を、2025年05月15日（木）に会場：●●●●会議室202　13:00～開催予定です。 関係協力業者様はご参加ください。',
      startNichiji: '2025/2/2',
    },
    {
      kubun: '80',
      kubunName: '協力会',
      oshiraseNumber: '005',
      oshiraseNaiyou: '当システムに関するお問い合わせは、最寄りの営業所の弊社社員までお問い合わせください。',
      startNichiji: '2025/2/1',
    },
  ];

  return (
    <div className="topPage-container">
      <div className="headMargin">
        <div className="title">
          <h1 className="titleH1">
            <ErrorOutlineOutlinedIcon
              sx={{
                fontSize: '20px',
                verticalAlign: 'middle',
              }}
            />
            {'お知らせ'}
          </h1>
          <div className="titleLinks">
            <Link href="#" underline="hover" className="bulletinBoardLink">
              掲示板
            </Link>
            <Link href="#" underline="hover" className="applicationListLink">
              申請一覧へ
            </Link>
          </div>
        </div>
        <Box className="notificationContainer">
          <h2>通知・通達・社報（1）</h2>
          <NotificationSection items={notifications} showAll={showAll.notification} onShowAll={() => handleShowAll('notification')} />
          <Divider />
          <h2>申請・承認待ち（1）※関連する申請・承認のみ</h2>
          <NotificationSection items={approvals} showAll={showAll.approval} onShowAll={() => handleShowAll('approval')} />
          <Divider />
          <h2>協力会からのお知らせ</h2>
          <NotificationSection items={cooperations} showAll={showAll.cooperation} onShowAll={() => handleShowAll('cooperation')} />
        </Box>
      </div>
    </div>
  );
};

export default WebA0040;
