import React, { useRef, useEffect, useState } from 'react';
import './WebS0020ListPage.scss';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import SearchDialog from './SearchDialog/WebS0020SearchDialog';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { Column, FieldType, Formatter } from 'slickgrid-react';
import { STORAGE_KEY_SHONIN_SEKISAN, DBManager, sekisanDataList } from 'app/shared/util/construction-list';

const WebS0020ListPage = () => {
  const navigate = useNavigate();
  const [dataSource, setDataSource] = useState([]);
  const gridApi = useRef(null);
  const [selectedRowKey, setSelectedRowKey] = useState(null);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');

  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('承認一覧（精積算一覧）');
    return () => setPageTitle('');
  }, [setPageTitle]);

  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';

  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });

  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      cssClass: 'center',
      minWidth: 50,
    },
    {
      id: 'seisekisanCode',
      name: '精積算コード',
      field: 'seisekisanCode',
      sortable: true,
      filterable: true,
      minWidth: 130,
      type: FieldType.string,
    },
    {
      id: 'ankenName',
      name: '案件名称',
      field: 'ankenName',
      minWidth: 110,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 80,
      sortable: true,
      filterable: true,
      cssClass: 'center-align',
      type: FieldType.string,
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 70,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanKingaku',
      name: '概算金額',
      field: 'gaisanKingaku',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        if (val) {
          return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
        } else {
          return '';
        }
      },
      type: FieldType.number,
    },
    {
      id: 'seisekisanKingaku',
      name: '精積算金額',
      field: 'seisekisanKingaku',
      minWidth: 120,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        if (val) {
          return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
        } else {
          return '';
        }
      },
      type: FieldType.number,
    },
    {
      id: 'juchuYmd',
      name: '作成日/ 修正日',
      field: 'juchuYmd',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
    },
    {
      id: 'chakkouDate',
      name: '承認日',
      field: 'chakkouDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
    },
    {
      id: 'tantoBumon',
      name: '担当部門',
      field: 'tantoBumon',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'tantoSha',
      name: '担当者',
      field: 'tantoSha',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 80,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);

  const handleSearch = (values: any) => {
    let contractList = DBManager.getShoninSekisanDataList();
    if (contractList.length === 0) {
      contractList = sekisanDataList(200);
      localStorage.setItem(STORAGE_KEY_SHONIN_SEKISAN, JSON.stringify(contractList));
    }

    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  return (
    <div>
      <div className="WebS0020-container" id="WebS0020-ichiran-container">
        <div className="top-operation">
          <div>
            <SearchDialog onSearch={handleSearch} />
          </div>
        </div>
        <div>
          <BasicSlickGridTable
            columns={columnRef.current}
            data={rowData}
            onSelectionChanged={onSelectedRowsChanged}
            enableContextMenu
            contextMenuItems={[
              // TODO: 後期正式に接続する際は、インターフェースからの権限に基づいて右クリックメニューの利用可能性を制御する必要があります。
              {
                title: '参照',
                command: 'preview',
                action: (_, callbackArgs) => {
                  navigate(`/webD0030/preview/${callbackArgs.dataContext.id}`);
                },
              },
            ]}
          />
        </div>
      </div>
    </div>
  );
};

export default WebS0020ListPage;
