export const mockFormData = {
  siteCode: 'ABC123',
  siteName: '東京オフィスビル',
  siteNameKana: 'トウキョウオフィスビル',

  budgetCode: 'Y11-223-01', // 预算编号
  historyNumber: '99', // 番号
  applyDate: '2025-03-15 15:30',
  approvalDate: '2025-03-23 17:30',
  department: {
    departmentPart1: 'department1',
    departmentPart2: 'department5',
  }, // 部门
  preparer: '山田 花子', // 作成者
};

export const mockSiteInfoData = {
  siteCode: 'ABC123',
  siteName: '東京オフィスビル',
  siteNameKana: 'トウキョウオフィスビル',
  buildingAreaSqm: 500.5,
  buildingAreaTsubo: 151.4,
  constructionFloorAreaSqm: 2000.2,
  constructionFloorAreaTsubo: 605.1,
  structureType: '鉄筋コンクリート造',
  siteStartDate: '2025年04月01日',
  siteHandoverDate: '2026年06月30日',
  memo: 'このプロジェクトは東京都心のオフィスビル建設に関するものです。',
};

export const mockAdjustifyData = {
  no: 1,
  majorCategory: '直接仮設工事',
  subCategory: '水盛り・遣り方',
  specification: '',
  quantity: 1,
  unit: '式',
  unitPrice: 116300,
  budgetAmount: 116300,
  unorderedItems: 20000,
  orderAmount: 66300,
  orderNo: 'J0000000001',
  supplierCode: '10001',
  supplierName: 'A建設',
  approvedAmount: 63000,
  pendingApprovalAmount: 0,
  budgetChangeStatus: true,
  reducibleAmount: 200000, // 减免金额
  reduceAmount: 124000, // 减免可能金额
  reduceTotalAmount: 124000, // 减免总金额
  addAbleAmount: 124000, // 增加金额
  addTotalAmount: 124000, // 增加总金额
};

export const mockTableData = [
  {
    majorCategory: '直接仮設工事',
    subCategory: '水盛り・遣り方',
    specification: '',
    quantity: 1,
    unit: '式',
    unitPrice: 116300,
    budgetAmount: 116300,
    unorderedItems: 20000,
    orderAmount: 66300,
    orderNo: 'J0000000001',
    supplierCode: '10001',
    supplierName: 'A建設',
    approvedAmount: 63000,
    pendingApprovalAmount: 0,
    budgetChangeStatus: true,
    subSupplierList: [
      {
        orderAmount: 20000,
        orderNo: 'J0000000002',
        supplierCode: '10002',
        supplierName: 'B建設',
        approvedAmount: 20000,
        pendingApprovalAmount: 0,
        isSubSupplier: true,
        index: 0,
      },
      {
        orderAmount: 10000,
        orderNo: 'J0000000003',
        supplierCode: '10003',
        supplierName: 'C建設',
        approvedAmount: 10000,
        pendingApprovalAmount: 0,
        isSubSupplier: true,
        index: 1,
      },
    ],
    budgetChangeInfo: {
      majorCategory: '基礎工事',
      subCategory: '掘削',
      specification: '機械掘削',
      quantity: 10,
      unit: '式',
      unitPrice: 50000,
      budgetAmount: 500000,
      unorderedItems: 90000,
      orderAmount: 400000,
      orderNo: 'J0000000002',
      supplierCode: '10002',
      supplierName: 'B工業',
      approvedAmount: 400000,
      pendingApprovalAmount: 20000,
      reducibleAmount: 200000, // 减免金额
      reduceAmount: 124000, // 减免可能金额
      reduceTotalAmount: 124000, // 减免总金额
      addAbleAmount: 124000, // 增加金额
      addTotalAmount: 124000, // 增加总金额
      additionalList: ['', '', ''], // 附加列表
      changeHistoryList: [
        {
          changeDate: '2025-03-19 11:00',
          amountAfterChange: 1163000, // 变动后金额
          amountBeforeChange: 1000000, // 变动前金额
        },
        {
          changeDate: '2025-03-17 15:30',
          amountAfterChange: 1000000, // 变动后金额
          amountBeforeChange: 1200000, // 变动前金额
        },
      ], // 变更历史
      changeReason: '', // 变更理由
    },
  },
  {
    majorCategory: '基礎工事',
    subCategory: '掘削',
    specification: '機械掘削',
    quantity: 10,
    unit: '式',
    unitPrice: 50000,
    budgetAmount: 500000,
    unorderedItems: 90000,
    orderAmount: 400000,
    orderNo: 'J0000000002',
    supplierCode: '10002',
    supplierName: 'B工業',
    approvedAmount: 400000,
    pendingApprovalAmount: 20000,
    subSupplierList: [
      {
        orderAmount: 10000,
        orderNo: 'J0000000002',
        supplierCode: '10002',
        supplierName: 'B建設',
        approvedAmount: 10000,
        pendingApprovalAmount: 0,
        isSubSupplier: true,
        index: 0,
      },
    ],
  },
  {
    majorCategory: 'コンクリート工事',
    subCategory: '打設',
    specification: '生コン',
    quantity: 50,
    unit: '式',
    unitPrice: 24000,
    budgetAmount: 1200000,
    unorderedItems: 20000,
    orderAmount: 1180000,
    orderNo: 'J0000000003',
    supplierCode: '10003',
    supplierName: 'C建材',
    approvedAmount: 1180000,
    pendingApprovalAmount: 20000,
  },
  {
    majorCategory: '鉄筋工事',
    subCategory: '配筋',
    specification: 'D16',
    quantity: 30,
    unit: '式',
    unitPrice: 3000,
    budgetAmount: 90000,
    unorderedItems: 70000,
    orderAmount: 20000,
    orderNo: 'J0000000004',
    supplierCode: '10004',
    supplierName: 'D鉄筋',
    approvedAmount: 90000,
    pendingApprovalAmount: 10000,
  },
  {
    majorCategory: '型枠工事',
    subCategory: '組立',
    specification: '合板型枠',
    quantity: 100,
    unit: '式',
    unitPrice: 8000,
    budgetAmount: 800000,
    unorderedItems: 50000,
    orderAmount: 750000,
    orderNo: 'J0000000005',
    supplierCode: '10005',
    supplierName: 'E工務店',
    approvedAmount: 750000,
    pendingApprovalAmount: 50000,
  },
  {
    majorCategory: '型枠工事',
    subCategory: '組立',
    specification: '合板型枠0',
    quantity: 100,
    unit: '式',
    unitPrice: 8000,
    budgetAmount: 800000,
    unorderedItems: 50000,
    orderAmount: 750000,
    orderNo: 'J0000000005',
    supplierCode: '10005',
    supplierName: 'E工務店',
    approvedAmount: 750000,
    pendingApprovalAmount: 50000,
  },
  {
    majorCategory: '型枠工事',
    subCategory: '組立',
    specification: '合板型枠1',
    quantity: 100,
    unit: '式',
    unitPrice: 8000,
    budgetAmount: 800000,
    unorderedItems: 50000,
    orderAmount: 750000,
    orderNo: 'J0000000005',
    supplierCode: '10005',
    supplierName: 'E工務店',
    approvedAmount: 750000,
    pendingApprovalAmount: 50000,
  },
];
