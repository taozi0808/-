import React, { useEffect, useRef, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Box, IconButton, DialogTitle, InputAdornment } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useForm, Controller } from 'react-hook-form';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import ControlPointIcon from '@mui/icons-material/ControlPoint';
import { generateUUID } from 'app/shared/util/construction-list';
import BasicAgGridTable from 'app/components/BasicAgGridTable';
import dayjs from 'dayjs';
import ConfirmationDialog from 'app/components/ConfirmationDialog';

const BudgetChangeDialog = ({
  submitHandler,
  initData,
  onClose,
}: {
  submitHandler: (newData: any) => void;
  initData: any;
  onClose: () => void;
}) => {
  const notify = useNotify();
  const columnDefsRef = useRef([
    { name: '変更日', field: 'changeDate', width: 200 },
    { name: '変更前金額', field: 'amountBeforeChange', width: 160 },
    { name: '変更後金額', field: 'amountAfterChange', width: 160 },
  ]);

  const { control, handleSubmit } = useForm({
    defaultValues: {
      majorCategory: initData.majorCategory ?? '',
      subCategory: initData.subCategory ?? '',
      budgetAmount: initData.budgetAmount ?? '',
      orderAmount: initData.orderAmount ?? '',
      reduceAmount: initData?.budgetChangeInfo?.reduceAmount ?? '',
      amountAfterChange: initData?.budgetChangeInfo?.amountAfterChange ?? '',
      changeReason: initData?.budgetChangeInfo?.changeReason ?? '',
    },
  });
  const [additionalList, setAdditionalList] = useState(() => {
    let list;
    if (initData?.budgetChangeInfo?.additionalList?.length) {
      list = initData.budgetChangeInfo.additionalList;
    } else {
      list = ['', '', ''];
    }
    return list.map(content => ({ id: generateUUID(), content }));
  });

  const onSubmit = data => {
    console.log('data', data);
    initData.budgetChangeStatus = true;
    if (!initData.budgetChangeInfo) {
      initData.budgetChangeInfo = { changeHistoryList: [] };
    }

    initData.budgetChangeInfo.changeHistoryList.unshift({
      changeDate: dayjs().format('YYYY-MM-DD HH:mm'),
      amountAfterChange: data.amountAfterChange,
      amountBeforeChange: initData.budgetChangeInfo.amountAfterChange ?? 0,
    });

    Object.assign(initData.budgetChangeInfo, {
      reduceAmount: data.reduceAmount,
      amountAfterChange: data.amountAfterChange,
      changeReason: data.changeReason,
      additionalList: additionalList.map(item => item.content),
    });

    submitHandler(initData);
    onClose();
  };

  const renderTextField = (label: string, name: any, required: boolean = false, disabled: boolean = false) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex">
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
            disabled={disabled}
          />
        </Box>
      )}
    />
  );

  const renderAmountTextField = (label: string, name: any, required: boolean = false, disabled: boolean = false) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex">
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            slotProps={{
              input: {
                startAdornment: <InputAdornment position="start">¥</InputAdornment>,
              },
            }}
            sx={{
              width: '100%',
            }}
            type="number"
            disabled={disabled}
          />
        </Box>
      )}
    />
  );

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="lg">
      <DialogTitle>予算変更</DialogTitle>
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={theme => ({
          position: 'absolute',
          right: 8,
          top: 8,
          color: theme.palette.grey[500],
        })}
      >
        <CloseIcon />
      </IconButton>
      <DialogContent sx={{ padding: '20px 36px' }}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <DialogActions sx={{ mb: 2, p: 0, justifyContent: 'start' }}>
            <Button type="submit" variant="contained">
              変更
            </Button>
            <ConfirmationDialog
              buttonText="キャンセル"
              title="キャンセルの確認"
              content="編集内容を破棄します。よろしいでしょうか？（Yes/No）"
              primaryButtonText="No"
              secondaryButtonText="Yes"
              onSecondaryButtonClick={onClose}
              showSecondaryButton={true}
            />
          </DialogActions>

          <Box display="flex" flexDirection="column" gap={2} className="budget-change-dialog-form">
            <Box sx={{ width: '80%', display: 'flex', gap: 2, flexDirection: 'column' }}>
              {renderTextField('大工種', 'majorCategory', false, true)}
              {renderTextField('小工種', 'subCategory', false, true)}
            </Box>
            <Box sx={{ width: '65%', display: 'flex', gap: 2, flexDirection: 'column' }}>
              {renderAmountTextField('実行予算金額', 'budgetAmount', false, true)}
              {renderAmountTextField('発注済金額', 'orderAmount', false, true)}
              {renderAmountTextField('減額可能額', 'reduceAmount', false)}
              {renderAmountTextField('変更後金額', 'amountAfterChange', false)}
            </Box>
          </Box>

          <Box sx={{ position: 'relative' }}>
            <Box sx={{ mb: 1, mt: 2, fontWeight: 'bold', lineHeight: '40px' }}>添付</Box>
            {additionalList.map((item, index) => (
              <Box key={item.id + index} sx={{ display: 'flex', mb: 1 }}>
                <TextField
                  defaultValue={item.content}
                  size="small"
                  sx={{
                    width: '100%',
                    mr: 2,
                  }}
                  onChange={e => {
                    additionalList[index].content = e.target.value;
                  }}
                />
                <Button
                  variant="contained"
                  onClick={() => {
                    setAdditionalList(pre => {
                      const list = [...pre];
                      list.splice(index, 1);
                      return list;
                    });
                  }}
                >
                  削除
                </Button>
              </Box>
            ))}
            <IconButton
              onClick={() => {
                setAdditionalList(pre => {
                  const list = [...pre];
                  list.push({
                    id: generateUUID(),
                    content: '',
                  });
                  return list;
                });
              }}
              sx={{
                position: 'absolute',
                left: -36,
                bottom: 0,
              }}
            >
              <ControlPointIcon />
            </IconButton>
          </Box>

          <Box sx={{ mb: 1, mt: 2, fontWeight: 'bold', lineHeight: '40px' }}>変更履歴</Box>
          <div
            style={{
              width: '90%',
              height: '300px',
            }}
            className="ag-theme-alpine"
          >
            <BasicAgGridTable
              data={initData?.budgetChangeInfo?.changeHistoryList ?? []}
              columns={columnDefsRef.current as any}
              disabledPagination
              agGridProps={{ overlayNoRowsTemplate: '表示する行がありません' }}
            />
          </div>
          <Box sx={{ mb: 1, mt: 2, fontWeight: 'bold', lineHeight: '40px' }}>変更理由</Box>
          <Controller
            name="changeReason"
            control={control}
            rules={{ required: '変更理由が入力されていません。' }}
            render={({ field, fieldState }) => (
              <TextField
                {...field}
                size="small"
                error={!!fieldState.error}
                helperText={fieldState.error ? fieldState.error.message : ''}
                sx={{
                  width: '100%',
                }}
                rows={12}
                multiline
              />
            )}
          />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BudgetChangeDialog;
