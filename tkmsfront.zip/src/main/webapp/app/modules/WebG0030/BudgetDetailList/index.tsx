import React, { useState, useRef, useEffect } from 'react';
import './index.scss';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import { CellContextMenuEvent, ColDef, ColGroupDef, GridReadyEvent } from 'ag-grid-community';
import { Button, Menu, MenuItem } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import BudgetChangeDialog from './BudgetChangeDialog';
import SummaryTable from './SummaryTable';

const BudgetDetailList = ({ data }: { data: any }) => {
  const [columnApi, setColumnApi] = useState<any>(null);
  const [originRowData, setOriginRowData] = useState(data);
  const [rowData, setRowData] = useState([]);
  const [budgetChangeData, setBudgetChangeData] = useState(null);
  const gridRef = useRef<AgGridReact>(null);
  const [contextMenu, setContextMenu] = useState<{
    mouseX: number;
    mouseY: number;
    rowData: any;
  } | null>(null);

  const onGridReady = (params: GridReadyEvent) => {
    setColumnApi(params.api);
    (window as any).aller = params.api;
  };

  const onGridSizeChanged = () => {
    columnApi?.sizeColumnsToFit();
  };

  const generateTableRenderData = () => {
    const newArr = [];
    let no = 0;
    for (let i = 0; i < originRowData.length; i++) {
      no += 1;
      const curData: any = originRowData[i];
      curData.no = no;
      curData.originIndex = i;

      newArr.push(curData);
      newArr.push(curData);

      if (curData?.subSupplierList?.length) {
        curData?.subSupplierList.forEach(item => {
          no += 1;
          item.no = no;
          item.originIndex = i;
          item.budgetChangeStatus = curData.budgetChangeStatus;
          item.isSubSupplier = true;

          newArr.push(item);
          newArr.push(item);
        });
      }
    }

    setRowData(newArr);
  };

  const addSubSupplier = (index: number) => {
    const copyOriginRowData = [...originRowData];
    const row = copyOriginRowData[index];
    const newSupplier = {
      orderAmount: 0,
      orderNo: `${row.orderNo}-${(row?.subSupplierList?.length ?? 0) + 1}`,
      supplierCode: '',
      supplierName: '',
      approvedAmount: 0,
      pendingApprovalAmount: 0,
      isSubSupplier: true,
      index: 0,
    };
    if (row.subSupplierList) {
      newSupplier.index = row.subSupplierList.length;
      row.subSupplierList.push(newSupplier);
    } else {
      row.subSupplierList = [newSupplier];
    }
    setOriginRowData(copyOriginRowData);
  };

  const deleteSubSupplier = (index: number, originIndex: number) => {
    const copyOriginRowData = [...originRowData];
    const row = copyOriginRowData[originIndex];
    row.subSupplierList.splice(index, 1);

    // 重新计算未下单金额
    let orderAmountCount = row.orderAmount;
    if (row.subSupplierList.length) {
      row.subSupplierList.forEach((item, i) => {
        orderAmountCount += item.orderAmount;
        item.index = i;
      });
    }
    row.unorderedItems = row.budgetAmount - orderAmountCount;

    setOriginRowData(copyOriginRowData);
  };

  const getRowStyle = params => {
    if (params.data.budgetChangeStatus) {
      return { background: '#ccc' };
    }
  };

  const onCellEdit = (params, key) => {
    // eslint-disable-next-line no-prototype-builtins
    if (params.data.hasOwnProperty(key)) {
      params.data[key] = params.newValue;

      let originData = params.data;

      if (params.data.isSubSupplier) {
        originData = originRowData[params.data.originIndex];
      }
      const subSupplierList = originData?.subSupplierList ?? [];

      // 如果修改的是子供应商数据，则在原始数据中做对应修改；
      if (params.data.isSubSupplier && subSupplierList.length) {
        subSupplierList[params.data.index][key] = params.newValue;
      }

      // 修改订单金额或预算金额时，自动调整未下单金额；
      if (['orderAmount', 'budgetAmount'].includes(key)) {
        let orderAmountCount = originData.orderAmount;

        if (subSupplierList.length) {
          subSupplierList.forEach(item => {
            orderAmountCount += item.orderAmount;
          });
        }
        originData.unorderedItems = originData.budgetAmount - orderAmountCount;
      }

      setOriginRowData(pre => {
        const list = [...pre];
        list[originData.originIndex] = originData;
        return list;
      });

      return true;
    }
    return false;
  };

  const onBudgetChangeSubmit = newData => {
    setOriginRowData(pre => {
      const list = [...pre];
      list[newData.originIndex] = newData;
      return list;
    });
  };

  // 处理右击事件
  const onCellContextMenu = (event: CellContextMenuEvent) => {
    event.event.preventDefault();
    setContextMenu({
      mouseX: (event.event as any).clientX,
      mouseY: (event.event as any).clientY,
      rowData: event.data,
    });
  };

  // 关闭菜单
  const handleClose = () => {
    setContextMenu(null);
  };

  // 处理菜单项点击
  const handleMenuItemClick = (action: string) => {
    if (contextMenu) {
      switch (action) {
        case 'add':
          addSubSupplier(contextMenu.rowData.originIndex);
          break;
        case 'delete':
          deleteSubSupplier(contextMenu.rowData.index, contextMenu.rowData.originIndex);
          break;
        default:
      }
      handleClose();
    }
  };

  useEffect(() => {
    generateTableRenderData();
  }, [originRowData]);

  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'no',
      width: 70,
      spanRows: true,
      cellClass: 'cell-center',
      cellStyle: params => (params.data.budgetChangeStatus ? { backgroundColor: '#ccc' } : {}),
    },
    {
      headerName: '',
      field: 'no',
      width: 70,
      spanRows: true,
      cellClass: 'cell-center',
      cellStyle: params => (params.data.budgetChangeStatus ? { backgroundColor: '#ccc' } : {}),
      cellRenderer: params => {
        return params.data.isSubSupplier ? (
          <ArrowForwardIosIcon fontSize="small" />
        ) : (
          <AddIcon
            onClick={() => {
              addSubSupplier(params.data.originIndex);
            }}
            sx={{ cursor: 'pointer' }}
          />
        );
      },
    },
    {
      headerName: '大工種',
      field: 'majorCategory',
      width: 180,
      children: [
        {
          headerName: '小工種',
          field: 'subCategory',
          width: 180,
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.majorCategory : params.data.subCategory),
          colSpan: params => (params.data.isSubSupplier ? 5 : 1),
          cellClass: params => {
            if (params.data.isSubSupplier) {
              // 第一行手动设置高度超出1px，达到隐藏两个单元格之间横线的目的
              return params.node.rowIndex % 2 === 0 ? 'special-empty-cell-top' : 'special-empty-cell-bottom';
            }
            return 'add-arrow-icon';
          },
        },
      ],
    },
    {
      headerName: '規格',
      field: 'specification',
      width: 180,
      spanRows: true,
      cellClass: 'cell-align-center',
      cellStyle: params => (params.data.budgetChangeStatus ? { backgroundColor: '#ccc' } : {}),
    },
    {
      headerName: '数量',
      field: 'quantity',
      width: 90,
      children: [
        {
          headerName: '単価',
          field: 'unitPrice',
          width: 90,
          headerClass: 'budget-detail-special-header',
          cellClass: 'cell-end',
          valueFormatter: params =>
            params.node.rowIndex % 2 === 0
              ? params.data.quantity
              : new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.data.unitPrice),
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 2),
        },
      ],
    },
    {
      headerName: '単位',
      field: 'unit',
      width: 90,
      children: [
        {
          headerName: '',
          field: '',
          width: 90,
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.unit : ''),
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'add-arrow-icon' : ''),
        },
      ],
    },
    {
      headerName: '実行予算金額',
      field: 'budgetAmount',
      width: 180,
      children: [
        {
          headerName: '未発注残',
          field: 'unorderedItems',
          width: 180,
          cellClass: 'cell-end',
          editable: params => !params.data.isSubSupplier && params.node.rowIndex % 2 === 0,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.budgetAmount : params.data.unorderedItems;
          },
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'budgetAmount' : ''),
          cellEditor: 'agNumberCellEditor',
          valueFormatter: params =>
            new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(
              params.node.rowIndex % 2 === 0 ? params.data.budgetAmount : params.data.unorderedItems,
            ),
        },
      ],
    },
    {
      headerName: '注文書No.',
      field: 'orderNo',
      width: 180,
      children: [
        {
          headerName: '発注金額',
          field: 'orderAmount',
          width: 180,
          cellClass: 'cell-end',
          editable: params => params.node.rowIndex % 2 === 1,
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 1 ? 'orderAmount' : ''),
          cellEditor: 'agNumberCellEditor',
          valueFormatter: params =>
            params.node.rowIndex % 2 === 0
              ? params.data.orderNo
              : new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.data.orderAmount),
        },
      ],
    },
    {
      headerName: '業者コード.',
      field: 'supplierCode',
      width: 180,
      children: [
        {
          headerName: '業者名',
          field: 'supplierName',
          width: 180,
          editable: true,
          valueSetter: params => onCellEdit(params, params.node.rowIndex % 2 === 0 ? 'supplierCode' : 'supplierName'),
          cellEditor: 'agTextCellEditor',
          cellEditorParams: {
            useFormatter: true,
          },
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.supplierCode : params.data.supplierName),
        },
      ],
    },
    {
      headerName: '査定済金額',
      field: 'approvedAmount',
      width: 180,
      children: [
        {
          headerName: '未査定残',
          field: 'pendingApprovalAmount',
          width: 180,
          cellClass: 'cell-end',
          valueFormatter: params =>
            new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(
              params.node.rowIndex % 2 === 0 ? params.data.approvedAmount : params.data.pendingApprovalAmount,
            ),
        },
      ],
    },
    {
      headerName: '予算変更',
      field: 'budgetChange',
      width: 180,
      children: [
        {
          headerName: '',
          field: '',
          width: 180,
          valueFormatter: params => (params.node.rowIndex % 2 === 0 ? params.data.budgetChange : ''),
          cellClass: 'cell-center',
          cellStyle: params => {
            if (params.data.budgetChangeStatus) {
              return { backgroundColor: !params.data.isSubSupplier && params.node.rowIndex % 2 === 1 ? '#898787' : '#ccc' };
            }
            return { backgroundColor: !params.data.isSubSupplier && params.node.rowIndex % 2 === 0 ? '#fff' : '#898787' };
          },
          cellRenderer: params => {
            if (params.node.rowIndex % 2 === 0 && !params.data.isSubSupplier) {
              return (
                <Button
                  variant="text"
                  size="small"
                  onClick={() => {
                    setBudgetChangeData(params.data);
                  }}
                >
                  {params.data.budgetChangeStatus ? 'あり' : 'なし'}
                </Button>
              );
            }
            return '';
          },
        },
      ],
    },
  ]);

  return (
    <>
      <div
        className="ag-theme-alpine budget-detail-list"
        style={{ height: 670, width: '100%', overflow: 'auto' }}
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        {rowData.length > 0 && (
          <AgGridReact
            columnDefs={columnRef.current}
            onGridReady={onGridReady}
            onGridSizeChanged={onGridSizeChanged}
            onCellContextMenu={onCellContextMenu}
            getRowStyle={getRowStyle}
            rowData={rowData}
            domLayout="autoHeight"
            theme={AGGridTheme}
            headerHeight={30}
            rowHeight={30}
            enableCellSpan
            gridOptions={{
              defaultColDef: {
                resizable: false,
                sortable: false,
              },
              autoSizeStrategy: {
                type: 'fitGridWidth',
              },
            }}
          />
        )}
        {budgetChangeData && (
          <BudgetChangeDialog
            initData={budgetChangeData}
            submitHandler={onBudgetChangeSubmit}
            onClose={() => {
              setBudgetChangeData(null);
            }}
          />
        )}
        <Menu
          open={contextMenu !== null}
          onClose={handleClose}
          anchorReference="anchorPosition"
          anchorPosition={contextMenu ? { top: contextMenu.mouseY, left: contextMenu.mouseX } : undefined}
        >
          <MenuItem onClick={() => handleMenuItemClick('add')}>追加</MenuItem>
          {contextMenu?.rowData?.isSubSupplier && <MenuItem onClick={() => handleMenuItemClick('delete')}>削除</MenuItem>}
        </Menu>
      </div>
      {originRowData.length > 0 && <SummaryTable rowData={originRowData} />}
    </>
  );
};

export default BudgetDetailList;
