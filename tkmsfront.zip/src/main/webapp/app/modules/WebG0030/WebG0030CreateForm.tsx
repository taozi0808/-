import React, { FC, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebG0030CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Select, MenuItem, Button, FormHelperText } from '@mui/material';
import { FormValues } from './types';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { jaJP } from '@mui/x-date-pickers/locales';
import dayjs from 'dayjs';
import SiteInfo from './SiteInfo';
import BudgetDetailList from './BudgetDetailList';
import { mockFormData, mockSiteInfoData, mockTableData, mockAdjustifyData } from './initData';
import ConfirmationDialog from 'app/components/ConfirmationDialog';

const CreateWorkBudget: FC = () => {
  const { setPageTitle } = usePageTitleStore();

  const navigate = useNavigate();
  const notify = useNotify();
  const { id } = useParams();

  const {
    control,
    handleSubmit,
    formState: { errors },
    getValues,
    reset,
  } = useForm<FormValues>({
    defaultValues: {
      siteCode: id,
      siteName: '',
      siteName1: '',
      budgetCode: '', // 预算编号
      historyNumber: '', // 番号
      applyDate: '',
      approvalDate: '',
      department: {
        departmentPart1: '',
        departmentPart2: '',
      }, // 部门
      preparer: '', // 作成者
    },
    mode: 'onBlur',
  });

  const [budgetData, setBudgetData] = useState(null);
  const [budgetAdjustData, setBudgetAdjustData] = useState(null);

  const clear = () => {
    setBudgetData(null);
    setTimeout(() => {
      init();
    }, 0);
  };

  const init = () => {
    const values = getValues();
    // TODO: 数据请求
    if (values.siteCode) {
      setBudgetData({
        budgetDetailList: JSON.parse(JSON.stringify(mockTableData)),
        supplierSummaryList: JSON.parse(JSON.stringify([])),
        siteInfo: JSON.parse(JSON.stringify(mockAdjustifyData)),
      });
      reset(mockFormData);
    }
    setBudgetAdjustData(JSON.parse(JSON.stringify(mockAdjustifyData)));
    console.log('JSON.stringify(mockAdjustifyData):' + JSON.stringify(mockAdjustifyData));
  };

  const onSave: SubmitHandler<FormValues> = data => {
    console.log('表单提交结果:', data);
    // notify('保存成功！', 'success');
  };

  const renderTextField = (label: string, name: keyof FormValues, required: boolean = false, disabled: boolean = false) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex" flex={1}>
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
            disabled={disabled}
          />
        </Box>
      )}
    />
  );

  useEffect(() => {
    setPageTitle('実行予算作成');
    init();
  }, []);

  return (
    <div className="create-work-budget">
      <div className="top">
        <div className="top-item">
          <LastUpdateInfo userId={''} />
          <LastUpdateInfo userId={''} title="【承認者】" />
        </div>
        <div className="top-item">
          <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
          <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
        </div>
      </div>
      <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '100%', overflowY: 'auto' }} className="basic-form">
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', columnGap: 1, margin: '16px 0' }}>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
              保存
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}}>
              申請
            </Button>
            <ConfirmationDialog
              buttonText="クリア"
              title="クリア確認"
              content="画面を初期化します。よろしいでしょうか？（Yes/No）"
              primaryButtonText="No"
              secondaryButtonText="Yes"
              onSecondaryButtonClick={clear}
              showSecondaryButton={true}
            />
            <ConfirmationDialog
              buttonText="キャンセル"
              title="キャンセル確認"
              content="編集内容を破棄します。よろしいでしょうか？（Yes/No）"
              primaryButtonText="No"
              secondaryButtonText="Yes"
              onSecondaryButtonClick={() => {
                navigate('/webG0010');
              }}
              showSecondaryButton={true}
            />
          </Box>
          <Box>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              注文書印刷
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              印刷
            </Button>
          </Box>
        </Box>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
            mt: 4,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            {renderTextField('現場コード', 'siteCode', false, true)}
            <Button variant="contained" size="small" style={{ height: 32, width: 96, marginTop: 4, marginLeft: 16 }} onClick={init}>
              参照
            </Button>
          </Box>
          {renderTextField('現場名', 'siteName', false, true)}
        </Box>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          <span />
          {renderTextField('現場カナ名', 'siteName1', false, true)}
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>実行予算コード</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="budgetCode"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(70% - 8px)',
                    }}
                    disabled
                  />
                )}
              />
              <span>-</span>
              <Controller
                name="historyNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(30% - 8px)',
                    }}
                    disabled
                  />
                )}
              />
            </Box>
          </Box>
          <span />
        </Box>
        <LocalizationProvider
          dateAdapter={AdapterDayjs}
          adapterLocale="ja"
          localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
        >
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Controller
              name="applyDate"
              control={control}
              rules={{ required: '予算申請日が入力されていません。' }}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>*予算申請日</Box>
                  <Box sx={{ width: '100%' }}>
                    <DateTimePicker
                      label=""
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      format="YYYY年MM月DD日 HH:mm"
                      ampm={false}
                      slotProps={{ calendarHeader: { format: 'MM/YYYY' } }}
                      value={field.value ? dayjs(field.value) : null}
                    />

                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
            <Controller
              name="approvalDate"
              control={control}
              rules={{ required: '予算承認日が入力されていません。' }}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>*予算承認日</Box>
                  <Box sx={{ width: '100%' }}>
                    <DateTimePicker
                      label=""
                      {...field}
                      disableFuture={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      format="YYYY年MM月DD日 HH:mm"
                      ampm={false}
                      slotProps={{ calendarHeader: { format: 'MM/YYYY' } }}
                      value={field.value ? dayjs(field.value) : null}
                      // disabled
                    />

                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
          </Box>
        </LocalizationProvider>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          <Box sx={{ display: 'flex' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 100, lineHeight: '40px' }}>予算作成部門</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="department.departmentPart1"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(50% - 8px)',
                    }}
                    displayEmpty
                  >
                    <MenuItem value="department1">関西工事部</MenuItem>
                    <MenuItem value="department2">中部設備部</MenuItem>
                    <MenuItem value="department3">北海道建設部</MenuItem>
                  </Select>
                )}
              />
              <span>-</span>
              <Controller
                name="department.departmentPart2"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    size="small"
                    sx={{
                      width: 'calc(50% - 8px)',
                    }}
                    displayEmpty
                  >
                    <MenuItem value="department4">営業部</MenuItem>
                    <MenuItem value="department5">工事部</MenuItem>
                    <MenuItem value="department6">設計部</MenuItem>
                  </Select>
                )}
              />
            </Box>
          </Box>
          <span />
        </Box>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            columnGap: 6,
            mb: 2,
          }}
        >
          {renderTextField('予算作成者', 'preparer')}
          <span />
        </Box>
      </Box>
      {budgetData && (
        <>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, mt: 2 }}>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}}>
              予算変更
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}}>
              一括発注取消
            </Button>
          </Box>
          <BudgetDetailList data={budgetData.budgetDetailList} />
          <SiteInfo data={budgetData.siteInfo} />
        </>
      )}
    </div>
  );
};

export default CreateWorkBudget;
