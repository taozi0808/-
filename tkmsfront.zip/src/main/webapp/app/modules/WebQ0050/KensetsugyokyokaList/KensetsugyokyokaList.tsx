import React, { useRef, useState } from 'react';
import { CellContextMenuEvent, ColDef, ColGroupDef, GridReadyEvent, IHeaderParams } from 'ag-grid-community';
import dayjs from 'dayjs';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import './KensetsugyokyokaList.scss';
import CustomCellEditor from '../CustomCellEditor';

const KensetsugyokyokaList = ({ rowData }: { rowData: any }) => {
  // useEffect(() => {}, []);

  // 列の定義
  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    // No
    {
      headerName: 'No',
      field: 'no',
      width: 55,
      cellClass: 'text-center',
      editable: false,
    },
    // 許可·設定
    {
      headerName: '許可·設定',
      field: 'KyokaSettei',
      width: 218,
    },
    // 業種
    {
      headerName: '業種',
      field: 'gyoushu',
      width: 160,
    },
    {
      headerName: '番号',
      field: 'bango1',
      width: 128,
      editable: true,
      cellEditor: 'customCellEditor', // 使用自定义编辑器
    },
    {
      colId: 'bango2',
      field: 'bango2',
      width: 128,
      headerName: '',
      cellClass: 'text-right',
    },
    {
      headerName: '許可日·設定日',
      field: 'kyokabiSetteibi',
      width: 160,
      cellClass: 'text-right',
      cellEditor: 'agDateCellEditor',
      valueFormatter: params => {
        if (params.value) {
          const date = new Date(params.value);
          const yyyy = date.getFullYear();
          const mm = String(date.getMonth() + 1).padStart(2, '0');
          const dd = String(date.getDate()).padStart(2, '0');
          return `${yyyy}年${mm}月${dd}日`; // 格式化成 "yyyy年mm月dd日"
        }
        return '';
      },
    },
  ]);

  return (
    <>
      <div
        className="kensetsugyokyoka-table"
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        <AgGridReact
          columnDefs={columnRef.current}
          domLayout="normal"
          theme={AGGridTheme}
          rowData={rowData}
          headerHeight={30}
          rowHeight={30}
          gridOptions={{
            defaultColDef: {
              // flex: 1,
              // resizable: false,
              // sortable: false,
              editable: true,
            },
            components: {
              customCellEditor: CustomCellEditor, // 注册自定义编辑器
            },
          }}
        />
      </div>
    </>
  );
};

export default KensetsugyokyokaList;
