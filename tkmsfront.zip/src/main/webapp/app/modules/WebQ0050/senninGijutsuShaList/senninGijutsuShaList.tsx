import React, { useRef, useState } from 'react';
import { CellContextMenuEvent, ColDef, ColGroupDef, GridReadyEvent, IHeaderParams } from 'ag-grid-community';
import dayjs from 'dayjs';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import './senninGijutsuShaList.scss';

const senninGijutsuShaList = ({ rowData }: { rowData: any }) => {
  // useEffect(() => {}, []);

  const genbaBairininMeiList = ['　', '佐藤 一郎', '鈴木 花子', '高橋 大輔', '山田 美咲', '田中 俊介'];

  // 列の定義
  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    // 専任技術者
    {
      headerName: '*専任技術者名',
      field: 'senninGijutsuShamei',
      width: 215,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: genbaBairininMeiList,
      },
    },
    // 資格内容
    {
      headerName: '*資格内容',
      field: 'shikakunaiyo3',
      width: 280,
    },
    // 担当工事内容
    {
      headerName: '*担当工事内容',
      field: 'TantoKojiNaiyo',
      width: 249,
    },
  ]);

  return (
    <>
      <div
        className="senninGijutsuSha-table"
        onContextMenu={e => {
          e.preventDefault();
        }}
      >
        <AgGridReact
          columnDefs={columnRef.current}
          domLayout="normal"
          theme={AGGridTheme}
          rowData={rowData}
          headerHeight={30}
          rowHeight={30}
          gridOptions={{
            defaultColDef: {
              // flex: 1,
              // resizable: false,
              // sortable: false,
              editable: true,
            },
          }}
        />
      </div>
    </>
  );
};

export default senninGijutsuShaList;
