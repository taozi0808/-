import React, { FC, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebQ0050CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Button, Select, MenuItem, FormControlLabel, RadioGroup, Radio } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, sagyouInData } from 'app/shared/util/construction-list';
import KensetsugyokyokaList from './KensetsugyokyokaList/KensetsugyokyokaList';
import JiyoushoSeiriKigouList from './JiyoushoSeiriKigouList/JiyoushoSeiriKigouList';
import SenninGijutsuShaList from './senninGijutsuShaList/senninGijutsuShaList';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import { jaJP } from '@mui/x-date-pickers/locales';

const WebQ0050CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(false);
  const [selectedValue, setSelectedValue] = useState('');
  // サンプルデータ
  const [rowData, setRowData] = useState([]);
  const [jiyoushoSeiriKigouRowData, setjiyoushoSeiriKigouRowData] = useState([]);
  const [rowData2, setRowData2] = useState([]);

  const genbaBairininMeiList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '佐藤 一郎', code: '佐藤 一郎' },
    { id: 2, name: '鈴木 花子', code: '鈴木 花子' },
    { id: 3, name: '高橋 大輔', code: '高橋 大輔' },
    { id: 4, name: '山田 美咲', code: '山田 美咲' },
    { id: 5, name: '田中 俊介', code: '田中 俊介' },
  ];
  const kengenOyobiIkenMoshideHohoList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '請負契約書第13条掲載の通り', code: '13' },
    { id: 2, name: '請負契約書第14条掲載の通り', code: '14' },
    { id: 3, name: '請負契約書第15条掲載の通り', code: '15' },
    { id: 4, name: '請負契約書第26条掲載の通り', code: '26' },
    { id: 5, name: '請負契約書第88条掲載の通り', code: '88' },
  ];
  const kantokusList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '専任', code: '1' },
    { id: 2, name: '兼任', code: '0' },
  ];
  const kenkohokenNoKanyuJokyoList = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '加入', code: '1' },
    { id: 2, name: '未加入', code: '0' },
  ];
  const shikakunaiyo = [
    { id: 0, name: '　', code: '' },
    { id: 1, name: '一級建築士', code: '1' },
    { id: 2, name: '二級建築士', code: '2' },
    { id: 3, name: '三級建築士', code: '3' },
    { id: 4, name: '四級建築士', code: '4' },
  ];
  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<CustomerManagementFormValues>({
    defaultValues: {
      // 申請日
      shinseiNichi: '',
      // 承認日
      shounin: '',
    },
    mode: 'onBlur',
  });

  const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue('ichigoTokuteiGinoGaikokuhitoNoJujiNoJokyo', (event.target as HTMLInputElement).value);
  };

  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue('gaikokuHitoKensetsuShuroshaNoJujiNoJokyo', (event.target as HTMLInputElement).value);
  };

  const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue('gaikokuHitoGinoJisshuSeiNoJujiNoJokyo', (event.target as HTMLInputElement).value);
  };

  const onSave: SubmitHandler<CustomerManagementFormValues> = values => {
    console.log('表单提交结果:', values);

    // alert('保存成功！');
  };

  let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY996');
  if (sagyouInList.length === 0) {
    sagyouInList = sagyouInData(500);
    localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY996', JSON.stringify(sagyouInList));
  }

  if (id === undefined) {
    console.log('新規登録');
  } else {
    const editData = sagyouInList.find(item => item.id === id) || null;
    if (editData === null) {
      console.log('データ異常');
    } else {
      useEffect(() => {}, []);
    }
  }
  interface SelectItem {
    id: number;
    name: string;
    code: string;
  }
  const renderTextField = (label: string, name: keyof CustomerManagementFormValues, required: boolean, disabled: boolean) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex" flex={1}>
          <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
            disabled={disabled}
          />
        </Box>
      )}
    />
  );
  const jiyoushoSeiriKigouData = [
    { id: 0, kubun: '元請契約' },
    { id: 1, kubun: '下請契約' },
  ];

  const renderSelectField = (name: keyof CustomerManagementFormValues, width: string, dataList: SelectItem[], disabled: boolean) => (
    <Controller
      name={name}
      control={control}
      disabled={disabled}
      render={({ field }) => (
        <Select
          {...field}
          label=""
          sx={{
            width: width,
          }}
          MenuProps={{
            PaperProps: {
              width: '100%',
              style: {
                maxHeight: 200,
                overflow: 'auto',
              },
            },
          }}
          size="small"
        >
          {dataList.map(item => (
            <MenuItem key={item.id} value={item.code}>
              {item.name}
            </MenuItem>
          ))}
        </Select>
      )}
    />
  );
  useEffect(() => {
    for (let i = 0; i < 4; i++) {
      rowData.push({
        id: i + 1,
        no: i + 1,
      });
    }
    for (let i = 0; i < 2; i++) {
      rowData2.push({
        id: i + 1,
      });
    }
    setRowData(rowData);
    setRowData2(rowData2);
    setjiyoushoSeiriKigouRowData(jiyoushoSeiriKigouData);
    setPageTitle('下請契約台帳');
    if (type === 'add') {
      setIsHensyuuKengen(true);
    }
    return () => setPageTitle('');
  }, [setPageTitle]);
  return (
    <div>
      <div className="create-work-budget-WebQ0050">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>

        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit">
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={() => {}}>
              申請
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={() => {}}>
              クリア
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ margin: '8px 0', minWidth: 96 }}
              onClick={() => {
                navigate(`/WebQ0010ListPage`);
              }}
            >
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              印刷
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/WebQ0010ListPage`);
              }}
            >
              作業員名簿
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/`);
              }}
            >
              再下請通知書
            </Button>
          </div>
        </div>
        <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '100%', overflowY: 'auto' }}>
          {/* 申請日，承認日 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              {renderTextField('申請日', 'shinseiNichi', false, !isHensyuuKengen)}
              <label style={{ color: '#dc3545', minWidth: 50, paddingLeft: 6, paddingRight: 6 }}>【承認】</label>
              <label style={{ width: '150px' }}>{`<<< 1/3 >>>`}</label>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr' }}>
              {renderTextField('*承認日', 'shounin', false, !isHensyuuKengen)}
              <span />
            </Box>
          </Box>
          {/* 会社名，業者コード */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>{renderTextField('会社名', 'kaishaMei', false, !isHensyuuKengen)}</Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr' }}>
              {renderTextField('業者コード', 'gyoushaCode', false, !isHensyuuKengen)}
              <span />
            </Box>
          </Box>
          {/* 事業所名，物件コード */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>{renderTextField('事業所名', 'jigyoshomei', false, !isHensyuuKengen)}</Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr' }}>
              {renderTextField('物件コード', 'bukkenCode', false, !isHensyuuKengen)}
              <span />
            </Box>
          </Box>
          {/* 郵便番号，注文書番号 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>郵便番号</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <Controller
                  name="Yubenbango1"
                  control={control}
                  disabled={!isHensyuuKengen}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      sx={{
                        width: 'calc(25%)',
                      }}
                    />
                  )}
                />
                <span>-</span>
                <Controller
                  name="Yubenbango2"
                  control={control}
                  disabled={!isHensyuuKengen}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      sx={{
                        width: 'calc(25%)',
                      }}
                    />
                  )}
                />
              </Box>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr' }}>
              {renderTextField('注文書番号', 'chuBunshobango', false, !isHensyuuKengen)}
              <span />
            </Box>
          </Box>
          {/* 住所1 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>{renderTextField('住所1', 'jusho1', false, !isHensyuuKengen)}</Box>
            <span />
          </Box>
          {/* 住所2 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>{renderTextField('住所2', 'jusho2', false, !isHensyuuKengen)}</Box>
            <span />
          </Box>
          {/* 電話番号 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>電話番号</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <Controller
                  name="tenwabango1"
                  control={control}
                  disabled={!isHensyuuKengen}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      sx={{
                        width: 'calc(25%)',
                      }}
                    />
                  )}
                />
                <span>-</span>
                <Controller
                  name="tenwabango2"
                  control={control}
                  disabled={!isHensyuuKengen}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      sx={{
                        width: 'calc(25%)',
                      }}
                    />
                  )}
                />
                <span>-</span>
                <Controller
                  name="tenwabango3"
                  control={control}
                  disabled={!isHensyuuKengen}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      sx={{
                        width: 'calc(25%)',
                      }}
                    />
                  )}
                />
              </Box>
            </Box>
            <span />
          </Box>
          {/* 工事名称及び工事内容 */}
          <Box display="flex" justifyContent="space-between">
            <div className="form-item">
              <div className="title">*工事名称及び工事内容</div>
            </div>
          </Box>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
              mt: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}></Box>
              <Controller
                name="kojiMeishoOyobiKojiNaiyo"
                control={control}
                disabled={!isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    multiline
                    error={!!fieldState.error}
                    sx={{
                      width: '100%',
                    }}
                    minRows={5} // 最小表示は5行
                    maxRows={5} // 最大6行まで自動的に拡張され、6行を超えるとスクロールバーが表示されます。
                    helperText={fieldState.error ? fieldState.error.message : ''}
                  />
                )}
              />
            </Box>
            <span />
          </Box>
          {/* 工期 */}
          <Box
            sx={{
              display: 'grid',
              // gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>工期</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <LocalizationProvider
                  dateAdapter={AdapterDayjs}
                  adapterLocale="ja"
                  localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                >
                  <Controller
                    name="kokiStart"
                    control={control}
                    render={({ field }) => (
                      <DatePicker
                        disabled={!isHensyuuKengen}
                        {...field}
                        sx={{ width: '195px', textAlignLast: 'end' }}
                        className="custom-picker"
                        format="YYYY年MM月DD日"
                        value={field.value ? dayjs(field.value) : null}
                      />
                    )}
                  />
                  <span>～</span>
                  <Controller
                    name="kokiEnd"
                    control={control}
                    render={({ field }) => (
                      <DatePicker
                        disabled={!isHensyuuKengen}
                        {...field}
                        sx={{ width: '195px' }}
                        format="YYYY年MM月DD日"
                        value={field.value ? dayjs(field.value) : null}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Box>
            </Box>
          </Box>
          {/* 請書返信日 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>請書返信日</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <LocalizationProvider
                  dateAdapter={AdapterDayjs}
                  adapterLocale="ja"
                  localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
                >
                  <Controller
                    name="ukeshoHenshinbi"
                    control={control}
                    render={({ field }) => (
                      <DatePicker
                        disabled={!isHensyuuKengen}
                        {...field}
                        sx={{ width: '195px' }}
                        format="YYYY年MM月DD日"
                        value={field.value ? dayjs(field.value) : null}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Box>
            </Box>
            <span />
          </Box>
          {/* 建設業許可 */}
          <Box sx={{ display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100 }}>建設業許可</Box>
            <Box sx={{ width: '850px' }}>
              <KensetsugyokyokaList rowData={rowData} />
            </Box>
          </Box>
          {/* 健康保険の加入状況 */}
          <Box display="flex" justifyContent="space-between">
            <div className="form-item">
              <div className="title">*健康保険の加入状況</div>
            </div>
          </Box>
          {/* 健康保険，厚生年金保险，雇用保険 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr 1fr 1fr',
              columnGap: 2,
              mb: 2,
              mt: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>健康保険</Box>
              <Box>{renderSelectField('kenkouhoken', '150px', kenkohokenNoKanyuJokyoList, !isHensyuuKengen)}</Box>
            </Box>
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>厚生年金保険</Box>
              <Box>{renderSelectField('koseiNenkinBaoXian', '150px', kenkohokenNoKanyuJokyoList, !isHensyuuKengen)}</Box>
            </Box>
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100, lineHeight: '40px' }}>雇用保険</Box>
              <Box>{renderSelectField('koyohoken', '150px', kenkohokenNoKanyuJokyoList, !isHensyuuKengen)}</Box>
            </Box>
            <span />
          </Box>
          {/* 事業所整理記号 */}
          <Box display="flex" justifyContent="space-between">
            <div className="form-item">
              <div className="title">*事業所整理記号</div>
            </div>
          </Box>
          <Box sx={{ display: 'flex', mt: 2, mb: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100 }}></Box>
            <Box sx={{ width: '850px' }}>
              <JiyoushoSeiriKigouList rowData={jiyoushoSeiriKigouRowData} />
            </Box>
          </Box>
          {/* 会社代表者 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>会社代表者</Box>
              <Box>{renderSelectField('kaishaDaihyosha', '200px', genbaBairininMeiList, !isHensyuuKengen)}</Box>
            </Box>
            <span />
          </Box>
          {/* 現場代理人名,権限及び意見申出方法 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 2fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>*現場代理人名</Box>
              <Box>{renderSelectField('genbaBairininMei', '200px', genbaBairininMeiList, !isHensyuuKengen)}</Box>
            </Box>
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>*権限及び意見申出方法</Box>
              <Box sx={{ display: 'flex', ml: 2 }}>
                {renderSelectField('kengenOyobiIkenMoshideHoho', '350px', kengenOyobiIkenMoshideHohoList, !isHensyuuKengen)}
              </Box>
            </Box>
          </Box>
          {/* 監督·主任技術者名,資格内容 */}
          <Box
            sx={{
              display: 'grid',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>*監督·主任技術者名</Box>
              <Box>{renderSelectField('kantokus', '104px', kantokusList, !isHensyuuKengen)}</Box>
              <Box sx={{ display: 'flex', ml: 2 }}>
                {renderSelectField('shuninGijutsuShaMei', '255px', genbaBairininMeiList, !isHensyuuKengen)}
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'center', ml: 2, minWidth: 70, lineHeight: '40px' }}>*資格内容</Box>
              <Box sx={{ display: 'flex', ml: 2 }}>{renderSelectField('shikakunaiyo1', '264px', shikakunaiyo, !isHensyuuKengen)}</Box>
            </Box>
          </Box>
          {/* 監督技術者·補佐名 */}
          <Box
            sx={{
              display: 'grid',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>*監督技術者·補佐名</Box>
              <Box sx={{ display: 'flex' }}>
                {renderSelectField('kantokuGijutsuShaHosaMei', '255px', genbaBairininMeiList, !isHensyuuKengen)}
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'center', ml: 17, minWidth: 70, lineHeight: '40px' }}>*資格内容</Box>
              <Box sx={{ display: 'flex', ml: 2 }}>{renderSelectField('shikakunaiyo2', '264px', shikakunaiyo, !isHensyuuKengen)}</Box>
            </Box>
          </Box>
          {/* 安全衛生責任者名 */}
          <Box
            sx={{
              display: 'grid',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>安全衛生責任者名</Box>
              <Box sx={{ display: 'flex' }}>
                {renderSelectField('anzenEiseiSekininshamei', '255px', genbaBairininMeiList, !isHensyuuKengen)}
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'center', marginLeft: '93px', minWidth: 70, lineHeight: '40px' }}>
                安全衛生推進者名
              </Box>
              <Box sx={{ display: 'flex', ml: 2 }}>
                {renderSelectField('anzenEiseiSuishinShaMei', '200px', genbaBairininMeiList, !isHensyuuKengen)}
              </Box>
            </Box>
          </Box>
          {/* 雇用管理責任者名 */}
          <Box
            sx={{
              display: 'grid',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 160, lineHeight: '40px' }}>雇用管理責任者名</Box>
              <Box sx={{ display: 'flex' }}>
                {renderSelectField('koyoKanriSekininshamei', '255px', genbaBairininMeiList, !isHensyuuKengen)}
              </Box>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', mt: 2, mb: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', minWidth: 100 }}></Box>
            <Box sx={{ width: '745px' }}>
              <SenninGijutsuShaList rowData={rowData2} />
            </Box>
          </Box>
          {/* 一号特定技能外国人の従事の状況, 外国人建設就労者の従事の状況 */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '2fr 2fr 1fr',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <div className="meisaiHyoji-label">
                <Controller
                  name="ichigoTokuteiGinoGaikokuhitoNoJujiNoJokyo"
                  control={control}
                  render={({ field, fieldState }) => (
                    <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                      <Box sx={{ mr: 1, minWidth: 230, lineHeight: '40px', textAlign: 'center' }}>*一号特定技能外国人の従事の状況</Box>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }}>
                        <FormControlLabel value={1} control={<Radio />} label="有" />
                        <FormControlLabel value={0} control={<Radio />} label="無" />
                      </RadioGroup>
                    </Box>
                  )}
                />
              </div>
            </Box>
            <Box sx={{ display: 'flex' }}>
              <div className="meisaiHyoji-label">
                <Controller
                  name="gaikokuHitoKensetsuShuroshaNoJujiNoJokyo"
                  control={control}
                  render={({ field, fieldState }) => (
                    <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                      <Box sx={{ mr: 1, minWidth: 230, lineHeight: '40px', textAlign: 'center' }}>*外国人建設就労者の従事の状況</Box>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }}>
                        <FormControlLabel value={1} control={<Radio />} label="有" />
                        <FormControlLabel value={0} control={<Radio />} label="無" />
                      </RadioGroup>
                    </Box>
                  )}
                />
              </div>
            </Box>
            <span />
          </Box>
          {/* 外国人技能実習生の従事の状況 */}
          <Box
            sx={{
              display: 'grid',
              columnGap: 6,
              mb: 2,
            }}
          >
            <Box sx={{ display: 'flex' }}>
              <div className="meisaiHyoji-label">
                <Controller
                  name="gaikokuHitoGinoJisshuSeiNoJujiNoJokyo"
                  control={control}
                  render={({ field, fieldState }) => (
                    <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                      <Box sx={{ mr: 1, minWidth: 230, lineHeight: '40px', textAlign: 'center' }}>*外国人技能実習生の従事の状況</Box>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }}>
                        <FormControlLabel value={1} control={<Radio />} label="有" />
                        <FormControlLabel value={0} control={<Radio />} label="無" />
                      </RadioGroup>
                    </Box>
                  )}
                />
              </div>
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebQ0050CreateForm;
