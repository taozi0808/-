import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { STORAGE_KEY_DEKIDAKA, DBManager, DekidakaSimulationDataList } from 'app/shared/util/construction-list';
import { Column } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import WebI0010SearchDialog from './SearchDialog/WebI0010SearchDialog';
import './WebI0010ListPage.scss';

const WebI0010 = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  // 列の定義
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 50,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      width: 130,
      sortable: true,
      filterable: true,
      formatter: (row, cell, value, columnDef, dataContext) => {
        const isRed = dataContext.isZure ? 'red-background' : '';
        return `<div class="${isRed}">${value}</div>`;
      },
    },
    { id: 'genbaName', name: '現場名', field: 'genbaName', width: 350, sortable: true, filterable: true },
    {
      id: 'genbaChakkouDate',
      name: '現場着工日',
      field: 'genbaChakkouDate',
      width: 165,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
    },
    {
      id: 'genbaKankouDate',
      name: '現場完工日',
      field: 'genbaKankouDate',
      width: 165,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集権限
    hensyuuKengen: true,
    // 参照権限
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // 仮データ作成
    let contractList = DBManager.getDekidakaList();
    if (contractList.length === 0) {
      contractList = DekidakaSimulationDataList(500);
      localStorage.setItem(STORAGE_KEY_DEKIDAKA, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    handleSearch('');
    setPageTitle('出来高シミュレーション一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webI0010-container">
        <div className="top-operation">
          <div>
            <WebI0010SearchDialog onSearch={handleSearch} />
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={() => {
                  // navigate(`/webI0030/preview/${selectedId}`);
                }}
              >
                全現場一覧出力
              </Button>
            )}

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  // navigate(`/webI0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
          </div>
        </div>

        {/* デーブルエリア */}
        <label style={{ color: 'red' }}>
          *現場コードが赤色の現場は、出来高シミュレーションにずれがあります。修正して保存してください。
        </label>
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                // navigate(`/webI0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                // navigate(`/webI0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebI0010;
