import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './index.scss';
import dayjs from 'dayjs';
import PageTitle from 'app/components/PageTitle';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { STORAGE_KEY, DBManager, generateRandomData } from 'app/shared/util/construction-list';
import AdvancedSearchDialog from './AdvancedSearchDialog';
import axios from 'axios';
import { Column } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const ContractList = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const columnRef = useRef<Array<Column>>([
    { id: 'ankenCode', name: '案件コード', field: 'ankenCode', minWidth: 130 },
    { id: 'ankenName', name: '案件名', field: 'ankenName', minWidth: 220 },
    { id: 'kokyakuName', name: '顧客名', field: 'kokyakuName', minWidth: 130 },
    {
      id: 'genbaJyuusyo1',
      name: '現場住所',
      field: 'genbaJyuusyo1',
      minWidth: 320,
    },
    {
      id: 'souteiKingaku',
      name: '想定金額',
      field: 'souteiKingaku',
      cssClass: 'align-right',
      minWidth: 130,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
    },
    {
      id: 'jyucyuuMikomiYMD',
      name: '受注見込日',
      field: 'jyucyuuMikomiYMD',
      minWidth: 130,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'cyakkouKibouYMD',
      name: '着工希望日',
      field: 'cyakkouKibouYMD',
      minWidth: 130,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    { id: 'eigyouBumonName', name: '営業部門', field: 'eigyouBumonName', minWidth: 110 },
    {
      id: 'eigyouTantousyaShiMei',
      name: '営業担当者',
      field: 'eigyouTantousyaShiMei',
      minWidth: 150,
    },
    {
      id: 'shincyokudo',
      name: '進捗度',
      field: 'shincyokudo',
      minWidth: 160,
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // TODO: 后续接口对接后，两个权限的默认值都要改为false
    hensyuuKengen: true,
    sansyouKengen: false,
  });

  const handleSearch = values => {
    // TODO: 后续下面前三个字段要做替换
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // TODO: 有了接口文档后放开下面的代码
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 临时mock数据
    let contractList = DBManager.getList();
    if (contractList.length === 0) {
      contractList = generateRandomData(500);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('案件一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="contract-list" id="contract-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate('/contractEntry/add');
              }}
            >
              新規登録
            </Button>
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/contractEntry/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/contractEntry/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
          </div>
          <div>
            <AdvancedSearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        {/* 表格区域 */}
        <div onContextMenu={e => e.preventDefault()}>
          <BasicSlickGridTable
            columns={columnRef.current}
            data={rowData}
            onSelectionChanged={onSelectedRowsChanged}
            // contextMenuItems={() => {
            //   const items = [];
            //   if (permissionInfo.hensyuuKengen) {
            //     items.push({
            //       name: '編集',
            //       action: params => {
            //         navigate(`/contract/entry/edit/${params.node.data.id}`);
            //       },
            //     });
            //   }
            //   if (permissionInfo.sansyouKengen) {
            //     items.push({
            //       name: '参照',
            //       action: params => {
            //         navigate(`/contract/entry/preview/${params.node.data.id}`);
            //       },
            //     });
            //   }

            //   return items;
            // }}
          />
        </div>
      </div>
    </div>
  );
};

export default ContractList;
