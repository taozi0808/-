import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0040ListPage.scss';
import { STORAGE_KEY_SHONIN_JIKKOYOSAN, DBManager, shoninJikkoYosanDataList } from 'app/shared/util/construction-list';
import WebS0040SearchDialog from './SearchDialog/WebS0040SearchDialog';
import { Column, FieldType, Formatter } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import dayjs from 'dayjs';

const WebS0040ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';

  // 列の定義
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      type: FieldType.string,
      cssClass: 'center',
    },
    {
      id: 'bukkenCode',
      name: '物件コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 100,
      cssClass: 'left',
    },
    {
      id: 'bukkenName',
      name: '物件名称',
      field: 'bukkenName',
      minWidth: 160,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'ukeoiKingaku',
      name: '請負金額',
      field: 'ukeoiKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.string,
      cssClass: 'right',
    },
    {
      id: 'jikkoYosanKingaku',
      name: '実行予算金額',
      field: 'jikkoYosanKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'right',
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 85,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 135,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 50,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 60,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);

  const handleSearch = value => {
    // 仮データ作成
    let contractList = DBManager.getShoninJikkoYosanList();
    if (contractList.length === 0) {
      contractList = shoninJikkoYosanDataList(500);
      // 番号作成
      contractList = contractList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SHONIN_JIKKOYOSAN, JSON.stringify(contractList));
    }
    setRowData(contractList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    handleSearch('');
    setPageTitle('承認一覧（実行予算管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0040-container">
        {/* ボタンエリア */}
        <div className="top-operation">
          <div>
            <WebS0040SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                // navigate(`/webG0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0040ListPage;
