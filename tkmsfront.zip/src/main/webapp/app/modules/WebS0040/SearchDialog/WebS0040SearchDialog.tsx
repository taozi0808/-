import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, Checkbox, Button, Select, MenuItem, Box, FormControlLabel } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebS0040SearchDialog.scss';
import DialogHead from 'app/components/DialogHead';

const WebS0040SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  // ポップアップ開ける処理
  const handleClickOpen = () => setOpen(true);
  // ポップアップ閉じる処理
  const handleClose = () => {
    setOpen(false);
    // ポップアップが閉じる後、データをクリアする
    setTimeout(() => {
      reset();
    }, 0);
  };
  // フォーム」
  const { control, handleSubmit, reset } = useForm({
    defaultValues: {
      // 物件コードFROM
      bukkenCodeFrom: '',
      // 物件コードTO
      bukkenCodeTo: '',
      // 申請日FROM
      shinseiBiFrom: '',
      // 申請日TO
      shinseiBiTo: '',
      // 申請部門
      shinseiBumon: '',
      // 申請者
      shinseiSha: '',
      // 承認状況
      shoninStatus: {
        '1': true,
        '2': false,
        '3': false,
        '4': false,
      },
    },
  });

  // フォームを送信
  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }
    console.log(`SearchData:${data}`);
    onSearch(data);
    handleClose();
  };
  const bukkenCodeArr = [
    { id: 0, name: '', code: '1088813' }, // 未選択用
    { id: 1, name: '1088814', code: '1088814' },
    { id: 2, name: '1088815', code: '1088815' },
    { id: 3, name: '1088816', code: '1088816' },
  ];

  const shinseiBiArr = [
    { id: 0, name: '', code: '001' },
    { id: 1, name: '2025/02/02', code: '002' },
    { id: 2, name: '2025/02/03', code: '003' },
    { id: 3, name: '2025/02/03', code: '004' },
  ];

  const shinseiBumonArr = [
    { id: 0, name: '', code: '' },
    { id: 1, name: '管理部門', code: '001' },
    { id: 2, name: '技術部門', code: '002' },
    { id: 3, name: '事務部門', code: '003' },
  ];

  const shinseiShaArr = [
    { id: 0, name: '', code: 'CLIN-000' },
    { id: 1, name: '保手 優子', code: 'CLIN-MITSUI-F' },
    { id: 2, name: '佐藤 橋本', code: 'CLIN-SUMITOMO' },
    { id: 3, name: '湯村 花子', code: 'CLIN-TOKYU' },
  ];
  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleClickOpen}>
        検索
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)} className="webS0040-search-container">
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" size="small" style={{ minWidth: 96 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" size="small" style={{ minWidth: 96 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box pb={4} display="grid" gap={2}>
              <Box display="flex">
                <Controller
                  name="bukkenCodeFrom"
                  control={control}
                  render={({ field }) => (
                    <div className="item1">
                      <label>物件コード</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {bukkenCodeArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
                <Controller
                  name="bukkenCodeTo"
                  control={control}
                  render={({ field }) => (
                    <div className="item2">
                      <label>～</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {bukkenCodeArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box display="flex">
                <Controller
                  name="shinseiBiFrom"
                  control={control}
                  render={({ field }) => (
                    <div className="item1">
                      <label>申請日</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {shinseiBiArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
                <Controller
                  name="shinseiBiTo"
                  control={control}
                  render={({ field }) => (
                    <div className="item2">
                      <label>～</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {shinseiBiArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box display="flex">
                <Controller
                  name="shinseiBumon"
                  control={control}
                  render={({ field }) => (
                    <div className="item1">
                      <label>申請部門</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {shinseiBumonArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box display="flex">
                <Controller
                  name="shinseiSha"
                  control={control}
                  render={({ field }) => (
                    <div className="item1">
                      <label>申請者</label>
                      <Select
                        {...field}
                        label=""
                        fullWidth
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                          },
                          PopoverClasses: {
                            root: 'webS0040-search-container',
                          },
                        }}
                        size="small"
                      >
                        {shinseiShaArr.map(item => (
                          <MenuItem key={item.id} value={item.code}>
                            {item.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box display="flex">
                <div className="item1">
                  <label>承認状況</label>
                  <Controller
                    name="shoninStatus.1"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel control={<Checkbox color="default" {...field} checked={field.value} />} label="未承認" />
                    )}
                  />
                  <Controller
                    name="shoninStatus.2"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel control={<Checkbox color="default" {...field} checked={field.value} />} label="承認" />
                    )}
                  />
                  <Controller
                    name="shoninStatus.3"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel control={<Checkbox color="default" {...field} checked={field.value} />} label="否認" />
                    )}
                  />
                  <Controller
                    name="shoninStatus.4"
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel control={<Checkbox color="default" {...field} checked={field.value} />} label="差戻" />
                    )}
                  />
                </div>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebS0040SearchDialog;
