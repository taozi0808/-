import './WebR0045CreateForm.scss';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { AGGridTheme } from 'app/app';
import { DBManager, STORAGE_KEY_SHAIN } from 'app/shared/util/construction-list';
import { Box, Button, Stack, TextField, Select, MenuItem, InputAdornment, IconButton } from '@mui/material';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
const WebR0045CreateForm = () => {
  // 画面パラメータ
  const { id, type } = useParams();
  // パスワード
  const [showPassword, setShowPassword] = useState(false);
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [isCollapse, setIsCollapse] = useState(false);
  const [rowData, setRowData] = useState([]);
  const [isDisabeld, setIsDisabeld] = useState(false);
  // メッセージ
  const [message, setMessage] = useState('');
  // SELECT職種
  const [selectShokushu, handleShokushu] = useState({
    value: '',
    label: '',
  });
  // SELECT所属部
  const [selectShozokuBu, handleShozokuBu] = useState({
    value: '',
    label: '',
  });
  // SELECT所属課
  const [selectShozokuKa, handleShozokuKa] = useState({
    value: '',
    label: '',
  });
  // SELECT所属役職
  const [selectShozokuYakushosku, handleShozokuYakushosku] = useState({
    value: '',
    label: '',
  });
  // ラベルリスト
  const levelCollection = ['', 'A', 'B', 'C', 'D', 'E'];
  // 職種
  const shokushus = [
    { label: '総務', value: '001' },
    { label: '営業', value: '002' },
    { label: '技術', value: '003' },
    { label: '生産', value: '004' },
  ];
  // 所属部
  const shozokuBus = [
    { label: 'IT部', value: '001' },
    { label: 'マーケティング部', value: '002' },
    { label: 'デザイン部', value: '003' },
    { label: '営業部', value: '004' },
    { label: 'サポート部', value: '005' },
    { label: '人事部', value: '006' },
    { label: '財務部', value: '007' },
    { label: '物流部', value: '008' },
    { label: 'プロジェクト部', value: '009' },
    { label: '品質管理部', value: '010' },
  ];
  // 所属課
  const shozokuKas = [
    { label: '開発課', value: '001' },
    { label: '戦略課', value: '002' },
    { label: 'グラフィック課', value: '003' },
    { label: '営業課', value: '004' },
    { label: 'カスタマーサービス課', value: '005' },
    { label: '採用課', value: '006' },
    { label: '経理課', value: '007' },
    { label: '配送課', value: '008' },
    { label: '管理課', value: '009' },
    { label: 'テスト課', value: '010' },
  ];
  // 所属役職
  const shozokuYakushoskus = [
    { label: '一般社員', value: '001' },
    { label: '主任', value: '002' },
    { label: '係長', value: '003' },
    { label: '課長', value: '004' },
    { label: '次長', value: '005' },
    { label: '部長', value: '006' },
    { label: '本部長', value: '007' },
    { label: '常務取締役', value: '008' },
    { label: '専務取締役', value: '009' },
    { label: '代表取締役社長', value: '010' },
  ];
  const defaultColDef = useMemo(() => {
    return {
      editable: isDisabeld ? true : false,
    };
  }, [isDisabeld]);
  const shutokuShikakuColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '資格名',
      field: 'shikakuName',
      width: 250,
      cellDataType: 'text',
      headerClass: 'header-center',
      cellClass: 'center',
    },
    {
      headerName: '等級',
      field: 'level',
      width: 199,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: levelCollection,
      },
      headerClass: 'header-center',
      cellClass: 'center',
    },
    {
      headerName: '有効期限',
      field: 'yukokigen',
      width: 250,
      cellDataType: 'text',
      headerClass: 'header-center',
      cellClass: 'center',
    },
  ]);
  const onSave = values => {
    const updatedMockData = [...DBManager.getMockList(STORAGE_KEY_SHAIN)].map(item => {
      if (String(item.id) !== String(id)) return item;

      const safeShutokuShikakuList = values.shutokuShikaku.map(entry => ({ ...entry })).filter(entry => entry !== '');

      return {
        ...item,
        // 社員コード
        shainCode: values.shainCode,
        // 氏名
        shiMei: `${values.firstName} ${values.lastName}`,
        // 職種
        shokushu: { ...selectShokushu },
        // 所属部署 部
        shozokuBu: { ...selectShozokuBu },
        // 所属部署 課
        shozokuKa: { ...selectShozokuKa },
        // 所属部署 役職
        shozokuYakushoku: { ...selectShozokuYakushosku },
        // 生年月日
        birth: `${values.birthYear}-${values.birthMonth}-${values.birthDate}`,
        // 退職年月日
        taishoku: `${values.taishokuYear}-${values.taishokuMonth}-${values.taishokuDate}`,
        // 会社携帯番号
        kaishaKeitaiNo: `${values.kaishaKeitaiNo1}-${values.kaishaKeitaiNo2}-${values.kaishaKeitaiNo3}`,
        // メールアドレス
        emailAddress: values.emailAddress,
        // 適用開始日付
        tekiyoKaishiDate: values.tekiyoKaishiDate,
        // ログインID
        loginID: values.loginID,
        // パスワード
        password: values.password,
        // 郵便番号
        yuBinNo: `${values.yuBinNo1}-${values.yuBinNo2}`,
        // 住所1
        address1: values.address1,
        // 住所2
        address2: values.address2,
        // 個人携帯番号
        kojinkeitaiNo: `${values.kojinkeitaiNo1}-${values.kojinkeitaiNo2}-${values.kojinkeitaiNo3}`,
        // 自宅電話番号
        jitakudenwaNo: `${values.jitakudenwaNo1}-${values.jitakudenwaNo2}-${values.jitakudenwaNo3}`,
        // 住所
        address: values.address,
        // 電話番号
        denwaNo: `${values.denwaNo1}-${values.denwaNo2}-${values.denwaNo3}`,
        // 続柄
        zokugara: values.zokugara,
        // 取得資格
        shutokuShikakuList: safeShutokuShikakuList,
      };
    });
    localStorage.setItem(STORAGE_KEY_SHAIN, JSON.stringify(updatedMockData));
    navigate('/webR0040');
  };
  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {
      // 社員コード
      shainCode: '',
      // 氏名
      firstName: '',
      lastName: '',
      // 職種
      shokushu: '',
      // 生年
      birthYear: '',
      // 生月
      birthMonth: '',
      // 生日
      birthDate: '',
      // 入社年
      nyusahYear: '',
      // 入社月
      nyusahMonth: '',
      // 入社日
      nyusahDate: '',
      // 退職年
      taishokuYear: '',
      // 退職月
      taishokuMonth: '',
      // 退職日
      taishokuDate: '',
      // 会社携帯番号1
      kaishaKeitaiNo1: '',
      // 会社携帯番号2
      kaishaKeitaiNo2: '',
      // 会社携帯番号3
      kaishaKeitaiNo3: '',
      // メールアドレス
      emailAddress: '',
      // 所属部署 部1
      shozokuBu1: '',
      // 所属部署 部2
      shozokuBu2: '',
      // 所属部署 部3
      shozokuBu3: '',
      // 所属部署 課1
      shozokuKa1: '',
      // 所属部署 課2
      shozokuKa2: '',
      // 所属部署 課3
      shozokuKa3: '',
      // 所属部署 役職
      shozokuYakushoku: '',
      // 適用開始日付
      tekiyoKaishiDate: '',
      // 部署移動設定 部1
      bushoBu1: '',
      // 部署移動設定 部2
      bushoBu2: '',
      // 部署移動設定 部3
      bushoBu3: '',
      // 部署移動設定 課1
      bushoKa1: '',
      // 部署移動設定 課2
      bushoKa2: '',
      // 部署移動設定 課3
      bushoKa3: '',
      // 部署移動設定 役職
      bushoYakushoku: '',
      // ログインID
      loginID: '',
      // パスワード
      password: '',
      // 顔確認写真1
      part1: '',
      // 顔確認写真2
      part2: '',
      // 顔確認写真3
      part3: '',
      // 郵便番号1
      yuBinNo1: '',
      // 郵便番号2
      yuBinNo2: '',
      // 住所1
      address1: '',
      // 住所2
      address2: '',
      // 個人携帯番号1
      kojinkeitaiNo1: '',
      // 個人携帯番号2
      kojinkeitaiNo2: '',
      // 個人携帯番号3
      kojinkeitaiNo3: '',
      // 自宅電話番号1
      jitakudenwaNo1: '',
      // 自宅電話番号2
      jitakudenwaNo2: '',
      // 自宅電話番号3
      jitakudenwaNo3: '',
      // 氏名
      shiMei: '',
      // 続柄
      zokugara: '',
      // 住所
      address: '',
      // 電話番号1
      denwaNo1: '',
      // 電話番号2
      denwaNo2: '',
      // 電話番号3
      denwaNo3: '',
      // 取得資格
      shutokuShikaku: [],
    },
    mode: 'onBlur',
  });

  const tenpuSearch = () => {};
  // テーブルデータ変更処理
  const handleGridChange = useCallback(
    params => {
      const newData = rowData.map(row => (row.id === params.data.id ? params.data : row));
      setRowData(newData);
    },
    [rowData],
  );
  // テーブルデータをフォームに同期する
  useEffect(() => {
    setValue('shutokuShikaku', rowData);
  }, [rowData, setValue]);
  useEffect(() => {
    const empData = [];
    for (let i = 0; i < 5; i++) {
      empData.push({
        id: i + 1,
        shikakuName: '',
        level: '',
        yukokigen: '',
      });
    }
    setRowData(empData);
    const mockData = DBManager.getMockList(STORAGE_KEY_SHAIN);
    const data = mockData.find(item => item.id.toString() === id);
    if (data && type !== 'add') {
      // 社員コード
      setValue('shainCode', data.shainCode);
      // 氏名 氏
      setValue('firstName', data.shiMei.split(' ')[0]);
      // 氏名 名
      setValue('lastName', data.shiMei.split(' ')[1]);
      // 職種
      setValue('shokushu', data.shokushu.value);
      handleShokushu({ ...data.shokushu });
      // 生年
      setValue('birthYear', data.birth.split('-')[0]);
      // 生月
      setValue('birthMonth', data.birth.split('-')[1]);
      // 生日
      setValue('birthDate', data.birth.split('-')[2]?.substring(0, 2));
      // 入社年
      setValue('nyusahYear', data.nyusah.split('-')[0]);
      // 入社月
      setValue('nyusahMonth', data.nyusah.split('-')[1]);
      // 入社日
      setValue('nyusahDate', data.nyusah.split('-')[2]?.substring(0, 2));
      // 退職年
      setValue('taishokuYear', data.taishoku?.split('-')[0]);
      // 退職月
      setValue('taishokuMonth', data.taishoku?.split('-')[1]);
      // 退職日
      setValue('taishokuDate', data.taishoku?.split('-')[2]?.substring(0, 2));
      // 会社携帯番号1
      setValue('kaishaKeitaiNo1', data.kaishaKeitaiNo.split('-')[0]);
      // 会社携帯番号2
      setValue('kaishaKeitaiNo2', data.kaishaKeitaiNo.split('-')[1]);
      // 会社携帯番号3
      setValue('kaishaKeitaiNo3', data.kaishaKeitaiNo.split('-')[2]);
      // メールアドレス
      setValue('emailAddress', data.emailAddress);
      // 所属部署 部1
      setValue('shozokuBu1', data.shozokuBu.value);
      handleShozokuBu({ ...data.shozokuBu });
      // 所属部署 部2
      setValue('shozokuBu2', data.shozokuBu2);
      // 所属部署 部3
      setValue('shozokuBu3', data.shozokuBu3);
      // 所属部署 課1
      setValue('shozokuKa1', data.shozokuKa.value);
      handleShozokuKa({ ...data.shozokuKa });
      // 所属部署 課2
      setValue('shozokuKa2', data.shozokuKa2);
      // 所属部署 課3
      setValue('shozokuKa3', data.shozokuKa3);
      // 所属部署 役職
      setValue('shozokuYakushoku', data.shozokuYakushoku.value);
      handleShozokuYakushosku({ ...data.shozokuYakushoku });
      // 適用開始日付
      setValue('tekiyoKaishiDate', data.tekiyoKaishiDate);
      // 部署移動設定 部1
      setValue('bushoBu1', data.bushoBu1);
      // 部署移動設定 部2
      setValue('bushoBu2', data.bushoBu2);
      // 部署移動設定 部3
      setValue('bushoBu3', data.bushoBu3);
      // 部署移動設定 課1
      setValue('bushoKa1', data.bushoKa1);
      // 部署移動設定 課2
      setValue('bushoKa2', data.bushoKa2);
      // 部署移動設定 課3
      setValue('bushoKa3', data.bushoKa3);
      // 部署移動設定 役職
      setValue('bushoYakushoku', data.bushoYakushoku);
      // ログインID
      setValue('loginID', data.loginID);
      // パスワード
      setValue('password', data.password);
      // 顔確認写真1
      setValue('part1', data.part1);
      // 顔確認写真2
      setValue('part2', data.part2);
      // 顔確認写真3
      setValue('part3', data.part3);
      // 郵便番号1
      setValue('yuBinNo1', data.yuBinNo.split('-')[0]);
      // 郵便番号2
      setValue('yuBinNo2', data.yuBinNo.split('-')[1]);
      // 住所1
      setValue('address1', data.address1);
      // 住所2
      setValue('address2', data.address2);
      // 個人携帯番号1
      setValue('kojinkeitaiNo1', data.kojinkeitaiNo.split('-')[0]);
      // 個人携帯番号2
      setValue('kojinkeitaiNo2', data.kojinkeitaiNo.split('-')[1]);
      // 個人携帯番号3
      setValue('kojinkeitaiNo3', data.kojinkeitaiNo.split('-')[2]);
      // 自宅電話番号1
      setValue('jitakudenwaNo1', data.jitakudenwaNo.split('-')[0]);
      // 自宅電話番号2
      setValue('jitakudenwaNo2', data.jitakudenwaNo.split('-')[1]);
      // 自宅電話番号3
      setValue('jitakudenwaNo3', data.jitakudenwaNo.split('-')[2]);
      // 氏名
      setValue('shiMei', data.shiMei);
      // 続柄
      setValue('zokugara', data.zokugara);
      // 住所
      setValue('address', data.address);
      // 電話番号1
      setValue('denwaNo1', data.jitakudenwaNo.split('-')[0]);
      // 電話番号2
      setValue('denwaNo2', data.jitakudenwaNo.split('-')[1]);
      // 電話番号3
      setValue('denwaNo3', data.jitakudenwaNo.split('-')[2]);
      // 取得資格
      if (data.shutokuShikakuList.length < 5) {
        const rowList = data.shutokuShikakuList;
        rowList.push(...empData.splice(data.shutokuShikakuList.length));
        setRowData(rowList);
      } else {
        setRowData(data.shutokuShikakuList);
      }
    }
    // この画面は編集画面の場合、編集できること
    if (type === 'preview') {
      setIsDisabeld(false);
    } else {
      setIsDisabeld(true);
    }
    setPageTitle('社員登録');
    return () => setPageTitle('');
  }, [isDisabeld]);
  return (
    <div className="webR0045-container">
      <div className="top">
        <div className="top-item">
          <LastUpdateInfo userId={''} />
          <LastUpdateInfo userId={''} title="【承認者】" />
        </div>
        <div className="top-item">
          <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
          <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
        </div>
      </div>
      <Box mt={2} component="form" onSubmit={handleSubmit(onSave)}>
        <Box>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 2,
            }}
          >
            <Stack direction="row" spacing={2}>
              <Button variant="contained" size="small" disabled={!isDisabeld} style={{ marginLeft: '24px', minWidth: 96 }} type="submit">
                保存
              </Button>
              <Button
                variant="contained"
                size="small"
                disabled={!isDisabeld}
                style={{ minWidth: 96 }}
                onClick={() => {
                  // TODO
                  const updatedMockData = [...DBManager.getMockList(STORAGE_KEY_SHAIN)]
                    .filter(item => String(item.id) !== String(id))
                    .map((item, index) => ({ ...item, no: index + 1 }));
                  localStorage.setItem(STORAGE_KEY_SHAIN, JSON.stringify(updatedMockData));
                  navigate('/webR0040');
                }}
              >
                削除
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ minWidth: 96 }}
                onClick={() => {
                  navigate('/webR0040');
                }}
              >
                キャンセル
              </Button>
            </Stack>
            <Button
              variant="contained"
              size="small"
              disabled={!isDisabeld}
              style={{ marginRight: '50px', minWidth: 96 }}
              onClick={() => {
                // TODO
              }}
            >
              印刷
            </Button>
          </Box>
        </Box>
        <Box display="grid" rowGap={2} ml={2}>
          <div className="messageDiv">{message}</div>
          <Box display="flex">
            <Box>
              <Controller
                name="shainCode"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*社員コード</label>
                    <TextField disabled={!isDisabeld} {...field} style={{ width: 120 }} size="small" />
                  </div>
                )}
              />
            </Box>
            <Box display="flex">
              <Box>
                <Controller
                  name="firstName"
                  control={control}
                  render={({ field, fieldState }) => (
                    <div className="item2">
                      <label>*氏名</label>
                      <TextField {...field} disabled={!isDisabeld} style={{ width: 100 }} size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box ml={2}>
                <Controller
                  name="lastName"
                  control={control}
                  render={({ field, fieldState }) => (
                    <div className="item2">
                      <TextField {...field} disabled={!isDisabeld} style={{ width: 100 }} size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box>
              <Controller
                name="shokushu"
                control={control}
                render={({ field }) => (
                  <div className="item7">
                    <label>職種</label>
                    <Select
                      {...field}
                      size="small"
                      disabled={!isDisabeld}
                      MenuProps={{
                        PaperProps: {
                          width: '100%',
                          style: {
                            maxHeight: 200,
                            overflow: 'auto',
                          },
                        },
                        PopoverClasses: {
                          root: 'webR0045-juguoin-syaxin',
                        },
                      }}
                      style={{ width: '100%' }}
                    >
                      <MenuItem key={''} value={''}></MenuItem>
                      {shokushus.map(item => (
                        <MenuItem
                          key={item.value}
                          value={item.value}
                          onClick={() => {
                            handleShokushu({
                              value: item.value,
                              label: item.label,
                            });
                          }}
                        >
                          {item.label}
                        </MenuItem>
                      ))}
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="birthYear"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*生年月日</label>
                    <span className="item-span">西暦</span>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 70 }} size="small" />
                    <span className="item-span">年</span>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="birthMonth"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>月</label>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="birthDate"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>日</label>
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="nyusahYear"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*入社年月日</label>
                    <span className="item-span">西暦</span>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 70 }} size="small" />
                    <span className="item-span">年</span>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="nyusahMonth"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>月</label>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="nyusahDate"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>日</label>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="taishokuYear"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*退職年月日</label>
                    <span className="item-span">西暦</span>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 70 }} size="small" />
                    <span className="item-span">年</span>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="taishokuMonth"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>月</label>
                  </div>
                )}
              />
            </Box>
            <Box>
              <Controller
                name="taishokuDate"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item4">
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 50 }} size="small" />
                    <label>日</label>
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <div className="item1">
              <label>取得資格</label>
            </div>
            <Box style={{ width: '700px', height: '260px' }}>
              <AgGridReact
                rowData={rowData}
                theme={AGGridTheme}
                columnDefs={shutokuShikakuColumns.current}
                defaultColDef={defaultColDef}
                enableCellSpan
                onCellValueChanged={handleGridChange}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="kaishaKeitaiNo1"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>会社携帯番号</label>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 65 }} size="small" />
                  </div>
                )}
              />
            </Box>
            <Box className="personInfo">
              <Controller
                name="kaishaKeitaiNo2"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item5">
                    <label>-</label>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                  </div>
                )}
              />
            </Box>
            <Box className="personInfo">
              <Controller
                name="kaishaKeitaiNo3"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item5">
                    <label>-</label>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="emailAddress"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*メールアドレス</label>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 300 }} size="small" />
                    <Button disabled={!isDisabeld} variant="contained" size="small" style={{ marginLeft: '24px', minWidth: 96 }}>
                      バスワード通知
                    </Button>
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Controller
              name="shozokuYakushoku"
              control={control}
              render={({ field }) => (
                <div style={{ width: '100%' }}>
                  <label className="labelItem">＊所属部署</label>
                  <label style={{ width: 50, lineHeight: '40px' }}>役職</label>
                  <Select
                    {...field}
                    disabled={!isDisabeld}
                    size="small"
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 200,
                          overflow: 'auto',
                        },
                      },
                      PopoverClasses: {
                        root: 'webR0045-juguoin-syaxin',
                      },
                    }}
                    style={{ width: '200px' }}
                  >
                    <MenuItem key={''} value={''}></MenuItem>
                    {shozokuYakushoskus.map(item => (
                      <MenuItem
                        key={item.value}
                        value={item.value}
                        onClick={() => {
                          handleShozokuYakushosku({
                            value: item.value,
                            label: item.label,
                          });
                        }}
                      >
                        {item.label}
                      </MenuItem>
                    ))}
                  </Select>
                </div>
              )}
            />
          </Box>
          <Box display="flex">
            <Box mb={14.5}>
              <div className="item1">
                <label></label>
              </div>
            </Box>
            <Box mr={2.5}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                }}
              >
                <div className="titleBox">部</div>
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuBu1"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        disabled={!isDisabeld}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              handleShozokuBu({
                                value: item.value,
                                label: item.label,
                              });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuBu2"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        disabled={!isDisabeld}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuBu({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuBu3"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        disabled={!isDisabeld}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuBu({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box mr={2.5}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                }}
              >
                <div className="titleBox">課</div>
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuKa1"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        disabled={!isDisabeld}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              handleShozokuKa({
                                value: item.value,
                                label: item.label,
                              });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuKa2"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        disabled={!isDisabeld}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuKa({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="shozokuKa3"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        disabled={!isDisabeld}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuKa({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="tekiyoKaishiDate"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>部署移動設定</label>
                    <span style={{ width: 100, lineHeight: '40px' }}>適用開始日付</span>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 160 }} size="small" />
                  </div>
                )}
              />
            </Box>
            <Box ml={2}>
              <Controller
                name="bushoYakushoku"
                control={control}
                render={({ field }) => (
                  <div style={{ width: '100%' }}>
                    <label style={{ width: 50, lineHeight: '40px' }}>役職</label>
                    <Select
                      {...field}
                      disabled={!isDisabeld}
                      size="small"
                      MenuProps={{
                        PaperProps: {
                          style: {
                            maxHeight: 200,
                            overflow: 'auto',
                          },
                        },
                        PopoverClasses: {
                          root: 'webR0045-juguoin-syaxin',
                        },
                      }}
                      style={{ width: '200px' }}
                    >
                      <MenuItem key={''} value={''}></MenuItem>
                      {shozokuKas.map(item => (
                        <MenuItem
                          key={item.value}
                          value={item.value}
                          onClick={() => {
                            handleShozokuKa({
                              value: item.value,
                              label: item.label,
                            });
                          }}
                        >
                          {item.label}
                        </MenuItem>
                      ))}
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box mb={14.5}>
              <div className="item1">
                <label></label>
              </div>
            </Box>
            <Box mr={2.5}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                }}
              >
                <div className="titleBox">部</div>
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoBu1"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        disabled={!isDisabeld}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuBu({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoBu2"
                  control={control}
                  disabled={!isDisabeld}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuBu({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoBu3"
                  control={control}
                  disabled={!isDisabeld}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem key={''} value={''}></MenuItem>
                        {shozokuBus.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuBu({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box mr={2.5}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                }}
              >
                <div className="titleBox">課</div>
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoKa1"
                  control={control}
                  disabled={!isDisabeld}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuKa({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoKa2"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        size="small"
                        disabled={!isDisabeld}
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuKa({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box mt={2}>
                <Controller
                  name="bushoKa3"
                  control={control}
                  render={({ field }) => (
                    <div className="item3">
                      <Select
                        {...field}
                        disabled={!isDisabeld}
                        size="small"
                        MenuProps={{
                          PaperProps: {
                            width: '100%',
                            style: {
                              maxHeight: 200,
                              overflow: 'auto',
                            },
                          },
                          PopoverClasses: {
                            root: 'webR0045-juguoin-syaxin',
                          },
                        }}
                        style={{ width: '100%' }}
                      >
                        <MenuItem value="000"></MenuItem>
                        {shozokuKas.map(item => (
                          <MenuItem
                            key={item.value}
                            value={item.value}
                            onClick={() => {
                              // handleShozokuKa({
                              //   value: item.value,
                              //   label: item.label,
                              // });
                            }}
                          >
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="loginID"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*ログインID</label>
                    <TextField {...field} disabled={!isDisabeld} style={{ width: 220 }} size="small" />
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <Controller
                name="password"
                control={control}
                render={({ field, fieldState }) => (
                  <div className="item1">
                    <label>*パスワード</label>
                    <TextField
                      required
                      {...field}
                      disabled={!isDisabeld}
                      style={{ width: 220 }}
                      size="small"
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                              {showPassword ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </div>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <div className="item1">
              <label>*顔確認写真</label>
            </div>
            <Box mr={2.5} style={{ width: 222 }}>
              <Controller
                name="part1"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        className="webR0045-juguoin-syaxin"
                        size="small"
                        disabled={!isDisabeld}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        disabled={!isDisabeld}
                        style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                        onClick={tenpuSearch}
                      >
                        添付
                      </Button>
                    </Box>
                  </Box>
                )}
              />
            </Box>
            <Box mr={2.5} style={{ width: 222 }}>
              <Controller
                name="part2"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        className="webR0045-juguoin-syaxin"
                        size="small"
                        disabled={!isDisabeld}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        disabled={!isDisabeld}
                        style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                        onClick={tenpuSearch}
                      >
                        添付
                      </Button>
                    </Box>
                  </Box>
                )}
              />
            </Box>
            <Box style={{ width: 222 }}>
              <Controller
                name="part3"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        disabled={!isDisabeld}
                        className="webR0045-juguoin-syaxin"
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        disabled={!isDisabeld}
                        style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                        onClick={tenpuSearch}
                      >
                        添付
                      </Button>
                    </Box>
                  </Box>
                )}
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box>
              <div
                className="item6"
                onClick={() => {
                  setIsCollapse(!isCollapse);
                }}
              >
                {isCollapse ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
                <span>個人情報</span>
              </div>
            </Box>
            {/* </Box> */}
            <Box>
              <Box style={{ border: '2px solid black', width: '700px', height: '570px' }} pl={2} className={isCollapse ? 'hidden' : ''}>
                <Box pt={2}>
                  <div className="titleBox">本人情報</div>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="yuBinNo1"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>郵便番号</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="yuBinNo2"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                          <Button disabled={!isDisabeld} variant="contained" size="small" style={{ left: '10px', minWidth: 96 }}>
                            検索
                          </Button>
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="address1"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>住所1</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 400 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="address2"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>住所2</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 400 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="kojinkeitaiNo1"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>個人携帯番号</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 65 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="kojinkeitaiNo2"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="kojinkeitaiNo3"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="jitakudenwaNo1"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>自宅電話番号</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 65 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="jitakudenwaNo2"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="jitakudenwaNo3"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box pt={2}>
                  <div className="titleBox">緊急連絡先</div>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="shiMei"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>氏名</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 140 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="zokugara"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item8">
                          <label>続柄</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 140 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="address"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>住所</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 400 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" mt={2}>
                  <Box>
                    <Controller
                      name="denwaNo1"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item1">
                          <label>電話番号</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 65 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="denwaNo2"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="denwaNo3"
                      control={control}
                      render={({ field, fieldState }) => (
                        <div className="item5">
                          <label>-</label>
                          <TextField {...field} disabled={!isDisabeld} style={{ width: 90 }} size="small" />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </div>
  );
};

export default WebR0045CreateForm;
