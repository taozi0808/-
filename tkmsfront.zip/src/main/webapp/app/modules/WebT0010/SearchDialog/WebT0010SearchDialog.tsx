import React, { useEffect, useState } from 'react';
import { Dialog, DialogActions, DialogContent, TextField, Button, Checkbox, FormControlLabel, Box, Typography } from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import './WebT0010SearchDialog.scss';
import '../../../app.scss';
import DialogHead from 'app/components/DialogHead';

const WebT0010SearchDialog = ({ onSearch }) => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const { control, handleSubmit } = useForm({
    defaultValues: {
      // 現場コード
      genbaCode: '',
      // 現場名
      genbaName: '',
      // 該当着手日start
      genbaChakushuNichiStart: '',
      // 該当着手日end
      genbaChakushuNichiEnd: '',
      // 該当引渡日start
      genbaBikiWataruNichiStart: '',
      // 該当引渡日end
      genbaBikiWataruNichiEnd: '',
      // 専任技術者
      senninGijutsuMono: '',
      // 書類提出状況
      shoruiTeishutsuJoukyou: true,
    },
  });

  const onSubmit = data => {
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" onClick={handleOpen} style={{ marginRight: '8px', minWidth: 96 }}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '350px',
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained">
                検索
              </Button>
              <Button onClick={handleClose} variant="contained">
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" className="webT0010-searchcontainer">
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between" style={{ width: '40%' }}>
                <Box flex={1} mr={2}>
                  <Controller
                    name="genbaCode"
                    control={control}
                    render={({ field }) => (
                      <div className="webT0010-searchitem">
                        <label>現場コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} mr={2}>
                  <Controller
                    name="genbaName"
                    control={control}
                    render={({ field }) => (
                      <div className="webT0010-searchitem">
                        <label>現場名(ｶﾅ含む)</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box display="flex" flexDirection="column" gap={2} justifyContent="space-between">
                <Box flex={1} mr={6}>
                  <div className="webT0010-searchitem">
                    <label>現場着手日</label>
                    <Controller
                      name="genbaChakushuNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="genbaChakushuNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
                <Box flex={1} mr={6}>
                  <div className="webT0010-searchitem">
                    <label>現場引渡日</label>
                    <Controller
                      name="genbaBikiWataruNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="genbaBikiWataruNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebT0010SearchDialog;
