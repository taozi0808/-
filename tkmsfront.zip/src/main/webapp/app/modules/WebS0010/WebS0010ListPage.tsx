import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Column, FieldType, Formatter } from 'slickgrid-react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import dayjs from 'dayjs';
import { STORAGE_KEY_GAISAN, DBManager, gaisanDataList } from 'app/shared/util/construction-list';
import WebS0010SearchDialog from './SearchDialog/WebS0010SearchDialog';
import './WebS0010ListPage.scss';

const WebS0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集権限
    hensyuuKengen: true,
    // 参照権限
    sansyouKengen: true,
  });

  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';

  const handleSearch = () => {
    console.log('handle search');
  };

  // 列の定義
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      type: FieldType.string,
      cssClass: 'text-align-center',
    },
    {
      id: 'ankenCode',
      name: '案件コード',
      field: 'ankenCode',
      minWidth: 135,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanCode',
      name: '概算コード',
      field: 'gaisanCode',
      minWidth: 110,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'ankenName',
      name: '案件名',
      field: 'ankenName',
      minWidth: 110,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'mitsumoriTeishutsuKigen',
      name: '見積提出期限',
      field: 'mitsumoriTeishutsuKigen',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'gaisanKingaku',
      name: '概算金額',
      field: 'gaisanKingaku',
      minWidth: 120,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
      type: FieldType.number,
      cssClass: 'text-align-right',
    },
    {
      id: 'chakkoKiboJiki',
      name: '着工希望時期',
      field: 'chakkoKiboJiki',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'kankoKiboJiki',
      name: '完工希望時期',
      field: 'kankoKiboJiki',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'gaisanBumon',
      name: '概算部門',
      field: 'gaisanBumon',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanTantousya',
      name: '概算担当者',
      field: 'gaisanTantousya',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'sinseisya',
      name: '申請者',
      field: 'sinseisya',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'sinseiDate',
      name: '申請日',
      field: 'sinseiDate',
      minWidth: 140,
      sortable: true,
      filterable: true,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
      cssClass: 'text-align-right',
    },
    {
      id: 'kekka',
      name: '結果',
      field: 'kekka',
      minWidth: 100,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      formatter: LinkFormatter,
      cssClass: ' text-align-center',
    },
  ]);

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    // 仮データ作成
    let contractList = DBManager.getGaisanList();
    if (contractList.length === 0) {
      contractList = gaisanDataList(500);
      // 番号作成
      contractList = contractList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_GAISAN, JSON.stringify(contractList));
    }
    setRowData(contractList);

    setPageTitle('承認一覧（概算一覧）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0010-container">
        {/* ボタンエリア */}
        <div className="top-operation">
          <WebS0010SearchDialog onSearch={handleSearch} />
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                // navigate(`/webG0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0010ListPage;
