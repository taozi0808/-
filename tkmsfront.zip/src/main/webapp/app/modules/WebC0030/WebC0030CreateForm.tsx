import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import './WebC0030CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { jaJP } from '@mui/x-date-pickers/locales';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { Box, TextField, Select, MenuItem, Button, Collapse } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import dayjs from 'dayjs';
import { STORAGE_KEY_GAISAN, DBManager } from 'app/shared/util/construction-list';

const WebC0030CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [dataSource, setDataSource] = useState([]);
  const [dataSource2, setDataSource2] = useState([]);
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');
  // 案件情報
  const [isCollapse, setIsCollapse] = useState(false);

  const seikyuuJoukenNameParams = ['信用状支払い', '延期付款', '(other)'];
  const shouhizeiRitsuParams = [30, 50, 80];
  const taniParams = ['式', '式1', '式2', '式3', '(other)'];
  const daikushuParams = ['鉄筋工', '配管工', '電気工', '(other)'];
  const shoukoushuParams = ['鉄筋工', '配管工', '電気工', '(other)'];
  let gaisanTotal = 0;

  const {
    control,
    // handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    defaultValues: {
      ankenCode: '',
      ankenName: '',
      gaisanCodePart1: '',
      gaisanCodePart2: '',
      ankenKanaName: '',
      gaisanBumon: '',
      gaisanHizuke: '',
      gaisanTantouMono: '',
      listJyucyuuJyoutai: '',
      tenpuFile: '',
      elia: '',
      sekisanKingaku: true,
      gaisanGoukeiKingaku: '',
      yuubinBangouPart1: '',
      yuubinBangouPart2: '',
      bukkenJuusho: '愛知県名古屋市中村区名駅南1-1-1',
      yuubinBangouPart3: '060606',
      yuubinBangouPart4: '070707',
      kokyakuJuusho: '北海道札幌市中央区北1条西1-1-1',
      kanminKubun: '20250303',
      teishutsuKigen: '20250505',
      shikichiMenseki1: '10',
      shikichiMenseki2: '20',
      kenchikuMenseki1: '30',
      kenchikuMenseki2: '10',
      enyukaMenseki1: '50',
      enyukaMenseki2: '60',
      sekouyukaMenseki1: '70',
      sekouyukaMenseki2: '80',
      juchuuMikomiNichi: '',
      eigyouBumon: '',
      eigyouKanrishoku: '',
      eigyouTantouMono: '',
      sekkeiGyousha: '田中美咲',
      sekkeiTantouMono: '田中美咲',
      chakkouKanryouNichi: '',
      kankouKibouNichi: '',
      items: [{ value: '' }],
    },
    mode: 'onBlur',
  });

  // 添加/削除行
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items',
  });

  const defaultColDef = useMemo(() => {
    return {
      editable: type === 'edit',
      singleClickEdit: true,
    };
  }, []);

  const getRowStyle = (params: any) => {
    if (!params.data.shoukoushu) {
      return { backgroundColor: '#BCF5D6' };
    }
    return null;
  };

  // 明細項目定義
  const table1ColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
      cellClass: 'center-cell',
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
    },
    {
      headerName: '区分/大工種',
      field: 'daikushu',
      width: 200,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: daikushuParams,
      },
      children: [
        {
          headerName: '小工種',
          field: 'shoukoushu',
          width: 200,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: shoukoushuParams,
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.daikushu : params.data.shoukoushu;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikushu = params.newValue;
            } else {
              params.data.shoukoushu = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '規格',
      field: 'kikaku',
      width: 200,
      spanRows: true,
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
    },
    {
      headerName: '数量',
      field: 'suuryou',
      width: 140,
      children: [
        {
          headerName: '単位',
          field: 'tani',
          width: 140,
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: taniParams,
          },
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.suuryou : params.data.tani;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.suuryou = params.newValue;
            } else {
              params.data.tani = params.newValue;
            }
            return true;
          },
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'center-cell'),
        },
      ],
    },
    {
      headerName: '単価',
      field: 'tanka',
      width: 210,
      cellClass: 'end-cell',
      children: [
        {
          headerName: '合計金額/概算金額',
          field: 'gaisanKingaku',
          cellClass: 'end-cell',
          width: 210,
          valueGetter: params => {
            return params.node.rowIndex % 2 === 0 ? params.data.tanka : params.data.gaisanKingaku;
          },
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.tanka = params.newValue;
            } else {
              params.data.gaisanKingaku = params.newValue;
            }
            return true;
          },
          valueFormatter: (params: any) => {
            if (params.value) {
              return Intl.NumberFormat('en-US').format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '備考',
      field: 'bikou',
      width: 165,
      spanRows: true,
      cellStyle: params => {
        if (!params.data.shoukoushu) {
          return { backgroundColor: '#BCF5D6' };
        }
        return null;
      },
    },
  ]);

  // 支払条件明細項目定義
  const requestColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '請求条件名',
      field: 'seikyuuJoukenName',
      width: 150,
      cellClass: 'center-cell',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: seikyuuJoukenNameParams,
      },
    },
    {
      headerName: '隔合',
      field: 'kakuGou',
      width: 100,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          Intl.NumberFormat('en-US').format(params.value);
          return params.value + '%';
        } else {
          return '%';
        }
      },
    },
    {
      headerName: '請求金額',
      field: 'seikyuuKingaku',
      width: 150,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('en-US').format(params.value);
        }
      },
    },
    {
      headerName: '消費税率',
      field: 'shouhizeiRitsu',
      width: 100,
      cellClass: 'center-cell',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: shouhizeiRitsuParams,
      },
      valueFormatter: (params: any) => {
        if (params.value) {
          Intl.NumberFormat('en-US').format(params.value);
          return params.value + '%';
        }
      },
    },
    {
      headerName: '消費税金額',
      field: 'shouhizeiKingaku',
      width: 140,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('en-US').format(params.value);
        }
      },
    },
    {
      headerName: '合計金額',
      field: 'goukeiKingaku',
      width: 140,
      cellClass: 'end-cell',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('en-US').format(params.value);
        }
      },
    },
  ]);

  const onFinish = values => {
    // navigate('/contractList');
  };

  /** TODO: 参照 */
  const ankenSanshou = () => {};

  useEffect(() => {
    const sagyouInList = DBManager.getMockList(STORAGE_KEY_GAISAN);
    if (id) {
      const editData = sagyouInList.find(item => item.id.toString() === id) || null;
      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('ankenCode', editData.ankenCode);
        setValue('ankenName', editData.ankenName);
        setValue('gaisanCodePart1', editData.gaisanCode);
        setValue('gaisanCodePart2', '00');
        setValue('ankenKanaName', 'アイウエオ');
        setValue('gaisanBumon', '01');
        setValue('gaisanHizuke', '2025-03-21');
        setValue('gaisanTantouMono', '01');
        setValue('items.0.value', '添付ファイル.png');
        setValue('elia', 'typeA');
        // setValue('gaisanGoukeiKingaku', Intl.NumberFormat('en-US').format(editData.gaisanKingaku));
        setValue('yuubinBangouPart1', '01001');
        setValue('yuubinBangouPart2', '0001');
        setValue('juchuuMikomiNichi', dayjs(editData.chakkouDate).format('YYYY年MM月DD日'));
        setValue('eigyouBumon', '東京工事部門 - 営業部');
        setValue('eigyouKanrishoku', '鈴木 太郎');
        setValue('eigyouTantouMono', '楽天 湯村');
        setValue('kanminKubun', dayjs(editData.chakkouDate).format('YYYY年MM月DD日'));
        setValue('teishutsuKigen', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
        setValue('bukkenJuusho', editData.genbaJusho);
        setValue('chakkouKanryouNichi', dayjs(editData.chakkoKiboJiki).format('YYYY年MM月DD日'));
        setValue('kankouKibouNichi', dayjs(editData.kankoKiboJiki).format('YYYY年MM月DD日'));
        setValue('sekkeiGyousha', '田中美咲');
        setValue('sekkeiTantouMono', editData.gaisanTantousya);
      }
    }

    // データ
    const tempDataSource = [];
    for (let i = 0; i < 5; i++) {
      if (i < 2) {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          daikushu: '鉄筋工',
          shoukoushu: '配管工',
          kikaku: 'メートル' + (i + 1),
          suuryou: '1.00',
          tani: '式',
          tanka: 1000000,
          gaisanKingaku: 1000000,
          bikou: '備考内容' + (i + 1),
        });
      } else {
        tempDataSource.push({
          id: i + 1,
          key: i + 1,
          daikushu: '土工事',
          shoukoushu: '配管工',
          kikaku: 'メートル' + (i + 1),
          suuryou: '1.00',
          tani: '式',
          tanka: 1000000,
          gaisanKingaku: 1000000,
          bikou: '備考内容' + (i + 1),
        });
      }
    }
    setDataSource(tempDataSource);

    // まず、明細表の各データを使用して、大工種に従って集約する；
    const categoryMap = {};
    tempDataSource.forEach(item => {
      if (categoryMap[item.daikushu]) {
        categoryMap[item.daikushu].push(item);
      } else {
        categoryMap[item.daikushu] = [item];
      }
    });

    // 大工種の集計データを計算する
    const newCurData = [];
    const list = [];
    for (const category in categoryMap) {
      const firstTotalRow = categoryMap[category].reduce(
        (acc, row) => ({
          gaisanKingaku: acc.gaisanKingaku + row.gaisanKingaku,
        }),
        { gaisanKingaku: 0 },
      );
      list.push({
        no: list.length.toString(),
        daikushu: category,
        ...firstTotalRow,
      });
    }

    // 概算合計金額
    for (let i = 0; i < list.length; i++) {
      gaisanTotal = gaisanTotal + list[i].gaisanKingaku;
    }

    // IDを再計算する
    let tableID = 1;
    let dateFlg = true;
    for (let i = 0; i < tempDataSource.length; i++) {
      if (i !== 0 && tempDataSource[i].daikushu !== tempDataSource[i - 1].daikushu) {
        dateFlg = true;
      }
      for (let x = 0; x < list.length; x++) {
        if (list[x].daikushu === tempDataSource[i].daikushu && dateFlg) {
          newCurData.push({
            id: i + tableID,
            daikushu: list[x].daikushu,
            gaisanKingaku: list[x].gaisanKingaku,
          });
          dateFlg = false;
          tableID = tableID + 1;
        }
      }
      const newTempDataSource = tempDataSource[i];
      newTempDataSource.id = i + tableID;
      newCurData.push(newTempDataSource);
    }

    // データ設定
    const newCurData1 = [];
    for (let i = 0; i < newCurData.length; i++) {
      newCurData1.push(newCurData[i]);
      newCurData1.push(newCurData[i]);
    }
    setDataSource(newCurData1);

    // 案件情報のデータ
    const tempDataSource2 = [];
    for (let i = 0; i < 4; i++) {
      tempDataSource2.push({
        seikyuuJoukenName: '延期付款',
        kakuGou: 2 + i,
        seikyuuKingaku: 200000 + i,
        shouhizeiRitsu: 30,
        shouhizeiKingaku: 300000 + i,
        goukeiKingaku: 200000 + i,
      });
    }
    setDataSource2(tempDataSource2);
    const newCurData2 = [];
    for (let i = 0; i < tempDataSource2.length; i++) {
      newCurData2.push(tempDataSource2[i]);
      newCurData2.push(tempDataSource2[i]);
    }
    setDataSource2(newCurData2);

    const lastTotalRow = tempDataSource2.reduce(
      (acc, row) => ({
        kakuGou: acc.kakuGou + row.kakuGou,
        seikyuuKingaku: acc.seikyuuKingaku + row.seikyuuKingaku,
        shouhizeiRitsu: acc.shouhizeiRitsu + row.shouhizeiRitsu,
        shouhizeiKingaku: acc.shouhizeiKingaku + row.shouhizeiKingaku,
        goukeiKingaku: acc.goukeiKingaku + row.goukeiKingaku,
      }),
      { kakuGou: 0, seikyuuKingaku: 0, shouhizeiRitsu: 0, shouhizeiKingaku: 0, goukeiKingaku: 0 },
    );
    tempDataSource2.push({ seikyuuJoukenName: '合計', ...lastTotalRow });
    setDataSource2(tempDataSource2);

    const contractList = [];
    contractList.push({ ...newCurData1, ...tempDataSource2 });
    localStorage.setItem('WebC0030', JSON.stringify(contractList));

    // タイトル
    setPageTitle('概算作成');
    return () => setPageTitle('');
  }, []);

  // 概算合計金額/精積算合計金額
  useEffect(() => {
    setValue('gaisanGoukeiKingaku', Intl.NumberFormat('en-US').format(gaisanTotal));
  }, [gaisanTotal]);

  return (
    <div>
      <div className="webc0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{`【最終更新日】`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} type="submit" disabled={isHensyuuKengen}>
              保存
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={isHensyuuKengen}
              onClick={() => {}}
            >
              申請
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={isHensyuuKengen}
              onClick={() => {}}
            >
              クリア
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={isHensyuuKengen}
              onClick={() => {}}
            >
              削除
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/webD0010`);
              }}
            >
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              印刷
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/WebE0010/${type}/webC/${id}`);
              }}
              disabled={isHensyuuKengen}
            >
              見積書印刷
            </Button>
          </div>
        </div>
        <Box component="form" onSubmit={onFinish} display="flex" flexDirection="column" gap={2} className="ad-search-seisekisan">
          {/*  案件コード/案件名 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="ankenCode"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>案件コード</label>
                    <TextField
                      {...field}
                      fullWidth
                      disabled
                      size="small"
                      sx={{
                        width: '227px',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      disabled={isHensyuuKengen}
                      // prettier-ignore
                      style={{ minWidth: 96 ,height: 30.75, marginLeft: 6, whiteSpace:"nowrap", marginTop: '3px' }}
                      onClick={ankenSanshou}
                    >
                      参照
                    </Button>
                  </div>
                )}
              />
            </Box>
            <Box flex={2} display="flex" justifyContent="space-between" sx={{ minWidth: '48%' }}>
              <Box flex={1}>
                <Controller
                  name="ankenName"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>案件名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={1} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  概算コード/案件カナ名 */}
          <Box display="flex" justifyContent="space-between">
            <Box className="ad-search-item" flex={2} mr={2}>
              <Box>
                <Controller
                  name="gaisanCodePart1"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>概算コード</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '165px' }} />
                    </div>
                  )}
                />
              </Box>
              <Box>
                <Controller
                  name="gaisanCodePart2"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '65px' }} />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} display="flex" justifyContent="space-between" sx={{ marginLeft: '7.7%', minWidth: '48%' }}>
              <Box flex={1}>
                <Controller
                  name="ankenKanaName"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>案件カナ名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={1} display="flex" justifyContent="space-between"></Box>
          </Box>
          {/*  概算日付 */}
          <LocalizationProvider
            dateAdapter={AdapterDayjs}
            adapterLocale="ja"
            localeText={jaJP.components.MuiLocalizationProvider.defaultProps.localeText}
          >
            <Box display="flex" sx={{ mb: 2, maxWidth: '76.5%', marginBottom: '0px' }} className="ad-search-container">
              <Box flex={1}>
                <Controller
                  name="gaisanHizuke"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item cell-date-picker">
                      <label>*概算日付</label>
                      <DatePicker
                        {...field}
                        disableFuture={!!fieldState.error}
                        sx={{ width: '30%', textAlignLast: 'end' }}
                        format="YYYY年MM月DD日"
                        value={field.value ? dayjs(field.value) : null}
                      />
                    </div>
                  )}
                />
              </Box>
            </Box>
          </LocalizationProvider>

          {/*  概算部門 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="gaisanBumon"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>*概算部門</label>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '300px',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="01">広報部</MenuItem>
                      <MenuItem value="02">営業部</MenuItem>
                      <MenuItem value="03">経理部</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          {/* 概算担当者 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="gaisanTantouMono"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>*概算担当者</label>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '227px',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="01">佐藤 愛菜</MenuItem>
                      <MenuItem value="02">吉田 美</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  添付ファイル */}
          <Box display="flex" gap={2} justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <label>添付ファイル</label>
              <div className="margin-left-36">
                {fields.map((item, index) => (
                  <Collapse in={true} key={item.id}>
                    {index === fields.length - 1 && (
                      <div
                        onClick={() => append({ value: '' })}
                        color="primary"
                        style={{ marginTop: '6px', pointerEvents: isHensyuuKengen ? 'none' : 'all' }}
                      >
                        <AddCircleOutlineIcon />
                      </div>
                    )}
                    <Controller
                      name={`items.${index}.value`}
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item  cell-date-picker">
                          <TextField
                            {...field}
                            fullWidth
                            variant="outlined"
                            error={!!errors.items?.[index]?.value}
                            sx={{
                              width: '300px',
                              marginLeft: '12px',
                              marginBottom: '12px',
                            }}
                          />
                          <Button
                            size="small"
                            variant="contained"
                            disabled={isHensyuuKengen}
                            onClick={() => remove(index)}
                            style={{ minWidth: 96, height: '30.75px', marginLeft: '2rem', marginTop: '3px' }}
                          >
                            削除
                          </Button>
                        </div>
                      )}
                    />
                  </Collapse>
                ))}
              </div>
            </Box>
          </Box>
          {/*  エリア */}
          <Box display="flex" justifyContent="space-between" sx={{ marginTop: '-12px' }}>
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="elia"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>エリア</label>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '227px',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">Type A</MenuItem>
                      <MenuItem value="typeB">Type B</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  見積依頼 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Button
                size="small"
                variant="contained"
                disabled={isHensyuuKengen}
                onClick={() => {}}
                style={{ minWidth: 96, height: '30.75px', marginTop: '3px' }}
              >
                見積依頼
              </Button>
              <Button
                size="small"
                variant="contained"
                disabled={isHensyuuKengen}
                onClick={() => {}}
                style={{ minWidth: 96, height: '30.75px', marginLeft: '40rem', marginTop: '3px' }}
              >
                出来高シミュレーションデータ作成
              </Button>
            </Box>
          </Box>
          {/* 明細テーブル */}
          <div className="ag-theme-alpine column-group-table" style={{ width: '100%', height: '350px' }}>
            <AgGridReact
              rowData={dataSource}
              theme={AGGridTheme}
              columnDefs={table1ColumnDefs.current}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              enableCellSpan
            />
          </div>
          {/*  概算合計金額/精積算合計金額 */}
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2}>
              <Controller
                name="gaisanGoukeiKingaku"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item" style={{ width: '35%', marginLeft: '45%' }}>
                    <label style={{ minWidth: '110px' }}>概算合計金額</label>
                    <TextField {...field} fullWidth size="small" style={{ textAlignLast: 'end' }} />
                  </div>
                )}
              />
            </Box>
          </Box>
          {/*  案件情報 */}
          <div style={{ marginLeft: '40px' }}>
            <div
              onClick={() => {
                setIsCollapse(!isCollapse);
              }}
            >
              {isCollapse ? <AddCircleOutlineRounded style={{ color: '#285ac8' }} /> : <RemoveCircleOutlineRounded />}
              <label style={{ marginLeft: '5px' }}>案件情報</label>
            </div>
          </div>
          <Box display="flex" justifyContent="space-between">
            <Box flex={1}></Box>
            <Box flex={12}>
              <Box style={{ border: '2px solid black' }} className={isCollapse ? 'hidden-seisekisan' : ''}>
                <Box display="flex" flexDirection="column" mt={2} mr={2} gap={2}>
                  {/*  郵便番号 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart1"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item2">
                              <label>郵便番号</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart2"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item1">
                              <label>-</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  物件住所 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2}>
                      <Controller
                        name="bukkenJuusho"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>物件住所</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                    {/* <Box flex={1}></Box> */}
                  </Box>
                  {/*  郵便番号 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart3"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item2">
                              <label>郵便番号</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2}>
                        <Controller
                          name="yuubinBangouPart4"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field }) => (
                            <div className="ad-search-item1">
                              <label>-</label>
                              <TextField {...field} size="small" style={{ width: '128.8px' }} />
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  顧客住所 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2}>
                      <Controller
                        name="kokyakuJuusho"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>顧客住所</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  官民区分 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="kanminKubun"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>官民区分</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px', textAlignLast: 'end' }} />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  見積提出期限 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={1} mr={2} className="ad-search-item">
                      <Controller
                        name="teishutsuKigen"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>見積提出期限</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px', textAlignLast: 'end' }} />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  敷地面積/建築面積 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="shikichiMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%' }}>
                            <label>敷地面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="shikichiMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="kenchikuMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%', marginLeft: '15%' }}>
                            <label>建築面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="kenchikuMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  延床面積/施工床面積 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="enyukaMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%' }}>
                            <label>延床面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="enyukaMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="sekouyukaMenseki1"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2" style={{ minWidth: '70.5%', marginLeft: '15%' }}>
                            <label>施工床面積</label>
                            <TextField {...field} size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="sekouyukaMenseki2"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ minWidth: '50%' }}>
                            <label>㎡</label>
                            <TextField {...field} size="small" />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  受注見込日 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="juchuuMikomiNichi"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>受注見込日</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                                textAlignLast: 'end',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  {/*  営業部門 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} className="ad-search-item">
                      <Box flex={2}>
                        <Controller
                          name="eigyouBumon"
                          control={control}
                          disabled={isHensyuuKengen}
                          render={({ field, fieldState }) => (
                            <div className="ad-search-item2">
                              <label>営業部門</label>
                              <TextField
                                {...field}
                                size="small"
                                error={!!fieldState.error}
                                sx={{
                                  width: '390px',
                                }}
                              />
                            </div>
                          )}
                        />
                      </Box>
                    </Box>
                    <Box flex={2}></Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  営業管理職/営業担当者 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="eigyouKanrishoku"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>営業管理職</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="eigyouTantouMono"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>営業担当者</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/* 着工完了日/完工希望日 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="chakkouKanryouNichi"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>着工完了日</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                                textAlignLast: 'end',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="kankouKibouNichi"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field, fieldState }) => (
                          <div className="ad-search-item2">
                            <label>完工希望日</label>
                            <TextField
                              {...field}
                              size="small"
                              error={!!fieldState.error}
                              sx={{
                                width: '280px',
                                textAlignLast: 'end',
                              }}
                            />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  {/*  設計業者/設計担当者 */}
                  <Box display="flex" justifyContent="space-between">
                    <Box flex={2} mr={2} display="flex">
                      <Controller
                        name="sekkeiGyousha"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>設計業者</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={2} display="flex">
                      <Controller
                        name="sekkeiTantouMono"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item2">
                            <label>設計担当者</label>
                            <TextField {...field} fullWidth size="small" style={{ width: '280px' }} />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>

                  <Box display="flex" justifyContent="space-between">
                    <Box flex={1} mr={2} className="ad-search-item">
                      <div className="ad-search-item2">
                        <label style={{ paddingTop: '4px' }}>請求条件</label>
                      </div>
                    </Box>
                    <Box flex={6}></Box>
                  </Box>
                  <div
                    className="ag-theme-alpine column-group-table"
                    style={{ width: '100%', height: '260px', paddingLeft: '100px', marginTop: '-20px', marginBottom: '20px' }}
                  >
                    <AgGridReact
                      rowData={dataSource2}
                      theme={AGGridTheme}
                      columnDefs={requestColumns.current}
                      defaultColDef={defaultColDef}
                      getRowStyle={params => {
                        if (params.data.seikyuuJoukenName === '合計') {
                          return { fontWeight: 'bold', backgroundColor: '#f5f5f5' };
                        }
                        return null;
                      }}
                      enableCellSpan
                      suppressRowTransform
                      gridOptions={{
                        defaultColDef: {
                          resizable: false,
                          sortable: false,
                        },
                        autoSizeStrategy: {
                          type: 'fitGridWidth',
                        },
                      }}
                    />
                  </div>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebC0030CreateForm;
