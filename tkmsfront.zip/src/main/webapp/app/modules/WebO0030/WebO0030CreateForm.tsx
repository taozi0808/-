import React, { FC, useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebO0030CreateForm.scss';
import { useLocation } from 'react-router-dom';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { TextField, Button, Checkbox, FormControlLabel, Box, Collapse, Select, MenuItem, Radio, RadioGroup } from '@mui/material';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import { DBManager, generatGyoushaData } from 'app/shared/util/construction-list';
import {
  ColDef,
  ColGroupDef,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);

const WebO0030: FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id, type } = useParams();
  const { setPageTitle } = usePageTitleStore();
  const { state } = location;
  const { param1 } = state || {};

  const dateFormat = 'YYYY/MM/DD';

  const [listJyucyuuJyoutai3disabled, setListJyucyuuJyoutai3disabled] = useState(false);
  const [listJyucyuuJyoutai2disabled, setListJyucyuuJyoutai2disabled] = useState(false);
  const [listJyucyuuJyoutai1disabled, setListJyucyuuJyoutai1disabled] = useState(false);
  const [listJyucyuuJyoutai4disabled, setListJyucyuuJyoutai4disabled] = useState(true);

  // let listJyucyuuJyoutai3disabled = true;

  const { control, handleSubmit, setValue } = useForm({
    defaultValues: {
      gyoushaCode: '',
      field2: '',
      field3: '',
      field4: '',
      field5: '',
      field6: '',
      field7: '',
      field8: '',
      field9: '',
      field10: '',
      field11: '',
      field12: '',
      field13: '',
      field14: '',
      field15: '',
      field16: '',
      field17: '',
      field18: '',
      field19: '',
      field20: '',
      field21: '',
      field22: '',
      field23: '',
      field24: '',
      field25: '',
      field26: '',
      field27: '',
      field28: '',
      field29: '',
      field30: '',
      field31: '',
      field32: '',
      field33: '',
      field34: '',
      field35: '',
      field36: '',
      field37: '',
      field38: '',
      field39: '',
      field40: '',
      field41: '',
      field42: '',
      field43: '',
      field44: '',
      field45: '',
      field46: '',
      field47: '',
      field48: '',
      field49: '',
      field50: '',
      field51: '',
      field52: '',
      field53: '',
      field54: '',
      listJyucyuuJyoutai1: '0',
      listJyucyuuJyoutai2: '0',
      listJyucyuuJyoutai3: '0',
      listJyucyuuJyoutai4: '0',
      listJyucyuuJyoutai: {
        '1': true,
        '2': false,
        '3': false,
      },
      items: [{ value: '' }],
      items1: [{ value: '' }],
      items2: [{ value: '' }],
      items3: [{ value: '' }],
      items4: [{ value: '' }],
      items5: [{ value: '' }],
      items6: [{ value: '' }],
      items7: [{ value: '' }],
      items8: [{ value: '' }],
    },
  });

  const columnRefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      spanRows: true,
      width: 60,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '許可・認定',
      field: 'conditionName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '業者',
      field: 'gyousya',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '番号',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '',
      field: 'percentage',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '許可日・認定日',
      field: 'conditionNameDate',
      cellEditor: 'agDateCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);
  const defaultColDef = useMemo(() => {
    return {
      // flex: 1,
      suppressMovable: true,
      sortable: false,
      editable: () => {
        return listJyucyuuJyoutai4disabled;
      },
    };
  }, []);

  // サンプルデータ
  const [data, setData] = useState([]);

  // 添加/削除行
  const {
    fields: fieldsitems,
    append: appenditems,
    remove: removeitems,
  } = useFieldArray({
    control,
    name: 'items',
  });

  // 添加/削除行
  const {
    fields: fieldsitems1,
    append: appenditems1,
    remove: removeitems1,
  } = useFieldArray({
    control,
    name: 'items5',
  });

  const gyoushaList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY999');
  useEffect(() => {
    if (id) {
      const editData = gyoushaList.find(item => item.id.toString() === id) || null;
      if (editData === null) {
        console.log('データ異常');
      } else {
        setValue('gyoushaCode', editData.gyoushaCode);
        // setValue('address', '00');
        // setValue('ankenKanaName', 'アイウエオ');
        // setValue('seisekisanCodePart2', '01');
        // setValue('seisekisanBumon', '財務部');
        // setValue('seisekisanHizuke', '2025-03-21');
        // setValue('seisekisanTantoumono', '佐藤 愛菜');
        // setValue('items.0.value', '添付ファイル.png');
        // setValue('elia', 'typeA');
        // setValue('gaisanGoukeiKingaku', Intl.NumberFormat('en-US').format(gaisanTotal));
        // setValue('seiSekisanGoukeiKingaku', Intl.NumberFormat('en-US').format(seiSekisanTotal));
        // setValue('yuubinBangouPart1', '01001');
        // setValue('yuubinBangouPart2', '0001');
        // setValue('juchuuMikomiNichi1', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
        // setValue('juchuuMikomiNichi2', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
        // setValue('eigyouBumon', '01');
        // setValue('eigyouKanrishoku', '01');
        // setValue('eigyouTantouMono', '01');
        // setValue('kanminKubun', '民間');
        // setValue('teishutsuKigen', dayjs(editData.juchuYmd).format('YYYY年MM月DD日'));
      }
    }
    const tempData = [];
    for (let i = 0; i < 4; i++) {
      tempData.push({
        id: i + 1,
      });
    }
    setData(tempData);
    setPageTitle('業者登録');
    return () => setPageTitle('');
  }, []);

  const genjyoCodeList = [
    { value: '1', label: '普通預金' },
    { value: '2', label: '当座預金' },
    { value: '3', label: '貯蓄預金' },
    { value: '9', label: 'その他' },
  ];

  const field23List = [
    { value: '00', label: '本社' },
    { value: '01', label: '東京本店' },
    { value: '02', label: '札幌支店' },
    { value: '03', label: '東北支店' },
    { value: '04', label: '北陸支店' },
    { value: '05', label: '関東支店' },
  ];

  const field22List = [
    { value: '00', label: '東京銀行' },
    { value: '01', label: '札幌銀行' },
    { value: '02', label: '東北銀行' },
    { value: '03', label: '北陸銀行' },
    { value: '04', label: '関東銀行' },
  ];

  const gyomuGyoshuArrList = [
    { value: '00', label: '土木工事業' },
    { value: '01', label: '建築工事業' },
    { value: '02', label: '電気通信工事業' },
    { value: '03', label: '機械器具設置工事業' },
  ];

  const lastNames = [
    { value: '00', label: '佐藤' },
    { value: '01', label: '鈴木' },
    { value: '02', label: '高橋' },
    { value: '03', label: '田中' },
    { value: '04', label: '湯村' },
    { value: '05', label: '保手' },
    { value: '06', label: '浜' },
  ];

  // 解体登録
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状态对象
    setValue('listJyucyuuJyoutai3', (event.target as HTMLInputElement).value);

    if (event.target.value === '0') {
      setListJyucyuuJyoutai3disabled(false);
    } else {
      setListJyucyuuJyoutai3disabled(true);
    }
  };
  // 産廃認定
  const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状态对象
    setValue('listJyucyuuJyoutai1', (event.target as HTMLInputElement).value);

    if (event.target.value === '0') {
      setListJyucyuuJyoutai1disabled(false);
    } else {
      setListJyucyuuJyoutai1disabled(true);
    }
  };

  // 産廃認定
  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状态对象
    setValue('listJyucyuuJyoutai2', (event.target as HTMLInputElement).value);

    if (event.target.value === '0') {
      setListJyucyuuJyoutai2disabled(false);
    } else {
      setListJyucyuuJyoutai2disabled(true);
    }
  };

  // 解体登録
  const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 更新状态对象
    setValue('listJyucyuuJyoutai4', (event.target as HTMLInputElement).value);

    if (event.target.value === '0') {
      setListJyucyuuJyoutai4disabled(true);
    } else {
      setListJyucyuuJyoutai4disabled(false);
    }
  };

  // 保存
  const onFinish = values => {
    // notify('正常に保存されました');
    navigate('/webO0010');
  };
  // クリア
  const onClear = record => {
    // notify('画面を初期化します。よろしいでしょうか？');
  };

  // 削除
  const onDelete = record => {
    // notify('該当データを削除します。よろしいでしょうか？', 'warning');
    navigate('/webO0010');
  };

  // キャンセル
  const onCancel = record => {
    // notify('未保存の編集内容を破棄して呼び出し元の画面に遷移します。よろしいでしょうか？', 'warning');
    navigate('/webO0010');
  };

  return (
    <div>
      <div className="webO0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
            <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onFinish}>
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              申請
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onClear}>
              クリア
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onDelete}>
              削除
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCancel}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
              印刷
            </Button>
          </div>
        </div>
        <form>
          <Box display="flex" flexDirection="column" gap={2} className="ad-search-operatorAdd">
            {/*  業者コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box className="ad-search-item" flex={3}>
                {/* <Box> */}
                <Box flex={1}>
                  <Controller
                    name="gyoushaCode"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>業者コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                {/* </Box> */}
                <Box flex={1} className="ad-search-item">
                  <Controller
                    name="field2"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label></label>
                        <FormControlLabel control={<Checkbox {...field} defaultChecked />} label="取消停止" />
                        <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                          一括発注取消
                        </Button>
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  会社*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field3"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>会社名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field4"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>会社名カナ</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  支店*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <Controller
                  name="field5"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>支店コード</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1} className="ad-search-item">
                <Controller
                  name="field6"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item3">
                      <label>支店名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field7"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>会社支店名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/* 代表者氏名 */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1}>
                <Controller
                  name="field8"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>代表者氏名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}>
                <Box flex={1} className="ad-search-item">
                  <Controller
                    name="field9"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item3">
                        <label>代表者カナ名</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={2}>
                <Controller
                  name="field10"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>メールアドレス</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  郵便番号*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <Box flex={2}>
                  <Controller
                    name="field11"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>郵便番号</label>
                        <TextField {...field} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={2}>
                  <Controller
                    name="field12"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label>-</label>
                        <TextField {...field} size="small" />
                        <Button variant="contained" size="small" style={{ left: '10px', minWidth: 90 }}>
                          住所検索
                        </Button>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}></Box>
              </Box>
              <Box flex={2}>
                <Box flex={1}>
                  <Controller
                    name="field13"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item2">
                        <label>初回登録者</label>
                        <Select {...field} size="small" style={{ width: '50%' }}>
                          <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                          {lastNames.map(items => (
                            <MenuItem key={items.value} value={items.value}>
                              {items.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  住所1*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field14"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>住所1</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  住所2*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field15"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>住所2</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  電話番号*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} display="flex">
                <Controller
                  name="field16"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>電話番号</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field17"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field18"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="field19"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>FAX番号</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field20"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field21"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <div>
              <Button
                variant="contained"
                className="Buttoncolor"
                size="small"
                disabled
                style={{ marginRight: '8px', minWidth: 96 }}
                onClick={onFinish}
              >
                口座情報
              </Button>
            </div>
            {/*  銀行名*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field22"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>銀行名</label>
                      <Select {...field} size="small" style={{ width: '100%' }}>
                        <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                        {field22List.map(item => (
                          <MenuItem key={item.value} value={item.value}>
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field23"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>支店名</label>
                      <Select {...field} size="small" style={{ width: '100%' }}>
                        <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                        {field23List.map(item => (
                          <MenuItem key={item.value} value={item.value}>
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field24"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>預金種別</label>
                      <Select {...field} size="small" style={{ width: '100%' }}>
                        <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                        {genjyoCodeList.map(item => (
                          <MenuItem key={item.value} value={item.value}>
                            {item.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  口座番号*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field25"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>口座番号</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field26"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>口座名義</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field27"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>口座名義カナ</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  会社設立日*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field28"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>会社設立日</label>
                      <TextField {...field} type="date" size="small" fullWidth />
                    </div>
                  )}
                />
              </Box>
              <Box flex={4}>
                <Box flex={1} display="flex" gap={1} className="ad-search-item">
                  <label style={{ lineHeight: '36px', width: 100 }}>企業区分</label>
                  {/* 第一个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.1"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="個人" />}
                  />

                  {/* 第二个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.2"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="非公開法人" />}
                  />

                  {/* 第三个复选框 */}
                  <Controller
                    name="listJyucyuuJyoutai.3"
                    control={control}
                    render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="公開法人" />}
                  />
                </Box>
              </Box>
            </Box>
            {/*  資本金*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field29"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>資本金</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={4}>
                <Controller
                  name="field30"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item4">
                      <label>インボイス認定番号</label>
                      <TextField {...field} fullWidth size="small" style={{ width: '50%' }} />
                      <Button variant="contained" size="small" style={{ marginRight: '8px', left: '24px' }} onClick={onFinish}>
                        インボイス登録認定
                      </Button>
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  事務所番号 */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field31"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>事務所番号</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field32"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>保険率</label>
                      <TextField {...field} fullWidth size="small" />
                      <label>/1000</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  従業員数*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} display="flex">
                <Box flex={1}>
                  <Controller
                    name="field33"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item5">
                        <label className="itemlabel">従業員数</label>
                        <TextField {...field} fullWidth size="small" />
                        <label className="itemlabel1">名</label>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field34"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item5">
                        <label className="itemlabel2">（ 管理職</label>
                        <TextField {...field} fullWidth size="small" />
                        <label className="itemlabel1">名</label>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field35"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item5">
                        <label className="itemlabel2">技術職</label>
                        <TextField {...field} fullWidth size="small" />
                        <label className="itemlabel1">名</label>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field36"
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item5">
                        <label className="itemlabel2">事務職</label>
                        <TextField {...field} fullWidth size="small" />
                        <label className="itemlabel1">名 ）</label>
                      </div>
                    )}
                  />
                </Box>
              </Box>
            </Box>
            {/*  会社の沿革 */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1}>
                <Controller
                  name="field37"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>会社の沿革</label>
                      <TextField {...field} fullWidth size="small" multiline rows={6} />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  建築許可*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <Controller
                  name="listJyucyuuJyoutai4"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label style={{ paddingTop: '4px' }}>建築許可</label>
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange4}>
                        <FormControlLabel value={0} control={<Radio />} label="有" />
                        <FormControlLabel value={1} control={<Radio />} label="無" />
                      </RadioGroup>
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/*  建築許可*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <label></label>
                <div style={{ width: '100%', height: '218px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={data} theme={AGGridTheme} columnDefs={columnRefs.current} defaultColDef={defaultColDef} />
                </div>
              </Box>
            </Box>
            {/*  解体登録*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <label style={{ paddingTop: '4px' }}>解体登録</label>
                <Controller
                  name="listJyucyuuJyoutai3"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange}>
                        <FormControlLabel value={0} control={<Radio />} label="有" />
                        <FormControlLabel value={1} control={<Radio />} label="無" />
                      </RadioGroup>
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/*  解体登録*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item5">
                <label className="itemlabel"></label>
                <Controller
                  name="field38"
                  disabled={listJyucyuuJyoutai3disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <label className="itemlabel1">知事</label>
              </Box>
              <Box flex={3} className="ad-search-item5">
                <label className="itemlabel3">番号</label>
                <Controller
                  name="field39"
                  disabled={listJyucyuuJyoutai3disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ marginRight: '24px' }}>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field40"
                  disabled={listJyucyuuJyoutai3disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item5">
                <label className="itemlabel4">許可日・認定日</label>
                <Controller
                  name="field41"
                  disabled={listJyucyuuJyoutai3disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <TextField {...field} type="date" size="small" fullWidth />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  警備認定*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <label style={{ paddingTop: '4px' }}>警備認定</label>
                <Controller
                  name="listJyucyuuJyoutai2"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange2}>
                        <FormControlLabel value={0} control={<Radio />} label="有" />
                        <FormControlLabel value={1} control={<Radio />} label="無" />
                      </RadioGroup>
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/*  警備認定*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item5">
                <label className="itemlabel"></label>
                <Controller
                  name="field42"
                  disabled={listJyucyuuJyoutai2disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
                <label className="itemlabel1">公安委員会</label>
              </Box>
              <Box flex={3} className="ad-search-item5">
                <label className="itemlabel3">番号</label>
                <Controller
                  name="field43"
                  disabled={listJyucyuuJyoutai2disabled}
                  control={control}
                  render={({ field }) => (
                    <div style={{ justifyContent: 'space-around', width: '38%' }}>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item5">
                <label className="itemlabel4">許可日・認定日</label>
                <Controller
                  name="field44"
                  disabled={listJyucyuuJyoutai2disabled}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <TextField {...field} type="date" size="small" defaultValue={{ field13: new Date() }} fullWidth />
                    </div>
                  )}
                />
              </Box>
            </Box>
            {/*  産廃認定*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} className="ad-search-item">
                <label style={{ paddingTop: '4px' }}>産廃認定</label>
                <Controller
                  name="listJyucyuuJyoutai1"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <RadioGroup value={field.value} row style={{ flexWrap: 'nowrap' }} onChange={handleChange1}>
                        <FormControlLabel value={0} control={<Radio />} label="有" />
                        <FormControlLabel value={1} control={<Radio />} label="無" />
                      </RadioGroup>
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/*  産廃認定*/}
            {fieldsitems1.map((item, index) => (
              <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                <Box display="flex" justifyContent="space-between">
                  <Box flex={2} className="ad-search-item5">
                    {index === fieldsitems1.length - 1 ? (
                      <label className="itemlabel" onClick={() => appenditems1({ value: '' })}>
                        <AddCircleOutlineIcon />
                      </label>
                    ) : (
                      <label className="itemlabel"></label>
                    )}
                    <Controller
                      name={`items5.${index}.value`}
                      disabled={listJyucyuuJyoutai1disabled}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item5">
                          <TextField {...field} fullWidth size="small" />
                          <label className="itemlabel1">市長</label>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={3} className="ad-search-item5" style={{ justifyContent: 'space-between' }}>
                    <label className="itemlabel3">番号</label>
                    <Controller
                      name={`items6.${index}.value`}
                      disabled={listJyucyuuJyoutai1disabled}
                      control={control}
                      render={({ field }) => (
                        <div style={{ width: '100%' }}>
                          <TextField {...field} size="small" fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={2} className="ad-search-item5">
                    <label className="itemlabel4">許可日・認定日</label>
                    <Controller
                      name={`items7.${index}.value`}
                      disabled={listJyucyuuJyoutai1disabled}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <TextField {...field} type="date" size="small" defaultValue={{ field13: new Date() }} fullWidth />
                        </div>
                      )}
                    />
                  </Box>
                </Box>
                <Box display="flex" justifyContent="space-between" mt={2}>
                  <Box flex={2} className="ad-search-item"></Box>
                  <Box flex={5} className="ad-search-item">
                    <label>産廃許可証</label>
                    <Controller
                      name={`items8.${index}.value`}
                      disabled={listJyucyuuJyoutai1disabled}
                      control={control}
                      render={({ field }) => (
                        <div style={{ width: '100%' }}>
                          <Select {...field} size="small" style={{ width: '70%' }}>
                            <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                            <MenuItem value={'1'}>新規許可</MenuItem>
                            <MenuItem value={'2'}>更新許可</MenuItem>
                            <MenuItem value={'3'}>変更許可</MenuItem>
                          </Select>
                          <Button
                            variant="contained"
                            disabled={listJyucyuuJyoutai1disabled}
                            size="small"
                            style={{ marginRight: '8px', minWidth: 96, left: '24px' }}
                            onClick={() => removeitems1(index)}
                          >
                            削除
                          </Button>
                        </div>
                      )}
                    />
                  </Box>
                </Box>
              </Collapse>
            ))}
            {/*  事業所*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field49"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>CCUS事業所ID</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={6}></Box>
            </Box>
            {/*  業種*/}
            {fieldsitems.map((item, index) => (
              <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                <Box display="flex" justifyContent="space-between">
                  <Box flex={1} className="ad-search-item">
                    {index === fieldsitems.length - 1 ? <label>業種</label> : <label></label>}
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name={`items.${index}.value`}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item" style={{ width: '88%' }}>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                              {gyomuGyoshuArrList.map(items => (
                                <MenuItem key={items.value} value={items.value}>
                                  {items.label}
                                </MenuItem>
                              ))}
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name={`items1.${index}.value`}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ width: '88%' }}>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                              {gyomuGyoshuArrList.map(items => (
                                <MenuItem key={items.value} value={items.value}>
                                  {items.label}
                                </MenuItem>
                              ))}
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name={`items2.${index}.value`}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ width: '88%' }}>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                              {gyomuGyoshuArrList.map(items => (
                                <MenuItem key={items.value} value={items.value}>
                                  {items.label}
                                </MenuItem>
                              ))}
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name={`items3.${index}.value`}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ width: '88%' }}>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                              {gyomuGyoshuArrList.map(items => (
                                <MenuItem key={items.value} value={items.value}>
                                  {items.label}
                                </MenuItem>
                              ))}
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name={`items4.${index}.value`}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item1" style={{ width: '88%' }}>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem key={''} value={''} style={{ height: 30 }}></MenuItem>
                              {gyomuGyoshuArrList.map(items => (
                                <MenuItem key={items.value} value={items.value}>
                                  {items.label}
                                </MenuItem>
                              ))}
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <label onClick={() => appenditems({ value: '' })} style={{ display: 'flex', alignItems: 'center' }}>
                      <AddCircleOutlineIcon />
                    </label>
                  </Box>
                </Box>
              </Collapse>
            ))}
          </Box>
        </form>
      </div>
    </div>
  );
};

export default WebO0030;
