import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebS0120ListPage.scss';
import { DBManager, STORAGE_KEY_SHONIN_KOKYAKU, shoninKokyaku } from 'app/shared/util/construction-list';
import { Column, Formatter } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import dayjs from 'dayjs';
import WebS0120SearchDialog from './SearchDialog/WebS0120SearchDialog';

const WebS0120ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const LinkFormatter: Formatter = (_, __, value) => {
    return value ? `<a style="text-decoration: underline">あり</a>` : '';
  };
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 48,
      sortable: true,
      filterable: true,
      cssClass: 'center',
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      sortable: true,
      filterable: true,
      minWidth: 100,
      cssClass: 'left',
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'torihikisakiKbn',
      name: '取引先区分',
      field: 'torihikisakiKbn',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'gyomuGyoshu',
      name: '業務・業種',
      field: 'gyomuGyoshu',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'daihyoshaName',
      name: '代表者名',
      field: 'daihyoshaName',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      width: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 100,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 70,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const handleSearch = values => {
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sagyouInList = DBManager.getShoninKokyaku();
    if (sagyouInList.length === 0) {
      sagyouInList = shoninKokyaku(500);
      // 番号作成
      sagyouInList = sagyouInList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem(STORAGE_KEY_SHONIN_KOKYAKU, JSON.stringify(sagyouInList));
    }
    setRowData(sagyouInList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('承認一覧（顧客管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0120-list" id="WebS0120-list-container">
        <div className="top-operation">
          <div>
            <WebS0120SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO:正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0120ListPage;
