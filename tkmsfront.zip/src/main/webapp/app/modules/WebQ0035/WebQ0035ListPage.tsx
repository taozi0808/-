import React, { useState, useRef, useEffect } from 'react';
import { Button, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebQ0035ListPage.scss';
import '../../app.scss';
import dayjs from 'dayjs';
import { DBManager, sagyouInMeiboData } from 'app/shared/util/construction-list';
import WebQ0035SearchDialog from './SearchDialog/WebQ0035SearchDialog';
import { Column, Filters } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
const WebQ0035ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 48,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    { id: 'genbaCode', name: '現場コード', field: 'genbaCode', minWidth: 160, sortable: true, filterable: true },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      width: 298,
      sortable: true,
      filterable: true,
    },
    { id: 'senninGijutsuMono', name: '専任技術者', field: 'senninGijutsuMono', width: 230, sortable: true, filterable: true },
    {
      id: 'genbaChakushuNichi',
      name: '現場着手日',
      field: 'genbaChakushuNichi',
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
    {
      id: 'genbaBikiWataruNichi',
      name: '現場引渡日',
      field: 'genbaBikiWataruNichi',
      minWidth: 150,
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      filterable: true,
      filter: { model: Filters.compoundDate },
      cssClass: 'text-align-right',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');

  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };
    console.log('params', params);

    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let genbaList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY998');
    // const genbaList = generatGyoushaData(500);
    if (genbaList.length === 0) {
      genbaList = sagyouInMeiboData(500);
      // 番号作成
      genbaList = genbaList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY998', JSON.stringify(genbaList));
    }
    console.log('genbaList', genbaList);
    setRowData(genbaList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('現場一覧');
    return () => setPageTitle('');
  }, []);
  return (
    <div>
      <div className="webQ0035-list" id="webQ0035-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/webQ0036`);
              }}
            >
              業者一覧
            </Button>
          </div>
          <div>
            <WebQ0035SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>
        <div>
          <Typography
            sx={{
              fontSize: '16px',
              display: 'block', // ブロックレベル要素に変更
              paddingLeft: '20px',
              lineHeight: '24px', // 行の高さをコンテナの高さに合わせて設定します
              alignItems: 'center',
            }}
          >
            凡例:
            <Box
              component="span"
              sx={{
                display: 'inline-block',
                verticalAlign: 'middle',
                width: 60,
                height: 20,
                bgcolor: '#FF6666',
                ml: 1, // 左側空白
                mr: 1, // 右側空白
                mb: '4px',
                border: '1px solid #333',
              }}
            />
            で表示されている行は下請書類が未提出の現場です。
          </Typography>
        </div>
        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '業者一覧',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webQ0010`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebQ0035ListPage;
