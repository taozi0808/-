import React, { FC, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebT0020CreateForm.scss';
import dayjs from 'dayjs';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, Controller } from 'react-hook-form';
import { Box, TextField, Button } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, sagyouInMeiboData } from 'app/shared/util/construction-list';

const WebT0020CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('現場情報');
    return () => setPageTitle('');
  }, [setPageTitle]);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<CustomerManagementFormValues>({
    defaultValues: {
      genbaCode: '',
      genbaName: '',
      genbaCanaName: '',
      genbaShochou: '',
      genbaShunin: '',
      genbaTantou: '',
      shochouPhone: '',
      shuninPhone: '',
      tantouPhone: '',
      yuubinBangou: '',
      genbaJuusho: '',
      genbaJimushoJuusho: '',
      shikichiMensekiPart1: '',
      shikichiMensekiPart2: '',
      kenchikuMensekiPart1: '',
      kenchikuMensekiPart2: '',
      enyukaMensekiPart1: '',
      enyukaMensekiPart2: '',
      sekouYukaMensekiPart1: '',
      sekouYukaMensekiPart2: '',
      kaisuu: '',
      chika: '',
      kouzouKubun: '',
      genbaChakushuNichi: '',
      genbaBikiWataruNichi: '',
      file1: '',
      file2: '',
      file3: '',
    },
    mode: 'onBlur',
  });

  /** TODO: 「工事行程」*/
  const genbaCodeSearch = () => {};

  // モックデータ
  let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY988');
  // let SagyouInList = DBManager.getList();
  if (sagyouInList.length === 0) {
    sagyouInList = sagyouInMeiboData(500);
    localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY988', JSON.stringify(sagyouInList));
  }

  if (id === undefined) {
    console.log('データ異常');
  } else {
    const editData = sagyouInList.find(item => item.id === id) || null;
    if (editData === null) {
      console.log('データ異常');
    } else {
      useEffect(() => {
        setValue('genbaCode', editData.genbaCode);
        setValue('genbaName', editData.genbaName);
        setValue('genbaCanaName', 'アイウエオ');
        setValue('genbaShochou', '鈴木 太郎');
        setValue('genbaShunin', '高橋 優子');
        setValue('genbaTantou', editData.senninGijutsuMono);
        setValue('shochouPhone', '080-1234-5678');
        setValue('shuninPhone', '080-1234-5678');
        setValue('tantouPhone', '080-1234-5678');
        setValue('yuubinBangou', '123-4567');
        setValue('genbaJuusho', '愛知県名古屋市中村区名駅南1-1-1');
        setValue('genbaJimushoJuusho', '北海道札幌市中央区北1条西1-1-1');
        setValue('shikichiMensekiPart1', '1111');
        setValue('shikichiMensekiPart2', '20');
        setValue('kenchikuMensekiPart1', '2222');
        setValue('kenchikuMensekiPart2', '30');
        setValue('enyukaMensekiPart1', '1111');
        setValue('enyukaMensekiPart2', '20');
        setValue('sekouYukaMensekiPart1', '2222');
        setValue('sekouYukaMensekiPart2', '30');
        setValue('kaisuu', '88');
        setValue('chika', '99');
        setValue('kouzouKubun', 'RC造');
        setValue('genbaChakushuNichi', dayjs(editData.genbaChakushuNichi).format('YYYY年MM月DD日'));
        setValue('genbaBikiWataruNichi', dayjs(editData.genbaBikiWataruNichi).format('YYYY年MM月DD日'));
        setValue('file1', '○○ビル建設工事.PDF');
        setValue('file2', '○○ビル建設工事.PDF');
        setValue('file3', '○○ビル建設工事.PDF');
      }, []);
    }
  }

  const renderTextField = (label: string, name: keyof CustomerManagementFormValues, required: boolean = false) => (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Box display="flex">
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
          />
        </Box>
      )}
    />
  );

  return (
    <div>
      <div className="webt0020-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <Button
              variant="contained"
              size="small"
              style={{ margin: '8px 0', minWidth: 96 }}
              onClick={() => {
                navigate(`/webT0010`);
              }}
            >
              閉じる
            </Button>
          </div>

          <Box display="flex" sx={{ mb: 2 }}>
            <Controller
              name="genbaCode"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex" sx={{ width: '45%' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場コード</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                  <Button
                    variant="contained"
                    size="small"
                    style={{ marginTop: 4, marginBottom: 4, left: '40px', minWidth: 90, maxHeight: '40px' }}
                    onClick={genbaCodeSearch}
                  >
                    工事行程
                  </Button>
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('現場名', 'genbaName')}
            {renderTextField('現場カナ名', 'genbaCanaName')}
          </Box>

          <Box sx={{ maxWidth: '100%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="genbaShochou"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場所長</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="genbaShunin"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場主任</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="genbaTantou"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場担当</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ maxWidth: '100%', padding: 0, display: 'flex', mb: 2 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name="shochouPhone"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>所長電話番号</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="shuninPhone"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>主任電話番号</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name="tantouPhone"
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ display: 'flex', flex: 1, p: 2, padding: '0px' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>担当電話番号</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2, width: '33.4%' }}>
            {renderTextField('郵便番号', 'yuubinBangou')}
          </Box>

          <Box sx={{ mb: 2, maxWidth: '69%' }}>
            <Controller
              name="genbaJuusho"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場住所</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                </Box>
              )}
            />
          </Box>

          <Box sx={{ mb: 2, maxWidth: '81%' }}>
            <Controller
              name="genbaJimushoJuusho"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>現場事務所住所</Box>
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '100%',
                    }}
                  />
                  <Button
                    variant="contained"
                    size="small"
                    style={{ marginTop: 4, marginBottom: 4, left: '20px', minWidth: 115, maxHeight: '40px', textTransform: 'none' }}
                    onClick={genbaCodeSearch}
                  >
                    Googleマップ
                  </Button>
                </Box>
              )}
            />
          </Box>

          <Box display="flex" sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="shikichiMensekiPart1"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '100%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>敷地面積</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>㎡</Box>
                  </Box>
                )}
              />
              <Controller
                name="shikichiMensekiPart2"
                control={control}
                render={({ field, fieldState }) => (
                  <div style={{ display: 'flex' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>坪</Box>
                  </div>
                )}
              />
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="kenchikuMensekiPart1"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '100%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>建築面積</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>㎡</Box>
                  </Box>
                )}
              />
              <Controller
                name="kenchikuMensekiPart2"
                control={control}
                render={({ field, fieldState }) => (
                  <div style={{ display: 'flex' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>坪</Box>
                  </div>
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="enyukaMensekiPart1"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '100%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>延床面積</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>㎡</Box>
                  </Box>
                )}
              />
              <Controller
                name="enyukaMensekiPart2"
                control={control}
                render={({ field, fieldState }) => (
                  <div style={{ display: 'flex' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>坪</Box>
                  </div>
                )}
              />
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="sekouYukaMensekiPart1"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '100%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>施工床面積</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>㎡</Box>
                  </Box>
                )}
              />
              <Controller
                name="sekouYukaMensekiPart2"
                control={control}
                render={({ field, fieldState }) => (
                  <div style={{ display: 'flex' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>坪</Box>
                  </div>
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="kaisuu"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '28.8%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>階数</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>階</Box>
                  </Box>
                )}
              />
              <Controller
                name="chika"
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex" sx={{ width: '20.5%' }}>
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 50, lineHeight: '40px', textAlign: 'center' }}>地下</Box>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 30, lineHeight: '40px', textAlign: 'center' }}>階</Box>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2, width: '34.5%' }}>
            {renderTextField('構造区分', 'kouzouKubun')}
          </Box>

          <Box display="flex" sx={{ mb: 2, width: '69%' }} className="input-textAlign">
            {renderTextField('現場着手日', 'genbaChakushuNichi')}
            {renderTextField('現場引渡日', 'genbaBikiWataruNichi')}
          </Box>

          <Box sx={{ width: '66.8%' }}>
            <div className="file-color">
              {renderTextField('添付ファイル', 'file1')}
              {renderTextField('', 'file2')}
              {renderTextField('', 'file3')}
            </div>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebT0020CreateForm;
