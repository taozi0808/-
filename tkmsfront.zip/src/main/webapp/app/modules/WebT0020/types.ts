/** 定义表单各字段的数据类型 */
export interface CustomerManagementFormValues {
  genbaCode: string;
  genbaName: string;
  genbaCanaName: string;
  genbaShochou: string;
  genbaShunin: string;
  genbaTantou: string;
  shochouPhone: string;
  shuninPhone: string;
  tantouPhone: string;
  yuubinBangou: string;
  genbaJuusho: string;
  genbaJimushoJuusho: string;
  shikichiMensekiPart1: string;
  shikichiMensekiPart2: string;
  kenchikuMensekiPart1: string;
  kenchikuMensekiPart2: string;
  enyukaMensekiPart1: string;
  enyukaMensekiPart2: string;
  sekouYukaMensekiPart1: string;
  sekouYukaMensekiPart2: string;
  kaisuu: string;
  chika: string;
  kouzouKubun: string;
  genbaChakushuNichi: string;
  genbaBikiWataruNichi: string;
  file1: string;
  file2: string;
  file3: string;
}
