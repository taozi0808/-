import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebF0030CreateForm.scss';
import dayjs from 'dayjs';
import { useLocation } from 'react-router-dom';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { DialogContent, TextField, Button, Box, Select, Collapse, MenuItem, Tab, Tabs } from '@mui/material';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import LastUpdateInfo from 'app/components/LastUpdateInfo';

const WebF0030CreateForm = () => {
  const navigate = useNavigate();
  const notify = useNotify();
  const gridRef = useRef();
  const location = useLocation();
  const { state } = location;
  const { param1 } = state || {};
  const { setPageTitle } = usePageTitleStore();
  const dateFormat = 'YYYY/MM/DD';
  const [divs, setDivs] = useState([]);
  const { id, type } = useParams();
  const [value1, setValue1] = React.useState('one');
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(false);

  const handleChangevalue1 = (event: React.SyntheticEvent, newValue: string) => {
    setValue1(newValue);
  };

  const { control, handleSubmit, setValue } = useForm({
    defaultValues: {
      field1: '',
      field2: '',
      field3: '',
      field4: '',
      field5: '',
      field6: '',
      field7: '',
      field8: '',
      field9: '',
      field10: '',
      field11: '',
      field12: '',
      field13: '',
      field14: '',
      field15: '',
      field16: '',
      field17: '',
      field18: '',
      field19: '',
      field20: '',
      field21: '',
      field22: '',
      field23: '',
      field24: '',
      field25: '',
      field26: '',
      field27: '',
      field28: '',
      field29: '',
      field30: '',
      field31: '',
      field32: '',
      field33: '',
      field34: '',
      field35: '',
      field36: '',
      field37: '',
      field38: '',
      field39: '',
      field40: '',
      field41: '',
      field42: '',
      field43: '',
      field44: '',
      field45: '',
      field46: '',
      field47: '',
      field48: '',
      field49: '',
      field50: '',
      field51: '',
      field52: '',
      field53: '',
      field54: '',
      field55: '',
      field56: '',
      field57: '',
      field58: '',
      field59: '',
      field60: '',
      field61: '',
      field62: '',
      items: [{ value: '' }],
      items1: [{ value: '' }],
      items2: [{ value: '' }],
      items3: [{ value: '' }],
      items4: [{ value: '' }],
      items5: [{ value: '' }],
      items6: [{ value: '' }],
      items7: [{ value: '' }],
      items8: [{ value: '' }],
      items9: [{ value: '' }],
    },
  });

  const onDeleteRemove = (index: number, name: string) => {
    if (name === 'items') {
      removeitems(index);
    } else if (name === 'items4') {
      remove4(index);
    } else {
      remove3(index);
    }
  };

  // 添加/削除行
  const {
    fields: fieldsitems,
    append: appenditems,
    remove: removeitems,
  } = useFieldArray({
    control,
    name: 'items',
  });

  // 添加/削除行
  const {
    fields: fields1,
    append: append1,
    remove: remove1,
  } = useFieldArray({
    control,
    name: 'items1',
  });

  // 添加/削除行
  const {
    fields: fields2,
    append: append2,
    remove: remove2,
  } = useFieldArray({
    control,
    name: 'items2',
  });
  // 添加/削除行
  const {
    fields: fields3,
    append: append3,
    remove: remove3,
  } = useFieldArray({
    control,
    name: 'items3',
  });
  // 添加/削除行
  const {
    fields: fields4,
    append: append4,
    remove: remove4,
  } = useFieldArray({
    control,
    name: 'items4',
  });

  useEffect(() => {
    if (id) {
      if (type === 'preview') {
        setIsHensyuuKengen(true);
      }
      // 示例数据
      setValue('field1', '0001');
      setValue('field2', '0008');
      setValue('field3', '京東区04-5-6');
      setValue('field4', 'ビル5F');
      setValue('field5', '2024-09-10');
      setValue('field6', '1');
      setValue('field7', '90');
      setValue('field8', '12');
      setValue('field9', '12');
      setValue('field10', '12');
      setValue('field21', '0001');
      setValue('field22', '0008');
      setValue('field23', '京東区04-5-6');
      setValue('field24', 'ビル5F');
      setValue('field25', '1');
      setValue('field26', '2024-09-10');
      setValue('field27', '90');
      setValue('field28', '12');
      setValue('field29', '12');
      setValue('field30', '12');
      setValue('field31', '0001');
      setValue('field32', '0008');
      setValue('field33', '京東区04-5-6');
      setValue('field34', 'ビル5F');
      setValue('field35', '1');
      setValue('field36', '2024-09-10');
      setValue('field37', '90');
      setValue('field38', '12');
      setValue('field39', '12');
      setValue('field40', '12');
      setValue('field41', '0001');
      setValue('field42', '0008');
      setValue('field43', '京東区04-5-6');
      setValue('field44', 'ビル5F');
      setValue('field45', '1');
      setValue('field46', '2024-09-10');
      setValue('field47', '90');
      setValue('field48', '12');
      setValue('field49', '12');
      setValue('field50', '12');
      setValue('field51', '0001');
      setValue('field52', '0008');
      setValue('field53', '京東区04-5-6');
      setValue('field54', 'ビル5F');
      setValue('field55', '1');
      setValue('field56', '2024-09-10');
      setValue('field57', '90');
      setValue('field58', '12');
      setValue('field59', '12');
      setValue('field60', '12');
      setValue('field61', '0001');
      setValue('field62', '0008');
    }
    setPageTitle('物件登録');
    return () => setPageTitle('');
  }, []);

  // 保存
  const onFinish = values => {
    // notify('正常に保存されました');
    navigate('/webF0010');
  };
  // クリア
  const onClear = record => {
    // notify('画面を初期化します。よろしいでしょうか？');
    setValue('field1', '0001');
    setValue('field2', '0008');
    setValue('field3', '京東区04-5-6');
    setValue('field4', 'ビル5F');
    setValue('field5', '2024-09-10');
    setValue('field6', '1');
    setValue('field7', '90');
    setValue('field8', '12');
    setValue('field9', '12');
    setValue('field10', '12');
    setValue('field21', '0001');
    setValue('field22', '0008');
    setValue('field23', '京東区04-5-6');
    setValue('field24', 'ビル5F');
    setValue('field25', '1');
    setValue('field26', '2024-09-10');
    setValue('field27', '90');
    setValue('field28', '12');
    setValue('field29', '12');
    setValue('field30', '12');
    setValue('field31', '0001');
    setValue('field32', '0008');
    setValue('field33', '京東区04-5-6');
    setValue('field34', 'ビル5F');
    setValue('field35', '1');
    setValue('field36', '2024-09-10');
    setValue('field37', '90');
    setValue('field38', '12');
    setValue('field39', '12');
    setValue('field40', '12');
    setValue('field41', '0001');
    setValue('field42', '0008');
    setValue('field43', '京東区04-5-6');
    setValue('field44', 'ビル5F');
    setValue('field45', '1');
    setValue('field46', '2024-09-10');
    setValue('field47', '90');
    setValue('field48', '12');
    setValue('field49', '12');
    setValue('field50', '12');
    setValue('field51', '0001');
    setValue('field52', '0008');
    setValue('field53', '京東区04-5-6');
    setValue('field54', 'ビル5F');
    setValue('field55', '1');
    setValue('field56', '2024-09-10');
    setValue('field57', '90');
    setValue('field58', '12');
    setValue('field59', '12');
    setValue('field60', '12');
    setValue('field61', '0001');
    setValue('field62', '0008');
  };

  // 削除
  const onDelete = record => {
    // notify('該当データを削除します。よろしいでしょうか？', 'warning');
    navigate('/webF0010');
  };

  // キャンセル
  const onCancel = record => {
    // notify('未保存の編集内容を破棄して呼び出し元の画面に遷移します。よろしいでしょうか？', 'warning');
    navigate('/webF0010');
  };

  return (
    <div>
      <DialogContent className="webF0030-container">
        <div className="top" style={{ display: id ? '' : 'none' }}>
          <div className="top-item">
            <LastUpdateInfo userId={'J123456789012'} userName={'田中　花子'} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【最終更新日】'}</div>
              <div>{`2024/02/01`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={onFinish}
              disabled={isHensyuuKengen}
            >
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              申請
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={onClear}
              disabled={isHensyuuKengen}
            >
              クリア
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={onDelete}
              disabled={isHensyuuKengen}
            >
              削除
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCancel}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              印刷
            </Button>
          </div>
        </div>
        <form>
          <Box display="flex" flexDirection="column" gap={2} className="ad-search-WebF0030">
            {/*  物件コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box display="flex" flex={3}>
                {/* <Box> 案件連携*/}
                <Box flex={1}>
                  <Controller
                    name="field1"
                    disabled={isHensyuuKengen}
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>物件コード</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field2"
                    disabled={isHensyuuKengen}
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>案件連携</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1} className="ad-search-item">
                  <div className="ad-search-item1">
                    <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
                      連携
                    </Button>
                    <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
                      解除
                    </Button>
                  </div>
                </Box>
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  物件名*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field3"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>物件名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  物件カナ名*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field4"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>物件カナ名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/* 受注日付 */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1}>
                <Controller
                  name="field5"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '受注日付が入力されていません。' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>受注日付</label>
                      <TextField
                        {...field}
                        size="small"
                        fullWidth
                        type="date"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
            {/*  郵便番号*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <Box flex={2}>
                  <Controller
                    name="field6"
                    control={control}
                    disabled={isHensyuuKengen}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>郵便番号</label>
                        <TextField {...field} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={2}>
                  <Controller
                    name="field7"
                    control={control}
                    disabled={isHensyuuKengen}
                    render={({ field }) => (
                      <div className="ad-search-item1">
                        <label>-</label>
                        <TextField {...field} size="small" />
                        <Button variant="contained" size="small" style={{ left: '10px', minWidth: 90 }} disabled={isHensyuuKengen}>
                          住所検索
                        </Button>
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}></Box>
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  物件住所*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field8"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>物件住所</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  該当エリア*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1}>
                <Controller
                  name="field9"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>該当エリア</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
            {/*  顧客コード*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={1} display="flex">
                <Controller
                  name="field10"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>顧客コード</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="field11"
                  control={control}
                  disabled
                  render={({ field }) => (
                    <div className="ad-search-item2" style={{ width: '100%' }}>
                      <label>顧客名</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  郵便番号*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <Box flex={2}>
                  <Controller
                    name="field12"
                    disabled={isHensyuuKengen}
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>郵便番号</label>
                        <TextField {...field} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={2}>
                  <Controller
                    name="field13"
                    control={control}
                    disabled={isHensyuuKengen}
                    render={({ field }) => (
                      <div className="ad-search-item1" style={{ minWidth: '53%', maxWidth: '47%' }}>
                        <label>-</label>
                        <TextField {...field} size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}></Box>
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  顧客住所*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field14"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>顧客住所</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  営業部門*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field15"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>営業部門</label>
                      <Select {...field} size="small" style={{ width: '38%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/* 営業管理職 */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field16"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>営業管理職</label>
                      <Select {...field} size="small" style={{ width: '56%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field17"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>営業担当者</label>
                      <Select {...field} size="small" style={{ width: '56%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  工事担当部門*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={3}>
                <Controller
                  name="field18"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>工事担当部門</label>
                      <Select {...field} size="small" style={{ width: '70%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            {/*  工事管理職*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field19"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>工事管理職</label>
                      <Select {...field} size="small" style={{ width: '56%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
              <Box flex={2}></Box>
            </Box>

            {/*  現場所長*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2}>
                <Controller
                  name="field20"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>現場所長</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field21"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>所長代理</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}>
                <Controller
                  name="field22"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>副所長</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  現場主任*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field23"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>現場主任</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field24"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>現場担当１</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field25"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <label>現場担当２</label>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/*  専任技術者*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <label>専任技術者</label>
              </Box>
            </Box>
            {/*  従業開始日*/}
            <Box display="flex" justifyContent="space-between" paddingLeft={'110px'}>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                従業開始日
              </Box>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                従業終了日
              </Box>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                担当者
              </Box>
              <Box flex={1}></Box>
              <Box flex={1}></Box>
            </Box>
            <Box display="flex" justifyContent="space-between" paddingLeft={'110px'}>
              <Box flex={1}>
                <Controller
                  name="field26"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}>
                <Controller
                  name="field27"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}>
                <Controller
                  name="field28"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <Select {...field} size="small" style={{ width: '100%' }}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={1} className="ad-search-item">
                <Button
                  variant="contained"
                  size="small"
                  style={{ marginRight: '8px', minWidth: 96, left: '12px' }}
                  disabled={isHensyuuKengen}
                >
                  資料添付
                </Button>
              </Box>
              <Box flex={1} className="ad-search-item"></Box>
            </Box>
            {fields1.map((item, index) => (
              <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                <Box display="flex" justifyContent="space-between" className="ad-search-item">
                  {index === fields1.length - 1 ? (
                    <label onClick={() => append1({ value: '' })}>
                      <AddCircleOutlineIcon />
                    </label>
                  ) : (
                    <label></label>
                  )}
                  <Box flex={1}>
                    <Controller
                      name={`items1.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name={`items8.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}>
                    <Controller
                      name={`items9.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <Select {...field} size="small" style={{ width: '100%' }}>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} className="ad-search-item"></Box>
                  <Box flex={1} className="ad-search-item"></Box>
                </Box>
              </Collapse>
            ))}
            {/*  技士*/}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <label>技士補</label>
              </Box>
            </Box>
            {/*  技士*/}
            <Box display="flex" justifyContent="space-between" paddingLeft={'110px'}>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                従業開始日
              </Box>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                従業終了日
              </Box>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                担当者
              </Box>
              <Box flex={1} sx={{ textAlign: 'center' }}>
                特例技術管理者
              </Box>
              <Box flex={1}></Box>
            </Box>
            {fields2.map((item, index) => (
              <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                <Box display="flex" justifyContent="space-between" className="ad-search-item">
                  {index === fields2.length - 1 ? (
                    <label onClick={() => append2({ value: '' })}>
                      <AddCircleOutlineIcon />
                    </label>
                  ) : (
                    <label></label>
                  )}
                  <Box flex={1} className="ad-search-item">
                    <Controller
                      name={`items2.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} className="ad-search-item">
                    <Controller
                      name={`items5.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} className="ad-search-item">
                    <Controller
                      name={`items6.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} className="ad-search-item" mr={2}>
                    <Controller
                      name={`items7.${index}.value`}
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1} className="ad-search-item">
                    <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
                      資料添付
                    </Button>
                  </Box>
                </Box>
              </Collapse>
            ))}
            {/* 設計業者 */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>設計業者</label>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field29"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box
                flex={2}
                className="ad-search-item"
                sx={{ textAlign: 'center', flexDirection: 'row-reverse', alignItems: 'center', paddingRight: '8px' }}
              >
                設計担当者
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field30"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item"></Box>
              <Box flex={2} className="ad-search-item"></Box>
            </Box>
            {/* 官民区分 */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>官民区分</label>
              <Box flex={1} className="ad-search-item">
                <Controller
                  name="field31"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={4}></Box>
            </Box>
            {/* 物件着手日 */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>物件着手日</label>
              <Box flex={2}>
                <Controller
                  name="field32"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box
                flex={2}
                className="ad-search-item"
                sx={{ textAlign: 'center', flexDirection: 'row-reverse', alignItems: 'center', paddingRight: '8px' }}
              >
                物件引渡日
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field33"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
              <Box flex={2}></Box>
            </Box>
            {/* 敷地面積 */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>敷地面積</label>
              <Box flex={2}>
                <Controller
                  name="field34"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field35"
                  control={control}
                  disabled
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item"></Box>
              <Box flex={2} className="ad-search-item"></Box>
              <Box flex={2} className="ad-search-item"></Box>
            </Box>
            {/* 用途地域 */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>用途地域</label>
              <Box flex={2}>
                <Controller
                  name="field36"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box
                flex={2}
                className="ad-search-item"
                sx={{ textAlign: 'center', flexDirection: 'row-reverse', alignItems: 'center', paddingRight: '8px' }}
              >
                防火地域
              </Box>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field37"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '100%' }}>
                      <Select {...field} size="small" fullWidth>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} className="ad-search-item"></Box>
              <Box flex={2} className="ad-search-item"></Box>
            </Box>
            {/* 添付ファイル（物件） */}
            <Box display="flex" justifyContent="space-between">
              <Box flex={2} className="ad-search-item">
                <label>添付ファイル（物件）</label>
              </Box>
            </Box>
            {fieldsitems.map((item, index) => (
              <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                <Box display="flex" justifyContent="space-between">
                  <Box flex={3} className="ad-search-item" mr={2}>
                    {index === fieldsitems.length - 1 ? (
                      <label onClick={() => appenditems({ value: '' })}>
                        <AddCircleOutlineIcon />
                      </label>
                    ) : (
                      <label></label>
                    )}
                    <Controller
                      name={`items.${index}.value`}
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item" style={{ width: '100%' }}>
                          <Select {...field} size="small" fullWidth>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                          </Select>
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={2} className="ad-search-item">
                    <Button
                      variant="contained"
                      size="small"
                      disabled={isHensyuuKengen}
                      style={{ marginRight: '8px', minWidth: 96 }}
                      onClick={() => onDeleteRemove(index, 'items')}
                    >
                      削除
                    </Button>
                  </Box>
                </Box>
              </Collapse>
            ))}
            {/* 請負合計金額（税抜） */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>請負合計金額（税抜）</label>
              <Box className="ad-search-item" flex={3}>
                {/* <Box> 案件連携*/}
                <Box flex={1}>
                  <Controller
                    name="field38"
                    disabled
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}>
                  <Controller
                    name="field39"
                    disabled
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <label>消費税合計金額</label>
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/* 請負合計金額（税込） */}
            <Box display="flex" justifyContent="space-between" className="ad-search-item">
              <label>請負合計金額（税込）</label>
              <Box flex={3} className="ad-search-item">
                {/* <Box> 案件連携*/}
                <Box flex={1}>
                  <Controller
                    name="field40"
                    disabled
                    control={control}
                    render={({ field }) => (
                      <div className="ad-search-item">
                        <TextField {...field} fullWidth size="small" />
                      </div>
                    )}
                  />
                </Box>
                <Box flex={1}></Box>
              </Box>
              <Box flex={2}></Box>
            </Box>
            {/* */}
            <Box flex={1}>
              <Tabs value={value1} onChange={handleChangevalue1} aria-label="wrapped label tabs example">
                <Tab value="one" label="01:A棟工事" wrapped />
                <Tab value="two" label="02:B棟工事" />
                <Tab value="three" label="99:外工事" />
              </Tabs>
            </Box>
            <div style={{ border: '2px solid black', width: '100%' }} className="add-WebF00301">
              <div className="top-operation">
                <div>
                  <Button
                    variant="contained"
                    size="small"
                    style={{ marginRight: '8px', minWidth: 96 }}
                    onClick={onFinish}
                    disabled={isHensyuuKengen}
                  >
                    保存
                  </Button>
                  <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
                    申請
                  </Button>
                  <Button
                    variant="contained"
                    size="small"
                    style={{ marginRight: '8px', minWidth: 96 }}
                    onClick={onClear}
                    disabled={isHensyuuKengen}
                  >
                    クリア
                  </Button>
                </div>
              </div>
              <Box display="flex" flexDirection="column" gap={2} className="ad-search-WebF00301" mb={2}>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    <Box className="ad-search-item" flex={2}>
                      <Controller
                        name="field41"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>現場コード</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  <Box flex={3} className="ad-search-item">
                    <Box flex={2} mr={2}>
                      <Controller
                        name="field42"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>付帯工事</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1} className="ad-search-item">
                      <div className="ad-search-item1">
                        <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
                          追加工事
                        </Button>
                      </div>
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field43"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>現場名</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={3}>
                    <Box flex={1}>
                      <Controller
                        name="field44"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>現場カナ名</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                {/* <Box> 建築面積*/}
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name="field45"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>建築面積</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="field46"
                        control={control}
                        disabled
                        render={({ field }) => (
                          <div className="ad-search-item1">
                            <label>㎡</label>
                            <TextField {...field} size="small" fullWidth />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={3}>
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name="field47"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>延床面積</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="field48"
                        control={control}
                        disabled
                        render={({ field }) => (
                          <div className="ad-search-item1">
                            <label>㎡</label>
                            <TextField {...field} size="small" fullWidth />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    {/* <Box> 現場名*/}
                    <Box flex={1} className="ad-search-item">
                      <Controller
                        name="field49"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>施工床面積</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                      <Controller
                        name="field50"
                        control={control}
                        disabled
                        render={({ field }) => (
                          <div className="ad-search-item1">
                            <label>㎡</label>
                            <TextField {...field} size="small" fullWidth />
                            <label>坪</label>
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={4}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    {/* <Box> 構造区分*/}
                    <Box flex={2}>
                      <Controller
                        name="field51"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>構造区分</label>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem value={10}>Ten</MenuItem>
                              <MenuItem value={20}>Twenty</MenuItem>
                              <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                    <Box flex={1}></Box>
                  </Box>
                  <Box flex={4}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={2}>
                    {/* <Box> 現場名*/}
                    <Box flex={2}>
                      <Controller
                        name="field52"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>現場着手日</label>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem value={10}>Ten</MenuItem>
                              <MenuItem value={20}>Twenty</MenuItem>
                              <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={2} className="ad-search-item">
                    <Box flex={2}>
                      <Controller
                        name="field53"
                        control={control}
                        disabled={isHensyuuKengen}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>引渡日</label>
                            <Select {...field} size="small" style={{ width: '100%' }}>
                              <MenuItem value={10}>Ten</MenuItem>
                              <MenuItem value={20}>Twenty</MenuItem>
                              <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={3}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={2}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field54"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>請負金額（税抜）</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box className="ad-search-item" flex={2}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field55"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>消費税金額</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={2}>
                    <Box flex={1}>
                      <Controller
                        name="field56"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>請負金額（税込）</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={2}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field57"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>実行予算金額（税抜）</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box className="ad-search-item" flex={2}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field58"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>消費税金額</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={2}>
                    <Box flex={1}>
                      <Controller
                        name="field59"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>実行予算金額（税込）</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Box className="ad-search-item" flex={3}>
                    {/* <Box> 現場名*/}
                    <Box flex={1}>
                      <Controller
                        name="field60"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>粗利益額（税込）</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={3}>
                    <Box flex={1}>
                      <Controller
                        name="field61"
                        disabled={isHensyuuKengen}
                        control={control}
                        render={({ field }) => (
                          <div className="ad-search-item">
                            <label>粗利益率</label>
                            <TextField {...field} fullWidth size="small" />
                          </div>
                        )}
                      />
                    </Box>
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                {/*  メモ */}
                <Box display="flex" justifyContent="space-between">
                  <Box flex={6}>
                    <Controller
                      name="field62"
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>メモ</label>
                          <TextField {...field} fullWidth size="small" multiline rows={6} />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                {/* 添付ファイル（社内用） */}
                <Box display="flex" justifyContent="space-between">
                  <Box flex={2} className="ad-search-item">
                    <label>添付ファイル（社内用）</label>
                  </Box>
                </Box>
                {fields3.map((item, index) => (
                  <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                    <Box display="flex" justifyContent="space-between">
                      <Box flex={3} className="ad-search-item" mr={2}>
                        {index === fields3.length - 1 ? (
                          <label onClick={() => append3({ value: '' })}>
                            <AddCircleOutlineIcon />
                          </label>
                        ) : (
                          <label></label>
                        )}
                        <Controller
                          name={`items3.${index}.value`}
                          disabled={isHensyuuKengen}
                          control={control}
                          render={({ field }) => (
                            <div className="ad-search-item" style={{ width: '100%' }}>
                              <Select {...field} size="small" fullWidth>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                              </Select>
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2} className="ad-search-item">
                        <Button
                          variant="contained"
                          size="small"
                          style={{ marginRight: '8px', minWidth: 96 }}
                          onClick={() => onDeleteRemove(index, 'items3')}
                          disabled={isHensyuuKengen}
                        >
                          削除
                        </Button>
                      </Box>
                    </Box>
                  </Collapse>
                ))}
                {/* 添付ファイル（業者用） */}
                <Box display="flex" justifyContent="space-between">
                  <Box flex={2} className="ad-search-item">
                    <label>添付ファイル（業者用）</label>
                  </Box>
                </Box>
                {fields4.map((item, index) => (
                  <Collapse in={true} key={item.id} style={{ display: 'flex' }}>
                    <Box display="flex" justifyContent="space-between">
                      <Box flex={3} className="ad-search-item" mr={2}>
                        {index === fields4.length - 1 ? (
                          <label onClick={() => append4({ value: '' })}>
                            <AddCircleOutlineIcon />
                          </label>
                        ) : (
                          <label></label>
                        )}
                        <Controller
                          name={`items4.${index}.value`}
                          disabled={isHensyuuKengen}
                          control={control}
                          render={({ field }) => (
                            <div className="ad-search-item" style={{ width: '100%' }}>
                              <Select {...field} size="small" fullWidth>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                              </Select>
                            </div>
                          )}
                        />
                      </Box>
                      <Box flex={2} className="ad-search-item">
                        <Button
                          variant="contained"
                          size="small"
                          style={{ marginRight: '8px', minWidth: 96 }}
                          onClick={() => onDeleteRemove(index, 'items4')}
                          disabled={isHensyuuKengen}
                        >
                          削除
                        </Button>
                      </Box>
                    </Box>
                  </Collapse>
                ))}
              </Box>
            </div>
          </Box>
        </form>
      </DialogContent>
    </div>
  );
};

export default WebF0030CreateForm;
