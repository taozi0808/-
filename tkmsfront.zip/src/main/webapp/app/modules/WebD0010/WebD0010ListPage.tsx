import React, { useRef, useEffect, useState } from 'react';
import { Button } from '@mui/material';
import './WebD0010ListPage.scss';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import SearchDialog from './SearchDialog/WebD0010SearchDialog';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { Column, FieldType } from 'slickgrid-react';
import { WebD0010, DBManager, WebD0010List } from 'app/shared/util/construction-list';

const WebD0010ListPage = () => {
  const navigate = useNavigate();
  const [dataSource, setDataSource] = useState([]);
  const gridApi = useRef(null);
  const [selectedRowKey, setSelectedRowKey] = useState(null);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');

  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('精積算一覧');
    return () => setPageTitle('');
  }, [setPageTitle]);

  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });

  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      cssClass: 'center',
      minWidth: 50,
    },
    {
      id: 'seisekisanCode',
      name: '精積算コード',
      field: 'seisekisanCode',
      sortable: true,
      filterable: true,
      minWidth: 150,
      type: FieldType.string,
    },
    {
      id: 'ankenCode',
      name: '案件コード',
      field: 'ankenCode',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanCode',
      name: '概算コード',
      field: 'gaisanCode',
      minWidth: 250,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'ankenName',
      name: '案件名称',
      field: 'ankenName',
      minWidth: 250,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'center-align',
      type: FieldType.string,
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'gaisanKingaku',
      name: '概算金額',
      field: 'gaisanKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        if (val) {
          return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
        } else {
          return '';
        }
      },
      type: FieldType.number,
    },
    {
      id: 'seisekisanKingaku',
      name: '精積算金額',
      field: 'seisekisanKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        if (val) {
          return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
        } else {
          return '';
        }
      },
      type: FieldType.number,
    },
    {
      id: 'juchuYmd',
      name: '作成日/ 修正日',
      field: 'juchuYmd',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
    },
    {
      id: 'chakkouDate',
      name: '承認日',
      field: 'chakkouDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
      type: FieldType.string,
    },
    {
      id: 'name',
      name: '積算担当者',
      field: 'name',
      minWidth: 150,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'busyoName',
      name: '精算担当部門',
      field: 'busyoName',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'align-center',
      headerCssClass: 'center-align',
      type: FieldType.string,
    },
  ]);

  useEffect(() => {
    let contractList = DBManager.getgetWebD0010List();
    // if (contractList.length === 0) {
    //   contractList = WebD0010List(200);
    //   localStorage.setItem(WebD0010, JSON.stringify(contractList));
    // }
    contractList = WebD0010List(200);
    localStorage.setItem(WebD0010, JSON.stringify(contractList));
    setRowData(contractList);
  }, []);

  const handleSearch = (values: any) => {
    let contractList = DBManager.getgetWebD0010List();
    // if (contractList.length === 0) {
    //   contractList = WebD0010List(200);
    //   localStorage.setItem(WebD0010, JSON.stringify(contractList));
    // }
    contractList = WebD0010List(200);
    localStorage.setItem(WebD0010, JSON.stringify(contractList));
    // 検索処理ロジック（一時的）
    const contractList1 = contractList.filter(item => {
      // 案件コード检索
      if (values.field1 && !item.ankenCode.includes(values.field1)) {
        return false;
      }

      // 案件名检索
      if (values.field1 && !item.ankenName.includes(values.field1)) {
        return false;
      }

      // 顧客名检索
      if (values.field2 && !item.kokyakuName.includes(values.field2)) {
        return false;
      }

      // 顧客名检索
      if (values.field2 && !item.kokyakuCode.includes(values.field2)) {
        return false;
      }

      // 概算コード
      if (values.field3 && !item.gaisanCode.includes(values.field3)) {
        return false;
      }

      // 精積算部門
      if (values.field4 && !item.busyoName.includes(values.field4)) {
        return false;
      }

      //  精積算コード field5
      if (values.field5 && !item.seisekisanCode.includes(values.field5)) {
        return false;
      }

      // 積算担当者
      if (values.field6 && !item.name.includes(values.field6)) {
        return false;
      }

      // 検索条件に満たすデータのみ表示する
      return true;
    });
    setRowData(contractList1);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  return (
    <div>
      <div className="WebD0010-container" id="WebD0010-ichiran-container">
        <div className="top-operation">
          <div>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webD0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webD0030/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>
        <div>
          <BasicSlickGridTable
            columns={columnRef.current}
            data={rowData}
            onSelectionChanged={onSelectedRowsChanged}
            enableContextMenu
            contextMenuItems={[
              // TODO: 後期正式に接続する際は、インターフェースからの権限に基づいて右クリックメニューの利用可能性を制御する必要があります。
              {
                title: '編集',
                command: 'edit',
                action: (_, callbackArgs) => {
                  navigate(`/webD0030/edit/${callbackArgs.dataContext.id}`);
                },
              },
              {
                title: '参照',
                command: 'preview',
                action: (_, callbackArgs) => {
                  navigate(`/webD0030/preview/${callbackArgs.dataContext.id}`);
                },
              },
            ]}
          />
        </div>
      </div>
    </div>
  );
};

export default WebD0010ListPage;
