import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import React, { useState, FC, useEffect, useRef, useMemo, useCallback, StrictMode } from 'react';
import { useNavigate } from 'react-router-dom';
import './WebP0030CreateForm.scss';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import AddIcon from '@mui/icons-material/Add';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { DialogContent, TextField, Button, Box } from '@mui/material';
import {
  ColDef,
  ColGroupDef,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);

interface IRow {
  id: string;
  conditionName1: string;
  conditionName2: string;
  conditionName3: string;
  conditionName4: string;
  country: string;
  group: string;
  level: 1 | 2 | 3;
}

/**
 * Web-P-0030
 * 下請登録
 */
const WebP0030CreateForm: FC = () => {
  const navigate = useNavigate();
  const gridRef = useRef();
  const [data, setData] = useState<IRow[]>([
    {
      id: '1',
      conditionName1: '0001',
      conditionName2: '0001-xxx',
      conditionName3: '0001-address',
      conditionName4: '0001-tel',
      country: '0001-repName',
      group: '1',
      level: 1,
    },
    {
      id: '2',
      conditionName1: '0002',
      conditionName2: '0002-xxx',
      conditionName3: '0002-address',
      conditionName4: '0002-tel',
      country: '0002-repName',
      group: '2',
      level: 2,
    },
    {
      id: '3',
      conditionName1: '0003',
      conditionName2: '0003-xxx',
      conditionName3: '0003-address',
      conditionName4: '0003-tel',
      country: '0003-repName',
      group: '3',
      level: 3,
    },
    {
      id: '4',
      conditionName1: '0004',
      conditionName2: '0004-xxx',
      conditionName3: '0004-address',
      conditionName4: '0004-tel',
      country: '0004-repName',
      group: '4',
      level: 1,
    },
    {
      id: '5',
      conditionName1: '0005',
      conditionName2: '0005-xxx',
      conditionName3: '0005-address',
      conditionName4: '0005-tel',
      country: '0005-repName',
      group: '5',
      level: 1,
    },
  ]);
  const [rowData, setRowData] = useState(data);

  const daikushuParams = ['鉄筋工', '配管工', '電気工', '(other)'];
  const defaultColDef = useMemo(() => {
    return {
      // flex: 1,
      editable: true,
    };
  }, []);

  const UserIdNameRender = params => {
    const handleAdd = () => {
      if (params.data.level === 1) {
        const newRow = { ...params.data, level: 2, id: `${parseInt(params.data.id, 10) + 1}` };
        params.addRow(newRow);
      } else {
        const newRow = { ...params.data, level: 3, id: `${parseInt(params.data.id, 10) + 1}` };
        params.addRow(newRow);
      }
    };
    const { level, conditionName1, conditionName2 } = params.data;
    if (level === 1) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <AddIcon onClick={handleAdd} />
          </Box>
          <Box flex={8}>
            <div style={{ height: '30px' }}>{conditionName1}</div>
            <div className="render-cellClass">{conditionName2}</div>
          </Box>
        </div>
      );
    } else if (level === 2) {
      return (
        <div style={{ display: 'flex', width: '100%' }}>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <AddIcon onClick={handleAdd} />
          </Box>
          <Box flex={2} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
            <PlayArrowIcon />
          </Box>
          <Box flex={6}>
            <div style={{ height: '30px' }}>{conditionName1}</div>
            <div className="render-cellClass">{conditionName2}</div>
          </Box>
        </div>
      );
    }
    return (
      <div style={{ display: 'flex', width: '100%' }}>
        <Box flex={2} className="render-button-cellClass"></Box>
        <Box flex={3} display="flex" alignItems="center" justifyContent="center" className="render-button-cellClass">
          <PlayArrowIcon />
        </Box>
        <Box flex={5}>
          <div style={{ height: '30px' }}>{conditionName1}</div>
          <div className="render-cellClass">{conditionName2}</div>
        </Box>
      </div>
    );
  };

  const UserIdNameRender1 = params => {
    const { country, conditionName4 } = params.data;
    return (
      <div style={{ width: '100%' }}>
        <div style={{ width: '100%' }}>
          <div
            style={{
              width: '100%',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottom: '1px solid',
            }}
          >
            {country}
          </div>
          <div style={{ width: '100%', height: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            {conditionName4}
          </div>
        </div>
      </div>
    );
  };
  const headerComponentRender = params => {
    return (
      <div style={{ width: '100%' }}>
        <div style={{ width: '100%' }}>
          <div
            style={{
              width: '100%',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottom: '1px solid',
            }}
          >
            業者コード-業者支店コード
          </div>
          <div style={{ width: '100%', height: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            業者名‐業者支店名
          </div>
        </div>
      </div>
    );
  };

  const headerComponentRender1 = params => {
    return (
      <div style={{ width: '100%' }}>
        <div style={{ width: '100%' }}>
          <div
            style={{
              width: '100%',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottom: '1px solid',
            }}
          >
            電話番号
          </div>
          <div style={{ width: '100%', height: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>代表者名</div>
        </div>
      </div>
    );
  };

  const sortData = (dataList: IRow[]) => {
    const dataList1 = [...dataList].sort((a, b) => {
      if (a.group < b.group) return -1;
      if (a.group > b.group) return 1;
      if (a.level < b.level) return -1;
      if (a.level > b.level) return 1;
      return parseInt(a.id, 10) - parseInt(b.id, 10);
    });
    for (let i = 0; i < dataList1.length; i++) {
      dataList1[i].id = i + 1 + '';
    }
    return dataList1;
  };

  const columnRef = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      width: 100,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '業者コード-業者支店コード',
      headerComponent: headerComponentRender,
      field: 'conditionName1',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      width: 250,
      cellRenderer: UserIdNameRender,
      cellRendererParams: {
        addRow: row => {
          setData(prev => {
            const newData = [...prev, row];
            return sortData(newData);
          });
        },
      },
    },
    {
      headerName: '住所',
      field: 'conditionName3',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      // spanRows: true,
      width: 360,
    },
    {
      headerName: '電話番号',
      field: 'conditionName4',
      headerComponent: headerComponentRender1,
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header header-padding',
      cellClass: 'center-cell header-padding',
      width: 150,
      cellRenderer: UserIdNameRender1,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  // 画面名
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('下請登録');
    return () => setPageTitle('');
  }, []);

  // 保存
  const onSave = values => {
    navigate('/webP0010');
  };

  // キャンセル
  const onCancel = () => {
    navigate('/webP0010');
  };

  // 印刷
  const onPrint = values => {
    navigate('/webP0010');
  };

  return (
    <div>
      <div className="webp0030-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
            <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onSave}>
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onCancel}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onPrint}>
              印刷
            </Button>
          </div>
        </div>
        <div
          className="ag-theme-alpine column-group-table"
          style={{
            padding: 16,
            width: 'auto',
            height: '76%', // 动态设置高度
            overflowY: 'auto', // 确保显示垂直滚动条
          }}
        >
          <AgGridReact
            rowData={data}
            theme={AGGridTheme}
            columnDefs={columnRef.current}
            headerHeight={60}
            rowHeight={60}
            defaultColDef={defaultColDef}
            suppressCellFocus={true}
          />
        </div>
      </div>
    </div>
  );
};
export default WebP0030CreateForm;
