import React, { FC, useEffect, useState } from 'react';
import './WebR0060CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import { Box, TextField, Select, MenuItem, Button, FormHelperText } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import Table from './Table';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, STORAGE_KEY_CUSTOMER, generatCustomerData } from 'app/shared/util/construction-list';
import useAccountStore from 'app/shared/zustandStore/account';

const tableData = [
  {
    bukkenCode: 'BKK-1001',
    bukkenName: '物件A',
    chumonShoNumber: 'CHU-202301',
    juchuKingaku: 500000,
    nyukinKingaku: 200000,
    hatchuHikiwatashiTanka: '1000円',
    status: '契約中',
    keiyakuBi: '2023-01-15',
    saishuBi: '2023-12-31',
  },
  {
    bukkenCode: 'BKK-1002',
    bukkenName: '物件B',
    chumonShoNumber: 'CHU-202302',
    juchuKingaku: 800000,
    nyukinKingaku: 400000,
    hatchuHikiwatashiTanka: '1200円',
    status: '完了',
    keiyakuBi: '2023-02-01',
    saishuBi: '2023-11-30',
  },
];

const bankFieldErrorMap = {
  bankName: '銀行名が入力されていません。',
  branchName: '支店名が入力されていません。',
  depositType: '預金種別が登録されていません。',
  accountNumber: '口座番号が登録されていません。',
  accountHolder: '口座名義が登録されていません。',
};

const WebR0060CreateForm: FC = () => {
  const { id, type } = useParams();
  const [internalType, setInternalType] = useState(type);
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const notify = useNotify();
  const { userName, setUserCode } = useAccountStore();

  // 更精确的字段名提取
  type StringFieldNames<T> = keyof {
    [K in keyof T as T[K] extends string ? K : never]: never;
  };

  // 应用到您的表单类型
  type CustomerStringFields = StringFieldNames<CustomerManagementFormValues>;

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setError,
  } = useForm<CustomerManagementFormValues>({
    defaultValues: {
      customerCode: '',
      customerName: '',
      customerShortName: '',
      customerKana: '',
      managerName: '',
      managerKana: '',
      transactionType: '',
      postalCodePart1: '',
      postalCodePart2: '',
      phone: {
        part1: '',
        part2: '',
        part3: '',
      },
      mobile: {
        part1: '',
        part2: '',
        part3: '',
      },
      fax: {
        part1: '',
        part2: '',
        part3: '',
      },

      bankName: '',
      branchName: '',
      depositType: '',
      accountNumber: '',
      accountHolder: '',

      capital: '',
      numberOfEmployees: '',
      industry: '',
      representativeName: '',
      companyUrl: '',
      remarks: '',
    },
    mode: 'onBlur',
  });

  const transactionTypeMap = new Map([
    ['10', '売上取引'],
    ['20', '仕入取引'],
    ['30', '経費取引'],
    ['40', '固定資産取引'],
    ['50', '金融取引'],
  ]);

  /** TODO: 点击「住所検索」按钮时的处理逻辑示例（可根据需要实现） */
  const handleAddressSearch = () => {};

  /** TODO: 保存按钮提交时的处理逻辑 */
  const onSave: SubmitHandler<CustomerManagementFormValues> = data => {
    console.log('表单提交结果:', data);

    // 账户信息校验，只要输入了其中一个字段，那么其余字段都要输入，若其余字段未输入，则提示。
    const emptyFieldList = [];
    for (const key in bankFieldErrorMap) {
      if (data[key] === '') {
        emptyFieldList.push(key);
      }
    }

    if (emptyFieldList.length > 0 && emptyFieldList.length !== Object.keys(bankFieldErrorMap).length) {
      emptyFieldList.forEach((key: keyof CustomerManagementFormValues) => {
        setError(key, { type: 'custom', message: bankFieldErrorMap[key] });
      });
      notify('口座情報入力にエラーがあります', 'warning');
      return;
    }
    alert('保存成功！');
  };

  const handleCancel = () => {
    // notify('K00004', 'warning');
    navigate('/webR0055');
    // setOpen(true);
  };

  useEffect(() => {
    if (id) {
      const data = DBManager.getItemByCustomerId(id);

      const formatPhoneObject = (phoneStr: string) => {
        const [part1 = '', part2 = '', part3 = ''] = phoneStr.split('-');
        return { part1, part2, part3 };
      };

      console.log('reset开始:', data);
      reset({ ...data, phone: formatPhoneObject(data.phone), mobile: formatPhoneObject(data.mobile), fax: formatPhoneObject(data.fax) });
    } else {
      reset({} as CustomerManagementFormValues); // 新规
    }
  }, [reset]);

  const renderTextField = (label: string, name: keyof CustomerManagementFormValues, required: boolean = false) => (
    <Controller
      name={name}
      control={control}
      rules={required ? { required: `${label}が入力されていません。` } : {}}
      render={({ field, fieldState }) => (
        <Box display="flex">
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 80, lineHeight: '40px' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            disabled={internalType === 'preview'}
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
          />
        </Box>
      )}
    />
  );

  const renderPhoneField = (label: string, name: string, required: boolean = false) => (
    <Box display="flex" sx={{ mb: 2, maxWidth: '60%' }}>
      <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 80, lineHeight: '40px' }}>{label}</Box>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
        <Controller
          name={`${name}.part1` as keyof CustomerManagementFormValues}
          control={control}
          rules={{ required: required ? `${label}が入力されていません` : false }}
          render={({ field, fieldState }) => (
            <TextField
              {...field}
              size="small"
              error={!!fieldState.error}
              helperText={fieldState.error ? fieldState.error.message : ''}
              disabled={internalType === 'preview'}
              sx={{
                width: '32%',
              }}
            />
          )}
        />
        <span>-</span>
        <Controller
          name={`${name}.part2` as keyof CustomerManagementFormValues}
          control={control}
          rules={{ required: required ? `${label}が入力されていません` : false }}
          render={({ field, fieldState }) => (
            <TextField
              {...field}
              size="small"
              error={!!fieldState.error}
              helperText={fieldState.error ? fieldState.error.message : ''}
              disabled={internalType === 'preview'}
              sx={{
                width: '32%',
              }}
            />
          )}
        />
        <span>-</span>
        <Controller
          name={`${name}.part3` as keyof CustomerManagementFormValues}
          control={control}
          rules={{ required: required ? `${label}が入力されていません` : false }}
          render={({ field, fieldState }) => (
            <TextField
              {...field}
              size="small"
              error={!!fieldState.error}
              helperText={fieldState.error ? fieldState.error.message : ''}
              disabled={internalType === 'preview'}
              sx={{
                width: '32%',
              }}
            />
          )}
        />
      </Box>
    </Box>
  );

  useEffect(() => {
    setPageTitle('顧客情報登録');
    return () => setPageTitle('');
  }, []);

  useEffect(() => {
    setInternalType(type); // 专门为Select服务的状态
  }, [type]);

  return (
    <div>
      <div className="customer-management">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356 }}>{`【最終更新日】`}</div>
            <div style={{ minWidth: 356 }}>{`【承認日】`}</div>
          </div>
        </div>
        <div className="top-operation-button">
          <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit" disabled={type === 'preview'}>
            保存
          </Button>
          <Button variant="contained" size="small" style={{ margin: '8px 0', minWidth: 96 }} onClick={handleCancel}>
            キャンセル
          </Button>
          <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}} disabled={type === 'preview'}>
            申請
          </Button>
        </div>
        <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '80%', overflowY: 'auto' }}>
          <div className="form-item">
            <div className="title">顧客情報</div>
            <Button variant="contained" size="small" style={{ marginRight: '193px', minWidth: 96 }}>
              印刷
            </Button>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('顧客コード', 'customerCode')}
            {renderTextField('*顧客名', 'customerName', true)}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('顧客略称', 'customerShortName')}
            {renderTextField('顧客カナ', 'customerKana')}
          </Box>

          <Box sx={{ mb: 2, maxWidth: '80%' }}>{renderTextField('*担当者名', 'managerName', true)}</Box>

          <Box sx={{ mb: 2, maxWidth: '80%' }}>{renderTextField('担当者カナ', 'managerKana')}</Box>

          <Controller
            name="transactionType"
            control={control}
            rules={{ required: '取引区分が入力されていません。' }}
            render={({ field, fieldState }) => (
              <Box display="flex" sx={{ mb: 2, maxWidth: 'calc(50% - 8px)' }}>
                <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 80, lineHeight: '40px' }}>*取引区分</Box>
                <Box sx={{ width: '100%' }}>
                  <Select
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    disabled={internalType === 'preview'}
                    sx={{ width: '100%' }}
                    displayEmpty
                  >
                    <MenuItem value="" disabled>
                      取引区分を選択してください
                    </MenuItem>
                    {Array.from(transactionTypeMap.entries()).map(([value, label]) => (
                      <MenuItem key={value} value={value}>
                        {label}
                      </MenuItem>
                    ))}
                  </Select>
                  {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                </Box>
              </Box>
            )}
          />

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            <Box display="flex">
              <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 80, lineHeight: '40px' }}>*郵便番号</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <Controller
                  name="postalCodePart1"
                  control={control}
                  rules={{ required: '郵便番号が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      disabled={internalType === 'preview'}
                      sx={{
                        width: 'calc(50% - 8px)',
                      }}
                    />
                  )}
                />
                <span>-</span>
                <Controller
                  name="postalCodePart2"
                  control={control}
                  rules={{ required: '郵便番号が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      disabled={internalType === 'preview'}
                      sx={{
                        width: 'calc(50% - 8px)',
                      }}
                    />
                  )}
                />
              </Box>
            </Box>

            <Button
              variant="contained"
              size="small"
              style={{ height: 32, maxWidth: 96, marginTop: 4 }}
              onClick={handleAddressSearch}
              disabled={type === 'preview'}
            >
              住所検索
            </Button>
          </Box>

          <Box sx={{ mb: 2, maxWidth: '80%' }}>{renderTextField('*顧客住所', 'customerAddress', true)}</Box>

          {renderPhoneField('*電話番号', 'phone', true)}

          {renderPhoneField('携帯番号', 'mobile')}

          {renderPhoneField('FAX番号', 'fax')}

          <div className="form-item" style={{ marginTop: 40 }}>
            <div className="title">口座情報</div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('銀行名', 'bankName')}
            {renderTextField('支店名', 'branchName')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('預金種別', 'depositType')}
            {renderTextField('口座番号', 'accountNumber')}
          </Box>

          <Box sx={{ mb: 2, maxWidth: '80%' }}>{renderTextField('口座名義', 'accountHolder')}</Box>

          <div className="form-item" style={{ marginTop: 40 }}>
            <div className="title">法人情報</div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('資本金', 'capital')}
            <Box display="flex">
              <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 80, lineHeight: '40px' }}>従業員数</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <Controller
                  name="numberOfEmployees"
                  control={control}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      disabled={internalType === 'preview'}
                      sx={{
                        width: '100%',
                        backgroundColor: fieldState.error ? '#ffe6e6' : 'inherit',
                      }}
                    />
                  )}
                />

                <span>人</span>
              </Box>
            </Box>
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
            }}
          >
            {renderTextField('業種・業態', 'industry')}
            {renderTextField('代表者名', 'representativeName')}
          </Box>

          <Box sx={{ mb: 2 }}>{renderTextField('会社URL', 'companyUrl')}</Box>

          <Box sx={{ mb: 2 }}>{renderTextField('備考', 'remarks')}</Box>

          <div className="form-item" style={{ marginTop: 40 }}>
            <div className="title">取引履歴</div>
          </div>
        </Box>
        <Table rowData={tableData} />
      </div>
    </div>
  );
};

export default WebR0060CreateForm;
