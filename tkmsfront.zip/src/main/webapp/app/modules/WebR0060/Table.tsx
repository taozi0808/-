import React, { FC, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';

interface Column {
  bukkenCode: string; // 物件コード
  bukkenName: string; // 物件名
  chumonShoNumber: string; // 注文書番号
  juchuKingaku: number | string; // 受注金額
  nyukinKingaku: number | string; // 入金金額
  hatchuHikiwatashiTanka: string; // 発注引き渡し単価
  status: string; // 状態
  keiyakuBi: string; // 契約日
  saishuBi: string; // 最終日
}

interface Props {
  rowData: Column[];
}

const Table: FC<Props> = ({ rowData }) => {
  const columnDefs = useMemo(() => {
    return [
      { headerName: '物件コード', field: 'bukkenCode', width: 120 },
      { headerName: '物件名', field: 'bukkenName', width: 200 },
      { headerName: '注文書番号', field: 'chumonShoNumber', width: 120 },
      { headerName: '受注金額', field: 'juchuKingaku', width: 120 },
      { headerName: '入金金額', field: 'nyukinKingaku', width: 120 },
      { headerName: '発注引き渡し単価', field: 'hatchuHikiwatashiTanka', width: 120 },
      { headerName: '状態', field: 'status', width: 120 },
      { headerName: '契約日', field: 'keiyakuBi', width: 120 },
      { headerName: '最終日', field: 'saishuBi', width: 120 },
    ];
  }, []);

  const gridStyle = useMemo(() => {
    return {
      width: '90%',
      height: '400px',
    };
  }, []);

  return (
    <div style={gridStyle} className="ag-theme-alpine">
      <AgGridReact rowData={rowData} columnDefs={columnDefs as any} />
    </div>
  );
};

export default Table;
