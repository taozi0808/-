import React, { FC, useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebJ0020CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import WebJ0020SearchDialog from './SearchDialog/WebJ0020SearchDialog';
import { useForm } from 'react-hook-form';
import { Box, Button } from '@mui/material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const WebJ0020CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  const [dataSource, setDataSource] = useState([]);

  // 支払条件明細テーブル
  const defaultColDef = useMemo(() => {
    return {
      // flex: 1,
      editable: true,
    };
  }, []);

  const LinkRenderer = (params: any) => {
    const url = `/webM0020/edit/${id}`;
    return (
      // <a href={url} target="_blank" rel="noopener noreferrer" className="custom-link">
      <a target="_blank" rel="noopener noreferrer" className="custom-link">
        {params.value}
      </a>
    );
  };

  const CheckboxCellRenderer = params => {
    const { data, node } = params;
    const [isChecked, setIsChecked] = useState(data.selected || false);

    if (node.rowIndex % 2 !== 0) {
      return null;
    }

    // チェックボックスの変化事件
    const handleChange = e => {
      const newValue = e.target.checked;
      setIsChecked(newValue);
    };

    return (
      <div
        style={{
          transform: 'scale(1.5)',
        }}
      >
        <input
          type="checkbox"
          checked={isChecked}
          onChange={handleChange}
          style={{
            cursor: 'pointer',
            margin: 0,
          }}
        />
      </div>
    );
  };

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {},
    mode: 'onBlur',
  });

  const handleSearch = values => {
    const tempDataSource = [];
    for (let i = 0; i < 10; i++) {
      tempDataSource.push({
        selected: false,
        id: i + 1,
        genbaCode: '0000001-000-01' + i,
        genbaName: '北海道苫小牧市錦岡' + i,
        shiharaiNichi: '2024年9月10日',
        uchiwake: '移動交通費' + i,
        shiharaiSakiKubun: '社員' + i,
        shiharaiSaki: '鈴木 健一' + i,
        daikuShu: '配管工' + i,
        bikou: '北海道苫小牧市錦岡' + i,
        shouKouShu: '型枠工' + i,
        shiharaiKingaku: 800000,
        tenpu: i % 2 === 0 ? '〇' : '×',
      });
    }
    setDataSource(tempDataSource);
    const newCurData = [];
    for (let i = 0; i < tempDataSource.length; i++) {
      newCurData.push(tempDataSource[i]);
      newCurData.push(tempDataSource[i]);
    }
    setDataSource(newCurData);
  };

  const tableColumnDefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '',
      field: 'id',
      cellRenderer: CheckboxCellRenderer,
      width: 60,
      spanRows: true,
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' },
      cellClass: 'center-cell',
    },
    {
      headerName: 'No',
      field: 'id',
      width: 60,
      spanRows: true,
      cellClass: 'center-cell',
    },
    {
      headerName: '現場コード',
      field: 'genbaCode',
      width: 185,
      children: [
        {
          headerName: '現場名',
          field: 'genbaName',
          width: 185,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.genbaCode : params.data.genbaName),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.genbaCode = params.newValue;
            } else {
              params.data.genbaName = params.newValue;
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '支払日',
      field: 'shiharaiNichi',
      width: 150,
      children: [
        {
          headerName: '内訳',
          field: 'uchiwake',
          width: 150,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiNichi : params.data.uchiwake),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiNichi = params.newValue;
            } else {
              params.data.uchiwake = params.newValue;
            }
            return true;
          },
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 3),
          cellStyle: params => {
            if (params.node.rowIndex % 2 === 0 && params.data.shiharaiNichi) {
              return { backgroundColor: '#FFBE4D' };
            }
            return null;
          },
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'start-cell'),
        },
      ],
    },
    {
      headerName: '支払先区分',
      field: 'shiharaiSakiKubun',
      width: 145,
      children: [
        {
          headerName: '',
          field: 'hiddenField1',
          width: 145,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiSakiKubun : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiSakiKubun = params.newValue;
            } else {
              params.data.hiddenField1 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '支払先',
      field: 'shiharaiSaki',
      width: 150,
      children: [
        {
          headerName: '',
          field: 'hiddenField2',
          width: 150,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiSaki : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiSaki = params.newValue;
            } else {
              params.data.hiddenField2 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '大工種',
      field: 'daikuShu',
      width: 140,
      cellClass: 'start-cell',
      children: [
        {
          headerName: '備考',
          field: 'bikou',
          cellClass: 'start-cell',
          width: 140,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.daikuShu : params.data.bikou),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.daikuShu = params.newValue;
            } else {
              params.data.bikou = params.newValue;
            }
            return true;
          },
          colSpan: params => (params.node.rowIndex % 2 === 0 ? 1 : 3),
        },
      ],
    },
    {
      headerName: '小工種',
      field: 'shouKouShu',
      width: 140,
      children: [
        {
          headerName: '',
          field: 'hiddenField3',
          width: 140,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shouKouShu : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shouKouShu = params.newValue;
            } else {
              params.data.hiddenField3 = '';
            }
            return true;
          },
        },
      ],
    },
    {
      headerName: '支払金額（税込）',
      field: 'shiharaiKingaku',
      width: 140,
      children: [
        {
          headerName: '',
          field: 'hiddenField4',
          width: 140,
          valueGetter: params => (params.node.rowIndex % 2 === 0 ? params.data.shiharaiKingaku : ''),
          valueSetter: params => {
            if (params.node.rowIndex % 2 === 0) {
              params.data.shiharaiKingaku = params.newValue;
            } else {
              params.data.hiddenField4 = '';
            }
            return true;
          },
          cellClass: params => (params.node.rowIndex % 2 === 0 ? 'end-cell' : 'start-cell'),
          valueFormatter: (params: any) => {
            if (params.node.rowIndex % 2 === 0 && params.value) {
              return Intl.NumberFormat('ja-JP', { currency: 'JPY' }).format(params.value);
            }
          },
        },
      ],
    },
    {
      headerName: '添付',
      field: 'tenpu',
      width: 75,
      spanRows: true,
      cellClass: 'center-cell',
      cellRenderer: LinkRenderer,
      cellStyle: { color: '#1890ff !important' },
    },
  ]);
  useEffect(() => {
    setPageTitle('連携用支払データ作成');
    return () => setPageTitle('');
  }, [setPageTitle]);

  useEffect(() => {
    if (id === undefined) {
      console.log('データ異常');
    } else {
      const tempDataSource = [];
      for (let i = 0; i < 10; i++) {
        tempDataSource.push({
          id: i + 1,
          genbaCode: '0000001-000-01' + i,
          genbaName: '北海道苫小牧市錦岡' + i,
          shiharaiNichi: '2024年9月10日',
          uchiwake: '移動交通費' + i,
          shiharaiSakiKubun: '社員' + i,
          shiharaiSaki: '鈴木 健一' + i,
          daikuShu: '配管工' + i,
          bikou: '北海道苫小牧市錦岡' + i,
          shouKouShu: '型枠工' + i,
          shiharaiKingaku: 800000,
          tenpu: i % 2 === 0 ? '〇' : '×',
        });
      }
      setDataSource(tempDataSource);
      const newCurData = [];
      for (let i = 0; i < tempDataSource.length; i++) {
        newCurData.push(tempDataSource[i]);
        newCurData.push(tempDataSource[i]);
      }
      setDataSource(newCurData);
    }
  }, []);

  return (
    <div>
      <div className="webj0020-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} userName="" />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={() => {}}>
                支払データ作成
              </Button>
            </div>
            <WebJ0020SearchDialog onSearch={handleSearch} />
          </div>

          <div className="ag-theme-alpine column-group-table" style={{ width: '100%', height: '350px' }}>
            <AgGridReact
              rowData={dataSource}
              theme={AGGridTheme}
              columnDefs={tableColumnDefs.current}
              defaultColDef={defaultColDef}
              enableCellSpan
            />
          </div>
        </Box>
      </div>
    </div>
  );
};

export default WebJ0020CreateForm;
