export interface OrgNode {
  key: string;
  name: string;
  code: string;
  order?: number;
  children?: OrgNode[];
}

export const organizationNextData: Array<OrgNode> = [
  {
    key: 'ac3d9f60a836',
    name: '大東協力建設株式会社',
    code: '027-000',
    children: [
      { key: 'y5z6a7b8c9d011', name: '契約11課', code: '001-0061', children: [] },

      {
        key: '47ef2f21f8fc',
        name: '関東工事部',
        code: '027-002',
        children: [
          {
            key: 'ff2a3e34acc7',
            name: '千葉営業所',
            code: '002-001',
            children: [
              {
                key: 'k9l0m1n2o3p4',
                name: '施工部',
                code: '002-002',
                children: [
                  { key: 'q5r6s7t8u9v0', name: '現場管理課', code: '002-003', children: [] },
                  { key: 'w1x2y3z4a5b6', name: '品質保証課', code: '002-004', children: [] },
                ],
              },
              {
                key: 'c6d7e8f9g0h1',
                name: '技術支援部',
                code: '002-005',
                children: [
                  { key: 'i2j3k4l5m6n7', name: '技術開発課', code: '002-006', children: [] },
                  { key: 'o8p9q0r1s2t3', name: '施工技術課', code: '002-007', children: [] },
                ],
              },
            ],
          },
          {
            key: 'u4v5w6x7y8z9',
            name: '東京営業所',
            code: '002-008',
            children: [
              {
                key: 'a0b1c2d3e4f5',
                name: '営業部',
                code: '002-009',
                children: [
                  { key: 'g6h7i8j9k0l1', name: '顧客管理課', code: '002-010', children: [] },
                  { key: 'm2n3o4p5q6r7', name: '販売促進課', code: '002-011', children: [] },
                ],
              },
            ],
          },
        ],
      },
      {
        key: 's8t9u0v1w2x3',
        name: '技術管理部',
        code: '027-003',
        children: [
          {
            key: 'y4z5a6b7c8d9',
            name: '研究開発課',
            code: '003-001',
            children: [
              { key: 'e0f1g2h3i4j5', name: '新技術開発室', code: '003-002', children: [] },
              { key: 'k6l7m8n9o0p1', name: '応用研究室', code: '003-003', children: [] },
            ],
          },
          {
            key: 'q2r3s4t5u6v7',
            name: '品質管理課',
            code: '003-004',
            children: [
              { key: 'w8x9y0z1a2b3', name: '材料管理課', code: '003-005', children: [] },
              { key: 'c4d5e6f7g8h9', name: '検査管理課', code: '003-006', children: [] },
            ],
          },
        ],
      },
    ],
  },
];
