import './WebR0030CreateForm.scss';
import OrganizationTree from './OrganizationTree';
import React, { useEffect, useState } from 'react';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { Box, Button } from '@mui/material';
import useAccountStore from 'app/shared/zustandStore/account';
import dayjs from 'dayjs';
import { organizationInitData } from './initData';
import { organizationNextData } from './nextData';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import Pagination from './Pagination';
const localStorageKey = 'CONSTRUCTION_MANAGEMENT_ORGANIZATION_KEY_1';

const OrganizationManage = () => {
  const { setPageTitle } = usePageTitleStore();
  const { userName } = useAccountStore();

  const [lastModifyInfo, setLastModifyInfo] = useState<{ lastUpdateUserId: string; lastUpdateTime: string }>();
  const [originalTreeData, setOriginalTreeData] = useState([]);
  const [treeData, setTreeData] = useState([]);

  const onSave = () => {
    const lastUpdateInfo = {
      lastUpdateUserId: userName,
      lastUpdateTime: dayjs(new Date().toISOString()).format('YYYY-MM-DD HH:mm:ss'),
    };
    localStorage.setItem(
      localStorageKey,
      JSON.stringify({
        treeData,
        lastUpdateInfo,
      }),
    );
    setOriginalTreeData(JSON.parse(JSON.stringify(treeData)));
    setLastModifyInfo(lastUpdateInfo);
  };

  useEffect(() => {
    setPageTitle('組織管理');

    let treeList;
    let lastUpdateInfo;
    const storeData = JSON.parse(localStorage.getItem(localStorageKey) || '{}');
    if (!storeData.treeData) {
      treeList = organizationInitData;
      lastUpdateInfo = {
        lastUpdateUserId: userName,
        lastUpdateTime: dayjs(new Date().toISOString()).format('YYYY-MM-DD HH:mm:ss'),
      };
      localStorage.setItem(
        localStorageKey,
        JSON.stringify({
          treeData: organizationInitData,
          lastUpdateInfo,
        }),
      );
    } else {
      treeList = storeData.treeData;
      lastUpdateInfo = storeData.lastUpdateInfo;
    }
    setTreeData(treeList);
    setLastModifyInfo(lastUpdateInfo);
    setOriginalTreeData(JSON.parse(JSON.stringify(organizationInitData)));
  }, []);

  const handlePageChange = (page: number) => {
    console.log('当前页码：', page);
    if (page === 1) {
      console.log('当前页码page ：', 1);
      setTreeData(JSON.parse(JSON.stringify(organizationInitData)));
    }
    if (page === 2) {
      console.log('当前页码page ：', 2);
      console.log('当前页码page ：', JSON.stringify(organizationNextData));
      setTreeData(JSON.parse(JSON.stringify(organizationNextData)));
    }
  };

  return (
    <div className="organization">
      {lastModifyInfo?.lastUpdateUserId && <LastUpdateInfo userId={lastModifyInfo.lastUpdateUserId} />}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 2, mb: 4 }}>
        <Box sx={{ display: 'flex' }}>
          <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={onSave}>
            保存
          </Button>
          <Button
            variant="contained"
            size="small"
            style={{ marginRight: '8px', minWidth: 96 }}
            onClick={() => {
              setTreeData(originalTreeData);
            }}
          >
            キャンセル
          </Button>
        </Box>
        {/* <Box>{'≪<1>≫'}</Box> */}
        <Box>
          <Pagination totalPages={2} onPageChange={handlePageChange} />
        </Box>

        <Box sx={{ display: 'flex' }}>
          <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
            CSV出力
          </Button>
          <Button variant="contained" size="small" style={{ minWidth: 96 }}>
            印刷
          </Button>
        </Box>
      </Box>
      <div className="tree-content">
        <div className="tree-left">
          <OrganizationTree disabled treeData={originalTreeData} />
        </div>
        <div className="tree-right">
          <div className="update-time">{`<更新後日付> ${lastModifyInfo?.lastUpdateTime ?? ''}`}</div>
          <div className="begin-time">{`<通用開始日付> 2026年4月1日`}</div>
          <OrganizationTree
            onChange={newData => {
              setTreeData([...newData]);
            }}
            treeData={treeData}
          />
        </div>
      </div>
    </div>
  );
};

export default OrganizationManage;
