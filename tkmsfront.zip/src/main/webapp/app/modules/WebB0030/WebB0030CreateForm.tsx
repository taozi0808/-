import {
  Box,
  Button,
  Stack,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Snackbar,
  TextField,
  Select,
  MenuItem,
} from '@mui/material';
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import './WebB0030CreateForm.scss';
import dayjs from 'dayjs';
import { CustomButtonRender } from 'app/components/CustomRender/customButtonRender';
import { STORAGE_KEY, DBManager, generateRandomData } from 'app/shared/util/construction-list';
import AddIcon from '@mui/icons-material/Add';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useNotify } from 'app/shared/layout/NotifyProvider';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import {
  ColDef,
  ColGroupDef,
  ICellRendererParams,
  CheckboxEditorModule,
  ClientSideRowModelModule,
  DateEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  ValidationModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  SelectEditorModule,
  createGrid,
} from 'ag-grid-community';
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  SelectEditorModule,
  TextEditorModule,
  NumberEditorModule,
  DateEditorModule,
  CheckboxEditorModule,
  ClientSideRowModelApiModule,
  RowApiModule,
  RowSelectionModule,
  ValidationModule /* Development Only */,
]);

const WebB0030 = () => {
  const { setPageTitle } = usePageTitleStore();
  const { id, type } = useParams();
  const navigate = useNavigate();
  const [isCollapse, setIsCollapse] = useState(false);
  const [data, setData] = useState([]);
  const [rowData, setRowData] = useState([]);
  const [youBouColumnsData, setYouBouColumnsData] = useState([]);
  const [isHensyuuKengen, setIsHensyuuKengen] = useState(type === 'preview');
  const [senkouSagyouNaidakusyoMeisaiInfoData, setSenkouSagyouNaidakusyoMeisaiInfoData] = useState([]);
  const data1 = DBManager.getItemById(id);

  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      editable: type === 'preview',
      singleClickEdit: true,
    };
  }, []);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm({
    defaultValues: {
      ankenCode: '',
      ankenEdaCode: '',
      ankenKubun: '',
      jyucyuuJyoutaiCode: '',
      ankenName: '',
      ankenKanaName: '',
      taisyouGenbaCode: '',
      genbaName: '',
      bukkenCode: '',
      bukkenName: '',
      bukkenKaneName: '',
      sekisanCode: '',
      yuubinNumberBukken1: '',
      yuubinNumberBukken2: '',
      genbaJyuusyo1: '',
      field16: '',
      kokyakuName: '',
      field18: '',
      field19: '',
      field20: '',
      field21: '',
      souteiKingaku: '',
      field23: '',
      field24: '',
      field25: '',
      field26: '',
      field27: '',
      field28: '',
      field29: '',
      field30: '',
      field31: '',
      field32: '',
      field33: '',
      field34: '',
      field35: '',
      field36: '',
      field37: '',
      field38: '',
      field39: '',
      jyucyuuMikomiYMD: '',
      cyakkouKibouYMD: '',
      eigyouBumonName: '',
      field43: '',
      eigyouTantousyaShiMei: '',
      shincyokudo: '',
      field46: '',
      field47: '',
      field48: '',
      field49: '',
    },
    mode: 'onBlur',
  });

  // 現場情報表格的列

  const siteInfoColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '棟番号',
      field: 'buildingNumber',
      minWidth: 150,
      maxWidth: 250,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditor: 'agTextCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
      // cellStyle: params => {
      //   if (params.data.key === '0') {
      //     return { backgroundColor: 'green' };
      //   }
      //   return null;
      // },
    },
    {
      headerName: '棟番号工事名',
      field: 'buildingName',
      minWidth: 344,
      headerClass: 'center-header',
      cellEditor: 'agTextCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
      // cellStyle: params => {
      //   if (params.data.key === '0') {
      //     return { backgroundColor: 'green' };
      //   }
      //   return null;
      // },
    },
  ]);

  const options = [
    {
      label: '',
      value: '',
    },
    {
      label: '請求条件名1',
      value: 0,
    },
    {
      label: '請求条件名2',
      value: 1,
    },
    {
      label: '請求条件名3',
      value: 2,
    },
    {
      label: '請求条件名4',
      value: 3,
    },
    {
      label: '請求条件名5',
      value: 4,
    },
    {
      label: '請求条件名6',
      value: 5,
    },
    {
      label: '請求条件名7',
      value: 6,
    },
    {
      label: '請求条件名8',
      value: 7,
    },
    {
      label: '請求条件名9',
      value: 8,
    },
    {
      label: '請求条件名10',
      value: 9,
    },
  ];

  const percentageList = [
    {
      label: '',
      value: '',
    },
    {
      label: '1%',
      value: 0,
    },
    {
      label: '2%',
      value: 1,
    },
    {
      label: '3%',
      value: 2,
    },
    {
      label: '4%',
      value: 3,
    },
  ];

  const taxRateList = [
    {
      label: '',
      value: '',
    },
    {
      label: '5%',
      value: 0,
    },
    {
      label: '8%',
      value: 1,
    },
    {
      label: '10%',
      value: 2,
    },
  ];

  // 請求条件表格的列
  const requestColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '請求条件名',
      field: 'conditionName',
      minWidth: 150,
      headerClass: 'center-header',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: options.map(opt => opt.value),
      },
      valueFormatter: params => {
        const option = options.find(opt => opt.value === params.value);
        if (option) {
          return option.label;
        }
      },
      valueParser: params => {
        return params.newValue;
      },
    },
    {
      headerName: '割合',
      field: 'percentage',
      minWidth: 75,
      maxWidth: 100,
      headerClass: 'center-header',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: percentageList.map(opt => opt.value),
      },
      valueFormatter: params => {
        const percentages = percentageList.find(opt => opt.value === params.value);
        if (percentages) {
          return percentages.label;
        }
        return '';
      },
      valueParser: params => {
        return params.newValue;
      },
    },
    {
      headerName: '請求金額',
      field: 'requestAmount',
      minWidth: 150,
      headerClass: 'center-header',
      cellClass: 'end-cell',
      cellEditor: 'agTextCellEditor',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value);
        }
      },
    },
    {
      headerName: '消費税率',
      field: 'taxRate',
      minWidth: 90,
      maxWidth: 130,
      headerClass: 'center-header',
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: taxRateList.map(opt => opt.value),
      },
      valueFormatter: params => {
        const taxRates = taxRateList.find(opt => opt.value === params.value);
        if (taxRates) {
          return taxRates.label;
        }
        return '';
      },
      valueParser: params => {
        return params.newValue;
      },
    },
    {
      headerName: '消費税金額',
      field: 'taxAmount',
      headerClass: 'center-header',
      cellClass: 'end-cell',
      cellEditor: 'agTextCellEditor',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value);
        }
      },
    },
    {
      headerName: '合計金額',
      field: 'totalAmount',
      headerClass: 'center-header',
      cellClass: 'end-cell',
      cellEditor: 'agTextCellEditor',
      valueFormatter: (params: any) => {
        if (params.value) {
          return Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(params.value);
        }
      },
    },
  ]);

  const addSubSupplier = (index: number) => {
    // const copyOriginRowData = [...youBouColumnsData];
    const newCurData = [];
    for (let i = 0; i < youBouColumnsData.length; i++) {
      if (i < index) {
        newCurData.push(youBouColumnsData[i]);
      } else if (i === index) {
        newCurData.push(youBouColumnsData[i]);
        const newSupplier = {
          youbouHasseiYMD: youBouColumnsData[i].youbouHasseiYMD,
          youbouNaiyou: '',
          isSubSupplier: true,
        };
        newCurData.push(newSupplier);
      } else {
        newCurData.push(youBouColumnsData[i]);
      }
    }
    setYouBouColumnsData(newCurData);
  };
  const youBouColumnsColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '発生年月日',
      field: 'youbouHasseiYMD',
      minWidth: 110,
      maxWidth: 210,
      spanRows: true,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditor: 'agDateCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '',
      field: 'isSubSupplier',
      minWidth: 40,
      maxWidth: 40,
      cellEditor: 'agDateCellEditor',
      cellClass: 'center-cell',
      cellRenderer: params => {
        return params.data.isSubSupplier ? (
          <ArrowForwardIosIcon fontSize="small" />
        ) : (
          <AddIcon
            onClick={() => {
              addSubSupplier(params.node.rowIndex);
            }}
            sx={{ cursor: 'pointer' }}
          />
        );
      },
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '要望内容',
      field: 'youbouNaiyou',
      headerClass: 'center-header',
      cellEditor: 'agTextCellEditor',
      minWidth: 458,
      cellEditorParams: {
        maxLength: 20,
      },
      // cellStyle: params => {
      //   if (params.data.key === '0') {
      //     return { backgroundColor: 'green' };
      //   }
      //   return null;
      // },
    },
  ]);

  const CustomKoushikoujiRender = props => {
    return (
      <div>
        <div>
          <span>{props.value}</span>
        </div>
        <div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center' }}>予定</div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center' }}>実績</div>
        </div>
      </div>
    );
  };

  const senkouSagyouNaidakusyoMeisaiInfoColumns = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      minWidth: 70,
      maxWidth: 70,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditor: 'agDateCellEditor',
    },
    {
      headerName: '印刷',
      field: 'fuseiyakuRiyuu',
      minWidth: 100,
      maxWidth: 100,
      cellRenderer: (params: ICellRendererParams) => {
        return <CustomButtonRender params={params} />;
      },
      cellRendererParams: {
        buttonName: () => {
          return `印刷`;
        },
        buttonStyle: {
          backgroundColor: `purple`,
          color: `white`,
          '&:hover': {
            backgroundColor: '#285ac8',
          },
        },
      },
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditor: 'agDateCellEditor',
    },
    {
      headerName: '計画概要',
      field: 'keikakuGaiyou',
      cellRenderer: CustomKoushikoujiRender,
      cellClass: 'center-cell',
      headerClass: 'center-header',
      cellEditor: 'agDateCellEditor',
    },
  ]);

  const countSekou = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field26', '' + val);
  };

  const countSekou1 = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field28', '' + val);
  };

  const countSekou2 = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field30', '' + val);
  };

  const countSekou3 = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field32', '' + val);
  };

  const countSekou4 = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field34', '' + val);
  };

  const countSekou5 = (event: any) => {
    const val = Math.round(parseFloat(event.target.value) / 3.305);
    setValue('field36', '' + val);
  };

  const onFinish = values => {
    navigate('/webB0010');
    // notify('K00003', 'warning');
  };

  const handleDelete = () => {
    // notify('K00004', 'warning');
    navigate('/webB0010');
    // setOpen(true);
  };

  // 住所検索
  const selectGenbaJyuusyo = () => {
    setValue('genbaJyuusyo1', '住所-京東区04-5-9');
    // setValue('field16', '住所-ビル5F 5-9');
  };
  useEffect(() => {
    const tempData = [];
    const empData = [];
    const mpData = [];
    const pData = [];
    if (id) {
      for (let i = 0; i < 10; i++) {
        tempData.push({
          id: i + 1,
          conditionName: i,
          requestAmount: 100 + i,
          percentage: i < 3 ? i : 1,
          taxRate: i === 2 ? 2 : 1,
          taxAmount: 1001 + i,
          totalAmount: 1021 + i,
        });
      }
      setData(tempData);
      for (let i = 0; i < 10; i++) {
        empData.push({
          id: i + 1,
          buildingNumber: '0' + (i + 1),
          buildingName: '' + (i + 1) + '棟工事',
        });
      }
      setRowData(empData);
      for (let i = 0; i < 10; i++) {
        mpData.push({
          id: i + 1,
          youbouHasseiYMD: '2010/10/' + (i + 1),
          youbouNaiyou: '要望' + (i + 1) + '内容',
          isSubSupplier: true,
        });
      }
      const newCurData = [];
      for (let i = 0; i < mpData.length; i++) {
        newCurData.push(mpData[i]);
        newCurData.push(mpData[i]);
      }
      for (let i = 0; i < newCurData.length; i++) {
        if (i % 2 === 0) {
          newCurData[i].isSubSupplier = false;
        }
      }
      setYouBouColumnsData(newCurData);

      for (let i = 0; i < 10; i++) {
        pData.push({
          id: i + 1,
          keikakuGaiyou: '計画概要' + (i + 1),
          senkouKoujiNaiyou: '先行工事内容' + (i + 1),
          koujiGenka: i + 112,
          shiharaiJyouken: '支払条件' + (i + 1),
          sonata: 'その他' + (i + 1),
        });
      }
      setSenkouSagyouNaidakusyoMeisaiInfoData(pData);
    } else {
      for (let i = 0; i < 10; i++) {
        tempData.push({
          id: i + 1,
        });
      }
      setData(tempData);
      for (let i = 0; i < 10; i++) {
        empData.push({
          id: i + 1,
        });
      }
      setRowData(empData);
      for (let i = 0; i < 10; i++) {
        mpData.push({
          id: i + 1,
        });
      }
      setYouBouColumnsData(mpData);

      for (let i = 0; i < 10; i++) {
        pData.push({
          id: i + 1,
        });
      }
      setSenkouSagyouNaidakusyoMeisaiInfoData(pData);
    }
  }, []);

  useEffect(() => {
    if (id) {
      // 示例数据
      setValue('ankenCode', data1.ankenCode);
      setValue('ankenName', data1.ankenName);
      setValue('kokyakuName', data1.kokyakuName);
      setValue('souteiKingaku', data1.souteiKingaku);
      setValue('genbaJyuusyo1', data1.genbaJyuusyo1);
      setValue('jyucyuuMikomiYMD', dayjs(data1.jyucyuuMikomiYMD).format('YYYY-MM-DD').toString());
      setValue('cyakkouKibouYMD', dayjs(data1.cyakkouKibouYMD).format('YYYY-MM-DD').toString());
      setValue('eigyouBumonName', data1.eigyouBumonName);
      setValue('eigyouTantousyaShiMei', data1.eigyouTantousyaShiMei);
      setValue('shincyokudo', data1.shincyokudo);

      setValue('ankenKanaName', '案件カナ名');
      setValue('taisyouGenbaCode', '7000000-200-20');
      setValue('genbaName', '現場名');
      setValue('bukkenCode', '7000000');
      setValue('bukkenName', '物件名');
      setValue('bukkenKaneName', '物件カナ名');
      setValue('ankenKubun', '1');
      setValue('jyucyuuJyoutaiCode', '1');
      setValue('sekisanCode', '2024080001');
      setValue('yuubinNumberBukken1', '175');
      setValue('yuubinNumberBukken2', '0001');
      setValue('field18', '0001');

      setValue('field19', '0008');
      setValue('field20', '京東区04-5-6');
      setValue('field21', 'ビル5F');
      setValue('field23', '1');
      setValue('field24', '2024-09-10');
      setValue('field25', '90');
      setValue('field26', '' + Math.round(parseFloat('90') / 3.305));
      setValue('field27', '45');
      setValue('field28', '' + Math.round(parseFloat('45') / 3.305));
      setValue('field29', '11');
      setValue('field30', '' + Math.round(parseFloat('11') / 3.305));
      setValue('field31', '97');
      setValue('field32', '' + Math.round(parseFloat('97') / 3.305));
      setValue('field33', '51');
      setValue('field34', '' + Math.round(parseFloat('33') / 3.305));
      setValue('field35', '17');
      setValue('field36', '' + Math.round(parseFloat('17') / 3.305));
      setValue('field37', '20');
      setValue('field38', '16');
      setValue('field39', '1');
      setValue('field43', '山本 太郎');
    }
  }, []);

  useEffect(() => {
    setPageTitle('案件登録');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webB0030-container">
        <div className="top" style={{ display: id ? '' : 'none' }}>
          <div className="top-item">
            <LastUpdateInfo userId={'J123456789012'} userName={'田中　花子'} />
            <LastUpdateInfo userId={''} title="【承認者】" />
          </div>
          <div className="top-item">
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【最終更新日】'}</div>
              <div>{`2024/02/01`}</div>
            </div>
            <div style={{ minWidth: 356, display: 'flex', gap: '8px' }}>
              <div style={{ width: 100 }}>{'【承認日】'}</div>
              <div>{``}</div>
            </div>
          </div>
        </div>
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              disabled={isHensyuuKengen}
              onClick={onFinish}
            >
              保存
            </Button>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleDelete}>
              キャンセル
            </Button>
          </div>
          <div>
            <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} disabled={isHensyuuKengen}>
              印刷
            </Button>
          </div>
        </div>

        <Box component="form" onSubmit={onFinish} display="flex" flexDirection="column" gap={2} className="ad-search-WebB0030">
          <Box display="flex" justifyContent="space-between">
            <Box flex={3} display="flex">
              <Box flex={'70%'}>
                <Controller
                  name="ankenCode"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '案件コードが入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*案件コード</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={'30%'}>
                <Controller
                  name="ankenEdaCode"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '案件コードが入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2}>
              <Controller
                name="ankenKubun"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item4">
                    <label>案件区分</label>
                    <Select {...field} size="small" style={{ width: '100%' }}>
                      <MenuItem value="1">自社物件</MenuItem>
                      <MenuItem value="2">新築工事</MenuItem>
                      <MenuItem value="3">営繕工事</MenuItem>
                      <MenuItem value="4">クレーム工事</MenuItem>
                      <MenuItem value="5">周辺事業</MenuItem>
                      <MenuItem value="6">その他</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
            <Box flex={2}>
              <Controller
                name="jyucyuuJyoutaiCode"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item">
                    <label>受注状態</label>
                    <Select {...field} size="small" style={{ width: '100%' }}>
                      <MenuItem value="1">未成約</MenuItem>
                      <MenuItem value="2">成約</MenuItem>
                      <MenuItem value="3">不成約</MenuItem>
                    </Select>
                  </div>
                )}
              />
            </Box>
            <Box flex={1}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box display="flex" flex={5}>
              <Box flex={3}>
                <Controller
                  name="ankenName"
                  disabled={isHensyuuKengen}
                  control={control}
                  // rules={{ required: '案件名が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*案件名</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={3}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            {/* <Box> */}
            <Box flex={5}>
              <Controller
                name="ankenKanaName"
                control={control}
                disabled={isHensyuuKengen}
                render={({ field }) => (
                  <div className="ad-search-item">
                    <label>案件カナ名</label>
                    <TextField {...field} fullWidth size="small" />
                  </div>
                )}
              />
            </Box>
            {/* </Box> */}
            <Box flex={3}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={1}>
              <div
                style={{ textAlign: 'end', paddingRight: '8px' }}
                onClick={() => {
                  setIsCollapse(!isCollapse);
                }}
              >
                {isCollapse ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
              </div>
            </Box>
            {/* </Box> */}
            <Box flex={12}>
              <Box style={{ border: '2px solid black' }} className={isCollapse ? 'hidden' : ''}>
                <Box display="flex" justifyContent="space-between" mt={2} mr={2}>
                  <Box flex={2}>
                    <Controller
                      name="taisyouGenbaCode"
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>対象現場コード</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={3}>
                    <Controller
                      name="genbaName"
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>現場名</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between" mt={2} mr={2}>
                  <Box flex={2}>
                    <Controller
                      name="bukkenCode"
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>物件コード</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={3}>
                    <Controller
                      name="bukkenName"
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>物件名</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between" mt={2} mr={2}>
                  <Box flex={2}></Box>
                  <Box flex={3}>
                    <Controller
                      name="bukkenKaneName"
                      disabled={isHensyuuKengen}
                      control={control}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>物件カナ名</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={1}></Box>
                </Box>
                <Box display="flex" justifyContent="space-between" mt={2} mb={2} mr={2}>
                  <Box flex={2}>
                    <Controller
                      name="sekisanCode"
                      control={control}
                      disabled={isHensyuuKengen}
                      render={({ field }) => (
                        <div className="ad-search-item">
                          <label>概算コード</label>
                          <TextField {...field} fullWidth size="small" />
                        </div>
                      )}
                    />
                  </Box>
                  <Box flex={3}></Box>
                  <Box flex={1}></Box>
                </Box>
              </Box>
            </Box>
            <Box flex={1}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2}>
                <Controller
                  name="yuubinNumberBukken1"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '郵便番号が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*郵便番号</label>
                      <TextField
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="yuubinNumberBukken2"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '郵便番号が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        style={{ left: '10px', minWidth: 90, maxHeight: '40px' }}
                        disabled={isHensyuuKengen}
                        onClick={selectGenbaJyuusyo}
                      >
                        住所検索
                      </Button>
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} mr={2} className="ad-search-item"></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={5}>
                <Controller
                  name="genbaJyuusyo1"
                  disabled={isHensyuuKengen}
                  control={control}
                  // rules={{ required: '物件住所１が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*物件住所１</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={5}>
                <Controller
                  name="field16"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>物件住所２</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Controller
                name="kokyakuName"
                control={control}
                disabled={isHensyuuKengen}
                // rules={{ required: '顧客名が入力されていません' }}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>*顧客名</label>
                    <TextField
                      {...field}
                      fullWidth
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                    />
                  </div>
                )}
              />
            </Box>
            <Box flex={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={3} mr={2} className="ad-search-item">
              <Box flex={2}>
                <Controller
                  name="field18"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>郵便番号</label>
                      <TextField {...field} size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}>
                <Controller
                  name="field19"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>-</label>
                      <TextField {...field} size="small" />
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={5} mr={2} className="ad-search-item"></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={5}>
                <Controller
                  name="field20"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>顧客住所１</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={5}>
                <Controller
                  name="field21"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>顧客住所２</label>
                      <TextField {...field} fullWidth size="small" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={3}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={3}>
                <Controller
                  name="souteiKingaku"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '想定金額（税抜）が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item" style={{ width: '85%' }}>
                      <label>*想定金額（税抜）</label>
                      <TextField
                        {...field}
                        fullWidth
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
              </Box>
              <Box flex={5}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={3}>
                <Controller
                  name="field23"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>官民区分</label>
                      <Select {...field} size="small" style={{ width: '55%' }}>
                        <MenuItem value="1">民間</MenuItem>
                        <MenuItem value="2">官民境界</MenuItem>
                      </Select>
                    </div>
                  )}
                />
              </Box>
              <Box flex={5}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={3}>
                <Controller
                  name="field24"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>見積提出期限</label>
                      <TextField {...field} size="small" style={{ width: '55%' }} type="date" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={5}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} display="flex">
                <Controller
                  name="field25"
                  disabled={isHensyuuKengen}
                  control={control}
                  // rules={{ required: '敷地面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*敷地面積</label>
                      <TextField
                        {...field}
                        size="small"
                        onBlur={countSekou}
                        fullWidth
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field26"
                  control={control}
                  disabled
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="field27"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '建設面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*建設面積</label>
                      <TextField
                        {...field}
                        size="small"
                        fullWidth
                        onBlur={countSekou1}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field28"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth disabled />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} display="flex">
                <Controller
                  name="field29"
                  disabled={isHensyuuKengen}
                  control={control}
                  // rules={{ required: '延床面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*延床面積</label>
                      <TextField
                        {...field}
                        size="small"
                        fullWidth
                        onBlur={countSekou2}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field30"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth disabled />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="field31"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '施工床面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*施工床面積</label>
                      <TextField
                        {...field}
                        size="small"
                        fullWidth
                        onBlur={countSekou3}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field32"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth disabled />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} display="flex">
                <Controller
                  name="field33"
                  disabled={isHensyuuKengen}
                  control={control}
                  // rules={{ required: '専有面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*専有面積</label>
                      <TextField
                        {...field}
                        size="small"
                        onBlur={countSekou4}
                        fullWidth
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field34"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth disabled />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <Controller
                  name="field35"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '施工面積が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*施工面積</label>
                      <TextField
                        {...field}
                        size="small"
                        fullWidth
                        onBlur={countSekou5}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                    </div>
                  )}
                />
                <Controller
                  name="field36"
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item1">
                      <label>㎡</label>
                      <TextField {...field} size="small" fullWidth disabled />
                      <label>坪</label>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} className="ad-search-item">
                <label>戸数</label>
                <Controller
                  name="field37"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item2" style={{ width: '35%' }}>
                      <TextField {...field} size="small" fullWidth />
                      <label>戸</label>
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} display="flex">
                <label>*階数</label>
                <Controller
                  name="field38"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '階数が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item2">
                      <label>地上</label>
                      <TextField
                        {...field}
                        size="small"
                        style={{ width: '56%' }}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                      <label>階</label>
                    </div>
                  )}
                />
                <Controller
                  name="field39"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '階数が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item2">
                      <label>地下</label>
                      <TextField
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      />
                      <label>階</label>
                    </div>
                  )}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} mr={2} display="flex">
                <Controller
                  name="jyucyuuMikomiYMD"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '95%' }}>
                      <label>受注見込日</label>
                      <TextField {...field} size="small" fullWidth type="date" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} mr={2} display="flex">
                <Controller
                  name="cyakkouKibouYMD"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '94%' }}>
                      <label>着工希望日</label>
                      <TextField {...field} size="small" fullWidth type="date" />
                    </div>
                  )}
                />
              </Box>
              <Box flex={2}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2} mr={2} display="flex">
                <Controller
                  name="eigyouBumonName"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item" style={{ width: '95%' }}>
                      <label>営業部門</label>
                      <TextField {...field} size="small" fullWidth />
                      {/* <Select {...field} size="small" style={{ width: '100%' }}>
                        <MenuItem value="販売部">販売部</MenuItem>
                        <MenuItem value="マーケティング部">マーケティング部</MenuItem>
                        <MenuItem value="営業企画部">営業企画部</MenuItem>
                        <MenuItem value="営業推進部">営業推進部</MenuItem>
                        <MenuItem value="営業サポート部">営業サポート部</MenuItem>
                      </Select> */}
                    </div>
                  )}
                />
              </Box>
              <Box flex={2} mr={2} display="flex"></Box>
              <Box flex={2}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2}>
                <Controller
                  name="field43"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>営業管理職</label>
                      <TextField {...field} size="small" style={{ width: '60%' }} />
                      {/* <Select {...field} size="small" style={{ width: '60%' }}>
                        <MenuItem value="販売部">販売部</MenuItem>
                        <MenuItem value="マーケティング部">マーケティング部</MenuItem>
                        <MenuItem value="営業企画部">営業企画部</MenuItem>
                        <MenuItem value="営業推進部">営業推進部</MenuItem>
                        <MenuItem value="営業サポート部">営業サポート部</MenuItem>
                      </Select> */}
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2}>
                <Controller
                  name="eigyouTantousyaShiMei"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>営業担当者</label>
                      <TextField {...field} size="small" style={{ width: '60%' }} />
                      {/* <Select {...field} size="small" style={{ width: '60%' }}>
                        <MenuItem value="販売部">販売部</MenuItem>
                        <MenuItem value="マーケティング部">マーケティング部</MenuItem>
                        <MenuItem value="営業企画部">営業企画部</MenuItem>
                        <MenuItem value="営業推進部">営業推進部</MenuItem>
                        <MenuItem value="営業サポート部">営業サポート部</MenuItem>
                      </Select> */}
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} mr={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={2} mr={2} className="ad-search-item">
              <Box flex={2}>
                <Controller
                  name="shincyokudo"
                  control={control}
                  disabled={isHensyuuKengen}
                  // rules={{ required: '進捗度が入力されていません' }}
                  render={({ field, fieldState }) => (
                    <div className="ad-search-item">
                      <label>*進捗度</label>
                      <Select {...field} size="small" style={{ width: '60%' }}>
                        <MenuItem value="初期調査中">初期調査中</MenuItem>
                        <MenuItem value="設計完了">設計完了</MenuItem>
                        <MenuItem value="着工式挙行">着工式挙行</MenuItem>
                        <MenuItem value="主体工事完了">主体工事完了</MenuItem>
                        <MenuItem value="内装工事完了">内装工事完了</MenuItem>
                        <MenuItem value="竣工式典挙行">竣工式典挙行</MenuItem>
                      </Select>
                      {/* <TextField
                        {...field}
                        size="small"
                        style={{ width: '66%' }}
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                      /> */}
                    </div>
                  )}
                />
              </Box>
              <Box flex={1}></Box>
            </Box>
            <Box flex={2} mr={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between" className="ad-search-item">
            <label>請求条件</label>
            <Box flex={1} mr={2} className="ag-theme-alpine" style={{ height: '182px' }}>
              <AgGridReact
                rowData={data}
                theme={AGGridTheme}
                columnDefs={requestColumns.current}
                headerHeight={30}
                rowHeight={30}
                defaultColDef={defaultColDef}
              />
            </Box>
          </Box>
          <Box className="ad-search-item">
            <Box flex={2} mr={2}>
              <Box flex={2} className="ad-search-item">
                <Controller
                  name="field46"
                  disabled={isHensyuuKengen}
                  control={control}
                  render={({ field }) => (
                    <div className="ad-search-item">
                      <label>支払日</label>
                      <TextField {...field} size="small" />
                    </div>
                  )}
                />
                <Controller
                  name="field47"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item2">
                      <label>日締</label>
                      <Select {...field} size="small" style={{ minWidth: 100 }}>
                        <MenuItem value="1">月末締</MenuItem>
                        <MenuItem value="2">15日締</MenuItem>
                      </Select>
                    </div>
                  )}
                />
                <Controller
                  name="field48"
                  control={control}
                  disabled={isHensyuuKengen}
                  render={({ field }) => (
                    <div className="ad-search-item3">
                      <TextField {...field} size="small" style={{ marginLeft: '12px' }} />
                      <label>日払い</label>
                    </div>
                  )}
                />
              </Box>
            </Box>
            <Box flex={2} mr={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between" className="ad-search-item">
            <label>現場情報</label>
            <Box flex={3} mr={2} className="ag-theme-alpine" style={{ height: '182px' }}>
              <AgGridReact
                rowData={rowData}
                theme={AGGridTheme}
                columnDefs={siteInfoColumns.current}
                headerHeight={30}
                rowHeight={30}
                defaultColDef={defaultColDef}
              />
            </Box>
            <Box flex={2} mr={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between" className="ad-search-item">
            <label>案件要望</label>
            <Box flex={1} mr={2} className="ad-search-item">
              <Box flex={3} mr={2} className="ag-theme-alpine" style={{ height: '182px' }}>
                <AgGridReact
                  rowData={youBouColumnsData}
                  theme={AGGridTheme}
                  columnDefs={youBouColumnsColumns.current}
                  headerHeight={30}
                  rowHeight={30}
                  defaultColDef={defaultColDef}
                  enableCellSpan
                />
              </Box>
              <Box flex={1} mr={2}></Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="space-between">
            <Box flex={6} mr={2}>
              <Controller
                name="field49"
                control={control}
                disabled={isHensyuuKengen}
                // rules={{ required: '不成約理由が入力されていません' }}
                render={({ field, fieldState }) => (
                  <div className="ad-search-item">
                    <label>*不成約理由</label>
                    <TextField
                      {...field}
                      fullWidth
                      size="small"
                      multiline
                      rows={6}
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                    />
                  </div>
                )}
              />
            </Box>
            <Box flex={2}></Box>
          </Box>
          <Box display="flex" justifyContent="space-between" className="ad-search-item">
            <label>先行作業内諾書</label>
            <Box flex={1} mr={2} className="ad-search-item">
              <Box flex={4} mr={2} className="ag-theme-alpine" style={{ height: '182px' }}>
                <AgGridReact
                  rowData={senkouSagyouNaidakusyoMeisaiInfoData}
                  theme={AGGridTheme}
                  columnDefs={senkouSagyouNaidakusyoMeisaiInfoColumns.current}
                  headerHeight={30}
                  rowHeight={30}
                  defaultColDef={defaultColDef}
                />
              </Box>
              <Box flex={1} mr={2}></Box>
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebB0030;
