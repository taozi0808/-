import React, { FC, useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebQ0070CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Button, Radio, RadioGroup, FormControlLabel } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { AddCircleOutlineRounded, RemoveCircleOutlineRounded } from '@mui/icons-material';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';

const WebQ0070CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();

  const [startDate, setStartDate] = useState('< < < 1/5 > > > ');
  const [startSubDate, setStartSubDate] = useState('< < < 1/3 > > > ');
  const [jzData, setJzData] = useState([]);
  const [jzData1, setJzData1] = useState([{}, {}]);
  const [isCollapse, setIsCollapse] = useState(false);
  const [isCollapse1, setIsCollapse1] = useState(false);

  useEffect(() => {
    setPageTitle('再下請通知書登録');
    const tempData = [];
    for (let i = 0; i < 4; i++) {
      tempData.push({
        id: i + 1,
      });
    }
    setJzData(tempData);
    return () => setPageTitle('');
  }, [setPageTitle]);

  const columnRefs = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: 'No',
      field: 'id',
      spanRows: true,
      width: 60,
      headerClass: 'center-header',
      cellClass: 'center-cell',
      editable: false,
    },
    {
      headerName: '許可・認定',
      field: 'conditionName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '業者',
      field: 'gyousya',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header hide-header-after',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '番号',
      field: 'percentage',
      cellEditor: 'agTextCellEditor',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '許可日・認定日',
      field: 'conditionNameDate',
      cellEditor: 'agDateCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 140,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs1 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '*专门技术者名',
      field: 'conditionName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*资格内容',
      field: 'gyousya',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '*担当工事内容',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const columnRefs2 = useRef<(ColDef | ColGroupDef)[]>([
    {
      headerName: '区分',
      field: 'conditionName',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'cell-gray',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '营业所の名称',
      field: 'gyousya',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '健康保险',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '厚生年金保险',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: '雇佣保险',
      field: 'number',
      cellEditor: 'agTextCellEditor',
      headerClass: 'center-header',
      cellClass: 'center-cell',
      width: 150,
      cellEditorParams: {
        maxLength: 20,
      },
    },
  ]);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<CustomerManagementFormValues>();

  const renderTextField = (
    label: string,
    name: keyof CustomerManagementFormValues,
    required: boolean = false,
    width = '100%',
    multiRow?: boolean,
  ) => (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Box display="flex">
          {label ? (
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 150, lineHeight: '40px', textAlign: 'center' }}>
              {required ? '* ' : ''}
              {label}
            </Box>
          ) : null}
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width,
            }}
            {...(multiRow && { multiline: true, rows: 4 })}
          />
        </Box>
      )}
    />
  );

  return (
    <div>
      <div className="webq0070-container">
        <div className="top">
          <span>{startDate}</span>
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <Box component="form" sx={{ width: '100%' }}>
          <div className="top-operation">
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                承认
              </Button>
              <Button
                variant="contained"
                size="small"
                style={{ margin: '8px 8px', minWidth: 96 }}
                onClick={() => {
                  navigate(`/webQ0010`);
                }}
              >
                キャンセル
              </Button>
            </div>
            <div>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                印刷
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96, margin: '0 8px' }} type="submit">
                作业者名簿
              </Button>
              <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
                下请契约台账
              </Button>
            </div>
          </div>

          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '20px',
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', width: '60%' }}>
              {renderTextField('申请日', 'sqDate', true)}
              <div style={{ display: 'flex', gap: 4 }}>
                <span style={{ color: 'red', fontWeight: 'bold', margin: '0 10px', fontSize: '0.7re,' }}>{'【承认】'}</span>
                <span style={{ fontSize: '0.6rem' }}>{startSubDate}</span>
              </div>
            </Box>
            <Box>{renderTextField('承认日', 'crDate', true)}</Box>
          </Box>
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '10px',
            }}
          >
            <Box sx={{ width: '60%' }}>{renderTextField('值近上位の注文者名', 'zwzName', false)}</Box>
            <Box>{renderTextField('事业者ID', 'syzID_zwz')}</Box>
          </Box>
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              mt: '10px',
            }}
          >
            <Box sx={{ width: '60%' }}>{renderTextField('现场代理人名(所长名)', 'dlrName', false)}</Box>
            <Box></Box>
          </Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【报告下请业者】'}
          </Button>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '50%' }}>{renderTextField('会社名', 'companyName', false)}</Box>
          <Box>{renderTextField('事业者ID', 'syzID_company')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '50%' }}>{renderTextField('代表者名', 'dbName', false)}</Box>
          <Box></Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ display: 'flex' }}>{renderTextField('邮政编号', 'yzId_1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'yzId_2', false, '80px')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '70%' }}>{renderTextField('住所1', 'address1', false)}</Box>
          <Box />
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ width: '70%' }}>{renderTextField('住所2', 'address2', false)}</Box>
          <Box />
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '10px',
          }}
        >
          <Box sx={{ display: 'flex' }}>{renderTextField('电话番号', 'tel1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'tel2', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'tel3', false, '80px')}</Box>
          <Box sx={{ display: 'flex', marginLeft: '10%' }}>{renderTextField('FAX番号', 'fax1', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'fax2', false, '80px')}</Box>
          <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
            <span>-</span>
          </Box>
          <Box>{renderTextField('', 'fax3', false, '80px')}</Box>
        </Box>
        <Box
          sx={{
            display: 'flex',
            width: '100%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【自社注意事项】'}
          </Button>
        </Box>
        <div style={{ display: 'flex', marginLeft: '-24px' }}>
          <div
            onClick={() => {
              setIsCollapse(!isCollapse);
            }}
          >
            {isCollapse ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
          </div>
          {isCollapse ? (
            <Box sx={{ border: '2px solid black', width: '100%', mt: '20px' }}>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【工事名称及工作内容】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('著文书工程', 'zsxg_zwsgz', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '158px' }} />
                <Box sx={{ width: '40%' }}>{renderTextField('', 'zsxg_detail', false, '100%', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ display: 'flex' }}>{renderTextField('工期', 'zsxg_startDate', false, '160px')}</Box>
                <Box sx={{ fontSize: '2rem', margin: '0 4px' }}>
                  <span>~</span>
                </Box>
                <Box>{renderTextField('', 'zsxg_endDate', false, '160px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('契约日', 'zsxg_qyDate', true, '160px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 150, lineHeight: '40px', textAlign: 'center' }}>{'建筑业许可'}</Box>
                <div style={{ width: '100%', height: '218px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData} theme={AGGridTheme} columnDefs={columnRefs.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('监督员名', 'zsxg_jdName', true)}</Box>
                <Box sx={{ width: '50%', marginLeft: '1%' }}>{renderTextField('权限及意见伸出方法', 'zsxg_jdscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('现场代理人名', 'zsxg_xcdlName', true)}</Box>
                <Box sx={{ width: '50%', marginLeft: '1%' }}>{renderTextField('权限及意见伸出方法', 'zsxg_scdlscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('主任技术者名', 'zsxg_zrLevel', true, '100px')}</Box>
                <Box sx={{ width: '10px' }}></Box>
                <Box>{renderTextField('', 'zsxg_zgContent', false, '200px')}</Box>
                <Box sx={{ width: '42%' }}>{renderTextField('资格内容', 'zsxg_scdlscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('安全卫生责任者名', 'zsxg_aqzrName', true)}</Box>
                <Box sx={{ width: '40%' }}>{renderTextField('安全卫生推进者名', 'zsxg_aqtjName')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('雇佣管理者名', 'zsxg_gyglName', true)}</Box>
                <Box sx={{ width: '40%' }}></Box>
              </Box>
              <Box
                sx={{
                  width: '90%',
                  mt: '10px',
                }}
              >
                <div style={{ width: 'calc( 100% - 158px)', height: '218px', marginLeft: '158px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData} theme={AGGridTheme} columnDefs={columnRefs1.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ marginLeft: '180px' }}>{renderTextField('登录基干技能者名', 'zsxg_dljnzName', true, '100%')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '180px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '220px' }}>
                    {'* 一号特定技能外国人的从业情况'}
                  </Box>
                  <Controller
                    name={'zsxg_yhwgrStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '220px' }}>
                    {'* 外国人建设就业者的情况'}
                  </Box>
                  <Controller
                    name={'zsxg_wgjszStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '180px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', width: '220px', lineHeight: '40px', textAlign: 'center' }}>
                    {'* 外国人实习生的从业情况'}
                  </Box>
                  <Controller
                    name={'zsxg_wgsxsStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【健康保险的加入情况】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('健康保险', 'zsxg_jkbx', false)}</Box>
                <Box sx={{ width: '30%' }}>{renderTextField('厚生年金保险', 'zsxg_njbx', false)}</Box>
                <Box sx={{ width: '30%', mr: '16px' }}>{renderTextField('雇佣保险', 'zsxg_gybs', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【*事业所整理记号等】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '90%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '100px' }}></Box>
                <div style={{ width: '100%', height: '134px', marginBottom: '2rem' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData1} theme={AGGridTheme} columnDefs={columnRefs2.current} />
                </div>
              </Box>
            </Box>
          ) : null}
        </div>
        <Box
          sx={{
            display: 'flex',
            width: '80%',
            mt: '20px',
          }}
        >
          <Button
            variant="contained"
            disabled
            sx={{
              '&.Mui-disabled': {
                color: 'black',
                fontWeight: 'bold',
              },
            }}
          >
            {'【在下请复关系】'}
          </Button>
        </Box>
        <div style={{ display: 'flex', marginLeft: '-24px' }}>
          <div
            onClick={() => {
              setIsCollapse1(!isCollapse1);
            }}
          >
            {isCollapse1 ? <AddCircleOutlineRounded /> : <RemoveCircleOutlineRounded />}
          </div>
          {isCollapse1 ? (
            <Box sx={{ border: '2px solid black', width: '100%', mt: '20px' }}>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '50%' }}>{renderTextField('会社名', 'zxqfgx_companyName', false)}</Box>
                <Box>{renderTextField('事业者ID', 'zxqfgx_syzID_company', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('代表者名', 'zxqfgx_dbName', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('邮政编号', 'zxqfgx_yzId_1', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_yzId_2', false, '80px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '60%' }}>{renderTextField('住所1', 'zxqfgx_address1', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '60%' }}>{renderTextField('住所2', 'zxqfgx_address2', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('电话番号', 'zxqfgx_tel1', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_tel2', false, '80px')}</Box>
                <Box sx={{ fontSize: '1.5rem', margin: '0 4px' }}>
                  <span>-</span>
                </Box>
                <Box>{renderTextField('', 'zxqfgx_tel3', false, '80px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '80%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【工事名称及工作内容】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('著文书工程', 'zsxg_zwsgz', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '158px' }} />
                <Box sx={{ width: '40%' }}>{renderTextField('', 'zsxg_detail', false, '100%', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ display: 'flex' }}>{renderTextField('工期', 'zsxg_startDate', false, '160px')}</Box>
                <Box sx={{ fontSize: '2rem', margin: '0 4px' }}>
                  <span>~</span>
                </Box>
                <Box>{renderTextField('', 'zsxg_endDate', false, '160px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('契约日', 'zsxg_qyDate', true, '160px')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 150, lineHeight: '40px', textAlign: 'center' }}>{'建筑业许可'}</Box>
                <div style={{ width: '100%', height: '218px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData} theme={AGGridTheme} columnDefs={columnRefs.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('监督员名', 'zsxg_jdName', true)}</Box>
                <Box sx={{ width: '50%', marginLeft: '1%' }}>{renderTextField('权限及意见伸出方法', 'zsxg_jdscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('现场代理人名', 'zsxg_xcdlName', true)}</Box>
                <Box sx={{ width: '50%', marginLeft: '1%' }}>{renderTextField('权限及意见伸出方法', 'zsxg_scdlscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box>{renderTextField('主任技术者名', 'zsxg_zrLevel', true, '100px')}</Box>
                <Box sx={{ width: '10px' }}></Box>
                <Box>{renderTextField('', 'zsxg_zgContent', false, '200px')}</Box>
                <Box sx={{ width: '42%' }}>{renderTextField('资格内容', 'zsxg_scdlscFunction', true)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('安全卫生责任者名', 'zsxg_aqzrName', true)}</Box>
                <Box sx={{ width: '40%' }}>{renderTextField('安全卫生推进者名', 'zsxg_aqtjName')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '40%' }}>{renderTextField('雇佣管理者名', 'zsxg_gyglName', true)}</Box>
                <Box sx={{ width: '40%' }}></Box>
              </Box>
              <Box
                sx={{
                  width: '90%',
                  mt: '10px',
                }}
              >
                <div style={{ width: 'calc( 100% - 158px)', height: '218px', marginLeft: '158px' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData} theme={AGGridTheme} columnDefs={columnRefs1.current} />
                </div>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ marginLeft: '180px' }}>{renderTextField('登录基干技能者名', 'zsxg_dljnzName', true, '100%')}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '180px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '220px' }}>
                    {'* 一号特定技能外国人的从业情况'}
                  </Box>
                  <Controller
                    name={'zsxg_yhwgrStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                  <Box sx={{ mr: 1, fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', width: '220px' }}>
                    {'* 外国人建设就业者的情况'}
                  </Box>
                  <Controller
                    name={'zsxg_wgjszStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box display={'flex'} sx={{ marginLeft: '180px' }}>
                  <Box sx={{ mr: 1, fontWeight: 'bold', width: '220px', lineHeight: '40px', textAlign: 'center' }}>
                    {'* 外国人实习生的从业情况'}
                  </Box>
                  <Controller
                    name={'zsxg_wgsxsStatus'}
                    control={control}
                    render={({ field }) => (
                      <RadioGroup row {...field}>
                        <FormControlLabel value="true" control={<Radio />} label="有" />
                        <FormControlLabel value="false" control={<Radio />} label="无" />
                      </RadioGroup>
                    )}
                  />
                </Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【健康保险的加入情况】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '30%' }}>{renderTextField('健康保险', 'zsxg_jkbx', false)}</Box>
                <Box sx={{ width: '30%' }}>{renderTextField('厚生年金保险', 'zsxg_njbx', false)}</Box>
                <Box sx={{ width: '30%', mr: '16px' }}>{renderTextField('雇佣保险', 'zsxg_gybs', false)}</Box>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '100%',
                  mt: '20px',
                  ml: '16px',
                }}
              >
                <Button
                  variant="contained"
                  disabled
                  sx={{
                    '&.Mui-disabled': {
                      color: 'black',
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {'【*事业所整理记号等】'}
                </Button>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  width: '90%',
                  mt: '10px',
                }}
              >
                <Box sx={{ width: '100px' }}></Box>
                <div style={{ width: '100%', height: '134px', marginBottom: '2rem' }} className="ag-theme-alpine">
                  <AgGridReact rowData={jzData1} theme={AGGridTheme} columnDefs={columnRefs2.current} />
                </div>
              </Box>
            </Box>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default WebQ0070CreateForm;
