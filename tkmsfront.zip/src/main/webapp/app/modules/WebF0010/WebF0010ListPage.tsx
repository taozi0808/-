import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebF0010ListPage.scss';
import dayjs from 'dayjs';
import { DBManager, STORAGE_KEY_BUKKEN, bukkenDataList } from 'app/shared/util/construction-list';
import WebF0010SearchDialog from './SearchDialog/WebF0010SearchDialog';
import { Column } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const WebF0010ListPage = () => {
  // ナビゲーション
  const navigate = useNavigate();
  // タイトル
  const { setPageTitle } = usePageTitleStore();
  // データ
  const [rowData, setRowData] = useState([]);
  // カラム
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      sortable: true,
      filterable: true,
      minWidth: 50,
      cssClass: 'center',
    },
    {
      id: 'bukkenCode',
      name: '物件コード',
      field: 'bukkenCode',
      sortable: true,
      filterable: true,
      minWidth: 150,
      cssClass: 'left',
    },
    {
      id: 'gaitouArea',
      name: '該当エリア',
      field: 'gaitouArea',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'bukkenName',
      name: '物件名',
      field: 'bukkenName',
      minWidth: 313,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'kokyakuCode',
      name: '顧客コード',
      field: 'kokyakuCode',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'kokyakuName',
      name: '顧客名',
      field: 'kokyakuName',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'juchuYmd',
      name: '受注年月日',
      field: 'juchuYmd',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'ukeoiKingaku',
      name: '請負金額',
      field: 'ukeoiKingaku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(val);
      },
    },
    {
      id: 'chakkouDate',
      name: '着工日',
      field: 'chakkouDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'kankoDate',
      name: '完工日',
      field: 'kankoDate',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'kojiBumon',
      name: '工事部門',
      field: 'kojiBumon',
      minWidth: 250,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'kojiKanrishoku',
      name: '工事管理職',
      field: 'kojiKanrishoku',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'senninGijutsuSha',
      name: '専任技術者',
      field: 'senninGijutsuSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'sekoTantoSha',
      name: '施工担当者',
      field: 'sekoTantoSha',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
  ]);
  // 権限
  const [permissionInfo, setPermissionInfo] = useState({
    // 編集
    hensyuuKengen: true,
    // 参照
    sansyouKengen: true,
  });
  // 行を選択
  const [selectedId, setSelectedId] = useState('');
  // 選択行変更イベント
  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };
  // 検索イベント
  const handleSearch = values => {
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // TODO API呼び出し
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    let contractList = DBManager.getBukkenList();
    if (contractList.length === 0) {
      // モックデータ
      contractList = bukkenDataList(500);
      localStorage.setItem(STORAGE_KEY_BUKKEN, JSON.stringify(contractList));
    }

    // データを設定
    setRowData(contractList);
  };

  useEffect(() => {
    // タイトルを設定
    setPageTitle('物件一覧');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webF0010-container" id="contract-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate('/webF0030/add');
              }}
            >
              新規登録
            </Button>

            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webF0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webF0030/preview/${selectedId}`);
                }}
              >
                参照
              </Button>
            )}
          </div>
          <div>
            <WebF0010SearchDialog onSearch={handleSearch} />
            {rowData.length > 0 && (
              <>
                <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }}>
                  印刷
                </Button>
                <Button variant="contained" size="small" style={{ minWidth: 96 }}>
                  CSV出力
                </Button>
              </>
            )}
          </div>
        </div>

        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            {
              title: '編集',
              command: 'edit',
              action: (_, callbackArgs) => {
                navigate(`/webF0030/edit/${callbackArgs.dataContext.id}`);
              },
            },
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webF0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebF0010ListPage;
