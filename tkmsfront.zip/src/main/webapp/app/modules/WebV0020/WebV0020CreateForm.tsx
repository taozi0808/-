import React, { FC, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './WebV0020CreateForm.scss';
import LastUpdateInfo from 'app/components/LastUpdateInfo';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { Box, TextField, Select, MenuItem, Button, FormHelperText, FormControlLabel, Checkbox } from '@mui/material';
import { CustomerManagementFormValues } from './types';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import { DBManager, sagyouInData } from 'app/shared/util/construction-list';

const WebV0020CreateForm: FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const { setPageTitle } = usePageTitleStore();
  useEffect(() => {
    setPageTitle('作業員登録');
    return () => setPageTitle('');
  }, [setPageTitle]);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setError,
    setValue,
  } = useForm<CustomerManagementFormValues>({
    defaultValues: {
      emailAddress: '',
      sagyouInCode: '',
      nameCana: '',
      shimei: '',
      gyoushaCode: '',
      gyoushaName: '',
      shurui: '',
      yatoiNyuuDate: '',
      seiDate: '',
      age: '',
      ketsuekigata: '',
      CCUSkakuninBangou: '',
      gaikokuSeki: true,
      kokuseki: '',
      postalCodePart1: '',
      postalCodePart2: '',
      address1: '',
      address2: '',
      phone: {
        part1: '',
        part2: '',
        part3: '',
      },
      renrakuSakiName: '',
      zokugara: '',
      bankName: '',
      address3: '',
      phone1: {
        part1: '',
        part2: '',
        part3: '',
      },
      kenkouShindanNichi: '',
      ketsuatsu: {
        part1: '',
        part2: '',
      },
      TksKenkouShindanNichi: '',
      shurui2: '',
      shikakuMenkyo: '',
      ginouKoushuu: '',
      tokubetsuKyoiku: '',
      koyouKubun: '',
      koyouKyoikuJisshi: '',
      shokuchouKyoikuJisshiDate: '',
      shuninGijutsuMono: '',
      ousaiTokubetsuBangou: '',
      shurui3: {
        part1: '',
        part2: '',
        part3: '',
      },
      bangou: {
        part1: '',
        part2: '',
        part3: '',
      },
      jogaiRiyuu: {
        part1: '',
        part2: '',
        part3: '',
      },
      kakuninTenpu: {
        part1: '',
        part2: '',
        part3: '',
      },
    },
    mode: 'onBlur',
  });

  /** TODO: 検索 */
  const postalCodeSearch = () => {};

  /** TODO: 添付 */
  const tenpuSearch1 = () => {};
  const tenpuSearch2 = () => {};
  const tenpuSearch3 = () => {};
  const tenpuSearch4 = () => {};
  const tenpuSearch5 = () => {};
  const tenpuSearch6 = () => {};

  /** TODO: 保存 */
  const onSave: SubmitHandler<CustomerManagementFormValues> = data => {
    console.log('フォーム送信結果:', data);
  };

  // 一時的なモックデータ
  let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY996');
  // let SagyouInList = DBManager.getList();
  if (sagyouInList.length === 0) {
    sagyouInList = sagyouInData(500);
    localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY996', JSON.stringify(sagyouInList));
  }

  if (id === undefined) {
    console.log('新規登録');
  } else {
    const editData = sagyouInList.find(item => item.id === id) || null;
    if (editData === null) {
      console.log('データ異常');
    } else {
      useEffect(() => {
        setValue('emailAddress', 'asdhajsda@cn.com');
        setValue('sagyouInCode', editData.sagyouInCode);
        setValue('shimei', editData.shimei);
        setValue('nameCana', 'アイウエオ');
        setValue('gyoushaCode', '54646515644');
        setValue('gyoushaName', '鈴木 太郎');
        setValue('shurui', editData.koyouKeitai);
        setValue('yatoiNyuuDate', '2024/05/05');
        setValue('seiDate', '1988/05/05');
        setValue('age', '38');
        setValue('ketsuekigata', 'typeA');
        setValue('CCUSkakuninBangou', editData.CCUS === '✕' ? '' : '1234567890');
        setValue('kokuseki', '日本');
        setValue(`${'phone'}.part1`, '100');
        setValue(`${'phone'}.part2`, '8888');
        setValue(`${'phone'}.part3`, '6666');
        setValue('postalCodePart1', '0010');
        setValue('postalCodePart2', '568');
        setValue('address1', '愛知県名古屋市中村区名駅南1-1-1');
        setValue('address2', '愛知県名古屋市中村区名駅南1-1-1');

        setValue('renrakuSakiName', '高橋 太郎');
        setValue('zokugara', '父親');
        setValue('address3', '北海道札幌市中央区北1条西1-1-1');
        setValue(`${'phone1'}.part1`, '100');
        setValue(`${'phone1'}.part2`, '9999');
        setValue(`${'phone1'}.part3`, '7777');
        if (editData.CCUS === '〇') {
          setValue('kenkouShindanNichi', '2024/01/01');
          setValue(`${'ketsuatsu'}.part1`, '80');
          setValue(`${'ketsuatsu'}.part2`, '180');
          setValue('TksKenkouShindanNichi', '2024/01/01');
          setValue('shurui2', '2024/01/01');
          setValue('tokubetsuKyoiku', 'typeA');
          setValue('ginouKoushuu', 'typeA');
          setValue('shikakuMenkyo', 'typeA');
          setValue('koyouKubun', editData.shimei === '社員' ? 'typeA' : 'typeB');
          setValue('koyouKyoikuJisshi', '実施済み');
          setValue('shokuchouKyoikuJisshiDate', '2024/02/02');
          setValue('shuninGijutsuMono', 'typeA');
          setValue('ousaiTokubetsuBangou', '9876543210');
        }
        setValue(`${'shurui3'}.part1`, editData.kenkouhoken === '非健康保険' ? 'typeB' : 'typeA');
        setValue(`${'bangou'}.part1`, '56445641');
        setValue(`${'jogaiRiyuu'}.part1`, '01');

        setValue(`${'shurui3'}.part2`, editData.kouseinenkin === '未加入' ? 'typeB' : 'typeA');
        setValue(`${'bangou'}.part2`, '41646544');
        setValue(`${'jogaiRiyuu'}.part2`, '02');

        setValue(`${'shurui3'}.part3`, editData.koyouhoken === '未加入' ? 'typeB' : 'typeA');
        setValue(`${'bangou'}.part3`, '46461321');
        setValue(`${'jogaiRiyuu'}.part3`, '02');
      }, []);
    }
  }

  const renderTextField = (label: string, name: keyof CustomerManagementFormValues, required: boolean = false) => (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Box display="flex">
          <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>{label}</Box>
          <TextField
            {...field}
            size="small"
            error={!!fieldState.error}
            helperText={fieldState.error ? fieldState.error.message : ''}
            sx={{
              width: '100%',
            }}
          />
        </Box>
      )}
    />
  );

  return (
    <div>
      <div className="webv0020-container">
        <div className="top">
          <div className="top-item">
            <LastUpdateInfo userId={''} />
          </div>
        </div>
        <Box component="form" onSubmit={handleSubmit(onSave)} sx={{ width: '100%', overflowY: 'hidden' }}>
          <div className="top-operation">
            <Button variant="contained" size="small" style={{ minWidth: 96 }} type="submit">
              保存
            </Button>
            <Button variant="contained" size="small" style={{ minWidth: 96 }} onClick={() => {}}>
              申請
            </Button>
            <Button
              variant="contained"
              size="small"
              style={{ margin: '8px 0', minWidth: 96 }}
              onClick={() => {
                navigate(`/webV0010`);
              }}
            >
              キャンセル
            </Button>
          </div>

          <Box sx={{ mb: 2, maxWidth: '80%', marginTop: '20px' }}>{renderTextField('メールアドレス', 'emailAddress', true)}</Box>
          <Box sx={{ mb: 2, maxWidth: '49%' }}>{renderTextField('作業員コード', 'sagyouInCode', true)}</Box>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('氏名', 'shimei')}
            {renderTextField('氏名カナ', 'nameCana', true)}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('業者コード', 'gyoushaCode')}
            {renderTextField('業者名', 'gyoushaName')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('種類', 'shurui')}
            {renderTextField('雇入年月日', 'yatoiNyuuDate')}
          </Box>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('生年月日', 'seiDate')}
            {renderTextField('年齢', 'age')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="ketsuekigata"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>血液型</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">A</MenuItem>
                      <MenuItem value="typeB">B</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
            {renderTextField('CCUS確認番号', 'CCUSkakuninBangou')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Box display="flex">
              <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>外国籍</Box>
              <Controller
                name="gaikokuSeki"
                control={control}
                render={({ field }) => <FormControlLabel control={<Checkbox {...field} checked={field.value} />} label="有り" />}
              />
            </Box>

            {renderTextField('国籍', 'kokuseki')}
          </Box>

          <Box display="flex" sx={{ mb: 2, maxWidth: '96%' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>電話番号</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name={`${'phone'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
              <span>-</span>
              <Controller
                name={`${'phone'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
              <span>-</span>
              <Controller
                name={`${'phone'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
            </Box>
          </Box>

          <Box display="flex" sx={{ mb: 2, width: '100%' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>郵便番号</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name="postalCodePart1"
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '26%',
                    }}
                  />
                )}
              />
              <span>-</span>
              <Controller
                name="postalCodePart2"
                control={control}
                render={({ field, fieldState }) => (
                  <div style={{ minWidth: '70%' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '16.4%',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      style={{ marginTop: 4, left: '10px', minWidth: 90, maxHeight: '40px' }}
                      onClick={postalCodeSearch}
                    >
                      検索
                    </Button>
                  </div>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%' }}>{renderTextField('住所1', 'address1', true)}</Box>
          <Box sx={{ mb: 2, maxWidth: '100%' }}>{renderTextField('住所2', 'address2', true)}</Box>

          <div className="form-item" style={{ marginTop: 40 }}>
            <div className="title">被災時連絡先</div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('氏名', 'renrakuSakiName')}
            {renderTextField('続柄', 'zokugara', true)}
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%' }}>{renderTextField('住所', 'address3', true)}</Box>

          <Box display="flex" sx={{ mb: 2, width: '95%' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>電話番号</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Controller
                name={`${'phone1'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
              <span> </span>
              <Controller
                name={`${'phone1'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
              <span> </span>
              <Controller
                name={`${'phone1'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <TextField
                    {...field}
                    size="small"
                    error={!!fieldState.error}
                    helperText={fieldState.error ? fieldState.error.message : ''}
                    sx={{
                      width: '12%',
                    }}
                  />
                )}
              />
            </Box>
          </Box>

          <div className="form-item" style={{ marginTop: 40 }}>
            <div className="title">健康診断情報</div>
          </div>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('健康診断日', 'kenkouShindanNichi')}
            <Box display="flex">
              <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>血圧</Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                <Controller
                  name={`${'ketsuatsu'}.part1` as keyof CustomerManagementFormValues}
                  control={control}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                    />
                  )}
                />
                <span>～</span>
                <Controller
                  name={`${'ketsuatsu'}.part2` as keyof CustomerManagementFormValues}
                  control={control}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                    />
                  )}
                />
              </Box>
            </Box>
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('特殊健康診断日', 'TksKenkouShindanNichi')}
            {renderTextField('種類', 'shurui2', true)}
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%' }}>
            <Controller
              name="tokubetsuKyoiku"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>特別教育</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">技能教育</MenuItem>
                      <MenuItem value="typeB">語言教育</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%' }}>
            <Controller
              name="ginouKoushuu"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>技能講習</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">鉄筋</MenuItem>
                      <MenuItem value="typeB">配管工</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%' }}>
            <Controller
              name="shikakuMenkyo"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>資格免許</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">資格証 A</MenuItem>
                      <MenuItem value="typeB">資格証 B</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            <Controller
              name="koyouKubun"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>雇用区分</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">社員</MenuItem>
                      <MenuItem value="typeB">協力</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
            {renderTextField('雇用教育実施', 'koyouKyoikuJisshi')}
          </Box>

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              columnGap: 2,
              mb: 2,
              maxWidth: '100%',
            }}
          >
            {renderTextField('職長教育実施年月日', 'shokuchouKyoikuJisshiDate')}
            <Controller
              name="shuninGijutsuMono"
              control={control}
              render={({ field, fieldState }) => (
                <Box display="flex">
                  <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>主任技術者</Box>
                  <Box sx={{ width: '100%' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">はい</MenuItem>
                      <MenuItem value="typeB">いいえ</MenuItem>
                    </Select>
                    {fieldState.error && <FormHelperText sx={{ color: '#d32f2f', ml: 1 }}>*{fieldState.error.message}</FormHelperText>}
                  </Box>
                </Box>
              )}
            />
          </Box>

          <Box sx={{ mb: 2, maxWidth: '49%' }}>{renderTextField('労災特別番号', 'ousaiTokubetsuBangou', true)}</Box>

          <Box sx={{ maxWidth: '100%', padding: 0 }}>
            <Box sx={{ display: 'flex', p: 2, padding: 0, marginLeft: '140px' }}>
              <Box sx={{ fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', padding: '0px 75px' }}>健康保険</Box>
              <Box sx={{ fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', padding: '0px 75px' }}>厚生年金</Box>
              <Box sx={{ fontWeight: 'bold', lineHeight: '40px', textAlign: 'center', padding: '0px 75px' }}>雇用保険</Box>
            </Box>
          </Box>

          <Box sx={{ maxWidth: '100%', padding: 0, display: 'flex' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>種類</Box>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name={`${'shurui3'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <Select
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        sx={{
                          width: '100%',
                        }}
                        displayEmpty
                      >
                        <MenuItem value="typeA">非健康保険</MenuItem>
                        <MenuItem value="typeB">健康保険組合</MenuItem>
                      </Select>
                    </Box>
                  </Box>
                )}
              />
              <Controller
                name={`${'shurui3'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">加入</MenuItem>
                      <MenuItem value="typeB">未加入</MenuItem>
                    </Select>
                  </Box>
                )}
              />
              <Controller
                name={`${'shurui3'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="typeA">加入</MenuItem>
                      <MenuItem value="typeB">未加入</MenuItem>
                    </Select>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%', display: 'flex', marginTop: '16px' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>番号</Box>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name={`${'bangou'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                    </Box>
                  </Box>
                )}
              />
              <Controller
                name={`${'bangou'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
              <Controller
                name={`${'bangou'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ maxWidth: '100%', padding: 0, display: 'flex' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center' }}>除外理由</Box>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name={`${'jogaiRiyuu'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <Select
                        {...field}
                        size="small"
                        error={!!fieldState.error}
                        sx={{
                          width: '100%',
                        }}
                        displayEmpty
                      >
                        <MenuItem value="01">個人事業主</MenuItem>
                        <MenuItem value="02">個人事業主家族</MenuItem>
                        <MenuItem value="03">短時間労働者</MenuItem>
                        <MenuItem value="04">後期高齢者医療の被保険者</MenuItem>
                        <MenuItem value="05">厚生労働大臣</MenuItem>
                        <MenuItem value="06">５人未満の個人事業所</MenuItem>
                      </Select>
                    </Box>
                  </Box>
                )}
              />
              <Controller
                name={`${'jogaiRiyuu'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="01">個人事業主</MenuItem>
                      <MenuItem value="02">個人事業主家族</MenuItem>
                      <MenuItem value="03">短時間労働者</MenuItem>
                      <MenuItem value="04">５人未満の個人事業所</MenuItem>
                    </Select>
                  </Box>
                )}
              />
              <Controller
                name={`${'jogaiRiyuu'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <Select
                      {...field}
                      size="small"
                      error={!!fieldState.error}
                      sx={{
                        width: '100%',
                      }}
                      displayEmpty
                    >
                      <MenuItem value="01">大学や専修学校の学生</MenuItem>
                      <MenuItem value="02">短期労働者</MenuItem>
                    </Select>
                  </Box>
                )}
              />
            </Box>
          </Box>

          <Box sx={{ mb: 2, maxWidth: '100%', display: 'flex', marginTop: '16px' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center', transform: 'translateY(30%)' }}>
              確認添付
            </Box>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name={`${'kakuninTenpu'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        className="input-kakuninTenpu"
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                        onClick={tenpuSearch1}
                      >
                        添付
                      </Button>
                    </Box>
                  </Box>
                )}
              />
              <Controller
                name={`${'kakuninTenpu'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      className="input-kakuninTenpu"
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                      onClick={tenpuSearch2}
                    >
                      添付
                    </Button>
                  </Box>
                )}
              />
              <Controller
                name={`${'kakuninTenpu'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      className="input-kakuninTenpu"
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                      onClick={tenpuSearch3}
                    >
                      添付
                    </Button>
                  </Box>
                )}
              />
            </Box>
          </Box>
          <Box sx={{ mb: 2, maxWidth: '100%', display: 'flex', marginTop: '16px' }}>
            <Box sx={{ mr: 1, fontWeight: 'bold', minWidth: 130, lineHeight: '40px', textAlign: 'center', transform: 'translateY(30%)' }}>
              顔確認写真
            </Box>
            <Box sx={{ display: 'flex', p: 2, padding: 0 }}>
              <Controller
                name={`${'kakuninTenpu'}.part1` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box display="flex">
                    <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px', marginLeft: '-7px' }}>
                      <TextField
                        {...field}
                        className="input-kakuninTenpu"
                        size="small"
                        error={!!fieldState.error}
                        helperText={fieldState.error ? fieldState.error.message : ''}
                        sx={{
                          width: '100%',
                        }}
                      />
                      <Button
                        variant="contained"
                        size="small"
                        style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                        onClick={tenpuSearch4}
                      >
                        添付
                      </Button>
                    </Box>
                  </Box>
                )}
              />
              <Controller
                name={`${'kakuninTenpu'}.part2` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      className="input-kakuninTenpu"
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                      onClick={tenpuSearch5}
                    >
                      添付
                    </Button>
                  </Box>
                )}
              />
              <Controller
                name={`${'kakuninTenpu'}.part3` as keyof CustomerManagementFormValues}
                control={control}
                render={({ field, fieldState }) => (
                  <Box sx={{ flex: 1, p: 2, width: '214px', padding: '0 5px' }}>
                    <TextField
                      {...field}
                      className="input-kakuninTenpu"
                      size="small"
                      error={!!fieldState.error}
                      helperText={fieldState.error ? fieldState.error.message : ''}
                      sx={{
                        width: '100%',
                      }}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      style={{ height: 32, width: '22%', marginTop: 4, marginLeft: 70 }}
                      onClick={tenpuSearch6}
                    >
                      添付
                    </Button>
                  </Box>
                )}
              />
            </Box>
          </Box>
        </Box>
      </div>
    </div>
  );
};

export default WebV0020CreateForm;
