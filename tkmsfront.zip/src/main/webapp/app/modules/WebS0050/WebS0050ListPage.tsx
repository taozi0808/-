import React, { useState, useEffect, useRef } from 'react';
import './WebS0050ListPage.scss';
import WebS0050SearchDialog from './SearchDialog/WebS0050SearchDialog';
import { DBManager, shoninSateiDataList } from 'app/shared/util/construction-list';
import { useNavigate } from 'react-router-dom';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { Column, FieldType, Formatter } from 'slickgrid-react';
import dayjs from 'dayjs';

const WebS0050ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const [selectedId, setSelectedId] = useState('');
  const navigate = useNavigate();
  const [permissionInfo] = useState({
    // TODO: 次のインタフェースがドッキングされると、両方の権限のデフォルト値がfalseに変更されます。
    hensyuuKengen: true,
    sansyouKengen: true,
  });
  const LinkFormatter: Formatter = (row, cell, value) => '<a style="text-decoration: underline">あり</a>';

  const columnRef = useRef<Array<Column>>([
    {
      id: 'No',
      name: 'No',
      field: 'no',
      minWidth: 50,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'center',
    },
    {
      id: 'genbaCode',
      name: '現場コード',
      field: 'genbaCode',
      minWidth: 160,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaName',
      name: '現場名',
      field: 'genbaName',
      width: 280,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'genbaShocho',
      name: '現場所長',
      field: 'genbaShocho',
      width: 110,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
    },
    {
      id: 'tantoBumon',
      name: '担当部門',
      field: 'tantoBumon',
      width: 130,
      minWidth: 80,
      sortable: true,
      filterable: true,
      cssClass: 'left',
      type: FieldType.string,
    },
    {
      id: 'kojiKotei',
      name: '工事工程',
      field: 'kojiKotei',
      width: 165,
      minWidth: 80,
      sortable: true,
      filterable: true,
      type: FieldType.string,
      cssClass: 'left',
    },
    {
      id: 'sateiShoninBi',
      name: '査定承認日',
      field: 'sateiShoninBi',
      minWidth: 150,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'shinseiSha',
      name: '申請者',
      field: 'shinseiSha',
      minWidth: 85,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'shinseiBi',
      name: '申請日',
      field: 'shinseiBi',
      minWidth: 135,
      sortable: true,
      filterable: true,
      cssClass: 'right',
      formatter: (_, __, val) => {
        return val ? dayjs(val).format('YYYY年MM月DD日') : '';
      },
    },
    {
      id: 'result',
      name: '結果',
      field: 'result',
      minWidth: 80,
      sortable: true,
      filterable: true,
      cssClass: 'left',
    },
    {
      id: 'comment',
      name: 'コメント',
      field: 'comment',
      minWidth: 70,
      sortable: true,
      filterable: true,
      formatter: LinkFormatter,
      cssClass: 'center',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const handleSearch = values => {
    // TODO: 次の3つのフィールドを置き換えます
    const params = {
      listSyozokuBusyoCode: 'test',
      syozokuBusyoCode: 'test',
      sbSyozokuCode: 'test',
      ...values,
    };

    // TODO: インタフェース・ドキュメントがある場合は、次のコードを放します。
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sateiList = DBManager.getShoninSateiList();
    if (sateiList.length === 0) {
      sateiList = shoninSateiDataList(500);
      // 番号作成
      sateiList = sateiList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_SATEI996', JSON.stringify(sateiList));
    }
    setRowData(sateiList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('承認一覧（査定管理）');
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webS0050-list-container" id="webS0050-list-container-container">
        <div className="top-operation">
          <div>
            <WebS0050SearchDialog onSearch={handleSearch} />
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable
          columns={columnRef.current}
          data={rowData}
          onSelectionChanged={onSelectedRowsChanged}
          enableContextMenu
          contextMenuItems={[
            // TODO: 正式なドッキングの後の段階では、右クリック メニューの可用性を、インターフェイスから返される権限に基づいて制御する必要があります。
            {
              title: '参照',
              command: 'preview',
              action: (_, callbackArgs) => {
                navigate(`/webB0030/preview/${callbackArgs.dataContext.id}`);
              },
            },
          ]}
        />
      </div>
    </div>
  );
};

export default WebS0050ListPage;
