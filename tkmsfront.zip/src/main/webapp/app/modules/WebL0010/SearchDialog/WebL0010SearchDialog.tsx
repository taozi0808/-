import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box,
  IconButton,
  Select,
  MenuItem,
  Typography,
  ListItemText,
  Radio,
  RadioGroup,
} from '@mui/material';
import DialogHead from 'app/components/DialogHead';
import { useForm, Controller } from 'react-hook-form';
import './WebL0010SearchDialog.scss';
import '../../../app.scss';
import { useNotify } from 'app/shared/layout/NotifyProvider';

const WebL0010SearchDialog = ({ onSearch }) => {
  const notify = useNotify();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedValue, setSelectedValue] = useState('');

  const { control, handleSubmit } = useForm({
    // TODO: 接口对接时按需修改字段名称，尤其是listJyucyuuJyoutai，因为目前还不知道受主状态的枚举值
    defaultValues: {
      // 顧客コード
      kokyakuCode: '',
      // 顧客名
      kokyakuMei: '',
      // 物件コード
      bukkenCode: '',
      // 物件名
      bukkenMei: '',
      // 請求書No
      seikyuuShoNo: '',
      // 予算作成者
      bukkenChakushuNichiStart: '',
      // 予算作成者
      bukkenChakushuNichiEnd: '',
      // 物件引渡日
      bukkenBikiWataruNichiStart: '',
      // 物件引渡日
      bukkenBikiWataruNichiEnd: '',
      // 表示対象
      hyojiTaishou: {
        '1': true,
        '2': false,
        '3': false,
      },
      // 表示履歴
      hyojiRireki: 'option1',
    },
  });
  const onSubmit = data => {
    // TODO: 有了接口文档后，按需调整入参数据结构；
    for (const key in data) {
      if (data[key] === '') {
        delete data[key];
      }

      if (key === 'listJyucyuuJyoutai') {
        data.listJyucyuuJyoutai = Object.keys(data.listJyucyuuJyoutai).filter(k => data.listJyucyuuJyoutai[k]);
      }
    }

    // if (data.listJyucyuuJyoutai.length === 0) {
    //   notify('受注状態を選択してください', 'warning');
    //   return;
    // }

    onSearch(data);
    handleClose();
  };

  useEffect(() => {
    // TODO: 接口对接时按需修改字段名称，尤其是listJyucyuuJyoutai，因为目前还不知道受主状态的枚举值
    onSearch({ listJyucyuuJyoutai: ['1'] });
  }, []);
  return (
    <>
      <Button variant="contained" size="small" style={{ marginRight: '8px', minWidth: 96 }} onClick={handleOpen}>
        検索
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        sx={{
          '& .MuiDialog-paper': {
            height: '500px', // 设置固定高度
          },
        }}
      >
        <DialogHead closeOnClick={handleClose} />
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogActions style={{ margin: '10px 8px 30px 0px' }}>
              <Button type="submit" variant="contained" style={{ minWidth: 105 }}>
                検索
              </Button>
              <Button onClick={handleClose} variant="contained" style={{ minWidth: 105 }}>
                キャンセル
              </Button>
            </DialogActions>
            <Box display="flex" flexDirection="column" gap={2} className="WebL0010-search-container">
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <div className="WebL0010-search-item">
                    <label>顧客コード</label>
                    <Controller
                      name="kokyakuCode"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '200px' }} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="WebL0010-search-item">
                    <label>物件着手日</label>
                    <Controller
                      name="bukkenChakushuNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="bukkenChakushuNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} size="small" type="date" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <div className="WebL0010-search-item">
                    <label>顧客名</label>
                    <Controller
                      name="kokyakuMei"
                      control={control}
                      render={({ field }) => <TextField {...field} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="WebL0010-search-item">
                    <label>物件引渡日</label>
                    <Controller
                      name="bukkenBikiWataruNichiStart"
                      control={control}
                      render={({ field }) => <TextField {...field} type="date" size="small" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                    <label style={{ minWidth: 20 }}> ～</label>
                    <Controller
                      name="bukkenBikiWataruNichiEnd"
                      control={control}
                      render={({ field }) => <TextField {...field} size="small" type="date" fullWidth InputLabelProps={{ shrink: true }} />}
                    />
                  </div>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <div className="WebL0010-search-item">
                    <label>物件コード</label>
                    <Controller
                      name="bukkenCode"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '200px' }} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="WebL0010-search-item0">
                    <label style={{ minWidth: 100 }}>表示対象</label>
                    <Controller
                      name="hyojiTaishou.1"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              defaultChecked={true}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                              sx={{
                                transform: 'scale(0.8)',
                                padding: '2px',
                              }}
                            />
                          }
                          label={
                            <Typography
                              sx={{
                                fontSize: '13px',
                                minWidth: '50px',
                                display: 'inline-block',
                                textAlign: 'left',
                              }}
                            >
                              未請求
                            </Typography>
                          }
                        />
                      )}
                    />
                    <Controller
                      name="hyojiTaishou.2"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              defaultChecked={true}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                              sx={{
                                transform: 'scale(0.8)',
                                padding: '2px',
                              }}
                            />
                          }
                          label={
                            <Typography
                              sx={{
                                fontSize: '13px',
                                minWidth: '75px',
                                display: 'inline-block',
                                textAlign: 'left',
                              }}
                            >
                              請求残有り
                            </Typography>
                          }
                        />
                      )}
                    />
                    <Controller
                      name="hyojiTaishou.3"
                      control={control}
                      render={({ field }) => (
                        <FormControlLabel
                          control={
                            <Checkbox
                              {...field}
                              defaultChecked={true}
                              checked={field.value}
                              color="default"
                              inputProps={{ 'aria-label': 'checkbox with default color' }}
                              sx={{
                                transform: 'scale(0.8)',
                                padding: '2px',
                              }}
                            />
                          }
                          label={<Typography sx={{ fontSize: '13px' }}>請求残無し</Typography>}
                        />
                      )}
                    />
                  </div>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <div className="WebL0010-search-item">
                    <label>物件名</label>
                    <Controller
                      name="bukkenMei"
                      control={control}
                      render={({ field }) => <TextField {...field} sx={{ width: '200px' }} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="WebL0010-search-item">
                    <label>表示履歴</label>
                    <Controller
                      name="hyojiRireki"
                      control={control}
                      render={({ field }) => (
                        <RadioGroup row {...field}>
                          <FormControlLabel
                            value="option1"
                            control={
                              <Radio
                                color="default"
                                inputProps={{ 'aria-label': 'checkbox with default color' }}
                                sx={{
                                  transform: 'scale(0.8)',
                                  padding: '2px',
                                }}
                              />
                            }
                            label={
                              <Typography
                                sx={{
                                  fontSize: '13px',
                                  minWidth: '120px',
                                  display: 'inline-block',
                                  textAlign: 'left',
                                }}
                              >
                                次回請求のみ表示
                              </Typography>
                            }
                          />
                          <FormControlLabel
                            value="option2"
                            control={
                              <Radio
                                color="default"
                                inputProps={{ 'aria-label': 'checkbox with default color' }}
                                sx={{
                                  transform: 'scale(0.8)',
                                  padding: '2px',
                                }}
                              />
                            }
                            label={<Typography sx={{ fontSize: '13px' }}>全請求を表示</Typography>}
                          />
                        </RadioGroup>
                      )}
                    />
                  </div>
                </Box>
              </Box>
              <Box display="flex" justifyContent="space-between">
                <Box flex={1}>
                  <div className="WebL0010-search-item">
                    <label>請求書No</label>
                    <Controller
                      name="seikyuuShoNo"
                      control={control}
                      render={({ field }) => <TextField {...field} fullWidth size="small" />}
                    />
                  </div>
                </Box>
                <Box flex={1} display="flex" justifyContent="space-between">
                  <div className="WebL0010-search-item"></div>
                </Box>
              </Box>
            </Box>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebL0010SearchDialog;
