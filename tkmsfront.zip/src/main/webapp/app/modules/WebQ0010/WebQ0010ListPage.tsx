import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './WebQ0010ListPage.scss';
import { DBManager, sagyouInData, kenkoushindan1 } from 'app/shared/util/construction-list';
import { Column, Filters } from 'slickgrid-react';
import BasicSlickGridTable from 'app/components/BasicSlickGridTable';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const WebQ0010ListPage = () => {
  const { setPageTitle } = usePageTitleStore();
  const navigate = useNavigate();
  const columnRef = useRef<Array<Column>>([
    {
      id: 'no',
      name: 'No',
      field: 'no',
      width: 48,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'sagyouInCode',
      name: '作業員コード',
      field: 'sagyouInCode',
      minWidth: 165,
      sortable: true,
      filterable: true,
    },
    {
      id: 'shimei',
      name: '氏名',
      field: 'shimei',
      width: 220,
      sortable: true,
      filterable: true,
    },
    {
      id: 'koyouKeitai',
      name: '雇用形態',
      field: 'koyouKeitai',
      width: 114,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'CCUS',
      name: 'CCUS',
      field: 'CCUS',
      width: 85,
      sortable: true,
      filterable: true,
      filter: { model: Filters.multipleSelect, collectionAsync: Promise.resolve(kenkoushindan1) },
      cssClass: 'text-align-center',
    },
    {
      id: 'kenkoushindan',
      name: '健康診断',
      field: 'kenkoushindan',
      width: 85,
      sortable: true,
      filterable: true,
      filter: { model: Filters.multipleSelect, collectionAsync: Promise.resolve(kenkoushindan1) },
      cssClass: 'text-align-center',
    },
    {
      id: 'kenkouhoken',
      name: '健康保険',
      field: 'kenkouhoken',
      width: 110,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'kouseinenkin',
      name: '厚生年金',
      field: 'kouseinenkin',
      width: 85,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
    {
      id: 'koyouhoken',
      name: '雇用保険',
      field: 'koyouhoken',
      width: 85,
      sortable: true,
      filterable: true,
      cssClass: 'text-align-center',
    },
  ]);
  const [rowData, setRowData] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [permissionInfo] = useState({
    hensyuuKengen: true,
    sansyouKengen: true,
  });

  const getMockList = () => {
    // const {
    //   data: {
    //     returnListAnkenInfo = [],
    //     hensyuuKengen = "0"
    //     sansyouKengen = "0"
    //   } = {,
    // } = await axios.post(`/getAnkenInfo`, params);

    // setPermissionInfo({
    //   hensyuuKengen: hensyuuKengen === "1",
    //   sansyouKengen: sansyouKengen === "1",
    // });
    // setRowData(returnListAnkenInfo);

    // 一時的なモックデータ
    let sagyouInList = DBManager.getMockList('CONSTRUCTION_MANAGEMENT_DB_KEY996');
    if (sagyouInList.length === 0) {
      sagyouInList = sagyouInData(500);
      // 番号作成
      sagyouInList = sagyouInList.map((item, index) => ({
        ...item,
        no: index + 1,
      }));
      localStorage.setItem('CONSTRUCTION_MANAGEMENT_DB_KEY996', JSON.stringify(sagyouInList));
    }
    setRowData(sagyouInList);
  };

  const onSelectedRowsChanged = (id: string) => {
    if (id) {
      setSelectedId(id);
    } else {
      setSelectedId('');
    }
  };

  useEffect(() => {
    setPageTitle('作業員一覧');
    getMockList();
    return () => setPageTitle('');
  }, []);

  return (
    <div>
      <div className="webQ0010-list" id="WebQ0010-list-container">
        <div className="top-operation">
          <div>
            <Button
              variant="contained"
              size="small"
              style={{ marginRight: '8px', minWidth: 96 }}
              onClick={() => {
                navigate(`/webQ0030/add`);
              }}
            >
              新規登録
            </Button>
            {permissionInfo.hensyuuKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(`/webQ0030/edit/${selectedId}`);
                }}
              >
                編集
              </Button>
            )}
            {permissionInfo.sansyouKengen && (
              <Button
                variant="contained"
                size="small"
                style={{ marginRight: '8px', minWidth: 96 }}
                disabled={!selectedId}
                onClick={() => {
                  navigate(``);
                }}
              >
                削除
              </Button>
            )}
          </div>
        </div>

        {/* テーブルエリア */}
        <BasicSlickGridTable columns={columnRef.current} data={rowData} onSelectionChanged={onSelectedRowsChanged} enableContextMenu />
      </div>
    </div>
  );
};

export default WebQ0010ListPage;
