import React, { useEffect } from 'react';
import { Route, useNavigate } from 'react-router';
import Home from 'app/modules/home/home';
import EntitiesRoutes from 'app/entities/routes';
import PrivateRoute from 'app/shared/auth/private-route';
import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';
import PageNotFound from 'app/shared/error/page-not-found';
import { AUTHORITIES } from 'app/config/constants';
import useAccountStore from 'app/shared/zustandStore/account';
import WebA0010 from 'app/modules/WebA0010/WebA0010LoginPage';
import WebR0055 from 'app/modules/WebR0055/WebR0055ListPage';
import WebR0060 from 'app/modules/WebR0060/WebR0060CreateForm';
import WebB0010 from 'app/modules/WebB0010/WebB0010ListPage';
import WebB0030 from 'app/modules/WebB0030/WebB0030CreateForm';
import WebQ0030 from 'app/modules/WebQ0030/WebQ0030CreateForm';
import WebV0020 from 'app/modules/WebV0020/WebV0020CreateForm';
import WebG0010 from 'app/modules/WebG0010/WebG0010ListPage';
import WebD0010 from 'app/modules/WebD0010/WebD0010ListPage';
import WebR0040 from 'app/modules/WebR0040/WebR0040ListPage';
import WebR0045 from 'app/modules/WebR0045/WebR0045CreateForm';
import WebD0030 from 'app/modules/WebD0030/WebD0030CreateForm';
import WebC0030 from 'app/modules/WebC0030/WebC0030CreateForm';
import WebF0010 from 'app/modules/WebF0010/WebF0010ListPage';
import WebA0040 from 'app/modules/WebA0040/WebA0040ListPage';
import WebE0010 from 'app/modules/WebE0010/WebE0010CreateForm';
import WebO0030 from 'app/modules/WebO0030/WebO0030CreateForm';
import WebP0030 from 'app/modules/WebP0030/WebP0030CreateForm';
import WebR0080 from 'app/modules/WebR0080/WebR0080CreateForm';
import WebH0010 from 'app/modules/WebH0010/WebH0010ListPage';
import WebH0030 from 'app/modules/WebH0030/WebH0030CreateForm';
import WebL0010 from 'app/modules/WebL0010/WebL0010ListPage';
import WebO0010 from 'app/modules/WebO0010/WebO0010ListPage';
import WebP0010 from 'app/modules/WebP0010/WebP0010ListPage';
import WebQ0010 from 'app/modules/WebQ0010/WebQ0010ListPage';
import WebQ0035 from 'app/modules/WebQ0035/WebQ0035ListPage';
import WebQ0036 from 'app/modules/WebQ0036/WebQ0036ListPage';
import WebT0010 from 'app/modules/WebT0010/WebT0010ListPage';
import WebT0020 from 'app/modules/WebT0020/WebT0020CreateForm';
import WebV0010 from 'app/modules/WebV0010/WebV0010ListPage';
import WebI0010 from 'app/modules/WebI0010/WebI0010ListPage';
import WebF0030 from 'app/modules/WebF0030/WebF0030CreateForm';
import WebL0030 from 'app/modules/WebL0030/WebL0030CreateForm';
import WebM0010 from 'app/modules/WebM0010/WebM0010ListPage';
import WebM0020 from 'app/modules/WebM0020/WebM0020CreateForm';
import WebN0010 from 'app/modules/WebN0010/WebN0010ListPage';
import WebN0030 from 'app/modules/WebN0030/WebN0030CreateForm';
import WebC0010 from 'app/modules/WebC0010/WebC0010ListPage';
import WebA0020 from 'app/modules/WebA0020/WebA0020PasswordResetPage';
import WebR0010 from 'app/modules/WebR0010/WebR0010ListPage';
import WebQ0050 from 'app/modules/WebQ0050/WebQ0050CreateForm';
import WebG0030 from 'app/modules/WebG0030/WebG0030CreateForm';
import GridExample from './components/Sample';
import WebU0010 from 'app/modules/WebU0010/WebU0010CreateForm';
import WebJ0010 from 'app/modules/WebJ0010/WebJ0010CreateForm';
import WebJ0020 from 'app/modules/WebJ0020/WebJ0020CreateForm';
import WebS0010 from 'app/modules/WebS0010/WebS0010ListPage';
import WebS0020 from 'app/modules/WebS0020/WebS0020ListPage';
import WebS0030 from 'app/modules/WebS0030/WebS0030ListPage';
import WebS0040 from 'app/modules/WebS0040/WebS0040ListPage';
import WebS0050 from 'app/modules/WebS0050/WebS0050ListPage';
import WebS0060 from 'app/modules/WebS0060/WebS0060ListPage';
import WebS0070 from 'app/modules/WebS0070/WebS0070ListPage';
import WebS0080 from 'app/modules/WebS0080/WebS0080ListPage';
import WebS0090 from 'app/modules/WebS0090/WebS0090ListPage';
import WebS0100 from 'app/modules/WebS0100/WebS0100ListPage';
import WebS0110 from 'app/modules/WebS0110/WebS0110ListPage';
import WebS0120 from 'app/modules/WebS0120/WebS0120ListPage';
import WebS0130 from 'app/modules/WebS0130/WebS0130ListPage';
import WebS0140 from 'app/modules/WebS0140/WebS0140ListPage';
import WebS0150 from 'app/modules/WebS0150/WebS0150ListPage';
import WebR0030 from 'app/modules/WebR0030/WebR0030CreateForm';
import WebI0020 from 'app/modules/WebI0020/WebI0020CreateForm';
import WebQ0070 from 'app/modules/WebQ0070/WebQ0070CreateForm';
import WebU0020 from 'app/modules/WebU0020/WebU0020CreateForm';

const loading = <div>loading ...</div>;

const AppRoutes = () => {
  const { userName } = useAccountStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (userName) {
      navigate(location.pathname === '/' ? '/webA0040' : location.pathname);
    } else {
      navigate('/webA0010');
    }
  }, []);
  return (
    <div className="view-routes">
      <ErrorBoundaryRoutes>
        <Route index element={<Home />} />
        {/* ログイン */}
        <Route path="webA0010" element={<WebA0010 />} />
        {/* 案件一覧 */}
        <Route path="webB0010" element={<WebB0010 />} />
        {/* 案件登録 */}
        <Route path="webB0030/:type/:id?" element={<WebB0030 />} />
        {/* 顧客一覧 */}
        <Route path="webR0055" element={<WebR0055 />} />
        {/* 顧客登録 */}
        <Route path="webR0060/:type/:id?" element={<WebR0060 />} />
        {/* 社員一覧 */}
        <Route path="webR0040" element={<WebR0040 />} />
        {/* 社員登録 */}
        <Route path="webR0045/:type/:id?" element={<WebR0045 />} />
        {/* 作業員登録（社員） */}
        <Route path="webQ0030/:type/:id?" element={<WebQ0030 />} />
        {/* 作業員登録（業者） */}
        <Route path="webV0020/:type/:id?" element={<WebV0020 />} />
        {/* 精積算作成 */}
        <Route path="webD0030/:type/:id?" element={<WebD0030 />} />
        {/* 精積算一覧 */}
        <Route path="webD0010" element={<WebD0010 />} />
        {/* 物件一覧 */}
        <Route path="webF0010" element={<WebF0010 />} />
        {/* ダッシュボード */}
        <Route path="webA0040" element={<WebA0040 />} />
        {/* 見積作成 */}
        <Route path="webE0010/:type/:stare/:id?" element={<WebE0010 />} />
        {/* 業者登録 */}
        <Route path="webO0030/:type/:id?" element={<WebO0030 />} />
        {/* 下請登録 */}
        <Route path="webP0030/:type/:id?" element={<WebP0030 />} />
        {/* 単価登録 */}
        <Route path="webR0080" element={<WebR0080 />} />
        {/* 請求書作成 */}
        <Route path="webL0030/:type/:id?" element={<WebL0030 />} />
        {/* 実行予算一覧 */}
        <Route path="webG0010" element={<WebG0010 />} />
        {/* 出来高シミュレーション一覧 */}
        <Route path="webI0010" element={<WebI0010 />} />
        {/* 査定一覧 */}
        <Route path="webH0010" element={<WebH0010 />} />
        {/* 査定登録 */}
        <Route path="webH0030/:type/:id?" element={<WebH0030 />} />
        {/* 請求書一覧*/}
        <Route path="webL0010" element={<WebL0010 />} />
        {/* 業者一覧 */}
        <Route path="webO0010" element={<WebO0010 />} />
        {/* 下請一覧 */}
        <Route path="webP0010" element={<WebP0010 />} />
        {/* 作業員一覧(社員用) */}
        <Route path="webQ0010" element={<WebQ0010 />} />
        {/* 作業員名簿業者一覧 */}
        <Route path="webQ0036" element={<WebQ0036 />} />
        {/* 作業員名簿現場一覧 */}
        <Route path="webQ0035" element={<WebQ0035 />} />
        {/* 再下請通知書登録 */}
        <Route path="webQ0070" element={<WebQ0070 />} />
        {/* 現場情報 */}
        <Route path="webT0020/:type/:id?" element={<WebT0020 />} />
        {/* 作業員一覧 */}
        <Route path="webV0010" element={<WebV0010 />} />
        {/* 現場経費一覧 */}
        <Route path="webM0010" element={<WebM0010 />} />
        {/* 現場経費入力 */}
        <Route path="webM0020/:type/:id?" element={<WebM0020 />} />
        {/* 物件登録 */}
        <Route path="webF0030/:type/:id?" element={<WebF0030 />} />
        {/* 工事予実一覧 */}
        <Route path="webN0010" element={<WebN0010 />} />
        {/* 工事予実入力 */}
        <Route path="webN0030/:type/:id?" element={<WebN0030 />} />
        {/* 概算一覧 */}
        <Route path="webC0010" element={<WebC0010 />} />
        {/* 概算作成 */}
        <Route path="webC0030/:type/:id?" element={<WebC0030 />} />
        {/* パスワード通知 */}
        <Route path="webA0020" element={<WebA0020 />} />
        {/* 権限管理 */}
        <Route path="webR0010" element={<WebR0010 />} />
        {/* 現場一覧 */}
        <Route path="webT0010" element={<WebT0010 />} />
        {/* 自社情報登録 */}
        <Route path="webU0010" element={<WebU0010 />} />
        {/* 実行予算作成 */}
        <Route path="webG0030/:id" element={<WebG0030 />} />
        {/* 連携用支払データ作成（査定支払） */}
        <Route path="webJ0010/:type/:id?" element={<WebJ0010 />} />
        {/* 連携用支払データ作成（経費支払） */}
        <Route path="webJ0020/:type/:id?" element={<WebJ0020 />} />
        {/* 出来高シミュレーション入力 */}
        <Route path="webI0020/:type/:id?" element={<WebI0020 />} />
        {/* 承認一覧（概算管理） */}
        <Route path="webS0010" element={<WebS0010 />} />
        {/* 承認一覧（精積算管理） */}
        <Route path="webS0020" element={<WebS0020 />} />
        {/* 承認一覧（物件管理） */}
        <Route path="webS0030" element={<WebS0030 />} />
        {/* 承認一覧（実行予算管理） */}
        <Route path="webS0040" element={<WebS0040 />} />
        {/* 承認一覧（査定管理） */}
        <Route path="webS0050" element={<WebS0050 />} />
        {/* 承認一覧（現場経費管理） */}
        <Route path="webS0060" element={<WebS0060 />} />
        {/* 承認一覧（工事予実管理） */}
        <Route path="webS0070" element={<WebS0070 />} />
        {/* 承認一覧（協力業者管理） */}
        <Route path="webS0080" element={<WebS0080 />} />
        {/* 承認一覧（作業員情報管理） */}
        <Route path="webS0090" element={<WebS0090 />} />
        {/* 承認一覧（下請契約台帳） */}
        <Route path="webS0100" element={<WebS0100 />} />
        {/* 承認一覧（再下請負通知書） */}
        <Route path="webS0110" element={<WebS0110 />} />
        {/* 承認一覧（顧客管理） */}
        <Route path="webS0120" element={<WebS0120 />} />
        {/* 承認一覧（会社管理） */}
        <Route path="webS0130" element={<WebS0130 />} />
        {/* 承認一覧（自社情報） */}
        <Route path="webS0140" element={<WebS0140 />} />
        {/* 承認一覧（作業員登録） */}
        <Route path="webS0150" element={<WebS0150 />} />
        {/* 組織管理 */}
        <Route path="webR0030" element={<WebR0030 />} />
        {/* 下請登録 業者用 */}
        <Route path="webU0020" element={<WebU0020 />} />
        <Route path="Sample" element={<GridExample />} />
        {/* 下請契約台帳登録 */}
        <Route path="WebQ0050/:type/:id?" element={<WebQ0050 />} />
        <Route
          path="*"
          element={
            <PrivateRoute hasAnyAuthorities={[AUTHORITIES.USER]}>
              <EntitiesRoutes />
            </PrivateRoute>
          }
        />
        <Route path="*" element={<PageNotFound />} />
      </ErrorBoundaryRoutes>
    </div>
  );
};

export default AppRoutes;
