import { create } from 'zustand';

const useAccountStore = create<any>(set => ({
  // 保存用户名和token
  userName: window.localStorage.CONSTRUCTION_MANAGEMENT_LOGIN_USER ?? '',
  token: '',

  // 设置用户名
  setUserName: name => set({ userName: name }),

  // 设置token
  setToken: token => set({ token }),

  // 清空用户信息（登出时用）
  clearUser: () => set({ userName: '', token: '', organization: '' }),
}));

export default useAccountStore;
