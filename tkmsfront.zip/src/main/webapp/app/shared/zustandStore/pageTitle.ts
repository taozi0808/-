import { create } from 'zustand';

type PageTitleState = {
  pageTitle: string;
  setPageTitle: (title: string) => void;
};

export const usePageTitleStore = create<PageTitleState>(set => ({
  pageTitle: '',
  setPageTitle: title => set({ pageTitle: title }),
}));
