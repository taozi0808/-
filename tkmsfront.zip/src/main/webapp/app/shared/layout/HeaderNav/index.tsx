import React, { useEffect, useState } from 'react';
import { IconButton, Menu, MenuItem } from '@mui/material';
import logo1 from './logo/logo1.png';
import logo2 from './logo/logo2.png';
import logo3 from './logo/logo3.png';
import { useNavigate } from 'react-router-dom';
import './index.scss';
import useAccountStore from 'app/shared/zustandStore/account';
import { usePageTitleStore } from 'app/shared/zustandStore/pageTitle';

const HeaderNav = () => {
  const [logo, setLogo] = useState(logo1);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();
  const { userName, clearUser } = useAccountStore();
  const { pageTitle } = usePageTitleStore();
  const open = Boolean(anchorEl);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const accountSVG = (
    <svg viewBox="0 0 20 20" focusable="false" style={{ width: '1.25rem', height: '1.25rem' }}>
      <g>
        <rect fill="none" width="20" height="20"></rect>
        <circle fill="#fff" cx="10" cy="10" r="7"></circle>
        <g>
          <path
            fill="#285ac8"
            d="M10,2.25c-4.27,0-7.75,3.48-7.75,7.75s3.48,7.75,7.75,7.75,7.75-3.48,7.75-7.75-3.48-7.75-7.75-7.75ZM10,3.75c3.45,0,6.25,2.8,6.25,6.25,0,1.23-.36,2.37-.97,3.33-1.43-1.33-3.3-2.08-5.28-2.08s-3.85.75-5.28,2.08c-.61-.97-.97-2.11-.97-3.33,0-3.45,2.8-6.25,6.25-6.25ZM5.67,14.5c1.16-1.12,2.7-1.75,4.33-1.75s3.17.63,4.33,1.75c-1.12,1.08-2.65,1.75-4.33,1.75s-3.21-.67-4.33-1.75Z"
          ></path>
          <path
            fill="#285ac8"
            d="M10,10.75c1.52,0,2.75-1.23,2.75-2.75s-1.23-2.75-2.75-2.75-2.75,1.23-2.75,2.75,1.23,2.75,2.75,2.75ZM10,6.75c.69,0,1.25.56,1.25,1.25s-.56,1.25-1.25,1.25-1.25-.56-1.25-1.25.56-1.25,1.25-1.25Z"
          ></path>
        </g>
      </g>
    </svg>
  );

  const menuItems = [
    {
      key: 1,
      label: `社員番号：${userName}`,
    },
    {
      key: 2,
      label: `氏名：${userName}`,
    },
    {
      key: 3,
      label: `所属：${userName}`,
    },
    {
      key: 4,
      label: 'ログアウト',
      onClick() {
        clearUser();
        navigate('/webA0010');
        setAnchorEl(null);
        window.localStorage.CONSTRUCTION_MANAGEMENT_LOGIN_USER = '';
      },
      danger: true,
    },
  ];

  useEffect(() => {
    let newLogo = '';
    switch (userName) {
      case 'admin':
        newLogo = logo1;
        break;
      case '':
        newLogo = logo1;
        break;
      case 'user':
        newLogo = logo3;
        break;
      default:
        newLogo = logo2;
        break;
    }
    setLogo(newLogo);
  }, [userName]);

  return (
    <div className={userName ? 'header' : 'headerLogin'}>
      <div className="pageTitle">{pageTitle}</div>
      <img src={logo} alt="logo" className={userName ? 'logo' : 'logoLogin'} />
      {userName && (
        <>
          <IconButton onClick={handleClick} size="large" className="account-button">
            {accountSVG}
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'right',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
          >
            {menuItems.map(item => (
              <MenuItem key={item.key} onClick={item.onClick}>
                {item.label}
              </MenuItem>
            ))}
          </Menu>
        </>
      )}
    </div>
  );
};

export default HeaderNav;
