import React, { useState } from 'react';
import { Snackbar, Alert } from '@mui/material';

let globalNotify = null; // 用来存储通知函数

export function useNotify() {
  // 通过这个 hook 来调用通知
  return globalNotify;
}

// 全局通知组件
export const NotifyProvider = ({ children }) => {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState('success'); // 默认成功消息

  const handleClose = () => {
    setOpen(false);
  };

  // 存储通知函数，使其可以被其他地方调用
  globalNotify = (msg, type = 'success') => {
    setMessage(msg);
    setSeverity(type);
    setOpen(true);
  };

  return (
    <>
      {children}
      <Snackbar open={open} autoHideDuration={3000} onClose={handleClose} anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
        <Alert onClose={handleClose} severity={severity as any}>
          {message}
        </Alert>
      </Snackbar>
    </>
  );
};
