import React, { useState } from 'react';
import { Box, IconButton } from '@mui/material';
import { AddCircleOutline, RemoveCircleOutline } from '@mui/icons-material';

interface CollapsiblePanelProps {
  children: React.ReactNode;
  defaultOpen?: boolean;
  style?: React.CSSProperties;
}

const CollapsePanel: React.FC<CollapsiblePanelProps> = ({ children, style = {}, defaultOpen }) => {
  const [isOpen, setIsOpen] = useState(!!defaultOpen);

  const togglePanel = () => {
    setIsOpen(!isOpen);
  };

  return (
    <Box
      sx={{
        border: '1px solid black',
        borderRadius: '4px',
        overflow: 'hidden',
        position: 'relative',
        width: '100%',
        padding: isOpen ? '28px' : '20px',
      }}
      style={style}
    >
      <IconButton
        onClick={togglePanel}
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
        }}
      >
        {isOpen ? <RemoveCircleOutline /> : <AddCircleOutline />}
      </IconButton>
      <Box
        sx={{
          overflow: 'hidden',
          transition: 'height 0.3s ease',
        }}
      >
        {isOpen ? children : null}
      </Box>
    </Box>
  );
};

export default CollapsePanel;
