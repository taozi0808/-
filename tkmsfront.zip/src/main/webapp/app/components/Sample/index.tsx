import React, { useState } from 'react';

import type { ColDef, ICellRendererParams } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { Button } from '@mui/material';

// Row Data Interface
interface IRow {
  no: string;
  userId: string;
  userName: string;
  address: string;
  tel: string;
  repName: string;
  group: string;
  level: 1 | 2 | 3;
}

const GridExample = () => {
  const [rowData, setRowData] = useState<IRow[]>([
    {
      no: '1',
      userId: '0001',
      userName: '0001-xxx',
      address: '0001-address',
      tel: '0001-tel',
      repName: '0001-repName',
      group: '1',
      level: 1,
    },
    {
      no: '2',
      userId: '0002',
      userName: '0002-xxx',
      address: '0002-address',
      tel: '0002-tel',
      repName: '0002-repName',
      group: '2',
      level: 2,
    },
    {
      no: '3',
      userId: '0003',
      userName: '0003-xxx',
      address: '0003-address',
      tel: '0003-tel',
      repName: '0003-repName',
      group: '3',
      level: 3,
    },
    {
      no: '4',
      userId: '0004',
      userName: '0004-xxx',
      address: '0004-address',
      tel: '0004-tel',
      repName: '0004-repName',
      group: '4',
      level: 1,
    },
    {
      no: '5',
      userId: '0005',
      userName: '0005-xxx',
      address: '0005-address',
      tel: '0005-tel',
      repName: '0005-repName',
      group: '5',
      level: 1,
    },
  ]);

  const sortData = (data: IRow[]) => {
    return [...data].sort((a, b) => {
      if (a.group < b.group) return -1;
      if (a.group > b.group) return 1;

      if (a.level < b.level) return -1;
      if (a.level > b.level) return 1;

      return parseInt(a.no, 10) - parseInt(b.no, 10);
    });
  };

  // Column Definitions: Defines & controls grid columns.
  const [colDefs, setColDefs] = useState<ColDef<IRow>[]>([
    {
      headerName: 'No.',
      field: 'no',
      maxWidth: 80,
    },
    {
      headerName: '業者コード-業者支店コード',
      field: 'userId',
      width: 200,
      cellRenderer: UserIdNameRender,
      cellRendererParams: {
        addRow: row => {
          setRowData(prev => {
            const newData = [...prev, row];
            return sortData(newData);
          });
        },
      },
      autoHeight: true,
      cellStyle: {
        padding: '0',
      },
    },
    {
      headerName: '住所',
      field: 'address',
      width: 200,
    },
    {
      headerName: '電話番号',
      field: 'tel',
      width: 200,
    },
  ]);

  const defaultColDef: ColDef = {
    flex: 1,
  };

  return (
    <div style={{ width: '100%', height: '500px' }}>
      <AgGridReact rowData={rowData} columnDefs={colDefs} defaultColDef={defaultColDef} rowHeight={80} suppressCellFocus={true} />
    </div>
  );
};

export default GridExample;

export const UserIdNameRender = params => {
  const handleAdd = () => {
    const newRow = { ...params.data, level: params.data.level - 1, no: `${parseInt(params.data.no, 10) + 1}` };
    params.addRow(newRow);
  };
  const { level, userId, userName } = params.data;
  if (level === 1) {
    return (
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 2, lineHeight: '80px', border: 'solid 1px' }}>
          <Button variant="text" onClick={handleAdd}>
            {' '}
            +{' '}
          </Button>
        </div>
        <div style={{ flex: 8 }}>
          <div style={{ border: 'solid 1px' }}>{userId}</div>
          <div style={{ border: 'solid 1px' }}>{userName}</div>
        </div>
      </div>
    );
  } else if (level === 2) {
    return (
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 2, lineHeight: '80px', border: 'solid 1px' }}>
          <Button variant="text" onClick={handleAdd}>
            {' '}
            +{' '}
          </Button>
        </div>
        <div style={{ flex: 2, border: 'solid 1px', textAlign: 'center', lineHeight: '80px' }}>🍰</div>
        <div style={{ flex: 6 }}>
          <div style={{ border: 'solid 1px' }}>{userId}</div>
          <div style={{ border: 'solid 1px' }}>{userName}</div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 2, border: 'solid 1px' }}></div>
      <div style={{ flex: 3, border: 'solid 1px', textAlign: 'center', lineHeight: '80px' }}>🍰</div>
      <div style={{ flex: 5 }}>
        <div style={{ border: 'solid 1px' }}>{userId}</div>
        <div style={{ border: 'solid 1px' }}>{userName}</div>
      </div>
    </div>
  );
};
