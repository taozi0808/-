import type {
  BasePaginationComponent,
  PaginationMetadata,
  PaginationService,
  PubSubService,
  SlickGrid,
  Subscription,
} from '@slickgrid-universal/common';
import React from 'react';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';

import './index.scss';

interface State {
  currentPagination: PaginationMetadata;
  isLeftPaginationDisabled: boolean;
  isRightPaginationDisabled: boolean;
}

export class CustomPagerComponent extends React.Component<'', State> implements BasePaginationComponent {
  protected _elm?: HTMLDivElement | null;
  protected _grid!: SlickGrid;
  protected _paginationElement!: HTMLDivElement;
  protected _paginationService!: PaginationService;
  protected _pubSubService!: PubSubService;
  protected _subscriptions: Subscription[] = [];

  constructor() {
    super('');
    this.state = {
      currentPagination: {} as PaginationMetadata,
      isLeftPaginationDisabled: false,
      isRightPaginationDisabled: false,
    };
  }

  init(grid: SlickGrid, paginationService: PaginationService, pubSubService: PubSubService) {
    this._grid = grid;
    this._paginationService = paginationService;
    this._pubSubService = pubSubService;
    const currentPagination = this._paginationService.getFullPagination();
    this.setState((_, state: any) => {
      return {
        ...state,
        currentPagination,
        isLeftPaginationDisabled: this.checkLeftPaginationDisabled(currentPagination),
        isRightPaginationDisabled: this.checkRightPaginationDisabled(currentPagination),
      };
    });

    this._subscriptions.push(
      this._pubSubService.subscribe<PaginationMetadata>('onPaginationRefreshed', paginationChanges => {
        this.setState((_, state: any) => {
          return {
            ...state,
            currentPagination: paginationChanges,
            isLeftPaginationDisabled: this.checkLeftPaginationDisabled(paginationChanges),
            isRightPaginationDisabled: this.checkRightPaginationDisabled(paginationChanges),
          };
        });
      }),
    );
  }

  dispose() {
    this._pubSubService.unsubscribeAll(this._subscriptions);
    this._paginationElement.remove();
  }

  renderPagination() {
    this._paginationElement = this._elm;
    this._paginationElement.id = 'pager';
    this._paginationElement.className = `custom-pagination pager ${this._grid.getUID()}`;
    this._paginationElement.style.width = '100%';
  }

  onFirstPageClicked(event: any): void {
    if (!this.checkLeftPaginationDisabled(this.state.currentPagination)) {
      this._paginationService.goToFirstPage(event);
    }
  }

  onLastPageClicked(event: any): void {
    if (!this.checkRightPaginationDisabled(this.state.currentPagination)) {
      this._paginationService.goToLastPage(event);
    }
  }

  onNextPageClicked(event: any): void {
    if (!this.checkRightPaginationDisabled(this.state.currentPagination)) {
      this._paginationService.goToNextPage(event);
    }
  }

  onPreviousPageClicked(event: any): void {
    if (!this.checkLeftPaginationDisabled(this.state.currentPagination)) {
      this._paginationService.goToPreviousPage(event);
    }
  }

  protected checkLeftPaginationDisabled(currentPagination: PaginationMetadata): boolean {
    return currentPagination.pageNumber === 1 || currentPagination.totalItems === 0;
  }

  protected checkRightPaginationDisabled(currentPagination: PaginationMetadata): boolean {
    return currentPagination.pageNumber === currentPagination.pageCount || currentPagination.totalItems === 0;
  }

  onChangeItemsPerPage(event: React.ChangeEvent<HTMLSelectElement>) {
    const newPageSize = parseInt(event.target.value, 10);
    this._paginationService.changeItemPerPage(newPageSize);
  }

  onPageNumberClicked(pageNumber: number) {
    this._paginationService.goToPageNumber(pageNumber);
  }

  render() {
    const { currentPagination } = this.state;
    const { pageNumber, pageCount } = currentPagination;

    // 生成分页按钮的数组
    const getPageButtons = () => {
      const buttons = [];
      const maxButtons = 5; // 当前页前后显示的按钮数量
      const ellipsis = <span className="page-ellipsis">...</span>;

      // 始终显示第一页
      buttons.push(
        <button key={1} className={`page-number-button ${pageNumber === 1 ? 'active' : ''}`} onClick={() => this.onPageNumberClicked(1)}>
          1
        </button>,
      );

      // 如果当前页离第一页较远，显示省略号
      if (pageNumber > maxButtons + 1) {
        buttons.push(ellipsis);
      }

      // 显示当前页附近的按钮
      for (let i = Math.max(2, pageNumber - maxButtons); i <= Math.min(pageCount - 1, pageNumber + maxButtons); i++) {
        buttons.push(
          <button key={i} className={`page-number-button ${pageNumber === i ? 'active' : ''}`} onClick={() => this.onPageNumberClicked(i)}>
            {i}
          </button>,
        );
      }

      // 如果当前页离最后一页较远，显示省略号
      if (pageNumber < pageCount - maxButtons) {
        buttons.push(ellipsis);
      }

      // 始终显示最后一页
      if (pageCount > 1) {
        buttons.push(
          <button
            key={pageCount}
            className={`page-number-button ${pageNumber === pageCount ? 'active' : ''}`}
            onClick={() => this.onPageNumberClicked(pageCount)}
          >
            {pageCount}
          </button>,
        );
      }

      return buttons;
    };

    return (
      <div className="custom-pagination" ref={elm => (this._elm = elm)}>
        <div className="custom-pagination-nav">
          <nav aria-label="Page navigation">
            <ul className="custom-pagination-ul">
              <li className={'li page-item seek-first' + (this.state.isLeftPaginationDisabled ? ' disabled' : '')}>
                <a
                  className="pagination-link mdi mdi-page-first icon-seek-first mdi-22px"
                  aria-label="First Page"
                  role="button"
                  onClick={$event => this.onFirstPageClicked($event)}
                ></a>
              </li>
              <li className={'li page-item seek-prev' + (this.state.isLeftPaginationDisabled ? ' disabled' : '')}>
                <a
                  className="pagination-link icon-seek-prev mdi mdi-chevron-down mdi-22px mdi-rotate-90"
                  aria-label="Previous Page"
                  role="button"
                  onClick={$event => this.onPreviousPageClicked($event)}
                ></a>
              </li>
            </ul>
          </nav>
          {/* 可点击的页数按钮 */}
          <div className="page-number-buttons">{getPageButtons()}</div>

          <nav aria-label="Page navigation">
            <ul className="custom-pagination-ul">
              <li
                className={'li page-item seek-next' + (this.state.isRightPaginationDisabled ? ' disabled' : '')}
                onClick={$event => this.onNextPageClicked($event)}
              >
                <a
                  className="pagination-link icon-seek-next mdi mdi-chevron-down mdi-22px mdi-rotate-270"
                  aria-label="Next Page"
                  role="button"
                ></a>
              </li>
              <li className={'li page-item seek-end' + (this.state.isRightPaginationDisabled ? ' disabled' : '')}>
                <a
                  className="pagination-link icon-seek-end mdi mdi-page-last mdi-22px"
                  aria-label="Last Page"
                  role="button"
                  onClick={$event => this.onLastPageClicked($event)}
                ></a>
              </li>
            </ul>
          </nav>
        </div>
        {/* 每页显示条数的下拉选择框 */}
        <div className="custom-pagination-items-per-page">
          <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <Select value={this.state.currentPagination.pageSize ?? 10} onChange={($event: any) => this.onChangeItemsPerPage($event)}>
              <MenuItem value={10}>10件 / ページ</MenuItem>
              <MenuItem value={20}>20件 / ページ</MenuItem>
              <MenuItem value={50}>50件 / ページ</MenuItem>
              <MenuItem value={100}>100件 / ページ</MenuItem>
            </Select>{' '}
          </FormControl>
        </div>
      </div>
    );
  }
}
