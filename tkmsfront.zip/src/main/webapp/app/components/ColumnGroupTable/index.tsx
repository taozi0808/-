/**
 * 支持跨列和跨行功能的ag-grid表格公共组件，仅支持双行；
 * 支持 翻页、双行选中、列宽拖拽
 * 不支持过滤、排序；
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import './index.scss';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { Box, Button, FormControl, IconButton, MenuItem, Select } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import { AGGridTheme } from 'app/app';
import { ColDef, ColGroupDef, ColumnResizedEvent, FirstDataRenderedEvent, GridReadyEvent } from 'ag-grid-community';

interface Props {
  /**
   * 1. 每个column的children只能配置一层，不能嵌套children；
   * 2. 当存在跨列时，被跨越列的headerName要配置为空字符串，并且表体内对应单元格渲染时也要渲染为空字符串；
   * 3.
   */
  columns: Array<ColDef | ColGroupDef>;
  /**
   * 跨列字段的对应关系
   * minField 表示存在跨列时，要渲染表头和表体数据的那一列的field；
   * subFields 表示被跨越列的field；
   */
  colSpanMap: Array<{
    mainField: string;
    subFields: Array<string>;
  }>;
  /**
   * 表格数据，目前没有后端接口，分页是组件内部实现，所以这里的data是全量数据；
   */
  data: any[];
  initialPageSize?: number;
  disabledPagination?: boolean;
  tableEmptyText?: string;
  onSelectedRow?: (id: string) => void;
  rowKey?: string;
}

const ColumnSpanningTable = (props: Props) => {
  const {
    columns,
    colSpanMap,
    tableEmptyText,
    initialPageSize = 10,
    data,
    disabledPagination = false,
    onSelectedRow,
    rowKey = 'id',
  } = props;

  // 初始页数为0，当data长度大于0时页数会设置为1；
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [pageSize, setPageSize] = useState<number>(initialPageSize);
  const totalPages = Math.ceil(data.length / pageSize);
  const currentPageData = useMemo(() => {
    if (currentPage > 0) {
      const start = (currentPage - 1) * pageSize;
      const curData = data.slice(start, start + pageSize);

      // 由于一条数据渲染表格的两行，所以在每次生成表格渲染数据时进行数据复制；
      const newCurData = [];
      for (let i = 0; i < curData.length; i++) {
        newCurData.push(curData[i]);
        newCurData.push(curData[i]);
      }
      return newCurData;
    }
    return [];
  }, [data, currentPage, pageSize]);

  // 用于存储当前 requestAnimationFrame 的 id，避免重复请求帧
  const rAFRef = useRef<number | null>(null);
  const [columnApi, setColumnApi] = useState<any>(null);
  const [columnDefs, setColumnDefs] = useState<typeof columns>(null);

  // 聚合出所有跨列相关的字段
  const specialFieldListRef = useRef<Array<string>>([]);
  const colSpanMainFieldListRef = useRef<Array<string>>([]);
  const specialHeaderClassRef = useRef<string>('special-header');

  // 生成翻页按钮逻辑：只显示当前页左右各 1 个页码，其他页码用省略号表示（始终显示首页与末页）
  const getPageButtons = () => {
    const buttons: (number | 'ellipsis')[] = [];
    const siblingCount = 1;
    const totalNumbers = siblingCount * 2 + 1;
    let startPage = Math.max(2, currentPage - siblingCount);
    let endPage = Math.min(totalPages - 1, currentPage + siblingCount);

    if (currentPage - siblingCount <= 1) {
      endPage = Math.min(totalPages - 1, totalNumbers);
    }
    if (currentPage + siblingCount >= totalPages) {
      startPage = Math.max(2, totalPages - totalNumbers + 1);
    }
    buttons.push(1);
    if (startPage > 2) {
      buttons.push('ellipsis');
    }
    for (let i = startPage; i <= endPage; i++) {
      buttons.push(i);
    }
    if (endPage < totalPages - 1) {
      buttons.push('ellipsis');
    }
    if (totalPages > 1) {
      buttons.push(totalPages);
    }
    return buttons;
  };

  const onPageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const onPageSizeChange = (e: any) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  const onGridReady = (params: GridReadyEvent) => {
    setColumnApi(params.api);
    (window as any).aller = params.api;
  };

  const onFirstDataRendered = (params: FirstDataRenderedEvent) => {
    setColumnApi(params.api);
    (window as any).aller = params.api;
    const allColumns = params.api.getColumns() as any;
    console.log('allColumns', allColumns, columnDefs);
    const totalWidth = allColumns.reduce((sum, col) => sum + col.getActualWidth(), 0);
    const containerWidth = (document.getElementsByClassName('ag-root')[0] as HTMLElement)?.offsetWidth ?? 0;

    if (containerWidth) {
      const newWidthList = [];
      // 动态设置每列的宽度百分比
      allColumns.forEach(col => {
        const widthPercent = col.getActualWidth() / totalWidth;
        newWidthList.push({ key: col?.colDef?.field, newWidth: widthPercent * containerWidth });
      });
      console.log('newWidthList', newWidthList);
      params.api.setColumnWidths(newWidthList, false);
    }
  };

  /**
   *  由于一条数据渲染了两行，所以这两行任意一行点击选中时，我们需要把另外一行也要选中。
   */
  const onSelectedRowsChanged = (event: any) => {
    // 由于该函数中会手动调用api.setNodesSelected会再次出发该函数的调用，所以我们只处理用户手动点击触发的调用。
    if (event.source !== 'rowClicked') return;

    const selectedNodes = event.api.getSelectedNodes();

    // 根据当前选中的行，找出与之关联的另外一行。
    const selectedRowNode = selectedNodes?.[0];
    if (selectedRowNode) {
      const rowIndex = selectedRowNode.rowIndex;
      let relatedRowIndex;
      if (rowIndex % 2 === 0) {
        relatedRowIndex = rowIndex + 1;
      } else {
        relatedRowIndex = rowIndex - 1;
      }
      const relatedRowNode = event.api.getRowNode(relatedRowIndex.toString());
      event.api.setNodesSelected({ nodes: [selectedRowNode, relatedRowNode], newValue: true });
    }

    if (onSelectedRow) {
      onSelectedRow(selectedRowNode?.data?.[rowKey] ?? '');
    }
  };

  // 动态更新跨越列的列宽
  const updateSpecialColumnWidth = () => {
    // 如果当前没有 pending 的 requestAnimationFrame 请求，则在下一帧渲染时修改对应列宽；
    if (rAFRef.current === null && columnApi) {
      rAFRef.current = requestAnimationFrame(() => {
        colSpanMap.forEach(item => {
          // 获取跨越列
          const targetColumn = columnApi.getColumn(item.mainField);

          if (targetColumn) {
            let hiddenColumnsWidth = 0;
            // 获取空白填充列的宽度
            item.subFields.forEach(field => {
              const column = columnApi.getColumn(field);
              if (column) {
                hiddenColumnsWidth += column.getActualWidth();
              }
            });

            const newWidth = hiddenColumnsWidth + targetColumn.getActualWidth() - 4;
            const targetColumnDom = document.getElementsByClassName(`${specialHeaderClassRef.current}-${item.mainField}`)[0];

            if (targetColumnDom && targetColumnDom instanceof HTMLElement) {
              targetColumnDom.style.width = `${newWidth}px`;
            }
          }
        });

        // 清空 requestAnimationFrame 引用
        rAFRef.current = null;
      });
    }
  };

  // 表格大小改变时
  const onGridSizeChanged = event => {
    console.log('表格大小改变时', event);
    updateSpecialColumnWidth();
  };

  // 列宽拖拽时
  const onColumnResized = (params: ColumnResizedEvent) => {
    console.log('列宽拖拽时', params);
    // 只在拖拽过程中执行，拖拽结束时 finished 为 true
    if (params.finished) {
      updateSpecialColumnWidth();
    }
  };

  useEffect(() => {
    colSpanMap.forEach(item => {
      specialFieldListRef.current.push(item.mainField, ...item.subFields);
      colSpanMainFieldListRef.current.push(item.mainField);
    });

    const copyColumns = [].concat(columns);
    // 为跨越列的column添加自定义的headerClass，用于隐藏跨越列的右侧边框，并添加colId，用于在拖拽列宽结束后通过colId找到对应列的dom来动态修改列宽；
    copyColumns.forEach(column => {
      if (colSpanMainFieldListRef.current.includes(column.field)) {
        column.headerClass = `${specialHeaderClassRef.current} ${specialHeaderClassRef.current}-${column.field}`;
      } else if (column.children?.length > 0 && colSpanMainFieldListRef.current.includes(column.children[0].field)) {
        column.children[0].headerClass = `${specialHeaderClassRef.current} ${specialHeaderClassRef.current}-${column.children[0].field}`;
      }
    });

    setColumnDefs(copyColumns);

    return () => {
      specialFieldListRef.current = [];
      setColumnDefs([]);
    };
  }, [columns, colSpanMap]);

  /**
   * 每当全量数据变化时，重置翻页数据
   */
  useEffect(() => {
    if (data.length > 0) {
      setCurrentPage(1);
    }

    return () => {
      setCurrentPage(0);
    };
  }, [data]);

  return (
    <div style={{ width: '100%' }}>
      <div
        className="ag-theme-alpine column-group-table"
        style={{
          padding: 16,
          width: '100%',
          height: 'calc(100vh - 300px)', // 动态设置高度
          overflowY: 'auto', // 确保显示垂直滚动条
        }}
      >
        <AgGridReact
          columnDefs={columnDefs}
          onGridReady={onGridReady}
          // onFirstDataRendered={onFirstDataRendered}
          rowData={currentPageData}
          domLayout="normal"
          theme={AGGridTheme}
          headerHeight={40}
          rowHeight={40}
          rowSelection={{ mode: 'multiRow', enableClickSelection: true, checkboxes: false, headerCheckbox: false }}
          onSelectionChanged={onSelectedRowsChanged}
          onGridSizeChanged={onGridSizeChanged}
          onColumnResized={onColumnResized}
          enableCellSpan
          overlayNoRowsTemplate={tableEmptyText ?? '該当件数が０件でした。検索条件を変更してください。'}
          defaultColDef={{ sortable: false }}
        />
      </div>

      {!disabledPagination && currentPageData.length > 0 && (
        <Box display="flex" justifyContent="end" alignItems="center" mt={2}>
          <Box>
            <IconButton onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1}>
              <ArrowBackIosIcon fontSize="small" />
            </IconButton>
            {getPageButtons().map((item, index) =>
              item === 'ellipsis' ? (
                <Button key={index} disabled sx={{ pointerEvents: 'none', mx: 0.5 }} size="small">
                  ...
                </Button>
              ) : (
                <Button
                  key={index}
                  size="small"
                  onClick={() => onPageChange(item)}
                  variant={item === currentPage ? 'contained' : 'outlined'}
                  sx={{ mx: 0.5, padding: '4px 12px', minWidth: 10 }}
                >
                  {item}
                </Button>
              ),
            )}
            <IconButton onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages}>
              <ArrowForwardIosIcon fontSize="small" />
            </IconButton>
          </Box>
          <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <Select value={pageSize} onChange={onPageSizeChange}>
              <MenuItem value={10}>10件 / ページ</MenuItem>
              <MenuItem value={20}>20件 / ページ</MenuItem>
              <MenuItem value={50}>50件 / ページ</MenuItem>
              <MenuItem value={100}>100件 / ページ</MenuItem>
            </Select>
          </FormControl>
        </Box>
      )}
    </div>
  );
};

export default ColumnSpanningTable;
