import React from 'react';
import { IHeaderParams } from 'ag-grid-community';
import FilterListHeader, { FilterListHeaderProps } from './FilterListHeader';

// 注意：ag‑Grid 在传入 headerComponentParams 时，可以将其它参数一起传入
// 此处约定 headerComponentParams 包含 filterOptions 与 onGlobalFilterChanged 回调
interface CustomHeaderParams extends IHeaderParams, FilterListHeaderProps {
  filterOptions: string[];
  onGlobalFilterChanged: (selected: string[]) => void;
}

const FilterHeaderWrapper: React.FC<CustomHeaderParams> = props => {
  const { displayName, filterOptions, onGlobalFilterChanged } = props;
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <FilterListHeader title={displayName || ''} filterOptions={filterOptions} onFilterChanged={onGlobalFilterChanged} />
    </div>
  );
};

export default FilterHeaderWrapper;
