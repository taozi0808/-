import React, { useCallback } from 'react';

interface InputLabelCellRenderProps {
  params: any;
  disabled?: boolean | ((rowData: any, key: string) => boolean);
  onChange?: (key: string, value: Date | null, rowData: any) => void;
  keys?: string[];
  isLabel: boolean;
}

export const CustomInputLabelCellRender = (params: any) => {
  const rowData = params.data;
  const { onChange, disabled, keys, isLabel } = params;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
      {keys.map(key => {
        return <span key={key}>{rowData[key]}</span>;
      })}
    </div>
  );
};
