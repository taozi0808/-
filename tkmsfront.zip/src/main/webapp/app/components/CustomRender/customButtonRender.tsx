import React, { useCallback } from 'react';
import Button from '@mui/material/Button';

interface CustomButtonProps {
  params: any; // 現在の行のみを使用して、他の行はヘルプ理解です
  buttonName?: string | ((rowData: any) => string);
  buttonStyle?: React.CSSProperties;
  onButtonClick?: (rowData: any) => void;
  disabled?: boolean | ((rowData: any) => boolean);
}

export const CustomButtonRender = ({ params }: CustomButtonProps) => {
  const rowData = params.data;

  const isDisabled = typeof params.disabled === 'function' ? params.disabled(rowData) : params.disabled;

  const handleClick = useCallback(() => {
    if (params.onButtonClick) {
      params.onButtonClick(rowData);
    }
  }, [rowData, params.onButtonClick]);

  return (
    <Button
      variant="contained"
      size="small"
      onClick={handleClick}
      disabled={isDisabled}
      style={{
        minWidth: 80,
        padding: '4px 8px',
        ...params.buttonStyle,
      }}
    >
      {typeof params.buttonName === 'function' ? params.buttonName(rowData) : params.buttonName}
    </Button>
  );
};
