import { Box } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import React, { useCallback } from 'react';

interface DateCellRenderProps {
  params: any;
  disabled?: boolean | ((rowData: any, key: string) => boolean);
  onChange?: (key: string, value: Date | null, rowData: any) => void;
  keys?: string[];
}

export const CustomDateCellRender = ({ params }: DateCellRenderProps) => {
  const rowData = params.data;
  const field = params.colDef.field;
  const { onChange, disabled, keys } = params;

  const createDateHandler = (key: string) => {
    const handleChange = useCallback(
      (newValue: dayjs.Dayjs | null) => {
        const dateValue = newValue ? newValue.toDate() : null;
        const newData = {
          ...rowData,
          [key]: dateValue,
        };

        onChange?.(key, dateValue, newData);

        setTimeout(() => params.api.stopEditing(), 100);
      },
      [key],
    );

    return handleChange;
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
        {keys.map((key: string) => {
          const isKeyDisabled = typeof disabled === 'function' ? disabled(rowData, key) : disabled;

          return (
            <DatePicker
              key={key}
              value={dayjs(rowData[key])}
              onChange={createDateHandler(key)}
              disabled={isKeyDisabled}
              slots={{
                openPickerIcon: CustomCalendarIcon,
              }}
              slotProps={{
                textField: {
                  variant: 'outlined',
                  size: 'small',
                  fullWidth: true,
                  InputProps: {
                    sx: {
                      '& input': {
                        fontSize: '0.875rem',
                      },
                    },
                  },
                },
                popper: {
                  placement: 'bottom-start',
                  modifiers: [{ name: 'flip', enabled: false }],
                  sx: { zIndex: 9999 },
                },
              }}
            />
          );
        })}
      </Box>
    </LocalizationProvider>
  );
};

/* eslint-disable*/
const CustomCalendarIcon = () => (
  <svg
    className="icon"
    viewBox="0 0 1024 1024"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
  >
    <path
      d="M910.5 846.2H175.2c-27.4 0-49.6-22.3-49.6-49.6V301.1c0-27.4 22.3-49.6 49.6-49.6h735.3c27.4 0 49.6 22.3 49.6 49.6v495.5c0 27.3-22.3 49.6-49.6 49.6z"
      fill="#A7B8C6"
      p-id="5516"
    ></path>
    <path d="M862.3 191.3H127.1c-27.4 0-49.6 22.3-49.6 49.6v138.2H912V241c0-27.4-22.3-49.7-49.7-49.7z" fill="#E46160" p-id="5517"></path>
    <path d="M77.5 379.1H912v203.5H77.5z" fill="#E2E3E5" p-id="5518"></path>
    <path d="M127.1 786.1h735.3c27.4 0 49.6-22.3 49.6-49.6V573.6H77.5v162.9c0 27.3 22.2 49.6 49.6 49.6z" fill="#F7F7F7" p-id="5519"></path>
    <path
      d="M862.3 743.9H127.1c-27.4 0-49.6-22.3-49.6-49.6v42.1c0 27.4 22.3 49.6 49.6 49.6h735.3c27.4 0 49.6-22.3 49.6-49.6v-42.1c0 27.4-22.3 49.6-49.7 49.6z"
      fill="#E2E3E5"
      p-id="5520"
    ></path>
    <path
      d="M862.3 799.6H127.1c-34.8 0-63.2-28.3-63.2-63.2V241c0-34.8 28.3-63.2 63.2-63.2h735.3c34.8 0 63.2 28.3 63.2 63.2v495.5c-0.1 34.8-28.4 63.1-63.3 63.1zM127.1 204.9c-19.9 0-36.1 16.2-36.1 36.1v495.5c0 19.9 16.2 36.1 36.1 36.1h735.3c19.9 0 36.1-16.2 36.1-36.1V241c0-19.9-16.2-36.1-36.1-36.1H127.1z"
      fill="#3E3A39"
      p-id="5521"
    ></path>
    <path
      d="M484.9 246.1v90.7H477v-6.3h-72.8v6.3h-7.9v-90.7h88.6z m-80.7 77.5H477v-18.8h-18.1c-6.9 0-10.4-3.3-10.4-10v-41.6h-15.8v23.2c-0.3 15.2-6.6 26.4-18.8 33.5l-6.4-5.6c11.5-5.8 17.3-15.1 17.5-27.8v-23.2h-20.8v70.3z m52-70.4V293c0 3 1.6 4.4 4.8 4.4h16v-44.3h-20.8zM528.2 304c-1.3 14.1-5.5 25.7-12.5 34.9l-6-5.4c7.1-9.7 10.7-22 10.9-37v-52.8h62v84.7c0 6.2-3.1 9.3-9.2 9.3h-14l-2.2-7.7c6.6 0.3 11.2 0.4 13.6 0.4 2.5 0 3.8-1.6 3.8-4.8V304h-46.4z m46.6-34v-19h-46.2v19h46.2z m-46.2 7.2v19.5h46.2v-19.5h-46.2z"
      fill="#FFFFFF"
      p-id="5522"
    ></path>
    <path
      d="M428.3 441.5v214.6h-35.2V483.8c-13 11.8-29.4 20.5-49 26.2v-34.9c9.4-2.4 19.7-6.6 31-12.6 10.6-6.4 19.5-13.4 26.8-21h26.4zM642.6 465.5c13.8 18.6 20.7 44.4 20.7 77.2 0 34.7-7.3 63-21.9 85.1-14.6 21.6-34.4 32.5-59.2 32.5-42.3 0-66-19.5-71.2-58.6h34.3c4.2 19.8 16.6 29.8 37.3 29.8 14 0 25.4-7 34.3-21 8.2-13.4 12.3-30 12.3-49.6v-2.7h-1.5c-6.4 8.8-13.9 15.3-22.5 19.5-8.6 4-18.2 6-28.9 6-21.2 0-38.2-6.9-50.8-20.7-12.4-13-18.6-30.2-18.6-51.4 0-21.6 7.2-39.4 21.6-53.2 14.2-14 32.3-21 54.1-21 26.1-0.2 46.2 9.3 60 28.1zM553 479c-7.6 8.2-11.4 19-11.4 32.5 0 13.4 3.8 23.9 11.4 31.6 7.4 8 17.6 12 30.7 12 12.8 0 23-4 30.7-12 7.4-8.4 11.1-19.3 11.1-32.8 0-13.6-3.9-24.3-11.7-32.2s-17.8-11.7-30.1-11.7c-12.6 0-22.9 4.2-30.7 12.6z"
      fill="#595757"
      p-id="5523"
    ></path>
  </svg>
);
